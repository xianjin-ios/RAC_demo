//
//  BaseVCWithPay.h
//  GGSH
//
//  Created by yanli on 16/10/25.
//  Copyright © 2016年 YL. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseVCWithPay : BaseViewController

//微信支付接口
- (void)payOnlineByWX : (NSDictionary *)infoDic withBrandCode:(NSString *)brandCode;



//服务器交易从星空返回失败，未发器微信交易。客户端显示处理，多态
- (void)payWXFail;

//调起微信支付,从星空平台获取交易数据，然后从微信交易平台交易 ECP订单
- (void)payEcpWXWith : (NSDictionary *) detailDic;
//调起微信支付 - 非ecp订单
- (void)payWXWith:(NSDictionary *)resultDic;

//调起微信支付(话费支付 支付宝、银联)
- (void)payEcpWith : (NSDictionary *)resultDic;

//返回首页
- (void)backToHome;
@end
