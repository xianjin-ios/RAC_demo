//
//  TabBarViewController.m
//  GGSH_Refactoring
//
//  Created by huadong on 16/9/14.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "TabBarViewController.h"
#import "MainViewController.h"
#import "MyAttentionViewController.h"
#import "NewLifeViewController.h"
#import "MyViewController.h"
#import "LoginVC.h"


#define UIColorFromRGB(rgbValue) \
[UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0x00FF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0x0000FF))/255.0 \
alpha:1.0]

@interface TabBarViewController ()<UITabBarDelegate,loginDelegate>

@property (nonatomic,strong)UIImageView *selectImage;

@end

@implementation TabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //改变tabbar背景颜色
    CGRect frame = CGRectMake(0, 0, SCREEN_WIDTH, 49);
    UIView *v = [[UIView alloc] initWithFrame:frame];
    UIImage *img = [UIImage imageNamed:@"app_nav64.png"];
    UIColor *color = [[UIColor alloc] initWithPatternImage:img];
    v.backgroundColor = color;
    self.selectImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
    self.selectImage.image = [UIImage imageNamed:@"tabbar_select.png"];
    [self.tabBar addSubview:self.selectImage];
    [self.tabBar insertSubview:v atIndex:0];
    self.tabBar.opaque = YES;
    self.tabBar.delegate = self;
    [self setUpTabBar];
    
}

- (void)setUpTabBar{
    
    if (self.rootBar == nil) {
        UIColor *itemSelTextColor = [UIColor whiteColor];
        UIColor *itemNormalTextColor = [UIColor whiteColor];
        
        NSMutableArray *itemArray = [[NSMutableArray alloc] init];
        UmTabBarItem *item1 = [[UmTabBarItem alloc] init];
        [item1 setBackgroundImage:nil  forState:YES];//选中时
        [item1 setForegroundImage:[UIImage imageNamed:@"tabbar_02.png"] forState:NO];
        [item1 setForegroundImage:[UIImage imageNamed:@"tabbar_02.png"] forState:YES];//选中时
        [item1 setTitle:@"首页" withSize:12*MyAppDelegate.autoSizeScaleFont];
        [item1 setTitleColor:itemSelTextColor forStatle:YES];
        [item1 setTitleColor:itemNormalTextColor forStatle:NO];
        [itemArray addObject:item1];
        
        UmTabBarItem *item2 = [[UmTabBarItem alloc] init];
        [item2 setBackgroundImage:nil forState:YES];
        [item2 setForegroundImage:[UIImage imageNamed:@"tabbar_01.png"]  forState:NO];
        [item2 setForegroundImage:[UIImage imageNamed:@"tabbar_01.png"]  forState:YES];
        [item2 setTitle:@"我的关注" withSize:12*MyAppDelegate.autoSizeScaleFont];
        [item2 setTitleColor:itemSelTextColor forStatle:YES];
        [item2 setTitleColor:itemNormalTextColor forStatle:NO];
        [itemArray addObject:item2];
        
        UmTabBarItem *item3 = [[UmTabBarItem alloc] init];
        [item3 setBackgroundImage:nil  forState:YES];
        [item3 setForegroundImage:[UIImage imageNamed:@"tabbar_03.png"] forState:NO];
        [item3 setForegroundImage:[UIImage imageNamed:@"tabbar_03.png"] forState:YES];
        [item3 setTitle:@"生活服务" withSize:12*MyAppDelegate.autoSizeScaleFont];
        [item3 setTitleColor:itemSelTextColor forStatle:YES];
        [item3 setTitleColor:itemNormalTextColor forStatle:NO];
        [itemArray addObject:item3];
        
        UmTabBarItem *item4 = [[UmTabBarItem alloc] init];
        [item4 setBackgroundImage:nil forState:YES];
        [item4 setForegroundImage:[UIImage imageNamed:@"tabbar_04.png"] forState:NO];
        [item4 setForegroundImage:[UIImage imageNamed:@"tabbar_04.png"] forState:YES];
        [item4 setTitle:@"我的" withSize:12*MyAppDelegate.autoSizeScaleFont];
        [item4 setTitleColor:itemSelTextColor forStatle:YES];
        [item4 setTitleColor:itemNormalTextColor forStatle:NO];
        [itemArray addObject:item4];
        
        static float tabBarHeight = 49.0f;
        UmTabBar *tabBar = [[UmTabBar alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, tabBarHeight) tabBarItems:itemArray layoutStyle:UmTabBarLayoutStyle_fixedItemWidth];
        [tabBar setBackgroundImage:nil];
        self.rootBar = tabBar;
        
    }
    
    if ( [self.viewControllers count] == 0 ) {
        
        //首页
        MainViewController *ctrl1 = [[MainViewController alloc] init];
        UINavigationController * navi1 = [[UINavigationController alloc] initWithRootViewController:ctrl1];
        
        //我的关注
        MyAttentionViewController * ctrl2 = [[MyAttentionViewController alloc] init];
        UINavigationController * navi2 = [[UINavigationController alloc] initWithRootViewController:ctrl2];
        
        
        //生活服务
        NewLifeViewController *ctrl3 = [[NewLifeViewController alloc]init];
        UINavigationController * navi3 = [[UINavigationController alloc] initWithRootViewController:ctrl3];
        
        //我的
        MyViewController *ctrl4 = [[MyViewController alloc]init];
        UINavigationController * navi4 = [[UINavigationController alloc] initWithRootViewController:ctrl4];
        
        self.viewControllers = [NSArray arrayWithObjects:
                                navi1,
                                navi2,
                                navi3,
                                navi4,
                                nil];
    }
    
    self.tabBar.tintColor = [UIColor clearColor];
    
    _rootBar.delegate = self;
    
    [self.tabBar addSubview:_rootBar];
    
    [self.tabBar setBackgroundColor:[UIColor darkGrayColor]];
    
    [self selectItem:0];
    
}
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    if (viewController == [self.viewControllers objectAtIndex:self.viewControllers.count - 1]) {
        if (!MyAppDelegate.userInfo) {
            LoginVC *loginV = [[LoginVC alloc]init];
            loginV.delegate = self;
            UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
            [self presentViewController:navi6 animated:YES completion:nil];
            return NO;
            
            
        }else{
            [UIView beginAnimations:nil context:nil];
            [self.selectImage setFrame:CGRectMake(SCREEN_WIDTH/4*(self.viewControllers.count - 1), 0, SCREEN_WIDTH/4, 49)];
            [UIView commitAnimations];
            
            return YES;
        }
        
    }else if (viewController == [self.viewControllers objectAtIndex:self.viewControllers.count - 2]){
        if (!MyAppDelegate.userInfo) {
            LoginVC *loginV = [[LoginVC alloc]init];
            loginV.delegate = self;
            UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
            [self presentViewController:navi6 animated:YES completion:nil];
            return NO;
            
        }else{
        
            [UIView beginAnimations:nil context:nil];
            [self.selectImage setFrame:CGRectMake(SCREEN_WIDTH/4*(self.viewControllers.count - 2), 0, SCREEN_WIDTH/4, 49)];
            [UIView commitAnimations];
            
            return YES;
        }
    }else if (viewController == [self.viewControllers objectAtIndex:self.viewControllers.count - 3]){
        if (!MyAppDelegate.userInfo) {
            LoginVC *loginV = [[LoginVC alloc]init];
            loginV.delegate = self;
            UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
            [self presentViewController:navi6 animated:YES completion:nil];
            return NO;
        }else{
        
            [UIView beginAnimations:nil context:nil];
            [self.selectImage setFrame:CGRectMake(SCREEN_WIDTH/4*(self.viewControllers.count - 3), 0, SCREEN_WIDTH/4, 49)];
            [UIView commitAnimations];
            
            return YES;
        }
    }else if (viewController == [self.viewControllers objectAtIndex:self.viewControllers.count - 4]){
        
        [UIView beginAnimations:nil context:nil];
        [self.selectImage setFrame:CGRectMake(SCREEN_WIDTH/4*(self.viewControllers.count - 4), 0, SCREEN_WIDTH/4, 49)];
        [UIView commitAnimations];
        
        return YES;
    }else
        return YES;

    
    return YES;
}
- (void)selectItem:(int)itemIdx
{
    _rootBar.selectedItem = itemIdx;
    self.selectedIndex = itemIdx;
    
}

-(void)umTabBar:(UmTabBar *)tabBar selectedItem:(int)itemIdx{
    
    self.selectedIndex = itemIdx;
    
}

@end
