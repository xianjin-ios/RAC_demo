//
//  confirmAddressCellVC.m
//  GGSH
//
//  Created by siqiyang on 15/9/18.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "confirmAddressCellVC.h"
#import "NSString+Height.h"

@interface confirmAddressCellVC ()

@end

@implementation confirmAddressCellVC

- (void)viewDidLoad {
    [super viewDidLoad];

    

}

+(double)getHeight:(NSMutableDictionary *) dicInfo withType:(int)type{
    
    ZLog(@"%@==%d",dicInfo,type);
    
    double height = 0;
    if (dicInfo == nil) {
        height = 10;
    }else{
        CGSize size;
        NSString *aString = [dicInfo objectForKey:@"address"];
        UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];

        size = [NSString getHeight:aString withFont:nameFont andWidth:SCREEN_WIDTH - 110 - 20];
        
        height = size.height;
    }
    
    return 30 + height;
}


-(void)loadData:(NSDictionary *)dicInfo withType:(int)type{
    if (type == 1) {
        _title1.text = @"订购人";
        _title2.text = @"取货地址";

        _lbNameAndContact.text = [dicInfo objectForKey:@"contact"];
        
        NSString *addressStr = [dicInfo objectForKey:@"address"];
        CGSize size;
        NSString *aString = [dicInfo objectForKey:@"address"];
        UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
        
        size = [NSString getHeight:aString withFont:nameFont andWidth:SCREEN_WIDTH - 110 - 20];
        
        [_lbAddress setFrame:CGRectMake(110, 30, SCREEN_WIDTH - 110 - 20, size.height)];
        _lbAddress.text = addressStr;
        [_lbAddress sizeToFit];
        
    }else if (type == 2){
        _title1.text = @"收货信息";
        _title2.text = @"";
        
        if (dicInfo == nil) {
            _lbNameAndContact.text = @"请填写收货信息";
            _lbAddress.text = @"";
             [_lbAddress setFrame:CGRectMake(110, 30, SCREEN_WIDTH - 110 - 20, 0)];
        }else{
            NSString *nameStr = [NSString stringWithFormat:@"%@  %@",[dicInfo objectForKey:@"acceptname"],[dicInfo objectForKey:@"contact"]];
            _lbNameAndContact.text = nameStr;
            
            NSString *addressStr = [dicInfo objectForKey:@"address"];
            CGSize size;
            NSString *aString = [dicInfo objectForKey:@"address"];
            UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
            
            size = [NSString getHeight:aString withFont:nameFont andWidth:SCREEN_WIDTH - 110 - 20];
            
            [_lbAddress setFrame:CGRectMake(110, 30, SCREEN_WIDTH - 110 - 20, size.height)];
            _lbAddress.text = addressStr;
            [_lbAddress sizeToFit];

        }
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
