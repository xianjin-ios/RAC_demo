//
//  confirmAddressCellVC.h
//  GGSH
//
//  Created by siqiyang on 15/9/18.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NSString+Height.h"

@interface confirmAddressCellVC : UIViewController
{
    IBOutlet UILabel *_title1;
    IBOutlet UILabel *_title2;
    
    IBOutlet UILabel *_lbNameAndContact;
    
    IBOutlet UILabel *_lbAddress;
    
    
}

@property (nonatomic, strong) UINavigationController * navigationController;

@property (nonatomic,assign) BOOL isShouHuo;

+(double)getHeight:(NSDictionary *) dicInfo withType:(int)type;
-(void)loadData:(NSDictionary *)dicInfo withType:(int)type;

@end
