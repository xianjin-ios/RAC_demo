//
//  TabBarController.m
//  Toptaste
//
//  Created by siqiyang on 16/6/17.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "TabBarController.h"
#import "MainViewController.h"
#import "MyAttentionViewController.h"
#import "NewLifeViewController.h"
#import "MyViewController.h"
#import "MyNavigationViewController.h"
#import "chatVC.h"
#import "MessageDetailVC.h"

@interface TabBarController ()<UITabBarControllerDelegate>

@property (nonatomic,strong) UITabBar *mTanBar;

@end

@implementation TabBarController

- (void)viewDidLoad {
    [super viewDidLoad];

    CGRect frame = CGRectMake(0, 0, SCREEN_WIDTH, 49);
    UIView *v = [[UIView alloc] initWithFrame:frame];
    UIImage *img = [UIImage imageNamed:@"app_nav64.png"];
    UIColor *color = [[UIColor alloc] initWithPatternImage:img];
    v.backgroundColor = color;
    self.selectImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
    self.selectImage.image = [UIImage imageNamed:@"tabbar_select.png"];
    [self.tabBar addSubview:self.selectImage];
    [self.tabBar insertSubview:v atIndex:0];
    self.tabBar.opaque = YES;
    self.delegate = self;
    [self setupItemTitleTextAttributes];
    
    [self setupChildViewControllers];
    
    
}
/**
 *  设置所有UITabBarItem的文字属性
 */
- (void)setupItemTitleTextAttributes
{
    UITabBarItem *item = [UITabBarItem appearance];
    
    // 普通状态下的文字属性
    NSMutableDictionary *normalAttrs = [NSMutableDictionary dictionary];
    normalAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:11];
    normalAttrs[NSForegroundColorAttributeName] = [UIColor whiteColor];
    [item setTitleTextAttributes:normalAttrs forState:UIControlStateNormal];
    // 选中状态下的文字属性
    NSMutableDictionary *selectedAttrs = [NSMutableDictionary dictionary];
    selectedAttrs[NSForegroundColorAttributeName] = [UIColor whiteColor];
    selectedAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:11];
    [item setTitleTextAttributes:selectedAttrs forState:UIControlStateSelected];
    
}
/**
 *  添加子控制器
 */
- (void)setupChildViewControllers{
    MainViewController *mainVC = [[MainViewController alloc] init];
    [mainVC setHideBackButton:YES];
    MyNavigationViewController *con = [[MyNavigationViewController alloc] initWithRootViewController:mainVC];
    
    [self setupOneChildViewController:con title:@"首页" image:@"tabbar_02" selectedImage:@"tabbar_02"];
    
    MyAttentionViewController *attentionVC = [[MyAttentionViewController alloc] init];
    [attentionVC setHideBackButton:YES];
    [self setupOneChildViewController:[[MyNavigationViewController alloc] initWithRootViewController:attentionVC] title:@"我的关注" image:@"tabbar_01" selectedImage:@"tabbar_01"];
    
    NewLifeViewController *newLifeVC = [[NewLifeViewController alloc] init];
    [newLifeVC setHideBackButton:YES];
    [self setupOneChildViewController:[[MyNavigationViewController alloc] initWithRootViewController:newLifeVC] title:@"生活服务" image:@"tabbar_03" selectedImage:@"tabbar_03"];
    
    MyViewController *myVC = [[MyViewController alloc] init];
    [myVC setHideBackButton:YES];
    [self setupOneChildViewController:[[MyNavigationViewController alloc] initWithRootViewController:myVC] title:@"我的" image:@"tabbar_04" selectedImage:@"tabbar_04"];
}
/**
 *  初始化一个子控制器
 *
 *  @param vc            子控制器
 *  @param title         标题
 *  @param image         图标
 *  @param selectedImage 选中的图标
 */
- (void)setupOneChildViewController:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    
    vc.tabBarItem.title = title;
    if (image.length) { // 图片名有具体值
      
        vc.tabBarItem.image = [[UIImage imageNamed:image]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
        vc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    }
    [self addChildViewController:vc];
}
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{

    [UIView beginAnimations:nil context:nil];
    [self.selectImage setFrame:CGRectMake(SCREEN_WIDTH/4*(tabBarController.selectedIndex), 0, SCREEN_WIDTH/4, 49)];
    [UIView commitAnimations];
    return YES;
}
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
    [UIView beginAnimations:nil context:nil];
    [self.selectImage setFrame:CGRectMake(SCREEN_WIDTH/4*(tabBarController.selectedIndex), 0, SCREEN_WIDTH/4, 49)];
    [UIView commitAnimations];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)getPushDic:(NSDictionary *)pushDic AndType:(NSString *)type{
    [[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(gotoPushView:) object:pushDic];
    [self performSelector:@selector(gotoPushView:) withObject:pushDic afterDelay:0.2f];
}

#pragma mark - 接收通知跳转界面
- (void)gotoPushView:(NSDictionary *)sender{
    NSDictionary *pushDic = sender;
    NSString *type = pushDic[@"type"];
    if (self.navigationController.viewControllers.count > 1) {
        [self.navigationController popToRootViewControllerAnimated:NO];
    }
    ZLog(@"push type value is:%@",type);
    
    UINavigationController *vc = (UINavigationController*)[self.viewControllers objectAtIndex:self.selectedIndex];
    if ([type isEqualToString:@"11"]) {
        //店铺名称：通知标题 跳转页面：店铺聊天页
        NSDictionary * dicInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                                  pushDic[@"shopname"],@"shopname",
                                  pushDic[@"shopid"],@"shopid",
                                  nil];
        chatVC * ctrl = [[chatVC alloc] init];
        ctrl.dicChatInfo = dicInfo;
        [vc pushViewController:ctrl animated:YES];
        
    }else if ([type isEqualToString:@"16"]){
        //店铺名称：消息内容 跳转页面：店铺通知详情页
        MessageDetailVC *ctrl = [[MessageDetailVC alloc]init];
        ctrl.shopid = pushDic[@"id"];
        [vc pushViewController:ctrl animated:YES];
        
    }else if ([type isEqualToString:@"41"]){
#warning 缺少优惠页面
        //接收优惠券 跳转页面：我的卡券（可用优惠券列表）
//        youhuiViewController *ctrl = [[youhuiViewController alloc]init];
//        ctrl.flag = 1;
//        [vc pushViewController:ctrl animated:YES];
        
    }else if ([type isEqualToString:@"42"]){
#warning 缺少优惠页面
        //优惠券被使用 ?跳转页面：我的卡券（已失效卡券列表）
        //优惠券转赠后被领取?跳转页面：我的卡券（已失效卡券列表）
//        youhuiViewController *ctrl = [[youhuiViewController alloc]init];
//        ctrl.flag = 2;
//        [vc pushViewController:ctrl animated:YES];
        
    }else if ([type isEqualToString:@"43"]){
        //卡密页面
        ZLog(@"push get in 卡密 VC");
#warning 缺少
//        cardVC *ctrl = [[cardVC alloc]init];
//        [vc pushViewController:ctrl animated:YES];
        
    }
    else if ([type isEqualToString:@"17"]){
        NSDictionary *dic = pushDic[@"custom_content"];
        //逛逛优惠券界面
#warning 缺少
//        GGCouponDetailViewController *couponListVC = [[GGCouponDetailViewController alloc]init];
//        couponListVC.couponId =  [dic objectForKey:@"id"] ;//couponId
//        [vc pushViewController:couponListVC animated:YES];
    }
}

@end
