//
//  UmTabBarItem.m
//  LifeSearch
//
//  Created by kekey on 11-11-16.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "UmTabBarItem.h"
#import <QuartzCore/QuartzCore.h>

@interface UmTabBarItem()
@property(nonatomic,retain)UIImageView *backgroundImageView, *foregroundImageView;
@property(nonatomic,retain)UILabel *titleLabel;
@property(nonatomic,retain)UIImage *normalBgImage, *selectedBgImage;
@property(nonatomic,retain)UIImage *normalFgImage, *selectedFgImage;
@end


@implementation UmTabBarItem
@synthesize backgroundImageView,foregroundImageView;
@synthesize selected;
@synthesize titleLabel;
@synthesize normalBgImage, selectedBgImage;
@synthesize normalFgImage, selectedFgImage;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)init
{
    self = [super init];
    if ( self ) {
        backgroundImageView = [[UIImageView alloc] init];
        foregroundImageView = [[UIImageView alloc] init];
        titleLabel = [[UILabel alloc] init];
        
        foregroundImageView.contentMode = UIViewContentModeCenter;
        
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.textAlignment = 1;
        titleLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
        titleLabel.font = [UIFont systemFontOfSize:15];
        
        [self addSubview:backgroundImageView];
        [self addSubview:foregroundImageView];
        [self addSubview:titleLabel];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    
    backgroundImageView.frame = self.bounds;
    float labelHeight = 12;
    foregroundImageView.frame = CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height-labelHeight);
//    titleLabel.frame = CGRectMake(0, self.bounds.size.height-labelHeight, self.bounds.size.width, labelHeight);
    
    titleLabel.frame = CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height);
}

- (void)updateState
{
    if ( selected ) {
        self.backgroundImageView.image = selectedBgImage;
        self.foregroundImageView.image = selectedFgImage;
        
    }
    else{
        self.backgroundImageView.image = normalBgImage;
        self.foregroundImageView.image = normalFgImage;
        
    }
    
    [titleLabel setHighlighted:selected];
}

- (void)setBackgroundImage:(UIImage *)bgImage forState:(BOOL)_selected
{
    if ( _selected ) {
        self.selectedBgImage = bgImage;
    }
    else{
        self.normalBgImage = bgImage;
    }
    
    [self updateState];
}

- (void)setForegroundImage:(UIImage *)fgImage forState:(BOOL)_selected
{
    if ( _selected ) {
        self.selectedFgImage = fgImage;
    }
    else{
        self.normalFgImage = fgImage;
    }
    
    [self updateState];
}

- (void)setTitle:(NSString*)title withSize:(CGFloat)size
{
    titleLabel.text = title;
    titleLabel.font = [UIFont systemFontOfSize:size];
}

- (void)setTitleColor:(UIColor*)color forStatle:(BOOL)_selected
{
    if ( _selected ) {
        [titleLabel setHighlightedTextColor:color];
    }
    else{
        [titleLabel setTextColor:color];
    }
}


-(void)setSelected:(BOOL)_selected
{
    if ( selected != _selected ) {
        selected = _selected;
        [self updateState];
    }
}


@end
