//
//  UIImage+FixRotation.h
//  WooLaLa
//
//  Created by Gemeng Qin on 15/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIImage(fixOrientation)

- (UIImage *)fixOrientation;

@end
