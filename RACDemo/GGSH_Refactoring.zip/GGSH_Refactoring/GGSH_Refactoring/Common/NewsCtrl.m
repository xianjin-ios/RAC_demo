//
//  NewsCtrl.m
//  news_test
//
//  Created by huadong on 16/10/17.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "NewsCtrl.h"
#import <XKImageControl/XKImageControl.h>
//#import "UIImageView+WebCache.h"

@interface NewsCtrl ()<UIScrollViewDelegate>
{
    UIScrollView *_scrollView;
    UIPageControl *_pageControl;
    
    NSMutableArray *_newsArray;
    
    CGRect _rect;
    
    NSInteger currentIndex;
    
    NSTimer *_timer;
}

@end

@implementation NewsCtrl

- (NewsCtrl *)initWithFrame:(CGRect)rect{
    self = [super init];
    if (self) {
        //
        _rect = rect;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self setNewsView];
    
}

- (void)setNewsView{
    [self.view setFrame:_rect];
    
    _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, _rect.size.width, _rect.size.height)];
    _scrollView.delegate = self;
    _scrollView.bounces = YES;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.pagingEnabled = YES;
    [self.view addSubview:_scrollView];

    [_scrollView setContentSize:CGSizeMake(_rect.size.width * 3, _rect.size.height)];
    
    _pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(0, _rect.size.height - 25, _rect.size.width, 20)];
    _pageControl.enabled = NO;
    [self.view addSubview:_pageControl];
    
    CGFloat width = 0;
    for (int i = 0; i < 3; i ++) {
        UIImageView *imageview = [[UIImageView alloc]initWithFrame:CGRectMake(width, 0, _rect.size.width, _rect.size.height)];
        [imageview setBackgroundColor:[UIColor clearColor]];
        [imageview setTag:2000+i];
        [imageview setUserInteractionEnabled:YES];
        [_scrollView addSubview:imageview];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setFrame:CGRectMake(0, 0, imageview.frame.size.width, imageview.frame.size.height)];
        [btn addTarget:self action:@selector(doSelect:) forControlEvents:UIControlEventTouchUpInside];
        [imageview addSubview:btn];
        
        width += _rect.size.width;
    }
    
}

- (void)setNewsArray:(NSArray *)array{
    if (_newsArray && _newsArray.count != 0) {
        [_newsArray removeAllObjects];
    }
    _newsArray = [NSMutableArray arrayWithArray:array];
    
    _pageControl.numberOfPages = _newsArray.count;
    _pageControl.currentPage = 0;
    
    currentIndex = 0;
    
    //加载imageview
    [self reloadImageViewData];
    
    [self setUpTimer];
    
}

- (void)setUpTimer{
    if (_timer) {
        [_timer invalidate];
    }
    _timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(scrollPages) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop]addTimer:_timer forMode:NSRunLoopCommonModes];
}

- (void)removeTimer{
    [_timer invalidate];
}

- (void)scrollPages{
    currentIndex ++;
    if (currentIndex == _newsArray.count) {
        currentIndex = 0;
    }
    _pageControl.currentPage = currentIndex;
    
    [_scrollView setContentOffset:CGPointMake(_rect.size.width*2, 0) animated:YES];
    [self performSelector:@selector(reloadImageViewData) withObject:nil afterDelay:0.2f];
    
}

- (void)reloadImageViewData{
    UIImageView *leftImage = (UIImageView *)[self.view viewWithTag:2000];
    UIImageView *currentImage = (UIImageView *)[self.view viewWithTag:2001];
    UIImageView *rightImage = (UIImageView *)[self.view viewWithTag:2002];
    
    NSInteger leftIndex = 0;
    NSInteger rightIndex = 0;
    if (currentIndex == 0) {
        leftIndex = _newsArray.count - 1;
        rightIndex = currentIndex + 1;
    }else if (currentIndex == _newsArray.count-1){
        leftIndex = currentIndex - 1;
        rightIndex = 0;
    }else{
        leftIndex = currentIndex - 1;
        rightIndex = currentIndex + 1;
    }
    
    NSDictionary *leftDic = _newsArray[leftIndex];
    NSDictionary *currentDic = _newsArray[currentIndex];
    NSDictionary *rightDic = _newsArray[rightIndex];
    
    //
    [leftImage XK_setImageWithURL:[NSURL URLWithString:[leftDic objectForKey:_urlString]] placeholderImage:nil];
    [currentImage  XK_setImageWithURL:[NSURL URLWithString:[currentDic objectForKey:_urlString]] placeholderImage:nil];
    [rightImage XK_setImageWithURL:[NSURL URLWithString:[rightDic objectForKey:_urlString]] placeholderImage:nil];
    
    //显示中间的iamgeview
    [_scrollView setContentOffset:CGPointMake(_rect.size.width, 0) animated:NO];
}

- (void)doSelect:(UIButton *)sender{
    NSLog(@"select index :%ld \n select :%@",currentIndex,_newsArray[currentIndex]);
    if ([self.delegate respondsToSelector:@selector(newsSelect:)]) {
        [self.delegate newsSelect:currentIndex];
    }
}

#pragma mark 
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self removeTimer];
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    [self setUpTimer];
    
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    [self updatePageControl];

}

- (void)updatePageControl{
    
    if (_scrollView.contentOffset.x > _rect.size.width) {
        currentIndex ++;
        if (currentIndex == _newsArray.count) {
            currentIndex = 0;
        }
    }else if (_scrollView.contentOffset.x < _rect.size.width){
        currentIndex --;
        if (currentIndex < 0) {
            currentIndex = _newsArray.count - 1;
        }
    }else{
        
    }
    
    _pageControl.currentPage = currentIndex;
    
    [self performSelectorOnMainThread:@selector(reloadImageViewData) withObject:nil waitUntilDone:YES];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
