//
//  LineView.m
//  GGSH
//
//  Created by STAR on 15/7/17.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "LineView.h"

@implementation LineView


- (void)drawRect:(CGRect)rect {
    //获得处理的上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    //设置线条样式
    CGContextSetLineCap(context, kCGLineCapSquare);
    //设置线条粗细宽度
    CGContextSetLineWidth(context, ONEPIXL);
    
    //设置颜色
    CGContextSetRGBStrokeColor(context, 169/255.0, 169/255.0, 169/255.0, 1.0);
    //开始一个起始路径
    CGContextBeginPath(context);
    //起始点设置为(0,0):注意这是上下文对应区域中的相对坐标，
    CGContextMoveToPoint(context, 0, 0);
    //设置下一个坐标点
    CGContextAddLineToPoint(context, rect.size.width, 0);
    //连接上面定义的坐标点
    CGContextStrokePath(context);
}


@end
