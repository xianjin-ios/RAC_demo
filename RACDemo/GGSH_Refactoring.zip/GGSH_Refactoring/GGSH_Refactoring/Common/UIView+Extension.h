//
//  UIView+Extension.h
//  Toptaste
//
//  Created by 孟现进 on 16/4/17.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Extension)
@property (nonatomic, assign) CGSize  M_size;
@property (nonatomic, assign) CGFloat M_width;
@property (nonatomic, assign) CGFloat M_height;
@property (nonatomic, assign) CGFloat M_x;
@property (nonatomic, assign) CGFloat M_y;
@property (nonatomic, assign) CGFloat M_centerX;
@property (nonatomic, assign) CGFloat M_centerY;

@property (nonatomic, assign) CGFloat M_right;
@property (nonatomic, assign) CGFloat M_bottom;

@end
