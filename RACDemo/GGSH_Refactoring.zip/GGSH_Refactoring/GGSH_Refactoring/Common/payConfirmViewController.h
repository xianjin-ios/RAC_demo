//
//  payConfirmViewController.h
//  GGSH
//
//  Created by siqiyang on 15/7/7.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "BaseVCWithPay.h"
#import "UPPayPlugin.h"
#import "UPPayPluginDelegate.h"

@interface payConfirmViewController : BaseVCWithPay<UITableViewDataSource,UITableViewDelegate,UITextViewDelegate,UIAlertViewDelegate,UPPayPluginDelegate>
{
    IBOutlet UIScrollView *_scrollView;
    
    IBOutlet UITableView *_tableView;
    IBOutlet UILabel *lbTotal;
    IBOutlet UILabel *lbYufu;
    
}
@property (retain, nonatomic) IBOutlet UIButton *confirmBtn;

@property (nonatomic,assign) BOOL isFromCart;
@property (nonatomic,strong) NSDictionary *infoDict;

- (IBAction)confirm:(id)sender;

@end
