//
//  UmTabBarItem.h
//  LifeSearch
//
//  Created by kekey on 11-11-16.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UmTabBarItem : UIView {
    UIImageView *backgroundImageView;
    UIImage *normalBgImage;
    UIImage *selectedBgImage;
    
    UIImageView *foregroundImageView;
    UIImage *normalFgImage;
    UIImage *selectedFgImage;
    
    UILabel *titleLabel;
    
    BOOL selected;
}

@property(nonatomic,assign)BOOL selected;

- (void)setBackgroundImage:(UIImage *)bgImage forState:(BOOL)selected;
- (void)setForegroundImage:(UIImage *)fgImage forState:(BOOL)selected;
- (void)setTitle:(NSString*)title withSize:(CGFloat)size;
- (void)setTitleColor:(UIColor*)color forStatle:(BOOL)selected;

@end
