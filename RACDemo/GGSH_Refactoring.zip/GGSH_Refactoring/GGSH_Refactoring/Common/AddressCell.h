//
//  AddressCell.h
//  GGSH
//
//  Created by siqiyang on 15/9/9.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ADDRESS_DELEGATE <NSObject>

- (void)set:(NSInteger)index;
- (void)edit:(NSInteger)index;
- (void)del:(NSInteger)index;

@end
@interface AddressCell : UITableViewCell

@property (nonatomic,assign) id<ADDRESS_DELEGATE> delegate;
@property (nonatomic,assign) BOOL isFromMy;

@property (nonatomic,assign) NSInteger index;

@property (retain, nonatomic) IBOutlet UILabel *name;
@property (retain, nonatomic) IBOutlet UILabel *phone;
@property (retain, nonatomic) IBOutlet UILabel *address;
@property (retain, nonatomic) IBOutlet UILabel *addressCode;


@property (retain, nonatomic) IBOutlet UIImageView *selectIcon;
@property (retain, nonatomic) IBOutlet UILabel *selectLabel;
- (IBAction)select:(id)sender;

@property (retain, nonatomic) IBOutlet UIImageView *delOrEditIcon;
@property (retain, nonatomic) IBOutlet UILabel *delOrEdit;
- (IBAction)delOrEdit:(id)sender;

@end
