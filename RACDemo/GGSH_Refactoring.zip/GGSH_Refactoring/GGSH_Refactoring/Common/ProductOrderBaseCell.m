//
//  ProductOrderBaseCell.m
//  GGSH
//  订单的CELL
//  Created by 任春宁 on 15/7/3.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "ProductOrderBaseCell.h"

@implementation ProductOrderBaseCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

@end
