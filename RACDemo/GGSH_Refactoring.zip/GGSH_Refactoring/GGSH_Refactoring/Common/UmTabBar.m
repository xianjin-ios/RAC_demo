//
//  UmTabBar.m
//  LifeSearch
//
//  Created by kekey on 11-11-16.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "UmTabBar.h"
//#import "GlobalStyle.h"

@interface UmTabBar()
@property(nonatomic,retain)NSArray* tabBarItems;
@property(nonatomic,retain)UIImageView* backgroundView;
@end


@implementation UmTabBar
@synthesize selectedItem, delegate;
@synthesize tabBarItems, backgroundView;


- (id)initWithFrame:(CGRect)frame tabBarItems:(NSArray *)items layoutStyle:(UmTabBarLayoutStyle)style
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.tabBarItems = items;
        self.backgroundColor = [UIColor clearColor];
        
        layoutStyle = style;
        
        selectedItem = -1;
        
        if ( [items count] > 0 ) {
            CGRect itemFrame;
            float itemWidth = frame.size.width/[items count];
            if ( layoutStyle == UmTabBarLayoutStyle_fixedItemWidth ) {
                itemWidth = frame.size.width/4;
            }
            itemFrame.origin = CGPointMake(0, 0);
            itemFrame.size = CGSizeMake(itemWidth, frame.size.height);
            
            for ( UmTabBarItem* item in items ) {
                item.frame = itemFrame;
                item.contentMode = UIViewContentModeScaleAspectFit;
                [self addSubview:item];
                itemFrame = CGRectOffset(itemFrame, itemFrame.size.width, 0);
            }
        }
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
/*- (void)drawRect:(CGRect)rect
{
    
}*/


-(void)setBackgroundImage:(UIImage *)image
{
    UIImageView* imageView = [[UIImageView alloc] initWithFrame:self.bounds];
    imageView.image = image;
    
    [backgroundView removeFromSuperview];
    
    self.backgroundView = imageView;
    [self addSubview:backgroundView];
    [self sendSubviewToBack:backgroundView];
    
}

-(void)setSelectedItem:(int)newSelectedItem
{
    if ( selectedItem != newSelectedItem ) {
        selectedItem = newSelectedItem;
        for ( int i = 0; i < [tabBarItems count]; i++ ) {
            UmTabBarItem* item = (UmTabBarItem*)[tabBarItems objectAtIndex:i];
            item.selected = i==selectedItem ? YES:NO;
        }
    }
    
    if ( [delegate respondsToSelector:@selector(umTabBar:selectedItem:)] ) {
        [delegate umTabBar:self selectedItem:selectedItem];
    }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint pos;
    
    for ( int i = 0; i < [tabBarItems count]; i++ ) {
        UmTabBarItem *item = [tabBarItems objectAtIndex:i];
        pos = [touch locationInView:item];
        if ( [item pointInside:pos withEvent:event] ) {
            [self setSelectedItem:i];
        }
    }
}


@end
