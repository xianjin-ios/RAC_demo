//
//  AddressCell.m
//  GGSH
//
//  Created by siqiyang on 15/9/9.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "AddressCell.h"

@implementation AddressCell

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)select:(id)sender {
    
    ZLog(@"%ld",(long)self.index);
    [self.delegate set:self.index];
    
}

- (IBAction)delOrEdit:(id)sender {
    
    ZLog(@"%ld",(long)self.index);
    if (self.isFromMy) {
        [self.delegate del:self.index];
    }else{
        [self.delegate edit:self.index];
    }
    
}

@end
