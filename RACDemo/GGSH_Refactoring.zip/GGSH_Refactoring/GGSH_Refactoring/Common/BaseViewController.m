//
//  BaseViewController.m
//  Toptaste
//
//  Created by huadong on 16/6/17.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()
{
    
}
@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    UIImage *toolBarIMG;
    if ([[[UIDevice currentDevice]systemVersion] doubleValue]>=7.0) {
        toolBarIMG = [[UIImage imageNamed:@"app_nav64"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    }else{
        toolBarIMG = [[UIImage imageNamed: @"app_nav"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    }
    
    UIImage * backgroundImage = toolBarIMG;

    //加载导航条图片
    [self.navigationController.navigationBar setBackgroundImage:backgroundImage forBarMetrics:UIBarMetricsDefault];
    
    //隐藏back按钮的方法
    [self.navigationController.navigationItem setHidesBackButton:YES];
    
    UIButton *bb = [UIButton buttonWithType:UIButtonTypeCustom];
    bb.frame = CGRectMake(0, 0, 26* MyAppDelegate.autoSizeScaleFont, 26* MyAppDelegate.autoSizeScaleFont);
    [bb addTarget:self action:@selector(goBack:) forControlEvents:UIControlEventTouchDown];
    [bb setTitle:@"" forState:UIControlStateNormal];
    [bb setTitle:@"" forState:UIControlStateHighlighted];
    UIImageView *bbImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 7, 10* MyAppDelegate.autoSizeScaleFont, 15* MyAppDelegate.autoSizeScaleFont)];
    bbImage.image = [UIImage imageNamed:@"backBtn"];
    [bb setContentEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
    bb.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [bb addSubview:bbImage];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithCustomView:bb];
    backItem.tag = 2222;
    self.navigationItem.leftBarButtonItem = backItem;
    
    [self hideBackButton:_hideBackButton];
    
    //设置默认标题为白色，加粗字体
    NSDictionary *attDic = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName,[UIFont fontWithName:@"Helvetica-Bold" size:18],NSFontAttributeName,[UIColor whiteColor], NSForegroundColorAttributeName, nil];
    [self.navigationController.navigationBar setTitleTextAttributes:attDic];

    //点击收起键盘
    tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismissKeyboard)];
    tap.cancelsTouchesInView = YES;
    [self.view addGestureRecognizer:tap];
    
}

- (void)dismissKeyboard{
    [self.view endEditing:YES];
    
}

- (void)cancelTapHideKeyBoard:(BOOL)cancel{
    if (cancel) {
        [[self view] removeGestureRecognizer:tap];
    }else{
        if (tap) {
            tap = nil;
        }
        tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismissKeyboard)];
        tap.cancelsTouchesInView = YES;
        [self.view addGestureRecognizer:tap];
    }
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    //**************方法一****************//
    //设置滑动回退
    __weak typeof(self) weakSelf = self;
    self.navigationController.interactivePopGestureRecognizer.delegate = weakSelf;
    //判断是否为第一个view
    if (self.navigationController && [self.navigationController.viewControllers count] == 1) {
        self.navigationController.interactivePopGestureRecognizer.enabled = YES;
    }
    
}

#pragma mark- UIGestureRecognizerDelegate
//- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
//    if (self.navigationController && [self.navigationController.viewControllers count] == 1) {
//        return NO;
//    }
//    return YES;
//}

-(void)goBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)hideBackButton:(BOOL)hidden{
    
    UIBarButtonItem *backItem = self.navigationItem.leftBarButtonItem;
    if (backItem ==nil) {
        UIButton *bb = [UIButton buttonWithType:UIButtonTypeCustom];
        bb.frame = CGRectMake(-20, 0, 59, 44);
        [bb addTarget:self action:@selector(goBack:) forControlEvents:UIControlEventTouchDown];
        [bb setTitle:@"" forState:UIControlStateNormal];
        [bb setTitle:@"" forState:UIControlStateHighlighted];
        UIImageView *bbImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 7, 10, 15)];
        bbImage.image = [UIImage imageNamed:@"Top_back"];
        [bb setContentEdgeInsets:UIEdgeInsetsMake(0, -50, 0, 0)];
        bb.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [bb addSubview:bbImage];
        UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithCustomView:bb];
        backItem.tag = 2222;
        self.navigationItem.leftBarButtonItem = backItem;
    }
    
    backItem.customView.hidden = hidden;
    
    return;
}


- (void)showHUD{
    [[XKProgressHUD sharedProgressHUD]XK_showHUDAddedTo:self.view withHintTitle:@"正在加载中..." animated:YES];
}
- (void)hideHUD{
    [[XKProgressHUD sharedProgressHUD]XK_hideHUDForView:self.view animated:YES];
}

- (void)showAlert:(NSString *)message withTitle:(NSString *)title haveCancelButton:(BOOL)cancel{
    
    UIAlertView *alertV = [[UIAlertView alloc]initWithTitle:title message:message delegate:self cancelButtonTitle:cancel?@"cancel":nil otherButtonTitles:@"OK", nil];
    alertV.delegate = self;
    [alertV show];
    
}
- (void)showalertString:(NSString *)alertSting{
    CGRect rect = [alertSting boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 80, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:14],NSFontAttributeName, nil] context:nil];
    UIView *backView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - 50, rect.size.height + 30)];
    backView.backgroundColor = [UIColor lightGrayColor];
    backView.tag = 10086;
    backView.center = self.view.center;
    [self.view addSubview:backView];
    UILabel *titleLabe  = [[UILabel alloc]initWithFrame:CGRectMake(15, 15,SCREEN_WIDTH - 80, rect.size.height)];
    titleLabe.font = [UIFont systemFontOfSize:14];
    titleLabe.textColor = [UIColor whiteColor];
    titleLabe.textAlignment = NSTextAlignmentCenter;
    titleLabe.numberOfLines = 0;
    titleLabe.text = alertSting;
    [backView addSubview:titleLabe];
    [self performSelector:@selector(hideAlertView) withObject:nil afterDelay:2];
}
- (void)hideAlertView{
    UIView *backView = (UIView *)[self.view viewWithTag:10086];
    if (backView) {
        [backView removeFromSuperview];
        backView = nil;
    }
}

@end
