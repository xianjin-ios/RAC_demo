//
//  BaseVCWithPay.m
//  GGSH
//
//  Created by yanli on 16/10/24.
//  Copyright © 2016年 YL. All rights reserved.
//

#import "BaseVCWithPay.h"
#import "BookSuccessViewController.h"
#import "PayResultVC.h"
#import "UPPayPlugin.h"
#import "UPPayPluginDelegate.h"

@interface BaseVCWithPay ()<UPPayPluginDelegate>
/**
 *  1-话费，2-京东E卡，3-爱奇艺，4-逛逛礼品卡,用于区分话费类还是卡类
 */
@property (nonatomic,strong) NSString *type;

@end

@implementation BaseVCWithPay


//微信支付接口 （infodic id num ecp_ext  detailDic[@"goodsname"]...4
- (void)payOnlineByWX : (NSDictionary *)infoDic withBrandCode:(NSString *)brandCode{
    if (![MyAppDelegate whetherHaveNet]) {
        //没有网
        [self showAlert:nil withTitle:@"请查看网络设置" haveCancelButton:NO];
        return;
    }
    
    //判断用户是否安装了微信
    if (![WXApi isWXAppInstalled]) {
        [self showAlert:nil withTitle:@"尚未安装微信" haveCancelButton:NO];
        return;
    }
    [self showHUD];
    NSLog(@"dic %@",infoDic);
    NSString *pcode = [infoDic objectForKey:@"pcode"];
    if(nil == pcode){
        pcode = @"";
    }
    _type = [NSString stringWithFormat:@"%@",infoDic[@"order_sub_type"]];
    NSDictionary *orderDetailDic = @{@"Mod":@"Order",@"Act":@"userOrder",@"Content":@{
                                             @"uid":[MyAppDelegate.userInfo objectForKey:@"id"],
                                             @"logintoken":[MyAppDelegate.userInfo objectForKey:@"logintoken"],
                                             @"pid":infoDic[@"id"],
                                             @"num": infoDic[@"num"],
                                             @"brand_code":brandCode,
                                             @"pcode":pcode,
                                             @"devicetype":@"1",
                                             @"version_name":KVERSION}};
    [xkNetwork xk_requstWithDic:orderDetailDic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* responseDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        if ([responseDic[@"Code"] isEqualToString:@"0000"]) {
            NSDictionary *detailDic = [[responseDic[@"DetailInfo"]objectForKey:@"goodsDetail"] objectAtIndex:0];
            NSDictionary *infoDic = [responseDic[@"DetailInfo"]objectForKey:@"payInfo"];
            
            NSDictionary *dic = @{
                                  @"phone":[infoDic objectForKey:@"ecp_ext"],
                                  @"product_name":detailDic[@"goodsname"],
                                  @"sellprice":detailDic[@"goodsprice"],
                                  @"paymoney":detailDic[@"sunmprice"],
                                  @"num": [infoDic objectForKey:@"num"],
                                  @"pcode":pcode,
                                  @"brandcode":brandCode,
                                  @"goodsnum":detailDic[@"goodsnum"]};
            
            [self payEcpWXWith:dic];
        }else{
            [self hideHUD];
            [self showAlert:nil withTitle:@"网络错误，请稍后重试！" haveCancelButton:NO];
        }
    }];
}

//处理微信支付后的结果
- (void)WXPayResultHandle:(NSNotification *)notify{
    
    if ([notify.object isEqualToString:WX_PAY_SUCCESS]) {
        [self showAlert:nil withTitle:@"支付成功" haveCancelButton:NO];
        if([_type isEqualToString:@"1"])
        {//话费类支付成功
            PayResultVC *pay = [[PayResultVC alloc]init];
            pay.hideBackButton = YES;
            [self.navigationController pushViewController:pay animated:YES];
        }
        else if([_type isEqualToString:@"2"]||[_type isEqualToString:@"3"]||[_type isEqualToString:@"4"]) {//卡密类暂时只有京东、爱奇艺、逛逛礼品卡
        //新增结果页面
        BookSuccessViewController  *ctrl = [[BookSuccessViewController alloc]init];
        ctrl.hideBackButton = YES;
        [self.navigationController pushViewController:ctrl animated:YES];
        }
        else{
            //未知类型
        }
    }else{
        [self showAlert:nil withTitle:@"订单支付未完成，请重新支付" haveCancelButton:NO];
        
    }
    [[NSNotificationCenter defaultCenter]removeObserver:self name:WX_PAY_RESULT object:nil];
   
}

//没点击微信支付或不支付，直接返回到应用,
- (void)handleWXPayIsDoing:(NSNotification *)noti{
    //子类实现
}

#pragma mark - 使用微信支付 ECP订单
- (void)payEcpWXWith : (NSDictionary *) detailDic{
    ZLog(@"%@",MyAppDelegate.userInfo);
    NSDictionary *dic = @{
                          @"devicetype":@"1",
                          @"version_name":KVERSION,
                          @"platform":@"wxpay",
                          @"spbill_create_ip":[MyAppDelegate  getIPAddress],
                    @"logintoken":MyAppDelegate.userInfo[@"logintoken"],
                          @"uid":MyAppDelegate.userInfo[@"id"],
                          @"ecp_ext":detailDic[@"phone"],
                          @"goodsname":detailDic[@"product_name"],
                          @"goodsprice":detailDic[@"sellprice"],
                          @"paymoney":detailDic[@"paymoney"],
                          @"num": detailDic[@"num"],//订单号
                          @"pcode":detailDic[@"pcode"],//大小类tel_yd1
                          @"brand_code":detailDic[@"brandcode"],//品牌号
                          @"goodsnum":detailDic[@"goodsnum"]//商品数
                          };
    NSString *enStr = [AESCrypt encrypt:[dic JSONRepresentation] password:KENCRYPTKEY];
    NSDictionary *requestDic =
    @{@"Mod":@"PaySign",
      @"Act":@"payOnlineEcpWx",
      @"Content":enStr};
    [xkNetwork xk_requstWithDic:requestDic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        if (error.code == 1) {
            [self showalertString:@"网络出错，请稍后重试！"];
            return ;
        }
        
        NSString *responseString = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"responseString = %@",responseString);
        NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([[responseDic objectForKey:@"Code"]isEqualToString:@"0000"]) {
            //加密的返回数据
            NSString *deStr1 = [AESCrypt decrypt:[responseDic objectForKey:@"DetailInfo"] password:KDECRYPTKEY];
            ;
            NSDictionary *detailDic = [NSJSONSerialization JSONObjectWithData:[deStr1 dataUsingEncoding:NSASCIIStringEncoding] options:NSJSONReadingMutableLeaves error:nil];
            NSDictionary *dic = [detailDic objectForKey:@"para"];
            MyAppDelegate.orderNum = [detailDic objectForKey:@"num"];
            
            MyAppDelegate.isCharging = YES;
            //调起微信支付
            PayReq *req = [[PayReq alloc]init];
            req.openID = dic[@"appid"];
            req.partnerId = dic[@"partnerid"];//商户id  mch_id
            req.prepayId = dic[@"prepayid"];//预支付订单 prepay_id
            req.package = dic[@"package"];//扩展字段Sign=WXPay
            req.nonceStr = dic[@"noncestr"];//随机串，防重发 noncestr
            NSString *timeStamp = dic[@"timestamp"]; //timestamp
            req.timeStamp = timeStamp.intValue;//时间戳
            req.sign = dic[@"sign"];//商家根据微信开放平台文档对数据做的签名
            
            [WXApi sendReq:req];
            //            注册通知，处理微信支付的结果
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(WXPayResultHandle:) name:WX_PAY_RESULT object:nil];
            
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleWXPayIsDoing:) name:WXPayIsDoing object:nil];
            NSLog(@"\npartid=%@\nprepayid=%@\nnoncestr=%@\ntimestamp=%ld\npackage=%@\nsign=%@",req.partnerId,req.prepayId,req.nonceStr,(long)req.timeStamp,req.package,req.sign );
            
        }else{
            [self showalertString:responseDic[@"Message"]];
        }
    }];
}

- (void)payWXFail{
    
}

//调起微信支付 - 非ecp订单
- (void)payWXWith:(NSDictionary *)resultDic{
    //判断有网
    if (![MyAppDelegate whetherHaveNet]) {
        [self showalertString:@"请查看网络设置"];
        return;
    }
    //判断用户是否安装了微信
    if (![WXApi isWXAppInstalled]) {
        [self showalertString:@"尚未安装微信"];
        return;
    }
    
    NSLog(@"%@",resultDic);
    NSDictionary *dic = [resultDic objectForKey:@"shopinfo"];
    NSDictionary *numInfo = [resultDic objectForKey:@"num"];
    NSString *shopName = [dic objectForKey:@"shopname"];
    NSString *contact = [dic objectForKey:@"contact"];
    NSString *fromFlag = resultDic[@"fromFlag"];// 默认为空，1从购物车来
    NSString *transport = [numInfo objectForKey:@"transport"];
    NSString *goods = [resultDic objectForKey:@"goods"];
    NSDictionary *contentDic = @{
                                 @"devicetype":@"1",
                                 @"version_name":KVERSION,
                                 @"shopname":shopName,
                                 @"phone":[MyAppDelegate.userInfo objectForKey:@"phone"],
                                 @"uid":[MyAppDelegate.userInfo objectForKey:@"id"],
                                 @"contact":contact,
                                 @"from_flag":fromFlag,
                                 @"transport":transport,
                                 @"shopid":[resultDic objectForKey:@"shopid"],
                                 @"platform":@"wxpay",//微信支付wxpay
                                 @"logintoken":[MyAppDelegate.userInfo objectForKey:@"logintoken"],
                                 @"address":[dic objectForKey: @"address"],
                                 @"receivetime":resultDic[@"receivetime"],
                                 @"num":numInfo[@"num"],
                                 @"prepay":numInfo [@"prepay"],
                                 @"acceptname":resultDic[@"acceptname"],
                                 @"remark":resultDic[@"remark"],
                                 @"goods":goods,
                                 @"spbill_create_ip":MyAppDelegate.userIpAddress
                                 };
    NSString *enStr = [AESCrypt encrypt:[contentDic JSONRepresentation] password:KENCRYPTKEY];
    NSDictionary *requestDic =
    @{@"Mod":@"PaySign",
      @"Act":@"PayOnlineWX",
      @"Content":enStr
      };
    
    [self showHUD];
    [xkNetwork xk_requstWithDic:requestDic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* responseDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if ([[responseDic objectForKey:@"Code"]isEqualToString:@"0000"]) {
            //新增的加密方式，取代下方非加密代码
            NSString *deStr1 = [AESCrypt decrypt:[responseDic objectForKey:@"DetailInfo"] password:KDECRYPTKEY];
            ;
            NSDictionary *detailDic = [NSJSONSerialization JSONObjectWithData:[deStr1 dataUsingEncoding:NSASCIIStringEncoding] options:NSJSONReadingMutableLeaves error:nil];
            NSDictionary *dic = [detailDic objectForKey:@"para"];
            
            MyAppDelegate.isCharging = YES;
            //NSDictionary *dic = [[responseDic objectForKey:@"DetailInfo"]objectForKey:@"para"];
            MyAppDelegate.orderNum = [detailDic objectForKey:@"num"];
            //调起微信支付
            PayReq *req = [[PayReq alloc]init];
            req.partnerId = dic[@"partnerid"];//商户id  mch_id
            req.prepayId = dic[@"prepayid"];//预支付订单 prepay_id
            req.package = dic[@"package"];//扩展字段Sign=WXPay
            req.nonceStr = dic[@"noncestr"];//随机串，防重发 noncestr
            NSString *timeStamp = dic[@"timestamp"]; //timestamp
            req.timeStamp = timeStamp.intValue;//时间戳
            req.sign = dic[@"sign"];//商家根据微信开放平台文档对数据做的签名
            
            [WXApi sendReq:req];
            //            注册通知，处理微信支付的结果
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(WXPayResultHandle:) name:WX_PAY_RESULT object:nil];
            
            //后台返回的微信支付后的结果
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(WXPayResultHandleFromBack:) name:WXPay_Fail object:nil];
            
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleWXPayIsDoing:) name:WXPayIsDoing object:nil];
            
            NSLog(@"\npartid=%@\nprepayid=%@\nnoncestr=%@\ntimestamp=%ld\npackage=%@\nsign=%@",req.partnerId,req.prepayId,req.nonceStr,(long)req.timeStamp,req.package,req.sign );
            
        }
        else{
            [self showalertString:responseDic[@"Message"]];
        }
    }];
}

- (void)WXPayResultHandleFromBack:(NSNotification *)notify{
    [self showAlert:nil withTitle:notify.object haveCancelButton:NO];
}

#pragma mark - network (话费支付 支付宝、银联)
- (void)payEcpWith : (NSDictionary *)resultDic{

    //#warning ----测试支付的一分钱
    //    [self.dicData setObject:@"1" forKey:@"sellprice"];
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"PaySign" forKey:@"Mod"];
    [dic setObject:@"payOnlineEcp" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    
    if(resultDic[@"platform"]){
        [dicContent setObject:resultDic[@"platform"]/*self.platform*/ forKey:@"platform"];
    }
    
    if(resultDic[@"num"]){
        [dicContent setObject:resultDic[@"num"] forKey:@"num"];
    }
    if(resultDic[@"ecp_ext"]){
        [dicContent setObject:resultDic[@"ecp_ext"]/*self.phoneStr*/ forKey:@"ecp_ext"];
    }
    
    //订单要显示售价，所以这里直接传入售价sellprice
    NSString *goodsprice = [/*self.dicData*/resultDic objectForKey:@"sellprice"];
    if(goodsprice){
        [dicContent setObject:goodsprice forKey:@"goodsprice"];
    }
    
    NSString *Goodsname = [/*self.dicData*/resultDic objectForKey:@"product_name"];
    if(Goodsname){
        [dicContent setObject:Goodsname forKey:@"goodsname"];
    }
    
    //测试需要
    NSString *paymoney = [/*self.dicData*/resultDic objectForKey:@"sellprice"];
    if(paymoney){
        [dicContent setObject:paymoney forKey:@"paymoney"];
    }
    
    NSString *pcode = [/*self.dicData*/resultDic objectForKey:@"pcode"];
    if(pcode){
        [dicContent setObject:pcode forKey:@"pcode"];
    }
    
    if(resultDic[@"brand_code"]){
        [dicContent setObject:resultDic[@"brand_code"] forKey:@"brand_code"];
    }
    if(resultDic[@"goodsnum"]){
        [dicContent setObject:resultDic[@"goodsnum"] forKey:@"goodsnum"];
    }
    
    NSString *enStr = [AESCrypt encrypt:[dicContent JSONRepresentation] password:KENCRYPTKEY];
    [dic setObject:enStr forKey:@"Content"];
    
    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        ZLog(@"registe info:%@",[resultDic objectForKey:@"Message"]);
        
        if (resultDic == nil) {
            
        }
        else if( [[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSString *deStr1 = [AESCrypt decrypt:[resultDic objectForKey:@"DetailInfo"] password:KDECRYPTKEY];
            ;
            NSDictionary *detailDic = [NSJSONSerialization JSONObjectWithData:[deStr1 dataUsingEncoding:NSASCIIStringEncoding] options:NSJSONReadingMutableLeaves error:nil];
            
            if ([[detailDic objectForKey:@"url"] isKindOfClass:[NSString class]] && [[detailDic objectForKey:@"url"] length] > 0) {
                ZLog(@"支付宝:%@",[detailDic objectForKey:@"para"]);
                //订单号用于进入结果页面
                MyAppDelegate.orderNum = [detailDic objectForKey:@"num"];
                
                [[UIApplication sharedApplication]openURL:[NSURL URLWithString:[detailDic objectForKey:@"url"]]];
                
                //通知刷新？
                [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
                
                [self performSelector:@selector(backToHome) withObject:nil afterDelay:2];
                
            }else{
                /**
                 *  mode:@"00" 正式版本
                 *  mode:@"01" 开发测试版
                 */
                ZLog(@"银联:%@",[detailDic objectForKey:@"tn"]);
                
                //订单号用于进入结果页面
                MyAppDelegate.orderNum = [detailDic objectForKey:@"num"];
                
                [UPPayPlugin startPay:[NSString stringWithFormat:@"%@",[detailDic objectForKey:@"tn"]] mode:@"00" viewController:self delegate:self];
                
            }
        }else{
            [self resetButtonState];

            [self showalertString:[resultDic objectForKey:@"Message"]];
            
        }
        
    }];
}

- (void)resetButtonState{
    //由子类实现，使按钮回复可点击状态
}

//返回主页
- (void)backToHome{
    [MyAppDelegate.mainTabVC setSelectedIndex:0];
    [MyAppDelegate.mainTabVC.selectImage setFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
    [self.navigationController popToRootViewControllerAnimated:YES];
}
@end
