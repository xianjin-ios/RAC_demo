//
//  LineView.h
//  GGSH
//
//  Created by STAR on 15/7/17.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LineView : UIView

@end
