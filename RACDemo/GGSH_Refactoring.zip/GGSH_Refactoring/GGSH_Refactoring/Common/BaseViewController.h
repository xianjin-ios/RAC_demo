//
//  BaseViewController.h
//  Toptaste
//
//  Created by huadong on 16/6/17.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "AppDelegate.h"
#import "SSKeychain.h"
#import "BMapKit.h"
#import "NSString+Height.h"

@interface BaseViewController : UIViewController<UIGestureRecognizerDelegate,UIAlertViewDelegate>
{
    
    UITapGestureRecognizer *tap;
}

@property (nonatomic,assign) BOOL hideBackButton;

- (void)cancelTapHideKeyBoard:(BOOL)cancel;

//返回操作
- (void)goBack:(id)sender;
- (void)hideBackButton:(BOOL)hide;


- (void)showHUD;
- (void)hideHUD;


- (void)showAlert:(NSString *)message withTitle:(NSString *)title haveCancelButton:(BOOL)cancel;
- (void)showalertString:(NSString *)alertSting;

@end
