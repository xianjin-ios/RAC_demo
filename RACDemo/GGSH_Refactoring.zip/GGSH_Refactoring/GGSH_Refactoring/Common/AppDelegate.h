//
//  AppDelegate.h
//  GGSH_Refactoring
//
//  Created by huadong on 16/9/12.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "GGSH_API.pch"
#import "TabBarController.h"
#import "UMMobClick/MobClick.h"
#import <ShareSDK/ShareSDK.h>

//自动登录后通知其它页面
@protocol AUTO_LOGIN <NSObject>

- (void)autoLoginSuccess;

@end


@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    
    //获取到beacon信息的时间 一个小时内不重复弹出本地通知
    NSDate *_dateOfGetBeacon;
    //这段时间内不再弹出beacon信息
    NSInteger _beaconDis;
    NSInteger _beaconTimeInterval;
    
}

@property (strong, nonatomic) UIWindow *window;
//用户的经纬度
@property (nonatomic, assign) CLLocationDegrees ilatitude;
@property (nonatomic, assign) CLLocationDegrees ilongitude;

@property (nonatomic,strong) TabBarController *mainTabVC;
@property (nonatomic,assign) double autoSizeScaleFont;
//订单号，用于跳转到支付结果页面
@property (nonatomic,retain) NSString *orderNum;

@property (nonatomic,retain) NSMutableDictionary *userInfo;

//微信支付时，看订单是否在支付过程中
@property (nonatomic,assign) BOOL isCharging;

@property (nonatomic,assign) id <AUTO_LOGIN> delegeta;

//微信支付时，看订单是否在支付过程中
//@property (nonatomic,assign) BOOL isCharging;

@property (nonatomic, retain) NSMutableArray *citylist;
@property (nonatomic,retain) NSMutableArray *bankList;

//beacons
@property (strong, nonatomic) NSMutableDictionary *beacons;
@property (strong, nonatomic) NSMutableDictionary *rangedRegions;

@property (nonatomic, assign) int curcity;//
@property (nonatomic,retain) NSMutableDictionary *localDic;
@property (nonatomic,retain) NSString *curcityname;

//定位城市
@property (nonatomic, retain) NSString *curPosition;

//优惠券N张待使用
@property (nonatomic, strong) NSString *couponNumForUse;

//是否有未读消息,是否添加红点提示。2015.12.3
@property (nonatomic, assign)BOOL isHaveNoReadMessage;
@property (nonatomic, assign)BOOL isHaveNoReadConpon;
@property (nonatomic, retain)NSString *shopCartNumber;//购物车数量
@property (nonatomic, retain)NSString *ecpcardnum;//卡密数量
@property (nonatomic,retain) NSString *ggCouponNum;//逛逛优惠券的数量
@property (nonatomic,strong) NSString *userIpAddress;
- (BOOL)isInstallWX;
//删除订单
@property (nonatomic, assign) BOOL isdel;

//云商城选择分类type
@property (nonatomic,assign) NSInteger mySelectType;//选择分类

//设备token
@property (nonatomic, retain) NSString *devTokenStr;

- (void)shareContext:(NSDictionary *)shareDic;//分享
//只分享微信
- (void)shareContextOnlyWechat:(NSDictionary *)shareDic;


-(NSString*)getDeviceToken;
//获取未读信息
- (void)getNoReadInfo;

//完整的baecons信息
@property (nonatomic, strong) NSMutableArray *beaconsInfoArray;

- (NSString *)getIPAddress ;

//清空beacon信息.比如蓝牙关闭，这时需要清空历史beacon
- (void)cleanBeaconInfoArray;
//获取当前beacon
- (NSDictionary *)getCurBeacon;
//删除陈旧数据 当前删除3秒以前的数据
- (void)removeOldBeaconData;

//百度push注册和解绑设备
- (void)registerBPush;
- (void)logoutBPush;

- (void)makeTabBarHidden:(BOOL)hide;
//判断是否有网络
- (BOOL)whetherHaveNet;
- (int)reachBility;                         //网络

- (void)shareContext:(NSDictionary *)shareDic;//分享

//设置当前选中的tab
- (void)setTabSelect : (int)index;

//用户自动登陆
- (void)autologinNet;

@end

