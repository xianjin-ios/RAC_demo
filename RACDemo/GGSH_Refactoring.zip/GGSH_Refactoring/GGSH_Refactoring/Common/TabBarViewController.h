//
//  TabBarViewController.h
//  GGSH_Refactoring
//
//  Created by huadong on 16/9/14.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "UmTabBar.h"

@interface TabBarViewController : UITabBarController<UITabBarControllerDelegate,UITabBarDelegate,UmTabBarDelegate>
{
    
    
}

@property(nonatomic,retain)UmTabBar *rootBar;

- (void)selectItem:(int)itemIdx;

@end
