//
//  MyNavigationViewController.h
//  Toptaste
//
//  Created by siqiyang on 16/6/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyNavigationViewController : UINavigationController

@end
