//
//  editAddressViewController.m
//  GGSH
//
//  Created by siqiyang on 15/9/8.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "editAddressViewController.h"

@interface editAddressViewController (){
    
    
    IBOutlet UITextField *_AName;
    
    IBOutlet UITextField *_APhone;
    
    IBOutlet UITextField *_ACode;
    
    IBOutlet UITextField *_AAdress;
    
    
    UIButton *rightBtn;
}

@end

@implementation editAddressViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if (self.isAddNewAddress) {
        self.title = @"新增地址信息";

    }else{
        self.title = @"编辑地址信息";
        [self getAddressDetail];

    }

    
    rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0.0, 0.0, 40, 25);
    [rightBtn addTarget:self action:@selector(submit:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setTitle:@"保存" forState:UIControlStateNormal];
    [rightBtn.titleLabel setFont:[UIFont systemFontOfSize:13]];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    rightBarButtonItem.style = UIBarButtonItemStylePlain;
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
}

- (void)submit:(UIButton *)sender{
    
    rightBtn.userInteractionEnabled = NO;
    
    //huad，bug 439 增加字段判断
    if (_AName.text.length == 0) {
        [self showAlert:nil withTitle:@"请填写收货人姓名" haveCancelButton:NO];
        rightBtn.userInteractionEnabled = YES;

        return;

    }
    
    if (_APhone.text.length == 0) {
        [self showAlert:nil withTitle:@"手机号码填写错误" haveCancelButton:NO];
        rightBtn.userInteractionEnabled = YES;

        return;
    }
    if (_ACode.text.length != 6) {
        [self showAlert:nil withTitle:@"邮编填写错误" haveCancelButton:NO];
        rightBtn.userInteractionEnabled = YES;

        return;
    }
    
    if (_AAdress.text.length == 0) {
        [self showAlert:nil withTitle:@"请填写收货地址" haveCancelButton:NO];
        rightBtn.userInteractionEnabled = YES;

        return;
        
    }
    
    if (self.isAddNewAddress) {
        [self addNewAddress];
    }else{
        [self editAddress];
    }
}

#pragma mark - network
//获取地址详情
- (void)getAddressDetail{
    [self showHUD];

    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"UserChange" forKey:@"Mod"];
    [dic setObject:@"selAddressdetails" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:[self.infoDic objectForKey:@"id"] forKey:@"addressid"];

    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        [self hideHUD];
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            //赋值
            _AName.text = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"acceptname"];
            _AAdress.text = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"address"];
            _APhone.text = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"contact"];
            _ACode.text = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"zipcode"];
            
            
        }
        
    }];
}

//添加新地址
- (void)addNewAddress{
    [self showHUD];

    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"UserChange" forKey:@"Mod"];
    [dic setObject:@"addAddress" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:_AAdress.text forKey:@"address"];
    [dicContent setObject:_AName.text forKey:@"acceptname"];
    [dicContent setObject:_APhone.text forKey:@"contact"];
    [dicContent setObject:_ACode.text forKey:@"zipcode"];

    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        [self hideHUD];
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            if (!self.isFromMy) {
                //通知新加地址并选择
                if (self.isFirst) {
                    [[NSNotificationCenter defaultCenter]postNotificationName:@"selectNewAddress" object:@"0"];
                    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count - 2] animated:YES];
                    
                }else{
                    [[NSNotificationCenter defaultCenter]postNotificationName:@"selectNewAddress" object:@"1"];
                    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count - 3] animated:YES];
                }
                
            }else{
                //发送通知修改信息，刷新列表
                [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshAddress" object:nil];
                [self.navigationController popViewControllerAnimated:YES];
                
            }
            
            rightBtn.userInteractionEnabled = YES;
        }
        else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
            
            rightBtn.userInteractionEnabled = YES;
        }
    }];
}

//编辑地址
- (void)editAddress{
    [self showHUD];

    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"UserChange" forKey:@"Mod"];
    [dic setObject:@"saveAddress" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:_AAdress.text forKey:@"address"];
    [dicContent setObject:_AName.text forKey:@"acceptname"];
    [dicContent setObject:_APhone.text forKey:@"contact"];
    [dicContent setObject:_ACode.text forKey:@"zipcode"];
    
    [dicContent setObject:[self.infoDic objectForKey:@"id"] forKey:@"addressid"];

    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        [self hideHUD];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            if (!self.isFromMy) {
                //通知新地址并选择
                if (self.isFirst) {
                    [[NSNotificationCenter defaultCenter]postNotificationName:@"selectNewAddress" object:@"0"];
                }else{
                    [[NSNotificationCenter defaultCenter]postNotificationName:@"selectNewAddress" object:@"1"];
                    
                }
                
                [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count - 3] animated:YES];
            }else{
                //发送通知修改信息，刷新列表
                [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshAddress" object:nil];
                [self.navigationController popViewControllerAnimated:YES];
                
            }
            rightBtn.userInteractionEnabled = YES;
            
        }
        else{
            
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
            rightBtn.userInteractionEnabled = YES;
            
        }
    }];
}

/*手机号码验证 MODIFIED BY HELENSONG*/
-(BOOL) isValidateMobile:(NSString *)mobile
{
    //手机号以13， 15，18开头，八个 \d 数字字符
    NSString *phoneRegex = @"^((13[0-9])|(147)|(145)|(17[0,6-8])|(15[^4,\\D])|(18[0-9]))\\d{8}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    //    ZLog(@"phoneTest is %@",phoneTest);
    return [phoneTest evaluateWithObject:mobile];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
