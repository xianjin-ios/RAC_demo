//
//  TabBarController.h
//  Toptaste
//
//  Created by siqiyang on 16/6/17.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarController : UITabBarController

@property (nonatomic,strong)UIImageView *selectImage;

- (void)getPushDic:(NSDictionary *)pushDic AndType:(NSString *)type;

@end
