//
//  NSString+Height.m
//  GGSH_Refactoring
//
//  Created by STAR on 2016/11/25.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "NSString+Height.h"

@implementation NSString (Height)

+ (CGSize)getHeight : (NSString *)str
        withFont :(UIFont *)font
        andWidth : (int)width{
    
    NSDictionary *attribute = @{NSFontAttributeName: font};
    CGSize size = [str boundingRectWithSize:CGSizeMake(width, NSIntegerMax)
                options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                    attributes:attribute context:nil].size;
    return size;
}

@end
