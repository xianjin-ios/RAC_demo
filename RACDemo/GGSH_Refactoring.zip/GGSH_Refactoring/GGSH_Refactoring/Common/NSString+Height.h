//
//  NSString+Height.h
//  GGSH_Refactoring
//
//  Created by STAR on 2016/11/25.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Height)

+ (CGSize)getHeight : (NSString *)str
        withFont :(UIFont *)font
        andWidth : (int)width;
@end
