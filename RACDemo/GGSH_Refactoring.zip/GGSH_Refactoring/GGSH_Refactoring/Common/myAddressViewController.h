//
//  myAddressViewController.h
//  GGSH
//
//  Created by siqiyang on 15/9/8.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@protocol SETADDRESS_DELEGATE <NSObject>

- (void)selectAddress:(NSInteger)selectIndex;

@end
@interface myAddressViewController : BaseViewController

@property (nonatomic,assign) id<SETADDRESS_DELEGATE> delegate;

@property (nonatomic,assign) BOOL isFromMy;

@property (nonatomic,assign) NSString *addressId;

@end
