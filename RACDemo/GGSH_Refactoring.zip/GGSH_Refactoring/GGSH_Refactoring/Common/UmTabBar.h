//
//  UmTabBar.h
//  LifeSearch
//
//  Created by kekey on 11-11-16.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UmTabBarItem.h"

typedef enum UmTabBarLayoutStyle
{
    UmTabBarLayoutStyle_fixedItemWidth = 0,
    UmTabBarLayoutStyle_flexibleItemWidth
}UmTabBarLayoutStyle;

@protocol UmTabBarDelegate;

@interface UmTabBar : UIView {
    NSArray* tabBarItems;
    int selectedItem;
    __unsafe_unretained id<UmTabBarDelegate> delegate;
    UIImageView* backgroundView;    
    UmTabBarLayoutStyle layoutStyle;
}

@property(nonatomic,assign)int selectedItem;
@property(nonatomic,assign)id<UmTabBarDelegate> delegate;

- (id)initWithFrame:(CGRect)frame tabBarItems:(NSArray*)items layoutStyle:(UmTabBarLayoutStyle)layoutStyle;
- (void)setBackgroundImage:(UIImage*)image;

@end



/////////////////////////////////
@protocol UmTabBarDelegate <NSObject>

-(void)umTabBar:(UmTabBar*)tabBar selectedItem:(int)itemIdx;

@end
