//
//  ProductOrderBaseCell.h
//  GGSH
//  订单的CELL
//  Created by 任春宁 on 15/7/3.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProductOrderBaseCell : UITableViewCell

//保存View的controller
@property (nonatomic, strong) UIViewController * ctrl;

@end
