//
//  NewsCtrl.h
//  news_test
//
//  Created by huadong on 16/10/17.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol NewsSelectDelegate <NSObject>

- (void)newsSelect:(NSInteger)index;

@end
@interface NewsCtrl : UIViewController
@property (nonatomic,strong) NSString *urlString;//url的字段
@property (nonatomic,weak)id<NewsSelectDelegate> delegate;

- (NewsCtrl *)initWithFrame:(CGRect)rect;
- (void)setNewsArray:(NSArray *)array;

- (void)setUpTimer;
- (void)removeTimer;

@end
