//
//  UIView+Extension.m
//  Toptaste
//
//  Created by 孟现进 on 16/4/17.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "UIView+Extension.h"

@implementation UIView (Extension)

- (CGSize)M_size{
    
    return self.frame.size;
}
- (void)setM_size:(CGSize)M_size{
    CGRect frame = self.frame;
    frame.size = M_size;
    self.frame = frame;
}

- (CGFloat)M_width{
    return self.frame.size.width;
}

- (CGFloat)M_height{
    return self.frame.size.height;
}

- (void)setM_width:(CGFloat)M_width{
    CGRect frame = self.frame;
    frame.size.width = M_width;
    self.frame = frame;
}
- (void)setM_height:(CGFloat)M_height{
    CGRect frame = self.frame;
    frame.size.height = M_height;
    self.frame = frame;
}

- (CGFloat)M_x{
    return self.frame.origin.x;
}
- (void)setM_x:(CGFloat)M_x{
    CGRect frame = self.frame;
    frame.origin.x = M_x;
    self.frame = frame;
}

- (CGFloat)M_y{
    return self.frame.origin.y;
}

- (void)setM_y:(CGFloat)M_y{
    CGRect frame = self.frame;
    frame.origin.y = M_y;
    self.frame = frame;
}
- (CGFloat)M_centerX{
    return self.center.x;
}
- (void)setM_centerX:(CGFloat)M_centerX{
    CGPoint center = self.center;
    center.x = M_centerX;
    self.center = center;
}

- (CGFloat)M_centerY{
    return self.center.y;
}
- (void)setM_centerY:(CGFloat)M_centerY{
    CGPoint center = self.center;
    center.y = M_centerY;
    self.center = center;
}
- (CGFloat)M_right{
    return CGRectGetMaxX(self.frame);
}
- (CGFloat)M_bottom{
    return CGRectGetMaxY(self.frame);
}
- (void)setM_right:(CGFloat)M_right{
    self.M_x = M_right - self.M_width;
}
- (void)setM_bottom:(CGFloat)M_bottom{
    self.M_y = M_bottom - self.M_height;
}

@end
