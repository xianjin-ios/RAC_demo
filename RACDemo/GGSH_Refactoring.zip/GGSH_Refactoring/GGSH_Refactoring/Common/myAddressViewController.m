//
//  myAddressViewController.m
//  GGSH
//
//  Created by siqiyang on 15/9/8.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "myAddressViewController.h"
#import "LineView.h"
#import "editAddressViewController.h"
#import "AddressCell.h"
#import "MJRefresh.h"
@interface myAddressViewController ()<UITableViewDataSource,UITableViewDelegate,ADDRESS_DELEGATE,MJRefreshBaseViewDelegate,UIActionSheetDelegate>{
    
    IBOutlet UIScrollView *_scrollView;
    
    IBOutlet UITableView *_tableView;
    
    IBOutlet UIView *_downView;
    
    IBOutlet LineView *_downLine;
    
    UIView *noView;
    
    int pageIndex;
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    
    
    NSString *delAddressId;
    
    NSMutableArray *_dataArray;
}

- (IBAction)addNewAddress:(id)sender;

@end

@implementation myAddressViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"我的地址";
    [_downLine setFrame:CGRectMake(0, 0, SCREEN_WIDTH, 0.5)];
    
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _tableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _tableView;
    _footer.delegate = self;
    
    pageIndex = 1;
    //添加通知修改信息
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getAddressList) name:@"refreshAddress" object:nil];
    
    [self getAddressList];
    
}

#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    if(refreshView == _header) {// 下拉刷新
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        pageIndex = 1;
        [self getAddressList];
        
    }else if (refreshView == _footer){
        
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        if(_dataArray.count%40 == 0){
            pageIndex += 1;
            [self getAddressList];
        }
        
    }
    
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];

}

//1s的假loading，取消正在加载就好
- (void)OneSecondElapse{
    [self hideHUD];
}

- (void)endHeaderFooterLoading{
    
    [_header endRefreshing];
    [_footer endRefreshing];
}

#pragma mark - network
//获取地址列表
- (void)getAddressList{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"UserChange" forKey:@"Mod"];
    [dic setObject:@"selAddresslist" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:[NSNumber numberWithInt:pageIndex] forKey:@"pageindex"];
    [dicContent setObject:[NSNumber numberWithInt:40] forKey:@"pagesize"];
    
    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if (pageIndex == 1) {
            [_dataArray removeAllObjects];
        }
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            //??此处需要判断翻页
            if (pageIndex == 1) {
                _dataArray = [[resultDic objectForKey:@"DetailInfo"]mutableCopy];
            }else
            {
                NSArray *tempArr = [resultDic objectForKey:@"DetailInfo"];
                [_dataArray addObjectsFromArray:tempArr];
            }
            
        }
        
        [_tableView reloadData];
        
        if (_dataArray.count == 0) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [_tableView addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
        
    }];
}

//设置默认地址
- (void)setDefaultAddressWithOldId:(NSString *)addressidold AndNewId:(NSString *)addressidnew{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"UserChange" forKey:@"Mod"];
    [dic setObject:@"saveAddressdefault" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:addressidnew forKey:@"addressidnew"];
    [dicContent setObject:addressidold forKey:@"addressidold"];

    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            [self showAlert:nil withTitle:@"设置默认地址成功" haveCancelButton:NO];
            
            //修改成功刷新列表
            pageIndex = 1;
            [self getAddressList];
            
        }
        else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
            
        }
        
    }];
}

//删除地址
- (void)delAddress:(NSString *)addressid{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"UserChange" forKey:@"Mod"];
    [dic setObject:@"delAddress" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:addressid forKey:@"addressid"];

    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];

    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            [self showAlert:nil withTitle:@"删除成功" haveCancelButton:NO];
            
            //刷新列表
            pageIndex = 1;
            [self getAddressList];
            
        }
        else{
            [self showAlert:nil withTitle:resultDic[@"Message"] haveCancelButton:NO];
        }
    }];
}

#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 138;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //COMMONCELL
    static NSString *CellIdentifier = @"COMMONCELL";
    UINib *nib = [UINib nibWithNibName:@"AddressCell" bundle:[NSBundle mainBundle]];
    [tableView registerNib:nib forCellReuseIdentifier:CellIdentifier];
    AddressCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    cell.delegate = self;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.clipsToBounds = YES;
    cell.isFromMy = self.isFromMy;
    cell.index = indexPath.row;
    
    //其他数据赋值
    NSDictionary *dic = [_dataArray objectAtIndex:indexPath.row];

    //底部文字设置
    if (self.isFromMy) {
        //圆圈旁边文字
        if (indexPath.row == 0) {
            cell.selectLabel.text = @"默认";
            cell.selectIcon.highlighted = YES;
        }else{
            cell.selectLabel.text = @"设为默认";
            cell.selectIcon.highlighted = NO;
        }
        
        //右边
        cell.delOrEditIcon.highlighted = YES;
        cell.delOrEdit.text = @"删除";
    }else{
        //圆圈旁边文字
        cell.selectLabel.text = @"";
        if ([[dic objectForKey:@"id"] isEqualToString:self.addressId]) {
            cell.selectIcon.highlighted = YES;
        }else{
            cell.selectIcon.highlighted = NO;
        }
        
        //右边
        cell.delOrEditIcon.highlighted = NO;
        cell.delOrEdit.text = @"编辑";
    }
    
    cell.name.text = [dic objectForKey:@"acceptname"];
    cell.address.text = [dic objectForKey:@"address"];
    cell.phone.text = [dic objectForKey:@"contact"];
    cell.addressCode.text = [dic objectForKey:@"zipcode"];
    
    return cell;
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.isFromMy) {
        //进入编辑
        editAddressViewController *ctrl = [[editAddressViewController alloc]init];
        ctrl.infoDic = [_dataArray objectAtIndex:indexPath.row];
        ctrl.isAddNewAddress = NO;
        ctrl.isFromMy = self.isFromMy;
        [self.navigationController pushViewController:ctrl animated:YES];
    }else{
        //选中
        [self set:indexPath.row];
    }
}

#pragma mark - cellDelegate
//设置
-(void)set:(NSInteger)index{
    ZLog(@"%ld",(long)index);

    if (self.isFromMy) {
        //设置默认
        NSString *addressidnew = [[_dataArray objectAtIndex:index] objectForKey:@"id"];
        NSString *addressidold = [[_dataArray objectAtIndex:0] objectForKey:@"id"];
        //相同不设定
        if ([addressidnew isEqualToString:addressidold]) {
            return;
        }
        [self setDefaultAddressWithOldId:addressidold AndNewId:addressidnew];

    }else{
        //选择此地址
        self.addressId = [[_dataArray objectAtIndex:index] objectForKey:@"id"];
        
        [self.delegate selectAddress:index];
        
        [self.navigationController popViewControllerAnimated:YES];
    }
}

//删除
-(void)del:(NSInteger)index{
    
    ZLog(@"%ld",(long)index);
    delAddressId = [[_dataArray objectAtIndex:index] objectForKey:@"id"];

    UIActionSheet *action = [[UIActionSheet alloc]initWithTitle:@"是否确认删除该地址？" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"删除" otherButtonTitles:nil];
    action.tag = 222;
    [action showInView:self.view];
    
}

//编辑
-(void)edit:(NSInteger)index{
    ZLog(@"%ld",(long)index);
    
    editAddressViewController *ctrl = [[editAddressViewController alloc]init];
    ctrl.infoDic = [_dataArray objectAtIndex:index];
    ctrl.isAddNewAddress = NO;
    ctrl.isFromMy = self.isFromMy;
    if (index == 0) {
        ctrl.isFirst = YES;
    }
    [self.navigationController pushViewController:ctrl animated:YES];

}

#pragma mark - actionDelegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (actionSheet.tag == 222) {
        if (buttonIndex == 0) {
            //删除
            [self delAddress:delAddressId];
            
        }else if (buttonIndex == 1){
            //取消
            
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)addNewAddress:(id)sender {
    
    editAddressViewController *ctrl = [[editAddressViewController alloc]init];
    ctrl.isAddNewAddress = YES;
    ctrl.isFromMy = self.isFromMy;
    if (_dataArray.count == 0) {
        ctrl.isFirst = YES;
    }
    [self.navigationController pushViewController:ctrl animated:YES];
    
}
@end
