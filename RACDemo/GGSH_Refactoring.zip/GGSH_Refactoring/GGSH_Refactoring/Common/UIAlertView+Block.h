//
//  UIAlertView+Block.h
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/11.
//  Copyright © 2016年 huadong. All rights reserved.
//
typedef void(^CompleteBlock) (NSInteger);

#import <UIKit/UIKit.h>

@interface UIAlertView (Block)
- (void)alertViewWithBlock:(CompleteBlock) block;
@end
