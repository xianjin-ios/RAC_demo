//
//  editAddressViewController.h
//  GGSH
//
//  Created by siqiyang on 15/9/8.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface editAddressViewController : BaseViewController

@property (nonatomic,assign) BOOL isAddNewAddress;
@property (nonatomic,retain) NSMutableDictionary *infoDic;
@property (nonatomic,assign) BOOL isFromMy;
@property (nonatomic,assign) BOOL isFirst;
@end
