//
//  AppDelegate.m
//  GGSH_Refactoring
//
//  Created by huadong on 16/9/12.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "AppDelegate.h"
#import "WXApi.h"
#import "SSKeychain.h"
#import "BPush.h"

#import <xkNetwork/Reachability.h>
#import <TencentOpenAPI/QQApi.h>
#import <TencentOpenAPI/QQApiInterface.h>
#import <TencentOpenAPI/TencentOAuth.h>
#include <sys/socket.h>// Per msqr
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <net/if.h>
#include <ifaddrs.h>
#import <dlfcn.h>
@interface AppDelegate ()<WXApiDelegate>
{
    UIImage *toolBarIMG;
    
    //当前的uuid只提醒一次 beacons
    NSString *curUUID;
    NSString *major;
    NSString *minor;
    //当前beacon的时间
    NSDate *curBeaconTime;
    CLBeaconMajorValue *vamajor;
}
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    //设置默认城市是北京
    [self setDefaultCity];
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    if(SCREEN_HEIGHT > 480){
        _autoSizeScaleFont = SCREEN_WIDTH/320;
    }else{
        _autoSizeScaleFont = 1.0;
    }

    
    TabBarController *tabBar = [[TabBarController alloc]init];
    _mainTabVC = tabBar;
    self.window.rootViewController = tabBar;
    
    [self.window makeKeyAndVisible];
    /**
     *  友盟统计sdk
     */
    UMConfigInstance.appKey = @"55b7063167e58e5e2c000445";
    UMConfigInstance.channelId = @"App Store";
    //配置以上参数后调用此方法初始化SDK！
    NSString *currentVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    [MobClick setAppVersion:currentVersion];
    [MobClick startWithConfigure:UMConfigInstance];
    [WXApi registerApp:WX_AppId withDescription:@"WXPay"];
    
    
    //注册ShareSdk
    [ShareSDK registerApp:@"74ed94524c40"];
    
    [ShareSDK connectQQWithQZoneAppKey:@"1102490064"
                     qqApiInterfaceCls:[QQApiInterface class]
                       tencentOAuthCls:[TencentOAuth class]];
    [ShareSDK connectWeChatWithAppId:WX_AppId wechatCls:[WXApi class]];
    
    [ShareSDK importQQClass:[QQApiInterface class] tencentOAuthCls:[TencentOAuth class]];
    [ShareSDK importWeChatClass:[WXApi class]];
    
    //百度推送
    [BPush registerChannel:launchOptions apiKey:@"TkD0oNy2myO5hGbeukq4YNRs" pushMode:BPushModeProduction withFirstAction:nil withSecondAction:nil withCategory:nil isDebug:NO];
    // App 是用户点击推送消息启动
    NSDictionary *pushDictionary = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    if (pushDictionary) {
        NSLog(@"从消息启动:%@",pushDictionary);
        [BPush handleNotification:pushDictionary];
        
        //启动时处理push；
        [self launchingWithPushArg:pushDictionary];
    }
    
    self.userIpAddress = [self getIPAddress];
    return YES;
}

/**
 获取未读消息
 */
- (void)getNoReadInfo
{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Shopping" forKey:@"Mod"];
    [dic setObject:@"getNewsCount" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([self.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[self.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[self.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
        [dicContent setObject:[self.userInfo objectForKey:@"phone"] forKey:@"phone"];
        
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        [dicContent setObject:@"" forKey:@"phone"];
    }
    
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];

    [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:YES andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        ZLog(@"%s  responseString = %@",__func__,[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        ZLog(@"%@",[resultDic objectForKeyedSubscript:@"Message"]);
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSDictionary *tempDic = [resultDic objectForKey:@"DetailInfo"];
            if ([tempDic objectForKey:@"newsnum"] && [[tempDic objectForKey:@"newsnum"] integerValue] > 0) {
                //有未读消息
                self.isHaveNoReadMessage = YES;
            }else{
                self.isHaveNoReadMessage = NO;
                
            }
            
            //保存全局的待使用优惠券数量，在我的卡券页面显示
            self.couponNumForUse = [[tempDic objectForKey:@"coupon_use_num"] copy];
            
            self.ggCouponNum = [NSString stringWithFormat:@"%@",[tempDic objectForKey:@"gg_coupon_use_num"]];
            
            if ([tempDic objectForKey:@"shoppingsum"] && [[tempDic objectForKey:@"shoppingsum"] integerValue] > 0) {
                //有购物车信息
                NSString *shopCartNum = [tempDic objectForKey:@"shoppingsum"];
                if (shopCartNum.integerValue > 99) {
                    shopCartNum = @"99+";
                }
                self.shopCartNumber = shopCartNum;
            }else{
                self.shopCartNumber = @"0";
            }
            
            if ([tempDic objectForKey:@"ecpcardnum"] && [[tempDic objectForKey:@"ecpcardnum"] integerValue] > 0) {
                //有购物车信息
                NSString *ecpcardnumStr = [tempDic objectForKey:@"ecpcardnum"];
                if (ecpcardnumStr.integerValue > 99) {
                    ecpcardnumStr = @"99+";
                }
                self.ecpcardnum = ecpcardnumStr;
            }else{
                self.ecpcardnum = @"0";
            }
            
            //判断我的卡券是否显示红点
            if (([tempDic objectForKey:@"couponnum"] && [[tempDic objectForKey:@"couponnum"] integerValue] > 0) || ([tempDic objectForKey:@"ecpcardnum"] && [[tempDic objectForKey:@"ecpcardnum"] integerValue] > 0)) {
                //有未读优惠券
                self.isHaveNoReadConpon = YES;
            }else{
                self.isHaveNoReadConpon = NO;
                
            }
        }else{
            //获取失败
            self.isHaveNoReadMessage = NO;
            self.isHaveNoReadConpon = NO;
            self.shopCartNumber = @"0";
            self.ecpcardnum = @"0";
            
        }
        
        //发送通知,修改主页的navbtn
        [[NSNotificationCenter defaultCenter]postNotificationName:@"HaveNoRead" object:nil];
        
        
    }];
 }
//第一次启动，城市自动设定北京
- (void)setDefaultCity{
    [USERDEFAULT setObject:@"北京" forKey:@"CityName"];
    [USERDEFAULT setObject:@"D0101" forKey:@"CityID"];
    self.curcityname = @"北京";
    self.ilongitude = 116.422824;
    self.ilatitude = 39.934427;
}


#pragma mark - 微信
-(void) onResp:(BaseResp*)resp{

    NSString *strMsg = [NSString stringWithFormat:@"errcode:%d", resp.errCode];
    ZLog(@"%@",strMsg);
    NSString *strTitle;
    
    if([resp isKindOfClass:[SendMessageToWXResp class]])
    {
        strTitle = [NSString stringWithFormat:@"发送媒体消息结果"];
    }
//    if([resp isKindOfClass:[PayResp class]]){
//        //支付返回结果，实际支付结果需要去微信服务器端查询
//        strTitle = [NSString stringWithFormat:@"支付结果"];
//        NSLog(@"resp.errCode%d",resp.errCode);
//        switch (resp.errCode) {
//                /*
//                 WXSuccess           = 0,    **< 成功
//                 WXErrCodeCommon     = -1,   **< 普通错误类型
//                 WXErrCodeUserCancel = -2,   **< 用户点击取消并返回
//                 WXErrCodeSentFail   = -3,   **< 发送失败
//                 WXErrCodeAuthDeny   = -4,   **< 授权失败
//                 WXErrCodeUnsupport  = -5,   **< 微信不支持
//                */
//            case WXSuccess:{
//                strMsg = @"支付结果：成功！";
//                NSLog(@"支付成功－PaySuccess，retcode = %d", resp.errCode);
////             发送通知
//                [[NSNotificationCenter defaultCenter] postNotificationName:WX_PAY_RESULT object:WX_PAY_SUCCESS];
//
//                break;
//            }
//            default:{
//                strMsg = [NSString stringWithFormat:@"支付结果：失败！retcode = %d, retstr = %@", resp.errCode,resp.errStr];
//                NSLog(@"错误，retcode = %d, retstr = %@", resp.errCode,resp.errStr);
//                 [[NSNotificationCenter defaultCenter]postNotificationName:WX_PAY_RESULT object:WX_PAY_FAIL];
//                break;
//            }
//        }
//    }
    if([resp isKindOfClass:[PayResp class]]){
        //微信回调，查询后台的订单
        [self requestDataForWXResp];
        
    }
}

/**
 *  微信回调，查询后台的订单状态
 */
- (void)requestDataForWXResp{
    NSDictionary *dic = @{@"Mod":@"PaySign",
                          @"Act":@"getPayStatusWX",
                          @"Content":@{
                                  @"devicetype":@"1",
                                  @"uid":[MyAppDelegate.userInfo objectForKey:@"id"],
                                  @"num":MyAppDelegate.orderNum,
                                  @"platform":@"wxpay",
                                  @"logintoken":[MyAppDelegate.userInfo objectForKey:@"logintoken"],
                                  @"version_name":KVERSION}};
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        NSString *responseString = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"WXresponseString%@",responseString);
        NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([[responseDic objectForKey:@"Code"]isEqualToString:@"0000"]) {
            
            //status 1-支付成功,2-支付失败
            NSString *status = [NSString stringWithFormat:@"%@",[[responseDic objectForKey:@"DetailInfo"]objectForKey:@"status"]];
            if ([status isEqualToString:@"1"]) {
                //成功 -- 发送通知
                [[NSNotificationCenter defaultCenter] postNotificationName:WX_PAY_RESULT object:WX_PAY_SUCCESS];
            }
            
            else{
                
                [[NSNotificationCenter defaultCenter]postNotificationName:WX_PAY_RESULT object:WX_PAY_FAIL];
                
            }
            
        }
        else{
            [[NSNotificationCenter defaultCenter]postNotificationName:WXPay_Fail object:responseDic[@"Message"]];
            
            
        }
    }];
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
   //友盟统计,开启background模式
    [MobClick setBackgroundTaskEnabled:YES];
    
    
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    //判断是否调起了微信支付
    if (self.isCharging == YES) {
        
        self.isCharging = NO;
        [[NSNotificationCenter defaultCenter]postNotificationName:WXPayIsDoing object:nil];
        
    }
#warning 一个是百度定位一个是beacon
//    [_locService startUserLocationService];
    
    if ([SSKeychain passwordForService:keyChainAccessGroup account:keyChainUser] || [SSKeychain passwordForService:keyChainAccessGroup account:keyChainLoginToken]) {
        
        if ([self.userInfo objectForKey:@"id"]) {
            return;
        }
        
        //解绑百度设备
        [self logoutBPush];
        
        //自动登录
        [self autologinNet];
        
        return;
    }
    
    //刷新未读提示
    if ([self.userInfo objectForKey:@"id"]) {
        [self getNoReadInfo];
    }
}

-(void)locationManager:(CLLocationManager*)manager
       didRangeBeacons:(NSArray*)beacons
              inRegion:(CLBeaconRegion*)region
{
    self.rangedRegions[region] = beacons;
    [self.beacons removeAllObjects];
    
    NSMutableArray *allBeacons = [NSMutableArray array];
    
    for (NSArray *regionResult in [self.rangedRegions allValues])
    {
        [allBeacons addObjectsFromArray:regionResult];
    }
    
    //处理最近的beacon
    NSNumber *disMin = [allBeacons valueForKeyPath:@"@min.accuracy"];
    for(CLBeacon *beacon in allBeacons){
        double curDis = beacon.accuracy;
        if(fabs(disMin.floatValue - beacon.accuracy) < 0.01f){
            NSLog(@"the same baecon");
            
            if(curDis < _beaconDis){
                curUUID = [[beacon.proximityUUID UUIDString] copy];
                major = [[beacon.major stringValue] copy];
                minor = [[beacon.minor stringValue] copy];
                curBeaconTime = [[NSDate date] copy];
                
                //找到服务器上该beacon的详细信息
                if(curUUID.length > 0 && major.length > 0 && minor.length > 0){
                    if([UIApplication sharedApplication].applicationState == UIApplicationStateBackground){
                        [self findBeacon:curUUID withMajor:major andMinor:minor];
                        
                    }
                }
            }
        }
    }
    
    
    for (NSNumber *range in @[@(CLProximityUnknown), @(CLProximityImmediate), @(CLProximityNear), @(CLProximityFar)])
    {
        NSArray *proximityBeacons = [allBeacons filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"proximity = %d", [range intValue]]];
        if([proximityBeacons count])
        {
            self.beacons[range] = proximityBeacons;
        }
    }
}

//获取到了新的beacon信息，当beacon信息没有保存时，获取其完整信息，保存数据
- (void)findBeacon : (NSString *)uuidstr
         withMajor : (NSString *)majorstr
          andMinor : (NSString *)minorstr{
    if(!self.beaconsInfoArray){
        self.beaconsInfoArray = [NSMutableArray array];
    }
    
    //已有数据只做更新，不插入
    BOOL isOldData = NO;
    for(NSDictionary *dic in self.beaconsInfoArray){
        NSString *str1 = [dic objectForKey:@"uuid"];
        NSString *str2 = [dic objectForKey:@"major"];
        NSString *str3 = [dic objectForKey:@"minor"];
        if([str1 isEqualToString:uuidstr] && [str2 isEqualToString:majorstr] && [str3 isEqualToString:minorstr]){
            isOldData = YES;
        }
    }
    
    if(!isOldData){
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString *time = [dateFormatter stringFromDate:[NSDate date]];
        if(time.length > 10){
            time = [time substringToIndex:10];
        }
        
        //完善信息，重新插入到完善信息
        NSMutableDictionary *tempDic = [[NSMutableDictionary alloc]init];
        [tempDic setObject:uuidstr forKey:@"uuid"];
        [tempDic setObject:majorstr forKey:@"major"];
        [tempDic setObject:minorstr forKey:@"minor"];
        [tempDic setObject:@"" forKey:@"shopname"];
        [tempDic setObject:@"" forKey:@"listpic"];
        [tempDic setObject:@"0" forKey:@"isnotification"];
        [tempDic setObject:@"1" forKey:@"isread"];
        
        //设置一个时间，用来顶起清空历史beacon数据
        [tempDic setObject:[NSDate date] forKey:@"latestTime"];
        [tempDic setObject:time forKey:@"time"];
        _beaconTimeInterval = time.intValue;
        
        [self.beaconsInfoArray insertObject:tempDic atIndex:0];
        
    }
    
    //一小时内不再弹出beacon提醒
    BOOL isRequestNetwork = NO;
    if(nil == _dateOfGetBeacon || NSOrderedDescending == [[NSDate date] compare : _dateOfGetBeacon]){
        _dateOfGetBeacon = [[[NSDate date] dateByAddingTimeInterval:_beaconTimeInterval] copy];
        
        isRequestNetwork = YES;
    }
    
    if (!isRequestNetwork) {
        return;
    }
    
    for(NSDictionary *dic in self.beaconsInfoArray){
        
        NSString *str1 = [dic objectForKey:@"uuid"];
        NSString *str2 = [dic objectForKey:@"major"];
        NSString *str3 = [dic objectForKey:@"minor"];
        if([str1 isEqualToString:uuidstr] && [str2 isEqualToString:majorstr] && [str3 isEqualToString:minorstr]){
            //组合参数
            NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
            [dic setObject:@"Beacon" forKey:@"Mod"];
            [dic setObject:@"activityShow" forKey:@"Act"];
            
            
            NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
            [dicContent setObject:uuidstr forKey:@"uuid"];
            [dicContent setObject:majorstr forKey:@"major"];
            [dicContent setObject:minorstr forKey:@"minor"];
            [dicContent setObject:@"1" forKey:@"devicetype"];
            [dicContent setObject:KVERSION forKey:@"version_name"];
            [dic setObject:dicContent forKey:@"Content"];
            
            [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
                if (data == nil || error != nil) {
                    NSLog(@"kong");
                    return;
                }
                NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
                
                NSLog(@"str : %@",tempStr);
                
                NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
                int code = [[resultDic  objectForKey:@"Code"] intValue];
                if (code == 0000) {
                    
                    NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
                    
                    if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
                        
                        NSDictionary *detailDic = [resultDic objectForKey:@"DetailInfo"];
                        if([detailDic isKindOfClass:[NSDictionary class]]){
                            NSDictionary *shopDic = [detailDic objectForKey:@"shopInfo"];
                            NSString *shopnameStr = [shopDic objectForKey:@"shopname"];
                            NSString *listpicStr = [shopDic objectForKey:@"listpic"];
                            
                            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                            [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                            NSString *time = [dateFormatter stringFromDate:[NSDate date]];
                            if(time.length > 10){
                                time = [time substringToIndex:10];
                            }
                            
                            //完善信息，重新插入到完善信息
                            for(NSMutableDictionary *dic in self.beaconsInfoArray){
                                NSString *str1 = [dic objectForKey:@"uuid"];
                                NSString *str2 = [dic objectForKey:@"major"];
                                NSString *str3 = [dic objectForKey:@"minor"];
                                
                                if([str1 isEqualToString:uuidstr] && [str2 isEqualToString:majorstr] && [str3 isEqualToString:minorstr]){
                                    [dic setObject:shopnameStr forKey:@"shopname"];
                                    [dic setObject:listpicStr forKey:@"listpic"];
                                    [dic setObject:@"1" forKey:@"isnotification"];
                                    [dic setObject:@"0" forKey:@"isread"];
                                    [dic setObject:time forKey:@"time"];
                                    
                                    //保存服务器参数
                                    if([detailDic objectForKey:@"remark"]){
                                        NSDictionary *dic = [detailDic objectForKey:@"remark"];
                                        NSString *disStr = [dic objectForKey:@"distance"];
                                        _beaconDis = disStr.intValue;
                                        NSString *time = [dic objectForKey:@"refresh_time"];
                                        _beaconTimeInterval = time.intValue;
                                        
                                        if([UIApplication sharedApplication].applicationState == UIApplicationStateBackground){
                                            _dateOfGetBeacon = [[[NSDate date] dateByAddingTimeInterval:_beaconTimeInterval] copy];
                                            
                                            NSString *tempStr = [shopnameStr stringByAppendingString:@"开始派券，快去抢吧"];
                                            
                                            [self showNotification:tempStr];
                                        }
                                        
                                        
                                    }
                                    
                                    //保存到本地
                                    [self saveBeaconsToLocal];
                                }
                            }
                            ZLog(@"cur beacon array is:%@",self.beaconsInfoArray);
                        }
                    }
                    
                }
            }];
        }
    }
}

//弹出提示beaon信息
- (void)showNotification : (NSString *) notifStr{
    UILocalNotification *alarm = [[UILocalNotification alloc] init];
    if (alarm)
    {
        NSDate *now = [NSDate dateWithTimeIntervalSinceNow:0.1f];
        
        alarm.fireDate = now;
        alarm.timeZone = [NSTimeZone defaultTimeZone];
        alarm.repeatInterval = NSCalendarUnitEra;
        alarm.soundName = @"LocalAlarm.caf";
        alarm.applicationIconBadgeNumber = 0;
        alarm.alertBody = notifStr;
        
        NSDictionary *infoDic = [NSDictionary dictionaryWithObjectsAndKeys:curUUID,@"uuid", major,@"major",minor,@"minor", nil];
        
        alarm.userInfo = infoDic;
        [[UIApplication sharedApplication] presentLocalNotificationNow:alarm];
    }
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


-(NSString*)getDeviceToken{
    return [[UIDevice currentDevice].identifierForVendor UUIDString];//[[ASIdentifierManager sharedManager].advertisingIdentifier UUIDString];
}


//获取用户设备当前的ip地址
- (NSString *)getIPAddress {
    
    NSString *address = @"118.244.208.7";
    NetworkStatus status=[[Reachability reachabilityForInternetConnection] currentReachabilityStatus];
    switch (status) {
            
        case ReachableViaWWAN:
        {
            NSError *error;
            NSURL *ipURL = [NSURL URLWithString:@"http://ip.3322.org"];
            address = [NSString stringWithContentsOfURL:ipURL encoding:1 error:&error];
            
            return address ? address : @"118.244.208.7";
        }
            break;
        case ReachableViaWiFi:{
            //WiFi状态下
            struct ifaddrs *interfaces = NULL;
            struct ifaddrs *temp_addr = NULL;
            int success = 0;
            // retrieve the current interfaces - returns 0 on success
            success = getifaddrs(&interfaces);
            if (success == 0) {
                // Loop through linked list of interfaces
                temp_addr = interfaces;
                while(temp_addr != NULL) {
                    if(temp_addr->ifa_addr->sa_family == AF_INET) {
                        // Check if interface is en0 which is the wifi connection on the iPhone
                        if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                            // Get NSString from C String
                            address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                        }
                    }
                    temp_addr = temp_addr->ifa_next;
                }
            }
            
            // Free memory
            freeifaddrs(interfaces);
            
        }
        default:
            break;
    }
    
    
    
    return address;
    
}





//清空beacon信息
- (void)cleanBeaconInfoArray{
    [self.beaconsInfoArray removeAllObjects];
    [self saveBeaconsToLocal];
}

- (void)saveBeaconsToLocal{
    //beacons 保存本地文件
    NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString * documentsDirectory = [paths objectAtIndex:0];
    NSString * path = [documentsDirectory stringByAppendingPathComponent:@"beaconsInLocal.plist"];
    [self.beaconsInfoArray writeToFile:path atomically:YES];
    
}

//获取当前的uuid major minor
- (NSDictionary *)getCurBeacon{
    if(curUUID.length > 0 && major.length > 0 && minor.length > 0){
        return [NSDictionary dictionaryWithObjectsAndKeys:curUUID,@"uuid",major,@"major",minor,@"minor", nil];
    }
    return nil;
}

//删除陈旧数据 当前删除3秒以前的数据
- (void)removeOldBeaconData{
    BOOL needSave = NO;
    
    //删除1秒以前的数据
    for(NSDictionary *dic in self.beaconsInfoArray){
        NSDate *beaconDate = [dic objectForKey:@"latestTime"];
        NSDate *curDate = [NSDate date];
        if(beaconDate && NSOrderedAscending == [[beaconDate dateByAddingTimeInterval:1] compare:curDate]){
            [self.beaconsInfoArray removeObject:dic];
            needSave = YES;
        }
    }
    
    //删除超过1秒的当前beacon信息
    if(curBeaconTime && NSOrderedAscending == [[curBeaconTime dateByAddingTimeInterval:1]compare:[NSDate date]]){
        curUUID = nil;
        major = nil;
        minor = nil;
    }
    //保存数据
    if(needSave){
        [self saveBeaconsToLocal];
    }
}

//- (BOOL)isInstallWX{
//    if ([WXApi isWXAppSupportApi]) {
//        ZLog(@"支持当前版本！！");
//    }
//    return [WXApi isWXAppInstalled];
//    
//}

//注册百度push设备
- (void)registerBPush
{
//    //组合参数
//    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
//    [dic setObject:@"Members" forKey:@"Mod"];
//    [dic setObject:@"pushRegiste" forKey:@"Act"];
//    
//    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
//    [dicContent setObject:[USERDEFAULT objectForKey:@"userName"]?[USERDEFAULT objectForKey:@"userName"]:@"" forKey:@"user_login_name"];
//    [dicContent setObject:[self.userInfo objectForKey:@"logintoken"]?[self.userInfo objectForKey:@"logintoken"]:@"" forKey:@"logintoken"];
//    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
//    [dicContent setObject:[NSNumber numberWithInt:5] forKey:@"user_type"];
//    if ([BPush getChannelId]) {
//        [dicContent setObject:[BPush getChannelId] forKey:@"channelid"];
//        [dicContent setObject:[BPush getUserId] forKey:@"userid"];
//    }else{
//        [dicContent setObject:@"" forKey:@"channelid"];
//        [dicContent setObject:@"" forKey:@"userid"];
//    }
//    NSString *shortVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
//    [dicContent setObject:shortVersion forKey:@"version"];
//    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
//    NSString *bundleId = [infoDic objectForKey:@"CFBundleIdentifier"];
//    ZLog(@"%@",bundleId);
//    if ([bundleId isEqualToString:@"com.xkdx.ggsh1"]){
//        //企业版
//        [dicContent setObject:[NSNumber numberWithInteger:1] forKey:@"os_type"];//应用os类型:1企业版;2AppStore(ios专用)
//    }else{
//        //App Store版本
//        [dicContent setObject:[NSNumber numberWithInteger:2] forKey:@"os_type"];//应用os类型:1企业版;2AppStore(ios专用)
//        
//    }
//    [dicContent setObject:KVERSION forKey:@"version_name"];
//    [dic setObject:dicContent forKey:@"Content"];
//    
//    //转换为NSString
//    NSData* result = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
//    NSString *jsonString = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
//    
//    ZLog(@"---%@",jsonString);
//    
//    NSURL *url = [NSURL URLWithString:kMposAppUrl];
//    __block ASIFormDataRequest *request= [ASIFormDataRequest requestWithURL:url];
//    [request setRequestMethod:@"POST"];
//    [request setPostValue:jsonString forKey:@"JsonString"];
//    [self checkNetStatus];
//    [request setCompletionBlock:^{
//        
//        NSString *responseString = [request responseString];
//        ZLog(@"*******= %@",responseString);
//        NSData *responseData = [responseString dataUsingEncoding:NSUTF8StringEncoding];
//        
//        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingAllowFragments error:nil];
//        ZLog(@"%@",[resultDic objectForKeyedSubscript:@"Message"]);
//        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
//            ZLog(@"注册设备成功！");
//            
//        }else{
//            //            [MyAppDelegate showAlert:@"开启推送失败！"];
//            [self registerBPush];
//        }
//    }];
//    [request setFailedBlock:^{
//        [self registerBPush];
//        
//    }];
//    [request startAsynchronous];
    
}

//解绑百度push设备
- (void)logoutBPush
{
//    //组合参数
//    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
//    [dic setObject:@"Members" forKey:@"Mod"];
//    [dic setObject:@"pushLogout" forKey:@"Act"];
//    
//    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
//    [dicContent setObject:[USERDEFAULT objectForKey:@"userName"]?[USERDEFAULT objectForKey:@"userName"]:@"" forKey:@"user_login_name"];
//    [dicContent setObject:[self.userInfo objectForKey:@"logintoken"]?[self.userInfo objectForKey:@"logintoken"]:@"" forKey:@"logintoken"];
//    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
//    [dicContent setObject:[NSNumber numberWithInt:5] forKey:@"user_type"];
//    if ([BPush getChannelId]) {
//        [dicContent setObject:[BPush getChannelId] forKey:@"channelid"];
//        [dicContent setObject:[BPush getUserId] forKey:@"userid"];
//    }else{
//        [dicContent setObject:@"" forKey:@"channelid"];
//        [dicContent setObject:@"" forKey:@"userid"];
//    }
//    
//    NSString *shortVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
//    [dicContent setObject:shortVersion forKey:@"version"];
//    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
//    NSString *bundleId = [infoDic objectForKey:@"CFBundleIdentifier"];
//    ZLog(@"%@",bundleId);
//    if ([bundleId isEqualToString:@"com.xkdx.ggsh1"]){
//        //企业版
//        [dicContent setObject:[NSNumber numberWithInteger:1] forKey:@"os_type"];//应用os类型:1企业版;2AppStore(ios专用)
//    }else{
//        //App Store版本
//        [dicContent setObject:[NSNumber numberWithInteger:2] forKey:@"os_type"];//应用os类型:1企业版;2AppStore(ios专用)
//        
//    }
//    [dicContent setObject:KVERSION forKey:@"version_name"];
//    [dic setObject:dicContent forKey:@"Content"];
//    
//    //转换为NSString
//    NSData* result = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
//    NSString *jsonString = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
//    
//    ZLog(@"---%@",jsonString);
//    
//    NSURL *url = [NSURL URLWithString:kMposAppUrl];
//    __block ASIFormDataRequest *request= [ASIFormDataRequest requestWithURL:url];
//    [request setRequestMethod:@"POST"];
//    [request setPostValue:jsonString forKey:@"JsonString"];
//    [self checkNetStatus];
//    [request setCompletionBlock:^{
//        
//        NSString *responseString = [request responseString];
//        ZLog(@"*******= %@",responseString);
//        NSData *responseData = [responseString dataUsingEncoding:NSUTF8StringEncoding];
//        
//        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingAllowFragments error:nil];
//        ZLog(@"%@",[resultDic objectForKeyedSubscript:@"Message"]);
//        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
//            ZLog(@"解绑设备成功！");
//            
//        }else{
//            ZLog(@"解绑设备失败！");
//            
//        }
//    }];
//    [request setFailedBlock:^{
//        
//    }];
//    [request startAsynchronous];
    
}

- (void)makeTabBarHidden:(BOOL)hide
{
    if ( [_mainTabVC.view.subviews count] < 2 )
    {
        return;
    }
    UIView *contentView;
    UIView *transitionView;
    
    if ( [[_mainTabVC.view.subviews objectAtIndex:1] isKindOfClass:[UITabBar class]] )
    {
        contentView = [_mainTabVC.view.subviews objectAtIndex:1];
        transitionView = [_mainTabVC.view.subviews objectAtIndex:0];
    }
    else
    {
        contentView = [_mainTabVC.view.subviews objectAtIndex:1];
        transitionView = [_mainTabVC.view.subviews objectAtIndex:0];
        
    }
    
    if ( hide )
    {
        transitionView.frame = CGRectMake(0, 0, 320, self.window.frame.size.height);
        contentView.frame = CGRectMake(0, self.window.frame.size.height, 320, 49);
    }
    else
    {
        transitionView.frame = CGRectMake(0, 0, 320, self.window.frame.size.height-49);
        contentView.frame = CGRectMake(0,self.window.frame.size.height-49,320,49);
    }
    
}

//判断是否有网络
- (BOOL)whetherHaveNet{
    
    NetworkStatus status=[[Reachability reachabilityForInternetConnection] currentReachabilityStatus];
    if (status == NotReachable) {//没有网络
        return NO;
    }
    else
        return YES;
}


- (void)autologinNet{
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    //通过keyChain取用户名和密码
    if (![SSKeychain passwordForService:keyChainAccessGroup account:keyChainUser] || ![SSKeychain passwordForService:keyChainAccessGroup account:keyChainLoginToken]) {
        self.userInfo = nil;
        
        return;
    }
    [item setObject:[SSKeychain passwordForService:keyChainAccessGroup account:keyChainUser] forKey:@"user_login_name"];
    [item setObject:[SSKeychain passwordForService:keyChainAccessGroup account:keyChainLoginToken] forKey:@"user_pass"];
    [item setObject:[NSNumber numberWithInteger:5] forKey:@"user_type"];
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    NSString *currentVersion = [infoDic objectForKey:@"CFBundleShortVersionString"];
    [item setObject:currentVersion forKey:@"version"];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:item,@"Content",@"Login",@"Act",@"Members",@"Mod", nil];
    [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:YES andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        int code = [[resultDic  objectForKey:@"Code"] intValue];
        if (code == 0000) {
            
            self.userInfo = [[resultDic objectForKey:@"DetailInfo"] mutableCopy];
            
            //发送通知刷新数据
            [[NSNotificationCenter defaultCenter]postNotificationName:kRefreshAutoLoginData object:nil];
            [[NSNotificationCenter defaultCenter]postNotificationName:kRefreshAttentData object:nil];
            
            //获取未读信息
            [self getNoReadInfo];
            
            if ([BPush getChannelId]) {
                [self registerBPush];
            }
            
            [self.delegeta autoLoginSuccess];
            
        }else {
            self.userInfo = nil;
        }
    }];
}

//点击通知启动应用
-(void)launchingWithPushArg:(NSDictionary *)pushDictionary{
    
    if(pushDictionary){
        ZLog(@"Receive push");
        if (![self.userInfo objectForKey:@"id"]) {
            return;
        }
        [_mainTabVC getPushDic:pushDictionary AndType:pushDictionary[@"type"]];
        
        return;
    }
}

- (int)reachBility{
    NetworkStatus internetStatus=[[Reachability reachabilityForInternetConnection] currentReachabilityStatus];
    int networkready = 0;
    switch(internetStatus){
        case NotReachable:
            networkready = 0;
            break;
        case ReachableViaWWAN:
            networkready = 1;
            break;
        case ReachableViaWiFi:
            networkready = 1;
            break;
        default:
            networkready = 1;
            break;
    }
    return networkready;
}

#pragma mark - ShareSDK
- (void)shareContext:(NSDictionary *)shareDic
{

    ZLog(@"%@",shareDic);
    //  ZLog(@"%@",shareDic);
    NSArray *oneKeyShareList = [ShareSDK getShareListWithType:
                                ShareTypeQQ,ShareTypeWeixiSession,ShareTypeWeixiTimeline, nil];
    
    id<ISSCAttachment> image;
    if ([shareDic objectForKey:@"image"]) {
        image = [ShareSDK pngImageWithImage:[shareDic objectForKey:@"image"]];
    }else{
        image = [ShareSDK imageWithPath:[[NSBundle mainBundle] pathForResource:@"1024" ofType:@"png"]];
    }
    //构造分享内容
    id<ISSContent> publishContent = [ShareSDK content:[shareDic objectForKey:@"content"]
                                       defaultContent:@""
                                                image:image
                                                title:
                                     [shareDic objectForKey:@"title"]?
                                     [shareDic objectForKey:@"title"]:
                                     @"逛逛生活"
                                                  url:
                                     [shareDic objectForKey:@"url"]?
                                     [shareDic objectForKey:@"url"]:
                                     @"https://www.guangguang.net.cn/app/index.html"
                                          description:nil
                                            mediaType:SSPublishContentMediaTypeNews];
    
    [ShareSDK showShareActionSheet:nil
                         shareList:oneKeyShareList
                           content:publishContent
                     statusBarTips:YES
                       authOptions:nil
                      shareOptions: nil
                            result:^(ShareType type, SSResponseState state, id<ISSPlatformShareInfo> statusInfo, id<ICMErrorInfo> error, BOOL end) {
                                if (state == SSResponseStateSuccess)
                                {
                                    NSLog(@"分享成功");
                                    UIAlertView *alertV = [[UIAlertView alloc]initWithTitle:@"提示" message:@"分享成功！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定",nil];
                                    [alertV show];
                                    
                                }else if (state == SSResponseStateFail)
                                {
                                    NSLog(NSLocalizedString(@"TEXT_SHARE_FAI", @"发布失败!errorCode == %d, errorDescription == %@"), [error errorCode], [error errorDescription]);
                                    UIAlertView *alertV = [[UIAlertView alloc]initWithTitle:@"提示" message:@"分享失败!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定",nil];
                                    [alertV show];
                                    
                                }
                            }];
    
}
#pragma mark - ShareSDK - 只有微信
- (void)shareContextOnlyWechat:(NSDictionary *)shareDic
{
    //定制⼀一键分享列表
    NSArray *oneKeyShareList = [ShareSDK getShareListWithType:
                                ShareTypeWeixiSession,ShareTypeWeixiTimeline, nil];
    ZLog(@"%@",shareDic);
    NSString *imagePath;
    if ([shareDic objectForKey:@"image"]) {
        imagePath = [shareDic objectForKey:@"image"];
    }else
        imagePath= [[NSBundle mainBundle] pathForResource:@"1024" ofType:@"png"];
    
    UIImage *shareimage = [UIImage imageNamed:imagePath];
    
    //构造分享内容
    id<ISSContent> publishContent = [ShareSDK content:[shareDic objectForKey:@"content"]
                                       defaultContent:@""
                                                image:[ShareSDK pngImageWithImage:shareimage]
                                                title:
                                     [shareDic objectForKey:@"title"]?
                                     [shareDic objectForKey:@"title"]:
                                     @"逛逛生活"
                                                  url:
                                     [shareDic objectForKey:@"url"]?
                                     [shareDic objectForKey:@"url"]:
                                     @"https://www.guangguang.net.cn/app/index.html"
                                          description:nil
                                            mediaType:SSPublishContentMediaTypeNews];
    
    [ShareSDK showShareActionSheet:nil
                         shareList:oneKeyShareList
                           content:publishContent
                     statusBarTips:YES
                       authOptions:nil
                      shareOptions: nil
                            result:^(ShareType type, SSResponseState state, id<ISSPlatformShareInfo> statusInfo, id<ICMErrorInfo> error, BOOL end) {
                                if (state == SSResponseStateSuccess)
                                {
                                    NSLog(@"分享成功");
                                    UIAlertView *alertV = [[UIAlertView alloc]initWithTitle:@"提示" message:@"分享成功！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定",nil];
                                    [alertV show];
                                }else if (state == SSResponseStateFail)
                                {
                                    NSLog(NSLocalizedString(@"TEXT_SHARE_FAI", @"发布失败!errorCode == %d, errorDescription == %@"), [error errorCode], [error errorDescription]);
                                    UIAlertView *alertV = [[UIAlertView alloc]initWithTitle:@"提示" message:@"分享失败!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定",nil];
                                    [alertV show];
                                    
                                }
                            }];
    
}

//设置当前选中的tab
- (void)setTabSelect : (int)index{
    [_mainTabVC setSelectedIndex:index];
    
    [UIView beginAnimations:nil context:nil];
    [_mainTabVC.selectImage setFrame:CGRectMake(SCREEN_WIDTH/4 * index, 0, SCREEN_WIDTH/4, 49)];
    [UIView commitAnimations];
}
//是否安装微信
- (BOOL)isInstallWX{
    
    return [WXApi isWXAppInstalled];
    
}


@end
