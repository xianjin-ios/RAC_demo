//
//  payConfirmViewController.m
//  GGSH
//
//  Created by siqiyang on 15/7/7.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "payConfirmViewController.h"
#import "myAddressViewController.h"
#import "LineView.h"
#import "ProductOrderBaseCell.h"
#import "confirmAddressCellVC.h"
#import "editAddressViewController.h"
#import "orderResultViewController.h"

@interface payConfirmViewController ()<SETADDRESS_DELEGATE>
{
    double preMoney;
    
    UIImageView *pay1Icon;//银联在线
    UIImageView *pay2Icon;//支付宝
    UIImageView *pay3Icon;//到店自取
    UIImageView *pay4Icon;//送货上门
    UIImageView *pay5Icon;//微信支付
    
    UITextView *textDetail;
    
    int type;//1-上门自取，2-送货上门
    NSMutableArray *arrAddress;
    NSMutableDictionary *dicAddress;
    NSInteger index;
    
    NSMutableArray *_dataArray;
}
@property (nonatomic,retain) NSString *platform;

@end

@implementation payConfirmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"提交订单";
    [self cancelTapHideKeyBoard:YES];
    ZLog(@"%@",self.infoDict);
    if ([self.infoDict objectForKey:@"goodlist"]) {
        _dataArray = [self.infoDict objectForKey:@"goodlist"];

    }
    
    //获取地址信息
    arrAddress = [NSMutableArray array];
    index = 0;
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(selectNewAddress:) name:@"selectNewAddress" object:nil];
    [self getAddressList];
    
    //预付钱数
    preMoney = 0;
    double totleMoney = 0;
    
    for(int i = 0; i < _dataArray.count; i++){
        NSDictionary *dict = [_dataArray objectAtIndex:i];
        
        //支付类型1：模糊价格；2：正常价格； 3：定制服务
        NSString *prcType = [dict objectForKey:@"pircestatus"];
        double perPrc = [[dict objectForKey:@"goodsprice"] doubleValue];
        if([prcType isEqualToString:@"1"]){
            //预付商品以最高价计算
            perPrc = [[dict objectForKey:@"endprice"] doubleValue];
        }
        double num = [[dict objectForKey:@"goodsnum"] doubleValue];
        totleMoney += perPrc * num;
        
        //预付
        NSString *preMoneyStr = [dict objectForKey:@"prepay"];
        preMoney += preMoneyStr.doubleValue * num;
        
    }
    NSString *totalStr = [NSString stringWithFormat:@"商品金额合计：%.2f",totleMoney/100];
    NSMutableAttributedString *prcStr1 = [[NSMutableAttributedString alloc]initWithString:totalStr];
    [prcStr1 addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(7, totalStr.length-7)];
    [lbTotal setAttributedText:prcStr1];
    
    NSString *yufuStr = [NSString stringWithFormat:@"预付金额合计：%.2f",preMoney/100];
    NSMutableAttributedString *prcStr2 = [[NSMutableAttributedString alloc]initWithString:yufuStr];
    [prcStr2 addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(7, yufuStr.length-7)];
    [lbYufu setAttributedText:prcStr2];

    ZLog(@"%f",preMoney);

    //初始化上门自取
    type= 1;
    [_tableView reloadData];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //友盟统计
    [MobClick beginLogPageView:@"G_SUBMMIT_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    self.confirmBtn.userInteractionEnabled = YES;
    //友盟统计
    [MobClick endLogPageView:@"G_SUBMMIT_VIEW"];
    
}

- (void)getOrderPayResult:(NSNotification *)notification{
    [self hideHUD];
    if ([notification.object isEqualToString:@"success"])
    {
        [self showAlert:nil withTitle:@"支付成功！" haveCancelButton:NO];
        
    }
    else
    {
        [self showAlert:nil withTitle:@"支付失败！" haveCancelButton:NO];
    }
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _dataArray.count + 4;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row < _dataArray.count) {
        return 80;
    }else if (indexPath.row == _dataArray.count){
        return 40;
    }else if (indexPath.row == _dataArray.count + 1){
        
        NSMutableDictionary *idicAddress = [self setDicAddress];
        double height = [confirmAddressCellVC getHeight:idicAddress withType:type];
        return height + 20;
    }else if (indexPath.row == _dataArray.count + 2){
        return 60;
    }else {
        return 60;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row < _dataArray.count) {
        static NSString *CellIdentifier = @"TOPCELL";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.clipsToBounds = YES;
            
            UIImageView *proIcon = [[UIImageView alloc]initWithFrame:CGRectMake(15, 5, 70, 70)];
            proIcon.tag = 1105;
            proIcon.image = [UIImage imageNamed:@"mpos_icon.png"];
            [cell.contentView addSubview:proIcon];
            
            UILabel *lbGoodsname = [[UILabel alloc]initWithFrame:CGRectMake(90, 5, SCREEN_WIDTH - 90 - 60, 20)];
            lbGoodsname.tag = 1101;
            lbGoodsname.textColor = [UIColor blackColor];
            lbGoodsname.textAlignment = 0;
            lbGoodsname.font = [UIFont systemFontOfSize:15];
            [cell.contentView addSubview:lbGoodsname];
            lbGoodsname.text = @"商品名称";
            
            UILabel *lbNum = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 60, 5, 50, 20)];
            lbNum.tag = 1102;
            lbNum.textColor = [UIColor blackColor];
            lbNum.font = [UIFont systemFontOfSize:15];
            lbNum.textAlignment = 2;
            [cell.contentView addSubview:lbNum];
            lbNum.text = @"x1";
            
            UILabel *lbMoneyTitle = [[UILabel alloc]initWithFrame:CGRectMake(90, 30, 80, 20)];
            lbMoneyTitle.textColor = [UIColor blackColor];
            lbMoneyTitle.font = [UIFont systemFontOfSize:15];
            lbMoneyTitle.textAlignment = 0;
            [cell.contentView addSubview:lbMoneyTitle];
            lbMoneyTitle.text = @"售价：";
            
            UILabel *lbMoney = [[UILabel alloc]initWithFrame:CGRectMake(180, 30, SCREEN_WIDTH - 190, 20)];
            lbMoney.tag = 1103;
            lbMoney.textColor = [UIColor redColor];
            lbMoney.font = [UIFont systemFontOfSize:15];
            lbMoney.textAlignment = 2;
            lbMoney.adjustsFontSizeToFitWidth = YES;
            [cell.contentView addSubview:lbMoney];
            lbMoney.text = @"￥44.44";
            
            UILabel *lbYufuTitle = [[UILabel alloc]initWithFrame:CGRectMake(90, 55, 80, 20)];
            lbYufuTitle.textColor = [UIColor blackColor];
            lbYufuTitle.font = [UIFont systemFontOfSize:15];
            lbYufuTitle.textAlignment = 0;
            [cell.contentView addSubview:lbYufuTitle];
            lbYufuTitle.text = @"预付款：";
            
            UILabel *lbYufujin = [[UILabel alloc]initWithFrame:CGRectMake(180, 55, SCREEN_WIDTH - 190, 20)];
            lbYufujin.tag = 1104;
            lbYufujin.textColor = [UIColor redColor];
            lbYufujin.font = [UIFont systemFontOfSize:15];
            lbYufujin.textAlignment = 2;
            [cell.contentView addSubview:lbYufujin];
            lbYufujin.text = @"￥44.44";
            
            LineView *downLine = [[LineView alloc]initWithFrame:CGRectMake(0, 79.5, SCREEN_WIDTH, 0.5)];
            downLine.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
            [cell.contentView addSubview:downLine];
            
        }
        //赋值
        UILabel *lbGoodsname = (UILabel *)[cell.contentView viewWithTag:1101];
        UILabel *lbNum = (UILabel *)[cell.contentView viewWithTag:1102];
        UILabel *lbMoney = (UILabel *)[cell.contentView viewWithTag:1103];
        UILabel *lbYufujin = (UILabel *)[cell.contentView viewWithTag:1104];
        UIImageView *proIcon = (UIImageView *)[cell.contentView viewWithTag:1105];
        
        lbGoodsname.text = [[_dataArray objectAtIndex:indexPath.row] objectForKey:@"goodsname"];
        lbNum.text = [NSString stringWithFormat:@"x%@",[[_dataArray objectAtIndex:indexPath.row] objectForKey:@"goodsnum"]];
        
        lbMoney.text = [NSString stringWithFormat:@"￥%.2f",[[[_dataArray objectAtIndex:indexPath.row] objectForKey:@"goodsprice"] doubleValue]/100];
        if ([[[_dataArray objectAtIndex:indexPath.row] objectForKey:@"pircestatus"] intValue] == 1) {
            lbMoney.text = [NSString stringWithFormat:@"￥%.2f",[[[_dataArray objectAtIndex:indexPath.row] objectForKey:@"endprice"] doubleValue]/100];
            
        }
        lbYufujin.text = [NSString stringWithFormat:@"￥%.2f",[[[_dataArray objectAtIndex:indexPath.row] objectForKey:@"prepay"] doubleValue]/100];
        
        NSString *proStr = [[_dataArray objectAtIndex:indexPath.row] objectForKey:@"listpic"];
        [proIcon XK_setImageWithURL:[NSURL URLWithString:proStr] placeholderImage:nil];
        
        return cell;
    }else if (indexPath.row == _dataArray.count + 0){
        static NSString *CellIdentifier = @"peisongCELL";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.clipsToBounds = YES;
            
            UILabel *lbTitle = [[UILabel alloc]initWithFrame:CGRectMake(15, 5, SCREEN_WIDTH/2, 30)];
            lbTitle.textColor = [UIColor lightGrayColor];
            lbTitle.textAlignment = 0;
            lbTitle.font = [UIFont systemFontOfSize:15];
            [cell.contentView addSubview:lbTitle];
            lbTitle.text = @"配送方式";
            
            pay3Icon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 160, 10, 20, 20)];
            pay3Icon.image = [UIImage imageNamed:@"goods_select.png"];
            pay3Icon.highlightedImage = [UIImage imageNamed:@"goods_selected.png"];
            [cell.contentView addSubview:pay3Icon];
            
            UILabel *pay3Label = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 140, 5, 60, 30)];
            pay3Label.text = @"到店自取";
            pay3Label.font = [UIFont systemFontOfSize:13];
            [cell.contentView addSubview:pay3Label];
            
            UIButton *pay3Btn = [UIButton buttonWithType:UIButtonTypeCustom];
            pay3Btn.frame = CGRectMake(SCREEN_WIDTH - 160, 5, 80, 40);
            pay3Btn.backgroundColor = [UIColor clearColor];
            [pay3Btn addTarget:self action:@selector(doAddress1:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:pay3Btn];
            
           
            pay4Icon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 80, 10, 20, 20)];
            pay4Icon.image = [UIImage imageNamed:@"goods_select.png"];
            pay4Icon.highlightedImage = [UIImage imageNamed:@"goods_selected.png"];
            [cell.contentView addSubview:pay4Icon];
            
            UILabel *pay4Label = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 60, 5, 60, 30)];
            pay4Label.text = @"送货上门";
            pay4Label.font = [UIFont systemFontOfSize:13];
            [cell.contentView addSubview:pay4Label];
            
            UIButton *pay4Btn = [UIButton buttonWithType:UIButtonTypeCustom];
            pay4Btn.frame = CGRectMake(SCREEN_WIDTH - 80, 5, 80, 40);
            pay4Btn.backgroundColor = [UIColor clearColor];
            [pay4Btn addTarget:self action:@selector(doAddress2:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:pay4Btn];
            
            LineView *downLine = [[LineView alloc]initWithFrame:CGRectMake(0, 39.5, SCREEN_WIDTH, 0.5)];
            downLine.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
            [cell.contentView addSubview:downLine];
            
        }
        
        if (type == 1) {
            pay3Icon.highlighted = YES;
            pay4Icon.highlighted = NO;

        }else if (type == 2){
            pay3Icon.highlighted = NO;
            pay4Icon.highlighted = YES;

        }

        return cell;
    }else if (indexPath.row == _dataArray.count + 1){
        static NSString *CellIdentifier = @"shouhuoCELL";
        
        ProductOrderBaseCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[ProductOrderBaseCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor colorWithHexString:@"#dfdfdf"];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.clipsToBounds = YES;
            
            confirmAddressCellVC *ctrl = [[confirmAddressCellVC alloc]init];
            ctrl.view.autoresizingMask = UIViewAutoresizingNone;
            ctrl.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, cell.frame.size.height - 1);
            [cell.contentView addSubview:ctrl.view];
            cell.ctrl = ctrl;
            ctrl.navigationController = self.navigationController;
            
            UIImageView *nextIcon = [[UIImageView alloc]init];
            nextIcon.frame = CGRectMake(SCREEN_WIDTH - 15, 34, 9, 13);
            nextIcon.image = [UIImage imageNamed:@"app_next.png"];
            nextIcon.tag = 111;
            [cell.contentView addSubview:nextIcon];
            
            LineView *downLine = [[LineView alloc]initWithFrame:CGRectMake(0, 79.5, SCREEN_WIDTH, 0.5)];
            downLine.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
            downLine.tag = 112;
            [cell.contentView addSubview:downLine];
            
        }
        UIImageView *nextIcon = (UIImageView *)[cell.contentView viewWithTag:111];
        LineView *downLine = (LineView *)[cell.contentView viewWithTag:112];
        confirmAddressCellVC * ctrl = (confirmAddressCellVC*)cell.ctrl;
        if (type == 1) {
            nextIcon.hidden = YES;
        }else if (type == 2){
            nextIcon.hidden = NO;
        }
        dicAddress = [self setDicAddress];
        double height = [confirmAddressCellVC getHeight:dicAddress withType:type]+10;
        ctrl.view.frame = CGRectMake(0, 1, SCREEN_WIDTH, height - 1);
        [nextIcon setFrame:CGRectMake(SCREEN_WIDTH - 15, height/2 - 6, 9, 13)];
        [downLine setFrame:CGRectMake(0, height - 0.5, SCREEN_WIDTH, 0.5)];
        [ctrl loadData:dicAddress withType:(int)type];
        
        return cell;
    }else if (indexPath.row == _dataArray.count + 2){
        static NSString *CellIdentifier = @"payCELL";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.clipsToBounds = YES;
            
            UILabel *lbTitle = [[UILabel alloc]initWithFrame:CGRectMake(15, 5, 110, 30)];
            lbTitle.textColor = [UIColor lightGrayColor];
            lbTitle.textAlignment = 0;
            lbTitle.font = [UIFont systemFontOfSize:15];
            [cell.contentView addSubview:lbTitle];
            lbTitle.text = @"预付款支付方式";
            
            //判断是否有预付款
            if (preMoney != 0) {
                
                //银联
                pay1Icon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 160, 35, 20, 20)];
                pay1Icon.image = [UIImage imageNamed:@"goods_select.png"];
                pay1Icon.highlightedImage = [UIImage imageNamed:@"goods_selected.png"];
                [cell.contentView addSubview:pay1Icon];
                
                UILabel *pay1Label = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 140, 30, 60, 30)];
                pay1Label.text = @"银联在线";
                pay1Label.font = [UIFont systemFontOfSize:13];
                [cell.contentView addSubview:pay1Label];
                
                UIButton *pay1Btn = [UIButton buttonWithType:UIButtonTypeCustom];
                pay1Btn.frame = CGRectMake(SCREEN_WIDTH - 160, 30, 80, 30);
                pay1Btn.backgroundColor = [UIColor clearColor];
                [pay1Btn addTarget:self action:@selector(doPay1:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:pay1Btn];
                //微信支付
                pay5Icon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 160, 10, 20, 20)];
                pay5Icon.image = [UIImage imageNamed:@"goods_select.png"];
                pay5Icon.highlightedImage = [UIImage imageNamed:@"goods_selected.png"];
                [cell.contentView addSubview:pay5Icon];
                
                UILabel *pay3Label = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 140, 5, 60, 30)];
                pay3Label.text = @"微信支付";
                pay3Label.font = [UIFont systemFontOfSize:13];
                [cell.contentView addSubview:pay3Label];
                
                UIButton *pay3Btn = [UIButton buttonWithType:UIButtonTypeCustom];
                pay3Btn.frame = CGRectMake(SCREEN_WIDTH - 160, 5, 80, 30);
                pay3Btn.backgroundColor = [UIColor clearColor];
                [pay3Btn addTarget:self action:@selector(doPay3:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:pay3Btn];
                
                //支付宝
                pay2Icon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 80, 10, 20, 20)];
                pay2Icon.image = [UIImage imageNamed:@"goods_select.png"];
                pay2Icon.highlightedImage = [UIImage imageNamed:@"goods_selected.png"];
                [cell.contentView addSubview:pay2Icon];
                
                UILabel *pay2Label = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 60, 5, 60, 30)];
                pay2Label.text = @"支付宝";
                pay2Label.font = [UIFont systemFontOfSize:13];
                [cell.contentView addSubview:pay2Label];
                
                UIButton *pay2Btn = [UIButton buttonWithType:UIButtonTypeCustom];
                pay2Btn.frame = CGRectMake(SCREEN_WIDTH - 80, 5, 80, 40);
                pay2Btn.backgroundColor = [UIColor clearColor];
                [pay2Btn addTarget:self action:@selector(doPay2:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:pay2Btn];
                
            }else{
                
                UILabel *nopayLabel = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 170, 5, 160, 30)];
                nopayLabel.text = @"不需支付";
                nopayLabel.textAlignment = 2;
                nopayLabel.font = [UIFont systemFontOfSize:13];
                [cell.contentView addSubview:nopayLabel];
            }
            
            LineView *downLine = [[LineView alloc]initWithFrame:CGRectMake(0, 59.5, SCREEN_WIDTH, 0.5)];
            downLine.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
            [cell.contentView addSubview:downLine];
            
        }
        //设置默认支付方式：微信支付
        if (preMoney != 0) {
            pay5Icon.highlighted = YES;
            self.platform = @"wxpay";
        }
        
        
        return cell;
    }else if (indexPath.row == _dataArray.count + 3){
        static NSString *CellIdentifier = @"beizhuCELL";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.clipsToBounds = YES;
            
            UILabel *lbTitle = [[UILabel alloc]initWithFrame:CGRectMake(15, 5, 70, 30)];
            lbTitle.textColor = [UIColor lightGrayColor];
            lbTitle.textAlignment = 0;
            lbTitle.font = [UIFont systemFontOfSize:15];
            [cell.contentView addSubview:lbTitle];
            lbTitle.text = @"备注说明";
            
            textDetail = [[UITextView alloc]initWithFrame:CGRectMake(90, 5, SCREEN_WIDTH - 100, 50)];
            textDetail.text = @"您如果有任何特殊需求，可以在这里进行描述";
            textDetail.font = [UIFont systemFontOfSize:13];
            textDetail.textColor = [UIColor colorWithHexString:@"#b0b0b0"];
            textDetail.textAlignment = NSTextAlignmentLeft;
            textDetail.delegate = self;
            [cell.contentView addSubview:textDetail];
            
            LineView *downLine = [[LineView alloc]initWithFrame:CGRectMake(0, 59.5, SCREEN_WIDTH, 0.5)];
            downLine.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
            [cell.contentView addSubview:downLine];
        }
        
        return cell;
    }else{
        return nil;
    }

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == _dataArray.count + 1){
        if (type == 1) {
            return;
        }
        //编辑收货人信息
        if (arrAddress.count == 0) {
            editAddressViewController *ctrl = [[editAddressViewController alloc]init];
            ctrl.isAddNewAddress = YES;
            ctrl.isFromMy = NO;
            ctrl.isFirst = YES;
            [self.navigationController pushViewController:ctrl animated:YES];

        }else{
            myAddressViewController *ctrl = [[myAddressViewController alloc]init];
            ctrl.delegate = self;
            ctrl.isFromMy = NO;
            ctrl.addressId = [[arrAddress objectAtIndex:index] objectForKey:@"id"];
            [self.navigationController pushViewController:ctrl animated:YES];

        }
    }
    
}

#pragma mark - textView
- (void)textViewDidBeginEditing:(UITextView *)textView {
    textDetail.text = @"";
    
    UIImage* image= [UIImage imageNamed:@"app_navBtn"];
    CGRect frame_1= CGRectMake(0, 0, 54, 24);
    UIButton* doneButton= [[UIButton alloc] initWithFrame:frame_1];
    [doneButton setBackgroundImage:image forState:UIControlStateNormal];
    [doneButton setTitle:@"完成" forState:UIControlStateNormal];
    [doneButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    doneButton.titleLabel.font=[UIFont systemFontOfSize:13];
    [doneButton addTarget:self action:@selector(inputContentDone) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem* someBarButtonItem= [[UIBarButtonItem alloc] initWithCustomView:doneButton];
    self.navigationItem.rightBarButtonItem = someBarButtonItem;
    
    [_scrollView setFrame:CGRectMake(0, -200, SCREEN_WIDTH, SCREEN_HEIGHT - 55)];
}

-(void)textViewDidEndEditing:(UITextView *)textView{
    [_scrollView setFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 55)];
    if ([textDetail.text isEqualToString:@""]) {
        textDetail.text = @"您如果有任何特殊需求，可以在这里进行描述";
    }
    
}

- (void) inputContentDone {
    [textDetail resignFirstResponder];
    self.navigationItem.rightBarButtonItem = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - buttonTarget

- (void)doAddress1:(UIButton *)sender{
    pay3Icon.highlighted = YES;
    pay4Icon.highlighted = NO;
    
    type= 1;

    [_tableView reloadData];
}

- (void)doAddress2:(UIButton *)sender{
    pay3Icon.highlighted = NO;
    pay4Icon.highlighted = YES;
    
    type= 2;

    [_tableView reloadData];
}

#pragma mark --- 银联、支付宝、微信--按钮的点击
//银联在线
- (void)doPay1:(UIButton *)sender{
    pay1Icon.highlighted = YES;
    pay2Icon.highlighted = NO;
    pay5Icon.highlighted = NO;
    self.platform = @"upmppay";

}
//支付宝
- (void)doPay2:(UIButton *)sender{
    pay1Icon.highlighted = NO;
    pay2Icon.highlighted = YES;
    pay5Icon.highlighted = NO;
    self.platform = @"alipay";

}
//微信支付
- (void)doPay3:(UIButton *)sender{
    pay1Icon.highlighted = NO;
    pay2Icon.highlighted = NO;
    pay5Icon.highlighted = YES;
    self.platform = @"wxpay";

    
}

#pragma mark - addressdelegate
//设置地址字典
- (NSMutableDictionary *)setDicAddress{
    ZLog(@"%@",MyAppDelegate.userInfo);
    if (type == 1) {//上门自取
        NSString *address = @"";
        if (_isFromCart) {//从购物车
            NSArray *goods = [self.infoDict objectForKey:@"goodlist"];
            NSDictionary *goodInfo = [goods objectAtIndex:0];
            address = [goodInfo objectForKey:@"address"];
        }
        else{
            address = [self.infoDict objectForKey:@"address"];
        }
        NSMutableDictionary *tempDic = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                        [MyAppDelegate.userInfo objectForKey:@"phone"],@"contact",
                                        address,@"address",
                                 nil];
        dicAddress = tempDic;
        
    }else if (type == 2){
        if (arrAddress.count != 0) {
            dicAddress = [arrAddress objectAtIndex:index];
        }else{
            dicAddress = nil;
        }
    }
    
    return dicAddress;
}

//选择地址代理
-(void)selectAddress:(NSInteger)selectIndex{
    index = selectIndex;
    [self setDicAddress];
    [_tableView reloadData];
}

//新添加地址通知方法
- (void)selectNewAddress:(NSNotification *)dicnoti{
    ZLog(@"%@",dicnoti.object);
    NSInteger tempIndex = [dicnoti.object integerValue];
    index = tempIndex;
    [self getAddressList];
}

#pragma mark - network
//获取地址列表
- (void)getAddressList{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"UserChange" forKey:@"Mod"];
    [dic setObject:@"selAddresslist" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"pageindex"];
    [dicContent setObject:[NSNumber numberWithInt:40] forKey:@"pagesize"];
    
    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            //??此处需要判断翻页
            arrAddress = [[resultDic objectForKey:@"DetailInfo"]mutableCopy];
            [self setDicAddress];
            if (type == 2) {
                [_tableView reloadData];
            }
        }
    }];
}

//预付
- (void)payOnline{
    [self showHUD];
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"PaySign" forKey:@"Mod"];
    [dic setObject:@"PayOnline" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
        
    }
    [dicContent setObject:self.platform forKey:@"platform"];
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"phone"];
    [dicContent setObject:[self.infoDict objectForKey:@"shopid"] forKey:@"shopid"];
    [dicContent setObject:[self.infoDict objectForKey:@"shopname"] forKey:@"shopname"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    //goods
    NSString *goodStr = [NSString string];
    if (_dataArray.count > 0) {
        for (int i = 0; i < _dataArray.count; i ++) {
            goodStr = [goodStr stringByAppendingFormat:@"%@-%@",[[_dataArray objectAtIndex:i] objectForKey:@"goodsid"],[[_dataArray objectAtIndex:i] objectForKey:@"goodsnum"]];
            if (i < _dataArray.count - 1) {
                goodStr = [goodStr stringByAppendingString:@","];
            }
        }
        [dicContent setObject:goodStr forKey:@"goods"];
    }
    
    //预付金额
    double prepay = 0;
    for (int i = 0; i < _dataArray.count; i ++) {
        prepay += [[[_dataArray objectAtIndex:i] objectForKey:@"prepay"]doubleValue] * [[[_dataArray objectAtIndex:i] objectForKey:@"goodsnum"]doubleValue];
    }
    [dicContent setObject:[NSNumber numberWithDouble:prepay] forKey:@"prepay"];
    
    //送货上门
    if ([dicAddress objectForKey:@"acceptname"]) {
        [dicContent setObject:[dicAddress objectForKey:@"acceptname"] forKey:@"acceptname"];
    }else{
        [dicContent setObject:@"" forKey:@"acceptname"];
    }
    [dicContent setObject:[dicAddress objectForKey:@"contact"] forKey:@"contact"];
    [dicContent setObject:[dicAddress objectForKey:@"address"] forKey:@"address"];
    
    //备注
    if ([textDetail.text isEqualToString:@"您如果有任何特殊需求，可以在这里进行描述"]) {
        [dicContent setObject:@"" forKey:@"remark"];
    }else{
        [dicContent setObject:textDetail.text forKey:@"remark"];
    }
    
    //配送方式
    [dicContent setObject:[NSNumber numberWithInt:type] forKey:@"transport"];
    
    //是否从购物车进入
    if (self.isFromCart == YES) {
        [dicContent setObject:@"1" forKey:@"from_flag"];
    }else if (self.isFromCart == NO){
        [dicContent setObject:@"" forKey:@"from_flag"];
    }
    NSString *enStr = [AESCrypt encrypt:[dicContent JSONRepresentation] password:KENCRYPTKEY];
    [dic setObject:enStr forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        if (data == nil || error != nil) {
            NSLog(@"kong");
            self.confirmBtn.userInteractionEnabled = YES;
            self.confirmBtn.backgroundColor = [UIColor colorWithHexString:@"FF0084"];
            
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if( [[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSString *deStr1 = [AESCrypt decrypt:[resultDic objectForKey:@"DetailInfo"] password:KDECRYPTKEY];
            ;
            NSDictionary *detailDic = [NSJSONSerialization JSONObjectWithData:[deStr1 dataUsingEncoding:NSASCIIStringEncoding] options:NSJSONReadingMutableLeaves error:nil];

            MyAppDelegate.orderNum = [detailDic objectForKey:@"num"];
            
            if ([[detailDic objectForKey:@"url"] isKindOfClass:[NSString class]] && [[detailDic objectForKey:@"url"] length] > 0) {
                ZLog(@"支付宝");
                
                ZLog(@"%@",[detailDic objectForKey:@"para"]);
                //订单号用于进入结果页面
                MyAppDelegate.orderNum = [detailDic objectForKey:@"num"];
                
                [[UIApplication sharedApplication]openURL:[NSURL URLWithString:[detailDic objectForKey:@"url"]]];
                
                //通知刷新？
                [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
                
                //返回主页
                [self.navigationController popToRootViewControllerAnimated:NO];
                
            }else{
                ZLog(@"银联");
                /**
                 *  mode:@"00" 正式版本
                 *  mode:@"01" 开发测试版
                 */
                ZLog(@"%@",[detailDic objectForKey:@"tn"]);
                
                //订单号用于进入结果页面
                MyAppDelegate.orderNum = [detailDic objectForKey:@"num"];
                
                [UPPayPlugin startPay:[NSString stringWithFormat:@"%@",[detailDic objectForKey:@"tn"]] mode:@"00" viewController:self delegate:self];
                
            }
            
            //刷新未读消息和购物车数量
            [MyAppDelegate getNoReadInfo];
            
        }
        else{
            self.confirmBtn.userInteractionEnabled = YES;
            self.confirmBtn.backgroundColor = [UIColor colorWithHexString:@"FF0084"];
            [self showAlert:nil withTitle:resultDic[@"Message"] haveCancelButton:NO];
        }
        
    }];
}

- (void)WXPayResultHandle:(NSNotification *)notify{
    if ([notify.object isEqualToString:WX_PAY_FAIL]) {
        [self showAlert:nil withTitle:@"订单支付未完成，请在”我的订单“中重新支付" haveCancelButton:NO];
        //返回主页
        [self.navigationController popToRootViewControllerAnimated:NO];
    }
    else{
        
        [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];

        //新增结果页面
        [self gotoResult];
        
        //刷新未读消息和购物车数量
        [MyAppDelegate getNoReadInfo];
        
    }
        [[NSNotificationCenter defaultCenter]removeObserver:self name:WX_PAY_RESULT object:nil];
    
}

- (void)handleWXPayIsDoing:(NSNotification *)notify{
    self.confirmBtn.userInteractionEnabled = YES;
    self.confirmBtn.backgroundColor = [UIColor colorWithHexString:@"FF0084"];
    UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"提示" message:@"订单支付未完成，请在”我的订单“中重新支付！" preferredStyle:UIAlertControllerStyleAlert];
    [alertVc addAction:[UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        MyAppDelegate.isCharging = NO;
        [self goHome];
    }]];
    
    [self presentViewController:alertVc animated:YES completion:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:WXPayIsDoing object:nil];
}

- (void)goHome{
    
    self.hideBackButton = YES;
    [self hideBackButton :YES];
    [self.navigationController popToRootViewControllerAnimated:YES];
#warning 跳转
//    [MyAppDelegate.mainTab setSelectedIndex:0];
//    [MyAppDelegate.mainTab.selectImage setFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
    
}

//预订
- (void)paySchedule{
    [self showHUD];
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Signedorder" forKey:@"Mod"];
    [dic setObject:@"Payschedule_v1" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
        
    }
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"phone"];
    NSString *shopName = @"";
    NSString *shopId = @"";
    if (_isFromCart) {
        NSArray *goods = [self.infoDict objectForKey:@"goodlist"];
        NSDictionary *goodInfo = [goods objectAtIndex:0];
        shopId = [goodInfo objectForKey:@"shopid"];
        shopName = [goodInfo objectForKey:@"shopname"];
    }
    else{
        shopName = [self.infoDict objectForKey:@"shopname"];
        shopId = [self.infoDict objectForKey:@"shopid"];
    }
    [dicContent setObject:shopId forKey:@"shopid"];
    [dicContent setObject:shopName forKey:@"shopname"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    //goods
    NSString *goodStr = [NSString string];
    if (_dataArray.count > 0) {
        for (int i = 0; i < _dataArray.count; i ++) {
            goodStr = [goodStr stringByAppendingFormat:@"%@-%@",[[_dataArray objectAtIndex:i] objectForKey:@"goodsid"],[[_dataArray objectAtIndex:i] objectForKey:@"goodsnum"]];
            if (i < _dataArray.count - 1) {
                goodStr = [goodStr stringByAppendingString:@","];
            }
        }
        [dicContent setObject:goodStr forKey:@"goods"];
    }
    
    //送货上门
    if ([dicAddress objectForKey:@"acceptname"]) {
        [dicContent setObject:[dicAddress objectForKey:@"acceptname"] forKey:@"acceptname"];
    }else{
        [dicContent setObject:@"" forKey:@"acceptname"];
    }
    [dicContent setObject:[dicAddress objectForKey:@"contact"] forKey:@"contact"];
    [dicContent setObject:[dicAddress objectForKey:@"address"] forKey:@"address"];

    //备注
    if ([textDetail.text isEqualToString:@"您如果有任何特殊需求，可以在这里进行描述"]) {
        [dicContent setObject:@"" forKey:@"remark"];
    }else{
        [dicContent setObject:textDetail.text forKey:@"remark"];
    }
    
    //配送方式
    [dicContent setObject:[NSNumber numberWithInt:type] forKey:@"transport"];
    
    //是否从购物车进入
    if (self.isFromCart == YES) {
        [dicContent setObject:@"1" forKey:@"from_flag"];
    }else if (self.isFromCart == NO){
        [dicContent setObject:@"" forKey:@"from_flag"];
    }
    NSString *enStr = [AESCrypt encrypt:[dicContent JSONRepresentation] password:KENCRYPTKEY];
    [dic setObject:enStr forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        [self hideHUD];
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if( [[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSString *deStr1 = [AESCrypt decrypt:[resultDic objectForKey:@"DetailInfo"] password:KDECRYPTKEY];
            ;
            NSDictionary *detailDic = [NSJSONSerialization JSONObjectWithData:[deStr1 dataUsingEncoding:NSASCIIStringEncoding] options:NSJSONReadingMutableLeaves error:nil];
            //新增结果页面

            orderResultViewController *ctrl = [[orderResultViewController alloc]init];
            ctrl.orderNum = [detailDic objectForKey:@"num"];
            ctrl.hideBackButton = YES;
            [self.navigationController pushViewController:ctrl animated:YES];
            
            //刷新未读消息和购物车数量
            [MyAppDelegate getNoReadInfo];
            
        }
        else{
            [self showAlert:nil withTitle:@"订单预订失败" haveCancelButton:NO];
            //返回主页
            [self.navigationController popToRootViewControllerAnimated:NO];
            
        }
    }];
}

- (IBAction)confirm:(id)sender {
    if (![MyAppDelegate whetherHaveNet]) {
        //没有网
        [self showAlert:nil withTitle:@"请查看网络设置" haveCancelButton:NO];
        return;
    }
    self.confirmBtn.userInteractionEnabled = NO;
    [self.confirmBtn setBackgroundColor:[UIColor colorWithHexString:@"AEAEAE"]];
    NSLog(@"platform %@",self.platform);
    
    //条件判断
    if (type == 1) {
        if (![dicAddress objectForKey:@"address"]) {
            [self showAlert:nil withTitle:@"请完善信息" haveCancelButton:NO];
            self.confirmBtn.userInteractionEnabled = YES;
            self.confirmBtn.backgroundColor = [UIColor colorWithHexString:@"FF0084"];
            return;
        }
    }
    //预付金额
    double prepay = 0;
    for (int i = 0; i < _dataArray.count; i ++) {
        prepay += [[[_dataArray objectAtIndex:i] objectForKey:@"prepay"]doubleValue] * [[[_dataArray objectAtIndex:i] objectForKey:@"goodsnum"]doubleValue];
    }
    if (prepay > 0) {
        //预付
        if([self.platform isEqualToString: @"wxpay"]){
            //微信支付
            if (MyAppDelegate.isCharging == YES) {
                [self showAlert:nil withTitle:@"已经发起了微信支付，请完成订单" haveCancelButton:NO];
                return;
            }
          
            

            NSMutableDictionary *addressInfo = [NSMutableDictionary dictionary];
            [addressInfo setObject:[dicAddress objectForKey:@"address"] forKey:@"address"];
            [addressInfo setObject:[dicAddress objectForKey:@"contact"] forKey:@"contact"];
            [addressInfo setObject:[self.infoDict objectForKey:@"shopname"] forKey:@"shopname"];
            
            NSMutableDictionary *dic = [NSMutableDictionary dictionary];
            [dic setObject:addressInfo forKey:@"shopinfo"];
            [dic setObject:@"" forKey:@"receivetime"];
            
            if (self.isFromCart == YES) {
                [dic setObject:@"1" forKey:@"fromFlag"];
            }else if (self.isFromCart == NO){
                [dic setObject:@"" forKey:@"fromFlag"];
            }
            if (_isFromCart) {
                NSArray *goods = [self.infoDict objectForKey:@"goodlist"];
                NSDictionary *goodInfo = [goods objectAtIndex:0];
                [addressInfo setObject:[goodInfo objectForKey:@"shopname"] forKey:@"address"];
                [dic setObject:[goodInfo objectForKey:@"shopid"] forKey:@"shopid"];
            }
            else{
                [addressInfo setObject:[self.infoDict objectForKey:@"shopname"] forKey:@"address"];
                [dic setObject:[self.infoDict objectForKey:@"shopid"] forKey:@"shopid"];
            }
            
            NSMutableDictionary *numdic = [NSMutableDictionary dictionaryWithObject:@"" forKey:@"num"];
            
            if ([dicAddress objectForKey:@"acceptname"]) {
                [dic setObject:[dicAddress objectForKey:@"acceptname"] forKey:@"acceptname"];
                
                [numdic setObject:@"2" forKey:@"transport"];
                [dicAddress objectForKey:@"address"];
            }else{
                [dic setObject:@"" forKey:@"acceptname"];
                [numdic setObject:@"1" forKey:@"transport"];
                
            }
            int sumMoney = 0;
            NSString *goods = [NSString string];
            NSArray *prepays = [self.infoDict objectForKey:@"goodlist"];
            if (_dataArray.count > 0) {
                for (int i = 0; i< prepays.count; i++) {
                    
                    int goodsnum = [[prepays[i]objectForKey:@"goodsnum"]intValue];
                    int  prepay = [[[prepays objectAtIndex:i] objectForKey:@"prepay"]intValue] ;
                    sumMoney += goodsnum * prepay;
                    
                    goods = [goods stringByAppendingFormat:@"%@-%@",[[prepays objectAtIndex:i]objectForKey:@"goodsid"],[[prepays objectAtIndex:i]objectForKey:@"goodsnum"]];
                    if (i< _dataArray.count - 1) {
                        goods = [goods stringByAppendingString:@","];
                    }
                }
            }
            
            NSString *totalMoney = [NSString stringWithFormat:@"%d",sumMoney];
            [numdic setObject:totalMoney forKey:@"prepay"];
            
            NSString *remark = @"";
            //备注
            if ([textDetail.text isEqualToString:@"您如果有任何特殊需求，可以在这里进行描述"]) {
                remark = @"";
            }else{
                remark = textDetail.text;
            }
            [dic setObject:remark forKey:@"remark"];
            [dic setObject:goods forKey:@"goods"];
            [dic setObject:numdic forKey:@"num"];
            
            //调用微信支付
            [self payWXWith:dic];
        }
        else
            
        [self payOnline];
    }else if (prepay == 0){
        //预订
        [self paySchedule];
    }
    
}

#pragma mark - 支付delegate
- (void)UPPayPluginResult:(NSString *)result
{
    if ([result isEqualToString:@"fail"]) {
        ZLog(@"%@失败",result);
     
        [self showAlert:nil withTitle:@"订单支付未完成，请在”我的订单“中重新支付" haveCancelButton:NO];
        //返回主页
        [self.navigationController popToRootViewControllerAnimated:NO];

    }else if ([result isEqualToString:@"success"]){
        ZLog(@"%@成功",result);

        [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
        
        //新增结果页面
        [self gotoResult];

        //刷新未读消息和购物车数量
        [MyAppDelegate getNoReadInfo];

    }else if ([result isEqualToString:@"cancel"]){
        ZLog(@"%@取消订单",result);
        [self showAlert:nil withTitle:@"订单支付未完成，请在”我的订单“中重新支付" haveCancelButton:NO];
      
        //返回主页
        [self.navigationController popToRootViewControllerAnimated:NO];

    }
}
#pragma mark - 跳转到支付结果界面
- (void)gotoResult{
    orderResultViewController *ctrl = [[orderResultViewController alloc]init];
    ctrl.orderNum = MyAppDelegate.orderNum;
    ctrl.hideBackButton = YES;
    [self.navigationController pushViewController:ctrl animated:YES];
}
@end
