//
//  TopScrollViewController.h
//  GGSH
//
//  Created by siqiyang on 16/1/12.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol TopScrollViewControllerDelegate <NSObject>
//设置代理，轮播图的点击的响应
- (void)pushToShopWithShopId:(NSString *)shopid;

@end
@interface TopScrollViewController : UIViewController


@property (retain, nonatomic) IBOutlet UIPageControl *pageControl;

@property (retain, nonatomic) IBOutlet UIScrollView *topScrollView;

@property (nonatomic,strong) NSMutableArray *arrNews;

@property (nonatomic,assign) id<TopScrollViewControllerDelegate>delegate;

- (void)updateTopScrollView;

@end
