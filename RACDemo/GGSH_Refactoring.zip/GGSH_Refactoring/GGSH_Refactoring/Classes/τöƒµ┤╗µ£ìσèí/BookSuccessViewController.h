//
//  BookSuccessViewController.h
//  GGSH
//
//  Created by siqiyang on 16/1/8.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface BookSuccessViewController : BaseViewController

//用于存储用户支付信息
@property (nonatomic,strong) NSMutableDictionary *userInfo;

//订单编号
@property (retain, nonatomic) IBOutlet UILabel *orderCode;

//商品名称:
@property (retain, nonatomic) IBOutlet UILabel *productName;

//订购数量
@property (retain, nonatomic) IBOutlet UILabel *bookNumber;
//产品名称折行时，会用到
@property (retain, nonatomic) IBOutlet UILabel *bookNumberTitle;

//订购时间
@property (retain, nonatomic) IBOutlet UILabel *bookDate;
//产品名称折行时，会用到
@property (retain, nonatomic) IBOutlet UILabel *bookDateTitle;

//@property (nonatomic,strong) UINavigationController *navigationController;

//我的卡券
- (IBAction)toMyCards:(id)sender;

//返回首页
- (IBAction)gotoFirstView:(id)sender;



@end
