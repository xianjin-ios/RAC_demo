//
//  JD_AQYViewController.h
//  GGSH
//
//  Created by siqiyang on 16/1/6.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface JD_AQYViewController : BaseViewController

@property (retain, nonatomic) IBOutlet UICollectionView *proCollectionView;
@property (nonatomic ,strong) NSMutableArray * proDataArray;
@property (nonatomic,strong)NSString *identifier;//标识界面（京东、爱奇艺....）
@property (nonatomic,strong) UIView *noView;

@end
