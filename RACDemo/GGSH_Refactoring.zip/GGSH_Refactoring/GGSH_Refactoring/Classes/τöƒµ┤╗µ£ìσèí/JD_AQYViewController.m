//
//  JD_AQYViewController.m
//  GGSH
//
//  Created by siqiyang on 16/1/6.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "JD_AQYViewController.h"
#import "JD_AQYCollectionViewCell.h"
//产品详情页
#import "ProductDetailViewController.h"
//#import "lookGoodsCell.h"
@interface JD_AQYViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,MJRefreshBaseViewDelegate>
{
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    int pageIndex;
    
}
@end

@implementation JD_AQYViewController
static NSString *Id = @"JDIQY";
- (void)viewDidLoad {
    [super viewDidLoad];
    self.proDataArray = [NSMutableArray arrayWithCapacity:2];
    [self cancelTapHideKeyBoard:YES];
    //注册 collectionViewCell
    [self.proCollectionView registerNib:[UINib nibWithNibName:@"JD_AQYCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:Id];
    self.proCollectionView.scrollEnabled = YES;
    self.proCollectionView.alwaysBounceVertical = YES;
    self.proCollectionView.showsHorizontalScrollIndicator = NO;
    self.proCollectionView.showsVerticalScrollIndicator = NO;
    _header = [MJRefreshHeaderView header];
    _header.scrollView = self.proCollectionView;
    _header.delegate = self;
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = self.proCollectionView;
    _footer.delegate = self;
    
    [self getProductInfo];
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //友盟统计
//    [MobClick beginLogPageView:@"G_JDAQY_VIEW"];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
//    [MobClick endLogPageView:@"G_JDAQY_VIEW"];
    
}
- (void)getProductInfo{
    
    [self showHUD];
    NSMutableDictionary *contentDic = [[NSMutableDictionary alloc]init];
    [contentDic setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
    
    [contentDic setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    [contentDic setObject:self.identifier forKey:@"ecptype"];//产品类型
    [contentDic setObject:@"1" forKey:@"devicetype"];
    [contentDic setObject:KVERSION forKey:@"version_name"];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    [dic setObject:@"UserChange" forKey:@"Mod"];
    [dic setObject:@"getCardProductEcp" forKey:@"Act"];
    [dic setObject:contentDic forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        ZLog(@"%@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *jsDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        if (self.proDataArray.count !=0) {
            [self.proDataArray removeAllObjects];
        }
        if ([jsDic[@"Code"] isEqualToString:@"0000"]) {
            
            NSArray *array = jsDic[@"DetailInfo"];
            for (NSDictionary *dic in array) {
                [self.proDataArray addObject:dic];
            }
            if (self.proDataArray.count == 0) {
                
                //无数据显示
                self.noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                self.noView.backgroundColor = [UIColor clearColor];
                self.noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [self.noView addSubview:bigbeen];
                [self.proCollectionView addSubview:self.noView];
            }
        }
        else{
            [self showAlert:@"系统错误，请稍后重试！" withTitle:@"提示" haveCancelButton:NO];
        }
        [self hideHUD];
        [self.proCollectionView reloadData];

        
    }];
    
//    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
//    //转化为string
//    NSString *jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
//    NSLog(@"+++ %@",jsonString);
//    NSURL *url = [NSURL URLWithString:kMposAppUrl];
//    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
//    [request setRequestMethod:@"POST"];
//    [request setPostValue:jsonString forKey:@"JsonString"];
//    [request setCompletionBlock:^{
//        NSString *responseString = request.responseString;
//        NSLog(@"responseString:%@",responseString);
//        NSData *jsData = [responseString dataUsingEncoding:NSUTF8StringEncoding];
//        NSDictionary *jsDic = [NSJSONSerialization JSONObjectWithData:jsData options:NSJSONReadingAllowFragments error:nil];
//        if (self.proDataArray.count !=0) {
//            [self.proDataArray removeAllObjects];
//        }
//        if ([jsDic[@"Code"] isEqualToString:@"0000"]) {
//            
//            NSArray *array = jsDic[@"DetailInfo"];
//            for (NSDictionary *dic in array) {
//                [self.proDataArray addObject:dic];
//            }
//            if (self.proDataArray.count == 0) {
//                
//                //无数据显示
//                self.noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
//                self.noView.backgroundColor = [UIColor clearColor];
//                self.noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
//                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
//                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
//                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
//                labela.backgroundColor = [UIColor clearColor];
//                labela.text = @"暂无内容";
//                labela.textAlignment = 1;
//                labela.font = [UIFont systemFontOfSize:15];
//                labela.textColor = [UIColor lightGrayColor];
//                [bigbeen addSubview:labela];
//                [self.noView addSubview:bigbeen];
//                [self.proCollectionView addSubview:self.noView];
//            }
//        }
//        [self hideHUD];
//        [self.proCollectionView reloadData];
//    }];
//    [request setFailedBlock:^{
//        [MyAppDelegate showAlert:@"系统错误，请稍后重试！"];
//        [self hideHUD];
//    }];
//    
//    [request startAsynchronous];
    
}
#pragma mark - 刷新的代理方法进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
//    if(0 == [MyAppDelegate reachBility]){
//        [MyAppDelegate showAlert:@"无网络连接"];
//        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
//        return;
//    }
    
    if(refreshView == _header) {// 下拉刷新
        pageIndex = 1;
        [self getProductInfo];
    }else if (refreshView == _footer){//上拉加载更多
        if(self.proDataArray.count%10 == 0){//每页有10个数据
            pageIndex += 1;
            [self getProductInfo];
        }
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    return;
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

#pragma mark --- collectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return self.proDataArray.count;
}
#pragma mark --- cell的
//边框
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

- (UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dic = self.proDataArray[indexPath.item];
    JD_AQYCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:Id forIndexPath:indexPath];
    [cell.proImageView XK_setImageWithURL:[NSURL URLWithString:dic[@"goodspic"]]  placeholderImage:[UIImage imageNamed:@"goodsDefaultImage"]];
    cell.proName.text = [NSString stringWithFormat:@"%@",dic[@"product_name"]];
    NSString *proPriceStr = dic[@"sellprice"];
    cell.proPrice.text = [NSString stringWithFormat:@"￥%.2f",proPriceStr.floatValue*0.01];
    
    cell.proSaleNum.text = [NSString stringWithFormat:@"已售出%@",dic[@"storenum"]];
    
    return cell;
    
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    //产品类型
    //京东E卡-PROType_JDEK 、爱奇艺-PROType_AQY、话费充值-tel、电影票-movie、Q币-qcoins、流量充值--
    NSDictionary *dic = self.proDataArray[indexPath.item];
    ProductDetailViewController *detailVC = [[ProductDetailViewController alloc]init];
  
    detailVC.title = dic[@"product_name"];

    detailVC.productType = dic[@"ecptype"];
    detailVC.productDic = dic;
    detailVC.hideBackButton = NO;
    [self.navigationController pushViewController:detailVC animated:YES];
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
