//
//  SubmitOrderViewController.h
//  GGSH
//
//  Created by siqiyang on 16/1/8.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "BaseVCWithPay.h"


//新增支付类型
typedef enum {
    WeixinPay = 0,
    ZhifubaoPay,
    YinlinPay
}PayType;//支付类型
@interface SubmitOrderViewController : BaseVCWithPay

@property (retain, nonatomic) IBOutlet UIButton *confirmBtn;

@property (nonatomic,assign) PayType payType;

//底层的滚动控件
@property (retain, nonatomic) IBOutlet UIScrollView *mainScrollView;
//产品图
@property (retain, nonatomic) IBOutlet UIImageView *proImageView;

@property (nonatomic,strong) NSString *pcode;
@property (nonatomic,strong) NSString *proType;
@property (nonatomic,strong) NSString *proImageViewUrlStr;
@property (nonatomic,strong)NSString *brand_code;//品牌code
//产品名
@property (retain, nonatomic) IBOutlet UILabel *proName;
@property (nonatomic,strong) NSString *productName;

//预订数
@property (retain, nonatomic) IBOutlet UILabel *bookNum;
@property (nonatomic,strong) NSString * bookNumber;

//售价（单价）
@property (retain, nonatomic) IBOutlet UILabel *salePrice;
@property (nonatomic,strong) NSString * price;

//总价格
@property (retain, nonatomic) IBOutlet UILabel *totalPrice;
//微信
@property (nonatomic,retain) IBOutlet UIButton *weixin;
@property (nonatomic,strong) UIImageView *weixinType;
- (IBAction)weixinClick:(id)sender;


//银联
@property (retain, nonatomic) IBOutlet UIButton *yinLian;
@property (nonatomic,strong) UIImageView *yinLianType;
- (IBAction)yinLianClick:(id)sender;

//支付宝
@property (retain, nonatomic) IBOutlet UIButton *zhifubao;
@property (nonatomic,strong) UIImageView *zhifubaoType;

//提交订单成功后，用于存储用户的支付信息
@property (nonatomic,strong) NSMutableDictionary *userInfo;

- (IBAction)zhifubaoClick:(id)sender;
@property (retain, nonatomic) IBOutlet UIView *lineView;

//确认
- (IBAction)verify:(id)sender;


@end
