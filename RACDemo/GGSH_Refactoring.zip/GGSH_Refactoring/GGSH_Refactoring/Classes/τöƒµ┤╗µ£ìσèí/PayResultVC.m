//
//  PayResultVC.m
//  GGSH
//
//  Created by siqiyang on 15/10/8.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "PayResultVC.h"
#import "LineView.h"

@interface PayResultVC ()
{
    
    IBOutlet UIScrollView *_scrollview;
    
    IBOutlet UIView *_topView;
    
    
    NSDictionary *backDic;
    
}
@end

@implementation PayResultVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"充值结果";
    
    LineView *downLine = [[LineView alloc]initWithFrame:CGRectMake(0, _topView.frame.size.height+_topView.frame.origin.y, SCREEN_WIDTH, 0.5)];
    downLine.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
    [_scrollview addSubview:downLine];
    
    [self loadDetailView:nil];
    
    [self getOrderData];
}

#pragma mark - network
-(void)getOrderData{
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"userOrder" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:MyAppDelegate.orderNum forKey:@"num"];
    
    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    //转换为NSString
    NSData* result = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonString = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
    
    ZLog(@"jsonString = %@",jsonString);
    
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
          [self hideHUD];
        ZLog(@"responseString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        ZLog(@"registe info:%@",[resultDic objectForKey:@"Message"]);
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            //加载详情
            backDic = [resultDic objectForKey:@"DetailInfo"];
            
            [self loadDetailView:backDic];
            
        }
        else{
            [self showalertString:[resultDic objectForKey:@"Message"]];
        }

        
    }];

}

- (void)loadDetailView:(NSDictionary *)dic{
    
    NSInteger top = 106 + 10;
    
    //订单编号
    UILabel *lbOrder = (UILabel *)[_scrollview viewWithTag:101];
    if (lbOrder == nil) {
        lbOrder = [[UILabel alloc]init];
    }
    [lbOrder setFrame:CGRectMake(15, top, SCREEN_WIDTH - 30, 20)];
    [lbOrder setFont:[UIFont systemFontOfSize:13]];
    [lbOrder setBackgroundColor:[UIColor clearColor]];
    [lbOrder setTextColor:[UIColor blackColor]];
    [lbOrder setTextAlignment:NSTextAlignmentLeft];
    [lbOrder setTag:101];
    [_scrollview addSubview:lbOrder];
    
    NSString *orderStr = [NSString stringWithFormat:@"%@",[[dic objectForKey:@"payInfo"] objectForKey:@"num"]];
    [lbOrder setText:[NSString stringWithFormat:@"订单编号:%@",orderStr]];
    
    top += 25;
    
    //充值手机号
    UILabel *lbPhone = (UILabel *)[_scrollview viewWithTag:102];
    if (lbPhone == nil) {
        lbPhone = [[UILabel alloc]init];
    }
    [lbPhone setFrame:CGRectMake(15, top, SCREEN_WIDTH - 30, 20)];
    [lbPhone setFont:[UIFont systemFontOfSize:13]];
    [lbPhone setBackgroundColor:[UIColor clearColor]];
    [lbPhone setTextColor:[UIColor blackColor]];
    [lbPhone setTextAlignment:NSTextAlignmentLeft];
    [lbPhone setTag:102];
    [_scrollview addSubview:lbPhone];
    
    NSString *phoneStr = [NSString stringWithFormat:@"%@",[[dic objectForKey:@"payInfo"] objectForKey:@"ecp_ext"]];
    [lbPhone setText:[NSString stringWithFormat:@"充值手机号:%@",phoneStr]];
    
    top += 25;
    
    //商品名称
    UILabel *lbGoods = (UILabel *)[_scrollview viewWithTag:107];
    if (lbGoods == nil) {
        lbGoods = [[UILabel alloc]init];
    }
    [lbGoods setFrame:CGRectMake(15, top, SCREEN_WIDTH - 30, 20)];
    [lbGoods setFont:[UIFont systemFontOfSize:13]];
    [lbGoods setBackgroundColor:[UIColor clearColor]];
    [lbGoods setTextColor:[UIColor blackColor]];
    [lbGoods setTextAlignment:NSTextAlignmentLeft];
    [lbGoods setTag:107];
    [_scrollview addSubview:lbGoods];
    
    NSString *goodsname = [[[dic objectForKey:@"goodsDetail"] objectAtIndex:0] objectForKey:@"goodsname"];
    [lbGoods setText:[NSString stringWithFormat:@"商品名称:%@",goodsname]];
    
    top += 25;
    
    //支付金额
    UILabel *lbMoney = (UILabel *)[_scrollview viewWithTag:103];
    if (lbMoney == nil) {
        lbMoney = [[UILabel alloc]init];
    }
    [lbMoney setFrame:CGRectMake(15, top, SCREEN_WIDTH - 30, 20)];
    [lbMoney setFont:[UIFont systemFontOfSize:13]];
    [lbMoney setBackgroundColor:[UIColor clearColor]];
    [lbMoney setTextColor:[UIColor blackColor]];
    [lbMoney setTextAlignment:NSTextAlignmentLeft];
    [lbMoney setTag:103];
    [_scrollview addSubview:lbMoney];
    
    double price = [[[dic objectForKey:@"payInfo"] objectForKey:@"paymoney"] doubleValue];
    [lbMoney setText:[NSString stringWithFormat:@"支付金额:%.2f元",price/100]];
    
    top += 25;
    
    //充值时间
    UILabel *lbTime = (UILabel *)[_scrollview viewWithTag:104];
    if (lbTime == nil) {
        lbTime = [[UILabel alloc]init];
    }
    [lbTime setFrame:CGRectMake(15, top, SCREEN_WIDTH - 30, 20)];
    [lbTime setFont:[UIFont systemFontOfSize:13]];
    [lbTime setBackgroundColor:[UIColor clearColor]];
    [lbTime setTextColor:[UIColor blackColor]];
    [lbTime setTextAlignment:NSTextAlignmentLeft];
    [lbTime setTag:104];
    [_scrollview addSubview:lbTime];
    
    NSString *timeStr = [NSString stringWithFormat:@"%@",[[dic objectForKey:@"payInfo"] objectForKey:@"ctime"]];
    [lbTime setText:[NSString stringWithFormat:@"充值时间:%@",timeStr]];
    
    top += 25;
    
    LineView *downLine = (LineView *)[_scrollview viewWithTag:105];
    if (downLine == nil) {
        downLine = [[LineView alloc]init];
    }
    [downLine setFrame:CGRectMake(0, top, SCREEN_WIDTH, 0.5)];
    downLine.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
    [downLine setTag:105];
    [_scrollview addSubview:downLine];
    
    top += 100;
    
    UIButton *btn = (UIButton *)[_scrollview viewWithTag:106];
    if (btn != nil) {
        [btn removeFromSuperview];
    }
    btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setFrame:CGRectMake((SCREEN_WIDTH - 120)/2, top, 120, 40)];
    [btn setBackgroundColor:[UIColor colorWithHexString:@"#ff0085"]];
    [btn setTitle:@"返回首页" forState:UIControlStateNormal];
    [btn.titleLabel setFont:[UIFont systemFontOfSize:15]];
    [btn setTag:106];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(backToHome) forControlEvents:UIControlEventTouchUpInside];
    [_scrollview addSubview:btn];
}

- (void)backToHome{
    [MyAppDelegate.mainTabVC setSelectedIndex:0];
    [MyAppDelegate.mainTabVC.selectImage setFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.hideBackButton = YES;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
