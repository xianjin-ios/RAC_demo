//
//  PayResultVC.h
//  GGSH
//
//  Created by siqiyang on 15/10/8.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface PayResultVC : BaseViewController

@end
