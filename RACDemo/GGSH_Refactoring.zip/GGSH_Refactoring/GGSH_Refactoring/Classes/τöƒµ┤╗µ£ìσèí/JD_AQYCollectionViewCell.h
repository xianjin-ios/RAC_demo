//
//  JD_AQYCollectionViewCell.h
//  GGSH
//
//  Created by siqiyang on 16/1/7.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JD_AQYCollectionViewCell : UICollectionViewCell
@property (retain, nonatomic) IBOutlet UIImageView *proImageView;

@property (retain, nonatomic) IBOutlet UILabel *proName;

@property (retain, nonatomic) IBOutlet UILabel *proPrice;

@property (retain, nonatomic) IBOutlet UILabel *proSaleNum;

@property (nonatomic,copy) NSString *imageName;

@end
