//
//  JD_AQYCollectionViewCell.m
//  GGSH
//
//  Created by siqiyang on 16/1/7.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "JD_AQYCollectionViewCell.h"



@implementation JD_AQYCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.proName.font = [UIFont systemFontOfSize:12];
    self.proName.numberOfLines = 0;
    self.proPrice.font = [UIFont systemFontOfSize:12];
    self.proSaleNum.font = [UIFont systemFontOfSize:11];
}

- (void)setImageName:(NSString *)imageName{
    
    _imageName = [imageName copy];
    [self.proImageView setImage:[UIImage imageNamed:_imageName]];
    
}


@end
