//
//  SubmitOrderViewController.m
//  GGSH
//
//  Created by siqiyang on 16/1/8.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "SubmitOrderViewController.h"
#import "BookSuccessViewController.h"
#import "UPPayPlugin.h"


@interface SubmitOrderViewController ()<UPPayPluginDelegate>
{
    BOOL isZhifubao;

}
@end

@implementation SubmitOrderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"提交订单";
    
    if (self.userInfo != nil) {
        self.userInfo = nil;
    }
    self.userInfo = [[NSMutableDictionary alloc]init];
    _payType = WeixinPay;//默认微信支付
    [self.weixin setImage:[UIImage imageNamed:@"goods_selected"] forState:UIControlStateNormal];
    [self.yinLian setImage:[UIImage imageNamed:@"goods_select"] forState:UIControlStateNormal];
    [self.zhifubao setImage:[UIImage imageNamed:@"goods_select"] forState:UIControlStateNormal];
    
    //显示 预订 产品个数、单价、总价格
    self.bookNum.text = [NSString stringWithFormat:@"x%@",self.bookNumber];
    self.proName.text = self.productName;
    self.salePrice.text = [NSString stringWithFormat:@"￥%.2f",self.price.floatValue * 0.01];
    self.totalPrice.text = [NSString stringWithFormat:@"￥%.2f",(self.price.floatValue)* (self.bookNumber.intValue) * 0.01];
    //    self.proImageView.noBorderFlag = YES;//YES--隐藏边框，默认为NO
    [self.proImageView XK_setImageWithURL:self.proImageViewUrlStr placeholderImage:[UIImage imageNamed:@"goodsDefaultImage"]];

    self.mainScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, self.view.frame.size.height - 150);
    self.mainScrollView.bounces = YES;
    self.mainScrollView.showsHorizontalScrollIndicator = NO;//关闭水平线
    self.mainScrollView.showsVerticalScrollIndicator = NO;
    self.mainScrollView.scrollEnabled = YES;
    
}

- (void)resetButtonState {
    self.confirmBtn.userInteractionEnabled = YES;
    self.confirmBtn.backgroundColor = [UIColor colorWithHexString:@"FF0084"];
}

#pragma mark -- UPPayPluginDelegate 银联支付结果回调
- (void)UPPayPluginResult:(NSString *)result{
    
        if ([result isEqualToString:@"fail"]) {
            ZLog(@"%@失败",result);
            [self showalertString1:@"订单支付未完成，请在”我的订单“中重新支付"];
           
    
        }else if ([result isEqualToString:@"success"]){
            ZLog(@"%@成功",result);
    
            [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
    
            //新增结果页面
            BookSuccessViewController *ctrl = [[BookSuccessViewController alloc]init];
            ctrl.hideBackButton = YES;
    
            [self.navigationController pushViewController:ctrl animated:YES];
    
        }else if ([result isEqualToString:@"cancel"]){
            ZLog(@"%@取消订单",result);
            [self showalertString1:@"订单支付未完成，请在”我的订单“中重新支付"];
          
    
        }
    
    
    
}
- (void)showalertString1:(NSString *)alertSting{
    UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"提示" message:alertSting preferredStyle:UIAlertControllerStyleAlert];
    [alertVc addAction:[UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        MyAppDelegate.isCharging = NO;
        //返回首页
        [self goHome];
        
    }]];
    
    [self presentViewController:alertVc animated:YES completion:nil];
}
//微信支付
- (IBAction)weixinClick:(id)sender{
    self.payType = WeixinPay;
    [self.weixin setImage:[UIImage imageNamed:@"goods_selected"] forState:UIControlStateNormal];
    [self.yinLian setImage:[UIImage imageNamed:@"goods_select"] forState:UIControlStateNormal];
    [self.zhifubao setImage:[UIImage imageNamed:@"goods_select" ] forState:UIControlStateNormal];
    
}
//支付宝支付
- (IBAction)zhifubaoClick:(id)sender {
    
    self.payType = ZhifubaoPay;
    [self.weixin setImage:[UIImage imageNamed:@"goods_select"] forState:UIControlStateNormal];
    [self.yinLian setImage:[UIImage imageNamed:@"goods_select"] forState:UIControlStateNormal];
    [self.zhifubao setImage:[UIImage imageNamed:@"goods_selected"] forState:UIControlStateNormal];
    
}
//银联支付
- (IBAction)yinLianClick:(id)sender {
    
    self.payType = YinlinPay;
    [self.yinLian setImage:[UIImage imageNamed:@"goods_selected"] forState:UIControlStateNormal];
    [self.zhifubao setImage:[UIImage imageNamed:@"goods_select"] forState:UIControlStateNormal];
    [self.weixin setImage:[UIImage imageNamed:@"goods_select"] forState:UIControlStateNormal];
    
}
// 确认
- (IBAction)verify:(id)sender {
    
    //判断有网
        if (![MyAppDelegate whetherHaveNet]) {
    
            [self showalertString:@"请查看网络设置"];
    
            return;
        }
    self.confirmBtn.userInteractionEnabled = NO;
    [self.confirmBtn setBackgroundColor:[UIColor colorWithHexString:@"AEAEAE"]];
    if (self.payType == ZhifubaoPay || self.payType == YinlinPay) {
        NSString *platform = @"alipay";
        if(self.payType == YinlinPay){
           platform = @"upmppay";
        }

        NSString *total = [NSString stringWithFormat:@"%f",(self.price.doubleValue)* (self.bookNumber.doubleValue)];
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        [dic setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"ecp_ext"];
        [dic setObject:@"" forKey:@"num"];
        [dic setObject:platform forKey:@"platform"];
        [dic setObject:self.price forKey:@"sellprice"];//价格，精确到分
        [dic setObject:self.productName forKey:@"product_name"];//商户名字
        [dic setObject:total forKey:@"sellprice"];//支付价格
        [dic setObject:self.brand_code forKey:@"brand_code"];//品牌code
        [dic setObject:[NSString stringWithFormat:@"%@_%@",self.proType,self.pcode] forKey:@"pcode"];//大类商品代号_小类商品代号(tel_yd1)
        [dic setObject:self.bookNumber forKey:@"goodsnum"];//商品数量
        
        [self payEcpWith:dic];
    }
    else if(self.payType == WeixinPay){
        //微信支付
        if ([WXApi isWXAppInstalled]) {
            NSString *total = [NSString stringWithFormat:@"%d",(self.price.intValue)* (self.bookNumber.intValue)];
            NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                 self.productName,@"product_name",
                                 self.price,@"sellprice",
                                 total,@"paymoney",
                                 MyAppDelegate.userInfo[@"phone"],@"phone",
                                 @"",@"num",
                                 [NSString stringWithFormat:@"%@_%@",
                                  self.proType,self.pcode],@"pcode",
                                 self.brand_code,@"brandcode",
                                 self.bookNumber,@"goodsnum",
                                 nil];
            [self payEcpWXWith : dic];
        }else{
            [self showAlert:nil withTitle:@"尚未安装微信" haveCancelButton:NO];
        }
    }
}

- (void)payWXFail{
    self.confirmBtn.userInteractionEnabled = YES;
    self.confirmBtn.backgroundColor = [UIColor colorWithHexString:@"FF0084"];
}

- (void)WXPayResultHandle:(NSNotification *)notify{
    NSString *result = notify.object;
        if ([result isEqualToString: WX_PAY_SUCCESS ]) {
            //支付成功，进入结果页面
            //新增结果页面
            [self showalertString:@"支付成功"];
            BookSuccessViewController *ctrl = [[BookSuccessViewController alloc]init];
            ctrl.hideBackButton = YES;
            [self.navigationController pushViewController:ctrl animated:YES];
    
        }else{
            //        支付失败，返回生活服务首页
            [self showalertString:@"订单支付未完成，请在”我的订单“中重新支付"];
            [self goHome];
    
        }
        //移除通知
        [[NSNotificationCenter defaultCenter] removeObserver:self name:WX_PAY_RESULT object:nil];
}
//返回首页
- (void)goHome{
    
    self.hideBackButton = YES;
    [self hideBackButton :YES];

    [MyAppDelegate.mainTabVC.selectImage setFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
    [MyAppDelegate.mainTabVC setSelectedIndex:0];
    [self.navigationController popToRootViewControllerAnimated:YES];
    
    
}
- (void)handleWXPayIsDoing:(NSNotification *)notify{
    
    UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"提示" message:@"订单支付未完成，请在”我的订单“中重新支付" preferredStyle:UIAlertControllerStyleAlert];
    [alertVc addAction:[UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        MyAppDelegate.isCharging = NO;
        [self goHome];
    }]];
    
    [self presentViewController:alertVc animated:YES completion:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:WXPayIsDoing object:nil];
    
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.confirmBtn.userInteractionEnabled = YES;
    
}
@end
