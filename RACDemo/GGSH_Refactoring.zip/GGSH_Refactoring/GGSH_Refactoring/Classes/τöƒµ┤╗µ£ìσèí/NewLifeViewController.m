//
//  NewLifeViewController.m
//  GGSH
//
//  Created by siqiyang on 16/1/6.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "NewLifeViewController.h"
#import "LoginVC.h"
#import "MyMessageVC.h"
#import "mposDetailViewController.h"
#import "PhoneViewController.h"
#import "JD_AQYViewController.h"
#import "NewLifeTypeButton.h"
#import "MJRefresh.h"
#import "NewsCtrl.h"

//轮播图的高度为125
#define TOP_Height  125

#define BUTTON_Width  150
#define BUTTON_Height 100
@interface NewLifeViewController ()<NewsSelectDelegate,MJRefreshBaseViewDelegate,loginDelegate>
{
    NewsCtrl *_newContrl;
    UIView *alertView;
    MJRefreshHeaderView *_header;
    
}
@property (nonatomic, retain) NSDate *date;
@property (nonatomic,strong) NSMutableArray *newsArray;//存储轮播数据
@property (nonatomic,strong) NSMutableArray *types;
@end
//
@implementation NewLifeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"生活服务";
    _newsArray = [[NSMutableArray alloc]init];
    _mainScrollView.scrollEnabled = YES;
    _mainScrollView.showsHorizontalScrollIndicator = YES;
    _mainScrollView.pagingEnabled = YES;
    [self cancelTapHideKeyBoard:YES];
    _types = [[NSMutableArray alloc]init];
    self.picArray = [[NSMutableArray alloc]init];
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _mainScrollView;
    _header.delegate = self;
    

    [self addMessageBtn];
    
    [self getLifeTypeData];
    [self getTopScrollData];
}


- (void)showLogin{
    LoginVC *loginV = [[LoginVC alloc]init];
    loginV.delegate = self;
    UINavigationController * navi = [[UINavigationController alloc] initWithRootViewController:loginV];
    [self presentViewController:navi animated:YES completion:nil];
}

//登录成功
- (void)finishLogin{
    [self getLifeTypeData];
}

//登录失败
- (void)cancelLogin{
    [MyAppDelegate setTabSelect:0];
}

/**
 获取轮播数据信息
 */
- (void)getTopScrollData{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Members" forKey:@"Mod"];
    [dic setObject:@"carousel" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    [dicContent setObject:@"3" forKey:@"type"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    [xkNetwork xk_requstWithDic:dic withUrl: kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        //        转换为NSString
        NSString *jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"jsonString = %@",jsonString);
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            //获取数据成功
            NSArray * arrNews = [resultDic objectForKey:@"DetailInfo"];
            [_newsArray addObjectsFromArray: arrNews];
            if (!_newContrl) {
                _newContrl = [[NewsCtrl alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,TOP_Height)];
                _newContrl.urlString = @"img";
                _newContrl.delegate = self;
                [self.mainScrollView addSubview:_newContrl.view];
            }
            [_newContrl setNewsArray:arrNews];
        }
    }];
    
    
}
- (void)addMessageBtn{
    
    UIButton *messageButton = [UIButton buttonWithType:UIButtonTypeCustom];
    messageButton.frame = CGRectMake(0, 0, 16, 16);
    [messageButton addTarget:self action:@selector(gotoMessage) forControlEvents:UIControlEventTouchUpInside];
    [messageButton setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    messageButton.titleLabel.font = [UIFont systemFontOfSize:13];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:messageButton];
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
    
}
#pragma mark -- 轮播图跳转到店铺首页
- (void)newsSelect:(NSInteger)index{
    NSDictionary *shopDic = [_newsArray objectAtIndex:index];
    mposDetailViewController *vc = [[mposDetailViewController alloc]init];
    vc.shopId = [shopDic objectForKey:@"shopid"];
    [self.navigationController pushViewController:vc animated:YES];
    
    
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    if(!MyAppDelegate.userInfo){
        [self showLogin];
    }
}
#pragma mark -- MJRefreshDelegate
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{

    if(refreshView == _header) {// 下拉刷新
        
        
        //3秒内不能重复发起网络请求，只是界面上闪动下正在加载，就1s。
        if(self.date){
            NSDate *tenMiniteLater = [self.date dateByAddingTimeInterval:3];
            NSDate *currentDate = [NSDate date];
            if(NSOrderedDescending == [tenMiniteLater compare:currentDate]){
                ZLog(@"ascending");
                self.date = [NSDate date];
                [self performSelector:@selector(OneSecondElapse) withObject:nil afterDelay:1];
                [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
                return;
            }
            
            //网络请求
            //刷新首页数据
            [self getLifeTypeData];
            [self getTopScrollData];
            
            
        }else{
            self.date = [NSDate date];
            //网络请求
            //刷新首页数据
            [self getLifeTypeData];
            [self getTopScrollData];
            
        }
        
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
}

//1s的假loading，取消正在加载就好
- (void)OneSecondElapse{
    [self hideHUD];
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
}

#pragma mark --- 获取生活服务类型
- (void)getLifeTypeData{
    NSString *uid = [MyAppDelegate.userInfo objectForKey:@"id"];
    NSString *token = [MyAppDelegate.userInfo objectForKey:@"logintoken"];
    NSDictionary *dic = @{@"Mod":@"Goods",@"Act":@"gServicesLifeTypeEcp",@"Content":@{@"uid":uid?uid:@"",@"logintoken":token?token:@""}};
    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST"  isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
                NSString *responseString = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
                ZLog(@"*** responseString** =\n%@ ",responseString);
                NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
                if ([[responseDic objectForKey:@"Code"]isEqualToString:@"0000"]) {
                    if (_types.count) {
                        [_types removeAllObjects];
                    }
                    [_types addObjectsFromArray: [responseDic objectForKey:@"DetailInfo"]];
                    [self addButtons];
                }
    }];
     

}
#pragma mark - 类型的跳转按钮
- (void)addButtons{
 
    for (int i = 0; i<_types.count; i++) {
        int num1 = i%2;
        int num2 = i/2;
        NSDictionary *btnDic = [_types objectAtIndex:i];
        NewLifeTypeButton *button = [[NewLifeTypeButton  alloc]initWithFrame:CGRectMake(6 + num1 * (BUTTON_Width +7), TOP_Height+5+num2*(BUTTON_Height +10),BUTTON_Width , BUTTON_Height)];
        [button setFirstTitle:btnDic[@"category_name"] andSecondTitle:btnDic[@"desc"] andImageName:btnDic[@"imgurl"]];
        
        button.tag = i+1;//tag : 1--6
        [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.mainScrollView addSubview:button];
    }
    self.mainScrollView.contentSize = CGSizeMake(self.mainScrollView.frame.size.width, BUTTON_Height*(_types.count*0.5 + 1) + TOP_Height);
    
}
//消息按钮的点击
- (void)gotoMessage{
    
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];
}
//按钮点击跳转页面
- (void)buttonClick:(id)sender{
   UIButton *button = (UIButton*)sender;
   NSInteger index = button.tag - 1;
   NSDictionary *typeDic = [_types objectAtIndex:index];
    NSString *status = [typeDic objectForKey:@"status"];
    if ([status isEqualToString:@"2"]) {
         [self showAlert:@"敬请期待..."];
        return;
    }
   NSInteger type = ((NSString *)[typeDic objectForKey:@"type"]).integerValue;

    switch (type) {
        case 1://话费充值

        {
            PhoneViewController *ctrl = [[PhoneViewController alloc]init];
            ctrl.hideBackButton = NO;
            [self.navigationController pushViewController:ctrl animated:YES];
        }
            break;
        case 2://京东E卡、爱奇艺、
        {
            JD_AQYViewController *ctrl = [[JD_AQYViewController alloc]init];
         
            ctrl.hideBackButton = NO;
            
            ctrl.title = [typeDic objectForKey:@"category_name"];
            ctrl.identifier = [typeDic objectForKey:@"category_code"];
            [self.navigationController pushViewController:ctrl animated:YES];
            
        }
            break;
        case 3://流量充值
            
            
            [self showAlert:@"敬请期待..."];
            
            
            break;
//        case 4://爱奇艺VIP卡
//        {
//            JD_AQYViewController *ctrl = [[JD_AQYViewController alloc]init];
//            ctrl.hideBackButton = NO;
//            ctrl.title = @"爱奇艺VIP卡";
//            ctrl.identifier = PROType_AQY;
//            [self.navigationController pushViewController:ctrl animated:YES];
//            
//            
//        }
//            break;
//        case 5://QQ币充值
//            
//            
//            [self showAlert:@"敬请期待..."];
//            
//            NSLog(@"QQ币充值");
//            break;
//        case 6://电影票
//            
//            [self showAlert:@"敬请期待..."];
//            
//            NSLog(@"电影票");
//            break;
//        default:
//
//            break;
    }
    
}

- (void)pageClick:(id)sender{
    //获取分页控件此时的页码号
//    NSInteger currentPage = _pageControl.currentPage;
//    [UIView animateWithDuration:1 animations:^{
//        _topScrollView.contentOffset = CGPointMake(currentPage * WIDTH, 0);
//    }];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)showAlert:(NSString *)str
{
    float w = self.view.frame.size.width;
    float h = self.view.frame.size.height;
    if (!alertView) {
        alertView = [[UIView alloc]initWithFrame:CGRectMake(w * 0.5 - 75, h * 0.5 - 20, 150, 35)];
        alertView.backgroundColor = [UIColor clearColor];
        UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 150, 40)];
        img.image = [UIImage imageNamed:@"app_alertViewBG.png"];
        [alertView addSubview:img];
        
        UILabel *label1 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 150, 35)];
        label1.text = str;
        label1.font = [UIFont systemFontOfSize:15];
        label1.backgroundColor = [UIColor clearColor];
        label1.textAlignment = NSTextAlignmentCenter;
        label1.adjustsFontSizeToFitWidth = YES;
        label1.textColor = [UIColor whiteColor];
        [alertView addSubview:label1];
        [self.view addSubview:alertView];
        
    }
    
    [self performSelector:@selector(hideAlert) withObject:self afterDelay:1.2];
    
}

- (void)hideAlert
{
    if (alertView) {
        [alertView removeFromSuperview];
        alertView = nil;
    }
}


@end
