//
//  PhoneViewController.m
//  GGSH_Refactoring
//
//  Created by siqiyang on 16/9/26.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "PhoneViewController.h"
#import "ChoosePaywayVC.h"

#define PhoneBtn_height  50
#define Space 15
@interface PhoneViewController ()<UITextFieldDelegate>
{
    
    __weak IBOutlet UITextField *phoneText;
    __weak IBOutlet UIButton *cancelBtn;
    
    __weak IBOutlet UIScrollView *mainScroll;

    NSString *phoneStr;
}
@property (nonatomic,strong) UIView *phoneBtnView;
@property (nonatomic,strong) NSMutableArray *phoneArray;
@property (nonatomic,strong) NSMutableDictionary *selectPriceInfo;

- (IBAction)cancelBtnClick:(id)sender;
@end

@implementation PhoneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"话费充值";
    _phoneArray = [[NSMutableArray alloc]init];
    _selectPriceInfo = [[NSMutableDictionary alloc]init];
    [self cancelTapHideKeyBoard:YES];
    [self getPhoneInfo];
    [self createPhoneView];
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismissKeyboard)];
    tap1.cancelsTouchesInView = YES;
    [mainScroll addGestureRecognizer:tap1];
    
}
- (void)dismissKeyboard{
    [self.view endEditing:YES];
    if (phoneText.text.length == 0) {
        [self cancelBtnClick:nil];
    }
}
/**
  获取手机的信息
 */
- (void)getPhoneInfo{
  
    [self showHUD];
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"UserChange" forKey:@"Mod"];
    [dic setObject:@"getTelProductEcp" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
        
    }
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    if (phoneStr) {
        NSString *tempPhoneStr = [phoneStr stringByReplacingOccurrencesOfString:@" " withString:@""];
        [dicContent setObject:tempPhoneStr forKey:@"phone"];
        
    }else{
        [dicContent setObject:@"" forKey:@"phone"];
        
    }
    [dic setObject:dicContent forKey:@"Content"];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
           [phoneText resignFirstResponder];
        ZLog(@"******* responseString= %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        if ([[responseDic objectForKey:@"Code"]isEqualToString:@"0000"]) {
            if (_phoneArray.count) {
                [_phoneArray removeAllObjects];
            }
            [_phoneArray addObjectsFromArray:[responseDic objectForKey:@"DetailInfo"]];
            
            [self createPhoneView];
        }
        else{
            [self showAlert:[responseDic objectForKey:@"Message"] withTitle:@"提示" haveCancelButton:NO];
        }
        
        
    }];
    
    
    
}

- (void)createPhoneView{
    NSInteger top = 20;
    if (_phoneBtnView == nil) {
        _phoneBtnView = [[UIView alloc]init];
        [mainScroll addSubview:_phoneBtnView];
        NSInteger height = [self getPhoneBtnSuperViewHeight];
        _phoneBtnView.frame = CGRectMake(0, top, SCREEN_WIDTH, height);
        
        if (_phoneArray.count >0) {
            top += height +10;
            //创建几种充值的按钮
            [self createPhoneBtns];
            
        }
//        top += 50;
       
    }
    else{
        if (_phoneArray.count >0) {
            NSInteger height = [self getPhoneBtnSuperViewHeight];
            _phoneBtnView.frame = CGRectMake(0, top, SCREEN_WIDTH, height);
            top += height +10;
            if (_phoneArray.count >0) {
                //创建几种充值的按钮
                [self createPhoneBtns];
            }
            //创建几种充值的按钮
            [self createPhoneBtns];
        }

    }
    
    UILabel *lbMoneyTotal = (UILabel *)[mainScroll viewWithTag:2000];
    if (!lbMoneyTotal) {
        lbMoneyTotal = [[UILabel alloc]init];
        lbMoneyTotal.backgroundColor = [UIColor clearColor];
        lbMoneyTotal.textColor = [UIColor colorWithHexString:@"#4f4f4f"];
        lbMoneyTotal.font = [UIFont systemFontOfSize:15];
        lbMoneyTotal.textAlignment = NSTextAlignmentRight;
        lbMoneyTotal.tag = 2000;
        [mainScroll addSubview:lbMoneyTotal];
    }
   lbMoneyTotal.frame = CGRectMake(15, top, SCREEN_WIDTH - 30, 50);
    NSString *prc = [NSString stringWithFormat:@"售价:￥0.00"];
    [lbMoneyTotal setTextColor:[UIColor colorWithHexString:@"#FF4F01"]];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:prc];
    [str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#4f4f4f"] range:NSMakeRange(0,3)];
    [str addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:NSMakeRange(0, 3)];
    lbMoneyTotal.attributedText = str;
    
    UIButton *btn = (UIButton *)[mainScroll viewWithTag:101];
    if (btn == nil) {
        btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setBackgroundColor:[UIColor colorWithHexString:@"#ff0084"]];
        [btn setTitle:@"立即充值" forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:15]];
        [btn setTag:101];
        [btn addTarget:self action:@selector(doAct:) forControlEvents:UIControlEventTouchUpInside];
        [mainScroll addSubview:btn];
    }
    
    [btn setFrame:CGRectMake(15,  top +=50, SCREEN_WIDTH - 30, 40)];

}
#pragma Mark-创建按钮们
- (void)createPhoneBtns{
    CGFloat btnW = (SCREEN_WIDTH - 60)/3.0;
    for (int i = 0; i<_phoneArray.count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setFrame:CGRectMake(Space + (i%3)*(btnW + Space), (1+i/3) *PhoneBtn_height, btnW, PhoneBtn_height - 8)];
        [btn setBackgroundColor:[UIColor clearColor]];
        [btn setTitleColor:[UIColor colorWithHexString:@"#4F4F4F"] forState:UIControlStateNormal];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:15]];
        [btn setTitle:[NSString stringWithFormat:@"%.0f元",[[[_phoneArray objectAtIndex:i] objectForKey:@"goodsprice"] doubleValue]/100] forState:UIControlStateNormal];
        btn.layer.borderWidth = 0.5f;
        btn.layer.borderColor = [UIColor colorWithHexString:@"#b7b7b7"].CGColor;
        [btn setTag:1000 + i];
        [btn addTarget:self action:@selector(doTouch:) forControlEvents:UIControlEventTouchUpInside];
        [_phoneBtnView addSubview:btn];
        
    }
    
}
- (void)doAct:(UIButton *)sender{
    UIButton *btn = (UIButton *)sender;
    NSInteger tag = btn.tag;
    
    NSString *tempPhoneStr = [phoneText.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (tempPhoneStr.length < 11) {
        [self showalertString:@"请输入充值手机号"];
        
        return;
    }
    
    if (![self isValidateMobile:tempPhoneStr]) {
        [self showalertString:@"请输入正确的手机号码"];
        return;
    }
    if ([[_selectPriceInfo objectForKey:@"sellprice"]doubleValue] <= 0) {
        [self showalertString:@"请选择充值金额"];
        return;
    }
    if (tag == 101) {
        ChoosePaywayVC *ctrl = [[ChoosePaywayVC alloc]init];
        ctrl.dicData = _selectPriceInfo;
        ctrl.phoneStr = tempPhoneStr;
        [self.navigationController pushViewController:ctrl animated:YES];
        
    }
    
}
#pragma mark - textFieldDelegate

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    [cancelBtn setHidden:NO];
    
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if (range.location > 0 && range.length == 1 && string.length == 0)
    {
        // Stores cursor position
        UITextPosition *beginning = textField.beginningOfDocument;
        UITextPosition *start = [textField positionFromPosition:beginning offset:range.location];
        NSInteger cursorOffset = [textField offsetFromPosition:beginning toPosition:start] + string.length;
        // Save the current text, in case iOS deletes the whole text
        NSString *text = textField.text;
        
        // Trigger deletion
        [textField deleteBackward];
        
        // iOS deleted the entire string
        if (textField.text.length != text.length - 1)
        {
            textField.text = [text stringByReplacingCharactersInRange:range withString:string];
            // Update cursor position
            UITextPosition *newCursorPosition = [textField positionFromPosition:textField.beginningOfDocument offset:cursorOffset];
            UITextRange *newSelectedRange = [textField textRangeFromPosition:newCursorPosition toPosition:newCursorPosition];
            [textField setSelectedTextRange:newSelectedRange];
        }
        return NO;
    }else{
        if (textField.text.length <= 12) {
            if (string == nil) {
                return YES;
            }
            //adjust phone number style
            if (textField.text.length == 3) {
                textField.text = [textField.text stringByAppendingString:@" "];
            }else if (textField.text.length == 8){
                textField.text = [textField.text stringByAppendingString:@" "];
            }
            
            phoneStr = [textField.text stringByAppendingString:string];
            
            if (textField.text.length == 12) {
             
                [self getPhoneInfo];

            }
            return YES;
            
        }else{
            
            return NO;
        }
    }
    
}

//- (void)textFieldDidEndEditing:(UITextField *)textField{
//      [self.view endEditing:YES];
//}
- (IBAction)cancelBtnClick:(id)sender {
     phoneText.text = @"";
    [self.view endEditing:YES];
    if (_phoneArray.count > 0) {
          [_phoneArray removeAllObjects];
    }
    [cancelBtn setHidden:YES];
    
}
- (NSInteger)getPhoneBtnSuperViewHeight{
    NSInteger height = 0;
    if (_phoneArray.count>0) {
        if (_phoneArray.count %3 == 0) {
            height =  PhoneBtn_height * _phoneArray.count / 3  + PhoneBtn_height;
        }
        else{
            height =  PhoneBtn_height * (_phoneArray.count / 3 + 1) + PhoneBtn_height; ;
        }
        
    }
    
    return height;
}
/*手机号码验证 MODIFIED BY HELENSONG*/
-(BOOL) isValidateMobile:(NSString *)mobile
{
    //手机号以13， 15，18开头，八个 \d 数字字符
    NSString *phoneRegex = @"^((13[0-9])|(147)|(145)|(17[0,6-8])|(15[^4,\\D])|(18[0-9]))\\d{8}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    //    ZLog(@"phoneTest is %@",phoneTest);
    return [phoneTest evaluateWithObject:mobile];
}
#pragma mark - 选择要充值的价格的按钮的点击
- (void)doTouch:(UIButton *)sender{
    UIButton *btn = (UIButton *)sender;
    NSInteger tag = btn.tag;
    
    for (UIButton *tempBtn in _phoneBtnView.subviews) {
        if (tempBtn.tag == tag) {
            tempBtn.layer.borderColor = [UIColor colorWithHexString:@"#ff0084"].CGColor;
        }else{
            tempBtn.layer.borderColor = [UIColor colorWithHexString:@"#b7b7b7"].CGColor;
        }
    }
    
    UILabel *lbMoneyTotal = (UILabel *)[mainScroll viewWithTag:2000];
    
    _selectPriceInfo = [self.phoneArray objectAtIndex:tag-1000];
    double price = [[_selectPriceInfo objectForKey:@"sellprice"]doubleValue];
    NSString *prc = [NSString stringWithFormat:@"售价:￥%.2f",price/100];
    [lbMoneyTotal setTextColor:[UIColor colorWithHexString:@"#FF4F01"]];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:prc];
    [str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#4f4f4f"] range:NSMakeRange(0,3)];
    [str addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:NSMakeRange(0, 3)];
    lbMoneyTotal.attributedText = str;
    
}

@end
