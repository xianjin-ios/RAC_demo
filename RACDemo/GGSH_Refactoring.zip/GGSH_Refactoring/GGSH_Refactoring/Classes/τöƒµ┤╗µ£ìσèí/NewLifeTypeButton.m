//
//  NewLifeTypeButton.m
//  GGSH
//
//  Created by siqiyang on 16/1/7.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "NewLifeTypeButton.h"

#define BTN_Height self.frame.size.height
#define BTN_Width  self.frame.size.width
@implementation NewLifeTypeButton

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 5;
        self.layer.borderColor = [[UIColor colorWithHexString:@"#F0F0F0"]CGColor];
        self.layer.borderWidth = 0.5;
        self.backgroundColor = [UIColor clearColor];
        //BtnImageView
        _btnImageView = [[UIImageView alloc]initWithFrame:CGRectMake(BTN_Width - 150, BTN_Height-100, 150, 100)];

        [self addSubview:_btnImageView];
        //firstLabel
        self.firstLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 10, BTN_Width - 20, 20)];
        _firstLabel.textColor = [UIColor colorWithHexString:@"#000000"];
        _firstLabel.font = [UIFont systemFontOfSize:15];
        [self addSubview:_firstLabel];
        //DetailLabel
        _detailLabal = [[UILabel alloc]initWithFrame:CGRectMake(10, 30, BTN_Width - 20, 15)];
        _detailLabal.textColor = [UIColor colorWithHexString:@"#636363"];
        _detailLabal.font = [UIFont systemFontOfSize:13];
        [self addSubview:_detailLabal];
        
    }
    return self;
}
- (void)setFirstTitle:(NSString *)first andSecondTitle:(NSString *)second andImageName:(NSString *)imageUrl{
    
    _firstLabel.text = first;
    _detailLabal.text = second;
    [_btnImageView XK_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:nil];
    
}

@end
