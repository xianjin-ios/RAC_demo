//
//  ProductDetailViewController.h
//  GGSH
//
//  Created by siqiyang on 16/1/7.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface ProductDetailViewController : BaseViewController

@property (retain, nonatomic) IBOutlet UIScrollView *mainScrollView;

@property (nonatomic,strong) NSDictionary *productDic;

@property (nonatomic,strong) NSString *productType;
//产品图
@property (retain, nonatomic) IBOutlet UIImageView *productPic;

@property (nonatomic,strong) NSString *brand_code;//品牌code
@property (nonatomic,strong) NSString *pcode;

//产品描述
@property (retain, nonatomic) IBOutlet UILabel *proDes;

//单价价格
@property (retain, nonatomic) IBOutlet UILabel *priceLabel;


//已售数量
@property (retain, nonatomic) IBOutlet UILabel *saledNum;


@property (retain, nonatomic) IBOutlet UIButton *minBtn;

- (IBAction)minBtnClick:(id)sender;


- (IBAction)plusBtnClick:(id)sender;


@property (retain, nonatomic) IBOutlet UIButton *plusBtn;


@property (retain, nonatomic) IBOutlet UITextField *numField;

- (IBAction)bookInstant:(id)sender;


@end
