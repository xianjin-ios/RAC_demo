//
//  BookSuccessViewController.m
//  GGSH
//
//  Created by siqiyang on 16/1/8.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "BookSuccessViewController.h"
//#import "NewLifeViewController.h"
//#import "myCouponTypeVC.h"
@interface BookSuccessViewController ()

@end

@implementation BookSuccessViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.userInfo = [[NSMutableDictionary alloc]init];
    self.title = @"订购成功";
    [self getSuccessInfo];
    [self hideBackButton:YES];
}

- (void)getSuccessInfo{
    NSLog(@"订单号：%@",MyAppDelegate.orderNum);
//    //组合参数
    NSMutableDictionary *contentDic = [[NSMutableDictionary alloc]init];
    [contentDic setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
    [contentDic setObject:@"1" forKey:@"devicetype"];//1--iOS
    [contentDic setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    [contentDic setObject:MyAppDelegate.orderNum forKey:@"num"];//订单号20160112165410149100
    [contentDic setObject:[MyAppDelegate getDeviceToken ]forKey:@"devicetoken"];
    [contentDic setObject:KVERSION forKey:@"version_name"];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"userOrder" forKey:@"Act"];
    [dic setObject:contentDic forKey:@"Content"];
    [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (error) {
            [self showAlert:@"网络错误，请稍后重试" withTitle:@"提示" haveCancelButton:NO];
        }
        ZLog(@"responseString= %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        if ([[responseDic objectForKey:@"Code"] isEqualToString:@"0000"]) {
            self.userInfo = [dic objectForKey:@"DetailInfo"];
            [MyAppDelegate getNoReadInfo];
            [self refreshUI];
        }
         else {
            [self showAlert:@"网络错误，请稍后重试" withTitle:@"提示" haveCancelButton:NO];
        }
    }];
  
    
//    NSString *jsonString = [[NSString alloc]initWithData:result encoding:NSUTF8StringEncoding];
//    NSURL *url = [NSURL URLWithString:KHTTPSURL];
//    __block ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
//    [request setRequestMethod:@"POST"];
//    [MyAppDelegate checkNetStatus];
//    [request setValidatesSecureCertificate:NO];
//    [self showHUD];
//    [request setPostValue:jsonString forKey:@"JsonString"];
//    [request setCompletionBlock:^{
//        NSString *responseString = [request responseString];
//        NSData *resultData = [responseString dataUsingEncoding:NSUTF8StringEncoding];
//        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:resultData options:NSJSONReadingMutableLeaves error:nil];
//        if ([dic[@"Code"]isEqualToString:@"0000"]) {
//            self.userInfo = dic[@"DetailInfo"];
//           
//            [MyAppDelegate getNoReadInfo];
//            
//            [self refreshUI];
//        }
//        else{
//            [MyAppDelegate showAlert:[dic objectForKey:@"Message"]];
//        }
//        [self hideHUD];
//    }];
//    [request setFailedBlock:^{
//        [MyAppDelegate showAlert:@"网络错误，请稍后重试！"];
//        [self hideHUD];
//    }];
//    [request startAsynchronous];
//
    
}

- (void)refreshUI{
    //运单号
    self.orderCode.text = [self.userInfo[@"payInfo"] objectForKey:@"num"];
    //产品名称
    NSString *productName = [self.userInfo[@"goodsDetail"][0] objectForKey:@"goodsname"];
    CGSize size = [NSString getHeight:productName withFont:[UIFont systemFontOfSize:12] andWidth:_productName.frame.size.width];
    int row = size.height/20 + 1;
    int height = 0;
    if (row >= 2) {
        height = 20;
        
        _productName.frame = CGRectMake(_productName.frame.origin.x, _productName.frame.origin.y, _productName.frame.size.width, _productName.frame.size.height + height);
        _bookDate.frame = CGRectMake(_bookDate.frame.origin.x, _bookDate.frame.origin.y, _bookDate.frame.size.width, _bookDate.frame.size.height + height);
        _bookDateTitle.frame =CGRectMake(_bookDateTitle.frame.origin.x, _bookDateTitle.frame.origin.y, _bookDateTitle.frame.size.width, _bookDateTitle.frame.size.height + height);
        _bookNumber.frame = CGRectMake(_bookNumber.frame.origin.x, _bookNumber.frame.origin.y, _bookNumber.frame.size.width, _bookNumber.frame.size.height + height);
        _bookNumberTitle.frame = CGRectMake(_bookNumberTitle.frame.origin.x, _bookNumberTitle.frame.origin.y, _bookNumberTitle.frame.size.width, _bookNumberTitle.frame.size.height + height);
    }
    self.productName.text =[self.userInfo[@"goodsDetail"][0] objectForKey:@"goodsname"];
    
    //订购数量
    self.bookNumber.text = [self.userInfo[@"goodsDetail"][0] objectForKey:@"goodsnum"];
    //订购时间
    NSString *dateStr = [self.userInfo[@"payInfo"] objectForKey:@"ctime"];
    NSString * date = [dateStr substringToIndex:10];
    
    self.bookDate.text = [NSString stringWithFormat:@"%@",date];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.hideBackButton = YES;
//    [MyAppDelegate makeTabBarHidden1:YES];//隐藏tabar
}

//返回我的卡券
- (IBAction)toMyCards:(id)sender {
    
//    myCouponTypeVC *myCouponTypeVc = [[myCouponTypeVC alloc]init];
//    [self.navigationController pushViewController:myCouponTypeVc animated:YES];
}

//返回首页
- (IBAction)gotoFirstView:(id)sender {
    
    [MyAppDelegate.mainTabVC setSelectedIndex:0];
    [MyAppDelegate.mainTabVC.selectImage setFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
     [self.navigationController popToRootViewControllerAnimated:YES];
    
}



@end
