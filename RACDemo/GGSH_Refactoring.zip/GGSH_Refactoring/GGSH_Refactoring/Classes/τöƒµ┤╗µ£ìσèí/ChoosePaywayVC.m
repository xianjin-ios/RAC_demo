//
//  ChoosePaywayVC.m
//  GGSH
//
//  Created by siqiyang on 15/10/8.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "ChoosePaywayVC.h"
#import "LineView.h"
#import "UPPayPlugin.h"
#import "UPPayPluginDelegate.h"
#import "PayResultVC.h"

@interface ChoosePaywayVC ()<UPPayPluginDelegate>
{
    IBOutlet UIScrollView *_scrollview;
    
    UIImageView *pay1Icon;//银联
    UIImageView *pay2Icon;//支付宝
    UIImageView *pay3Icon;//微信


}

@end

@implementation ChoosePaywayVC

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.title = @"提交订单";
    
    [self loadDetailView];
    
    //初始化支付方式
    if (!self.platform) {
        [self doPay3:nil];
    }
    
    //加载数据
    [self loadData:self.dicData];
}

- (void)loadDetailView{
    
    NSInteger top = 10;
    
    UIImageView *proIcon = [[UIImageView alloc]initWithFrame:CGRectMake(15, top, 60, 60)];
    proIcon.tag = 101;
//    proIcon.noBorderFlag = YES;
    proIcon.image = [UIImage imageNamed:@"mpos_icon.png"];
    [_scrollview addSubview:proIcon];
    
    UILabel *lbGoodsname = [[UILabel alloc]initWithFrame:CGRectMake(90, top, SCREEN_WIDTH - 90 - 60, 20)];
    lbGoodsname.tag = 102;
    lbGoodsname.textColor = [UIColor blackColor];
    lbGoodsname.textAlignment = 0;
    lbGoodsname.font = [UIFont systemFontOfSize:15];
    [_scrollview addSubview:lbGoodsname];
    lbGoodsname.text = @"商品名称";
    
    UILabel *lbNum = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 60, top, 50, 20)];
    lbNum.tag = 103;
    lbNum.textColor = [UIColor blackColor];
    lbNum.font = [UIFont systemFontOfSize:15];
    lbNum.textAlignment = 2;
    [_scrollview addSubview:lbNum];
    lbNum.text = @"x1";
    
    top += 40;
    
    UILabel *lbMoneyTitle = [[UILabel alloc]initWithFrame:CGRectMake(90, top, 80, 20)];
    lbMoneyTitle.textColor = [UIColor blackColor];
    lbMoneyTitle.font = [UIFont systemFontOfSize:15];
    lbMoneyTitle.textAlignment = 0;
    [_scrollview addSubview:lbMoneyTitle];
    lbMoneyTitle.text = @"售价：";
    
    UILabel *lbMoney = [[UILabel alloc]initWithFrame:CGRectMake(180, top, SCREEN_WIDTH - 190, 20)];
    lbMoney.tag = 104;
    lbMoney.textColor = [UIColor redColor];
    lbMoney.font = [UIFont systemFontOfSize:15];
    lbMoney.textAlignment = 2;
    lbMoney.adjustsFontSizeToFitWidth = YES;
    [_scrollview addSubview:lbMoney];
    lbMoney.text = @"￥0.00";
    
    LineView *downLine1 = [[LineView alloc]initWithFrame:CGRectMake(0, 79.5, SCREEN_WIDTH, 0.5)];
    downLine1.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
    [_scrollview addSubview:downLine1];
    
    top += 30;
    
    UILabel *lbTitle = [[UILabel alloc]initWithFrame:CGRectMake(15, top, 110, 40)];
    lbTitle.textColor = [UIColor lightGrayColor];
    lbTitle.textAlignment = 0;
    lbTitle.font = [UIFont systemFontOfSize:15];
    [_scrollview addSubview:lbTitle];
    lbTitle.text = @"支付方式";
    
    //微信
    pay3Icon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 160, top + 10, 20, 20)];
    pay3Icon.image = [UIImage imageNamed:@"goods_select.png"];
    pay3Icon.highlightedImage = [UIImage imageNamed:@"goods_selected.png"];
    [_scrollview addSubview:pay3Icon];
    
    UILabel *pay3Label = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 140, top + 5, 60, 30)];
    pay3Label.text = @"微信支付";
    pay3Label.font = [UIFont systemFontOfSize:13];
    [_scrollview addSubview:pay3Label];
    
    UIButton *pay3Btn = [UIButton buttonWithType:UIButtonTypeCustom];
    pay3Btn.frame = CGRectMake(SCREEN_WIDTH - 160, top + 5, 80, 40);
    pay3Btn.backgroundColor = [UIColor clearColor];
    [pay3Btn addTarget:self action:@selector(doPay3:) forControlEvents:UIControlEventTouchUpInside];
    [_scrollview addSubview:pay3Btn];
    
    
    //银联
    pay1Icon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 160, top + 40, 20, 20)];
    pay1Icon.image = [UIImage imageNamed:@"goods_select.png"];
    pay1Icon.highlightedImage = [UIImage imageNamed:@"goods_selected.png"];
    [_scrollview addSubview:pay1Icon];
    
    UILabel *pay1Label = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 140, top + 35, 60, 30)];
    pay1Label.text = @"银联在线";
    pay1Label.font = [UIFont systemFontOfSize:13];
    [_scrollview addSubview:pay1Label];
    
    UIButton *pay1Btn = [UIButton buttonWithType:UIButtonTypeCustom];
    pay1Btn.frame = CGRectMake(SCREEN_WIDTH - 160, top + 35, 80, 40);
    pay1Btn.backgroundColor = [UIColor clearColor];
    [pay1Btn addTarget:self action:@selector(doPay1:) forControlEvents:UIControlEventTouchUpInside];
    [_scrollview addSubview:pay1Btn];
    
    //支付宝
    pay2Icon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 80, top + 10, 20, 20)];
    pay2Icon.image = [UIImage imageNamed:@"goods_select.png"];
    pay2Icon.highlightedImage = [UIImage imageNamed:@"goods_selected.png"];
    [_scrollview addSubview:pay2Icon];
    
    UILabel *pay2Label = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 60, top + 5, 60, 30)];
    pay2Label.text = @"支付宝";
    pay2Label.font = [UIFont systemFontOfSize:13];
    [_scrollview addSubview:pay2Label];
    
    UIButton *pay2Btn = [UIButton buttonWithType:UIButtonTypeCustom];
    pay2Btn.frame = CGRectMake(SCREEN_WIDTH - 80, top + 5, 80, 40);
    pay2Btn.backgroundColor = [UIColor clearColor];
    [pay2Btn addTarget:self action:@selector(doPay2:) forControlEvents:UIControlEventTouchUpInside];
    [_scrollview addSubview:pay2Btn];
    
    LineView *downLine2 = [[LineView alloc]initWithFrame:CGRectMake(0, 119.5+30, SCREEN_WIDTH, 0.5)];
    downLine2.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
    [_scrollview addSubview:downLine2];
    
    
    UIView *downView = [[UIView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 50 - 64, SCREEN_WIDTH, 50)];
    [downView setBackgroundColor:[UIColor whiteColor]];
    [_scrollview addSubview:downView];
    
    LineView *downLine3 = [[LineView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 0.5)];
    downLine3.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
    [downView addSubview:downLine3];
    
    UILabel *lbMoneyTotal = [[UILabel alloc]initWithFrame:CGRectMake(10, 15, SCREEN_WIDTH - 140 - 10, 20)];
    lbMoneyTotal.backgroundColor = [UIColor clearColor];
    lbMoneyTotal.textColor = [UIColor colorWithHexString:@"#b7b7b7"];
    lbMoneyTotal.font = [UIFont systemFontOfSize:15];
    lbMoneyTotal.textAlignment = 0;
    lbMoneyTotal.tag = 105;
    [downView addSubview:lbMoneyTotal];
    lbMoneyTotal.text = @"商品金额合计:￥0.00";
    
    self.confirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.confirmBtn setFrame:CGRectMake(SCREEN_WIDTH - 140, 0, 140, 50)];
    [self.confirmBtn setBackgroundColor:[UIColor colorWithHexString:@"#ff0084"]];
    [self.confirmBtn setTitle:@"确认" forState:UIControlStateNormal];
    [self.confirmBtn.titleLabel setFont:[UIFont systemFontOfSize:15]];
    [self.confirmBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.confirmBtn addTarget:self action:@selector(confirm:) forControlEvents:UIControlEventTouchUpInside];
    [downView addSubview:self.confirmBtn];
    
}

- (void)loadData:(NSMutableDictionary *)dic{
    UIImageView *proIcon = (UIImageView *)[_scrollview viewWithTag:101];
    UILabel *lbGoodsname = (UILabel *)[_scrollview viewWithTag:102];
    UILabel *lbNum = (UILabel *)[_scrollview viewWithTag:103];
    UILabel *lbMoney = (UILabel *)[_scrollview viewWithTag:104];
    UILabel *lbMoneyTotal = (UILabel *)[_scrollview viewWithTag:105];
    [proIcon XK_setImageWithURL:[NSURL URLWithString:[dic objectForKey:@"goodspic"]] placeholderImage:nil];
//    [proIcon loadImageFromURL:[NSURL URLWithString:[dic objectForKey:@"goodspic"]]];
    NSString *goodsnameStr = [dic objectForKey:@"product_name"];
    lbGoodsname.text = goodsnameStr;
    
    NSString *numStr = @"1";
    lbNum.text = [NSString stringWithFormat:@"x%@",numStr];
    
    double price = [[dic objectForKey:@"sellprice"] doubleValue];
    lbMoney.text = [NSString stringWithFormat:@"￥%.2f",price/100];
    
    NSString *prc = [NSString stringWithFormat:@"商品金额合计:￥%.2f",price/100];
    [lbMoneyTotal setTextColor:[UIColor redColor]];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:prc];
    [str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#b7b7b7"] range:NSMakeRange(0,7)];
    lbMoneyTotal.attributedText = str;
    [lbMoneyTotal setAdjustsFontSizeToFitWidth:YES];
    
}
#pragma mark --- 支付类型按钮点击
//银联在线
- (void)doPay1:(UIButton *)sender{
    pay1Icon.highlighted = YES;
    pay2Icon.highlighted = NO;
    pay3Icon.highlighted = NO;
    self.platform = @"upmppay";
    
}
//支付宝
- (void)doPay2:(UIButton *)sender{
    pay1Icon.highlighted = NO;
    pay2Icon.highlighted = YES;
    pay3Icon.highlighted = NO;
    self.platform = @"alipay";
    
}
//微信支付
- (void)doPay3:(UIButton *)sender{
    pay3Icon.highlighted = YES;
    pay2Icon.highlighted = NO;
    pay1Icon.highlighted = NO;
    self.platform = @"wxpay";
}

- (void)resetButtonState{
    self.confirmBtn.userInteractionEnabled = YES;
    self.confirmBtn.backgroundColor = [UIColor colorWithHexString:@"FF0084"];
}

- (void)WXPayResultHandler:(NSNotification *)notify{
    NSString *result = notify.object;
   
    if ([result isEqualToString: WX_PAY_SUCCESS ]) {
//        支付成功，进入结果页面
//        新增结果页面
        PayResultVC *ctrl = [[PayResultVC alloc]init];
        ctrl.hideBackButton = YES;
        [self.navigationController pushViewController:ctrl animated:YES];
        
    }else{
        [self showalertString:@"订单支付未完成，请在”我的订单“中重新支付"];
      
    }
    //移除通知
    [[NSNotificationCenter defaultCenter]removeObserver:self name:WX_PAY_RESULT object:nil];
}

- (void)confirm:(UIButton *)sender {
    
    if (!self.platform) {
        
        [self showalertString:@"请选择支付方式"];
        return;
    }
    //判断有网
    if (![MyAppDelegate whetherHaveNet]) {
        
        [self showalertString:@"请查看网络设置"];
        
        return;
    }
    self.confirmBtn.userInteractionEnabled = NO;
    [self.confirmBtn setBackgroundColor:[UIColor colorWithHexString:@"AEAEAE"]];
    if ([self.platform isEqualToString: @"wxpay"]) {
        //判断用户是否安装了微信
        if ([WXApi isWXAppInstalled]) {
        
            //微信支付
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.dicData];
            [dic setObject:self.phoneStr forKey:@"phone"];
            [dic setObject:self.dicData[@"product_name"] forKey:@"product_name"];
            [dic setObject:[self.dicData objectForKey:@"sellprice"] forKey:@"sellprice"];
            [dic setObject:[self.dicData objectForKey:@"sellprice"] forKey:@"paymoney"];
            [dic setObject:@"" forKey:@"num"];
            [dic setObject:self.dicData[@"pcode"] forKey:@"pcode"];
            [dic setObject:@"" forKey:@"brandcode"];
            [dic setObject:@1 forKey:@"goodsnum"];
            [self payEcpWXWith:dic];
        }
        else{
             self.confirmBtn.userInteractionEnabled = YES;
             [self.confirmBtn setBackgroundColor:[UIColor colorWithHexString:@"#ff0084"]];
            [self showalertString:@"尚未安装微信"];
        }
       
    }else{
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.dicData];
        [dic setObject:self.platform forKey:@"platform"];
        [dic setObject:self.phoneStr forKey:@"ecp_ext"];
        [dic setObject:@"" forKey:@"num"];
        [self payEcpWith:dic];
    }
}

- (void)payWXFail{
    self.confirmBtn.userInteractionEnabled = YES;
    self.confirmBtn.backgroundColor = [UIColor colorWithHexString:@"FF0084"];
}

#pragma mark - 支付delegate
- (void)UPPayPluginResult:(NSString *)result
{
    if ([result isEqualToString:@"fail"]) {
        ZLog(@"%@失败",result);
        [self showalertString:@"订单支付未完成，请在”我的订单“中重新支付"];
    
        
    }else if ([result isEqualToString:@"success"]){
        ZLog(@"%@成功",result);
        
        [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
        
        //新增结果页面
        PayResultVC *ctrl = [[PayResultVC alloc]init];
        ctrl.hideBackButton = YES;
        [self.navigationController pushViewController:ctrl animated:YES];
        
    }else if ([result isEqualToString:@"cancel"]){
        ZLog(@"%@取消订单",result);
        [self showalertString:@"订单支付未完成，请在”我的订单“中重新支付"];
        
        
    }
    
}
- (void)showalertString:(NSString *)alertSting{
    UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:@"提示" message:alertSting preferredStyle:UIAlertControllerStyleAlert];
    [alertVc addAction:[UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        MyAppDelegate.isCharging = NO;
        //返回首页
        [self backToHome];
        
    }]];
    
    [self presentViewController:alertVc animated:YES completion:nil];
    
}
- (void)handleWXPayIsDoing:(NSNotification *)notify{

    self.confirmBtn.userInteractionEnabled = YES;
    self.confirmBtn.backgroundColor = [UIColor colorWithHexString:@"FF0084"];
    [self showalertString:@"订单支付未完成，请在”我的订单“中重新支付"];
}

- (void)viewWillDisappear:(BOOL)animated{
    self.confirmBtn.userInteractionEnabled = YES;
    [super viewWillDisappear:animated];
    MyAppDelegate.isCharging = NO;
    
}

@end
