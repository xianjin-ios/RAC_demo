//
//  ProductDetailViewController.m
//  GGSH
//
//  Created by siqiyang on 16/1/7.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "ProductDetailViewController.h"
#import "SubmitOrderViewController.h"
@interface ProductDetailViewController ()<UIScrollViewDelegate>

@end

@implementation ProductDetailViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.proDes.numberOfLines = 0;
    self.proDes.text = self.productDic[@"product_name"];
    self.saledNum.text = [NSString stringWithFormat:@"已售：%@",self.productDic[@"storenum"]];
    NSString *priStr = self.productDic[@"sellprice"];
    float price = priStr.floatValue;
    self.pcode = self.productDic[@"pcode"];

    self.priceLabel.text = [NSString stringWithFormat:@"￥%.2f",price * 0.01];
    self.mainScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, self.view.frame.size.height - 50);
//    self.mainScrollView.bounces = NO;
    self.mainScrollView.showsHorizontalScrollIndicator = NO;//隐藏水平线
    self.mainScrollView.showsVerticalScrollIndicator = NO;
    self.mainScrollView.scrollEnabled = YES;
    //加载网络图片
//    self.productPic.noBorderFlag = YES; 
    [self.productPic XK_setImageWithURL:self.productDic[@"goodspic"] placeholderImage:[UIImage imageNamed:@"goodsDefaultImage"]];
//    [self.productPic loadImageFromURL:[NSURL URLWithString:self.productDic[@"goodspic"]] AndDefaultImage:@"goodsDefaultImage"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)bookInstant:(id)sender {
    
    SubmitOrderViewController *subVC = [[SubmitOrderViewController alloc]init];
    
//    subVC.hideBackButton = NO;
    subVC.price = self.productDic[@"sellprice"];
    subVC.pcode = self.pcode;
    subVC.bookNumber = self.numField.text;
    subVC.productName = self.proDes.text;
    subVC.proType = self.productType;
    subVC.proImageViewUrlStr = self.productDic[@"goodspic"];
    subVC.brand_code = self.productDic[@"brand_code"];
    
    
    [self.navigationController pushViewController:subVC animated:YES];
    
    
}
- (IBAction)minBtnClick:(id)sender {
    
    int num = self.numField.text.intValue;
    if (num <= 1) {
        return;
    }
    num--;
    self.numField.text = [NSString stringWithFormat:@"%d",num];
}

- (IBAction)plusBtnClick:(id)sender {
    
    int num = self.numField.text.intValue;
    if (num >= 5) {//您每次最多可订购5张
//        [MyAppDelegate showAlert:@"您每次最多可订购5张"];
        [self showAlert:@"您每次最多可订购5张" withTitle:@"提示" haveCancelButton:NO];
        return;
    }
    num++;
    self.numField.text = [NSString stringWithFormat:@"%d",num];
    
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
  
    
    
}@end
