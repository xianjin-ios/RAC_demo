//
//  ChoosePaywayVC.h
//  GGSH
//
//  Created by siqiyang on 15/10/8.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "BaseVCWithPay.h"

@interface ChoosePaywayVC :BaseVCWithPay

@property (nonatomic,retain) NSString *phoneStr;
@property (nonatomic,retain) NSMutableDictionary *dicData;
@property (nonatomic,retain) NSString *platform;

@property (nonatomic,strong) UIButton *confirmBtn;


@end
