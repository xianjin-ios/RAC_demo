//
//  NewLifeTypeButton.h
//  GGSH
//
//  Created by siqiyang on 16/1/7.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewLifeTypeButton : UIButton

@property (nonatomic,strong) UILabel *firstLabel;//主标题
@property (nonatomic,strong) UILabel *detailLabal;//副标题
@property (nonatomic,strong) UIImageView *btnImageView;//图标View

- (void)setFirstTitle:(NSString *)first andSecondTitle:(NSString *)second andImageName:(NSString *)image;

@end
