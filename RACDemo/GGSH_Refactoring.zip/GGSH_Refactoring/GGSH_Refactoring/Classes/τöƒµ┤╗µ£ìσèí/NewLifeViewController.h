//
//  NewLifeViewController.h
//  GGSH
//
//  Created by siqiyang on 16/1/6.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface NewLifeViewController : BaseViewController

@property (retain, nonatomic) IBOutlet UIScrollView *mainScrollView;//底部

@property (nonatomic,strong)NSMutableArray *picArray;//图片数组
@property (nonatomic,strong)UIPageControl *pageControl;//分页控件

@property (nonatomic,strong)NSTimer *timer;//定时器
@end
