//
//  TopScrollViewController.m
//  GGSH
//
//  Created by siqiyang on 16/1/12.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "TopScrollViewController.h"

#define WIDTH self.view.frame.size.width
#define HEIGHT self.view.frame.size.height
@interface TopScrollViewController ()
{
    NSTimer *_timer;
    BOOL isFromStart ;//是否从头开始
}
@end

@implementation TopScrollViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _arrNews = [[NSMutableArray alloc]init];
    //初始化翻页控件
    _pageControl.frame = CGRectMake(WIDTH*0.5-25, HEIGHT - 15, 50, 10);
    _pageControl.backgroundColor = [UIColor clearColor];
    //    [self getNews:_topScrollView page:_pageControl];
    
    self.topScrollView.bounces = YES;//关闭回弹效果
    _topScrollView.showsHorizontalScrollIndicator = NO;
    _topScrollView.showsVerticalScrollIndicator = NO;
    _topScrollView.frame = CGRectMake(0, 0, WIDTH, HEIGHT);
    _topScrollView.pagingEnabled = YES;
    _timer = [NSTimer scheduledTimerWithTimeInterval:2.5 target:self selector:@selector(scrollPages) userInfo:nil repeats:YES];
    
}
//滚动动画
-(void)scrollPages{
    ++self.pageControl.currentPage;
    CGFloat pageWidth = CGRectGetWidth(self.topScrollView.frame);
    if (isFromStart) {
        [self.topScrollView setContentOffset:CGPointMake(0, 0) animated:YES];
        self.pageControl.currentPage = 0;
      
    }
    else
    {
        [self.topScrollView setContentOffset:CGPointMake(pageWidth*self.pageControl.currentPage, 0)];
        
    }
    if (_pageControl.currentPage == _pageControl.numberOfPages - 1) {
        isFromStart = YES;
    }
    else
    {
        isFromStart = NO;
    }
    
}

-(void)getNews:(UIScrollView*)scrollView page:(UIPageControl*)pageCtrl{
    
    
    UIPageControl * pCtrl = pageCtrl;
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Members" forKey:@"Mod"];
    [dic setObject:@"carousel" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    [dicContent setObject:@"3" forKey:@"type"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    [xkNetwork xk_requstWithDic:dic withUrl: kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        //        转换为NSString
        NSString *jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"jsonString = %@",jsonString);
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            //获取数据成功
            NSArray * arrNews = [resultDic objectForKey:@"DetailInfo"];
            [_arrNews addObjectsFromArray: arrNews];
            
            //初始化数据
            if (scrollView == nil) {
                return;
            }
            scrollView.contentSize = CGSizeMake(scrollView.frame.size.width* [arrNews count], scrollView.frame.size.height);
            scrollView.pagingEnabled = YES;
            
            pCtrl.numberOfPages = [arrNews count];
            
            for (int i = 0; i < [_arrNews count]; i ++) {
                
                NSDictionary * dicNews = [_arrNews objectAtIndex:i];
                
                //创建图片控件
                UIImageView * imgView = [[UIImageView alloc] init];
                imgView.frame = CGRectMake(i * scrollView.frame.size.width, 0, scrollView.frame.size.width, scrollView.frame.size.height);
                
                imgView.backgroundColor = [UIColor clearColor];
                [scrollView addSubview:imgView];
                //                            imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"1.jpg"]];
                imgView.tag = 300 + i;
                NSURL *url = [NSURL URLWithString:[dicNews objectForKey:@"img" ]];
                [imgView XK_setImageWithURL:url placeholderImage: [UIImage imageNamed:[NSString stringWithFormat:@"1.jpg"]]];
                UIButton *btnImageDetail = [UIButton buttonWithType:UIButtonTypeCustom];
                btnImageDetail.tag = 300 + i;
                btnImageDetail.frame = CGRectMake(i * scrollView.frame.size.width, 0, imgView.frame.size.width, imgView.frame.size.height);
                btnImageDetail.backgroundColor = [UIColor clearColor];
                [btnImageDetail addTarget:self action:@selector(clickNews:) forControlEvents:UIControlEventTouchUpInside];
                [scrollView addSubview:btnImageDetail];
                
            }
            
        }
        
        
    }];
    
}
//点击轮播图时调用
- (void)clickNews:(id)sender{
    UIButton * btn = (UIButton *)sender;
    NSInteger index = btn.tag - 300;
    NSDictionary * dic = [_arrNews objectAtIndex:index];
    NSString * strUrl = [dic objectForKey:@"Url"];
    
    NSString *shopid = [dic objectForKey:@"shopid"];
    if ([shopid isEqualToString:@"0"]) {
        return;
    }
    if ([self.delegate respondsToSelector:@selector(pushToShopWithShopId:)]) {
        [self.delegate pushToShopWithShopId:shopid];
    }
    
}
- (void)updateTopScrollView{
    
    
    [self getNews:_topScrollView page:_pageControl];
    
    
}

#pragma mark scrollViewDelegate
//拖拽开始时
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    //注意，Timer的停止方法invalidate会释放该Timer对象的所有引用计数，所以引用该Timer类的对象实例不需要再对其调用release方法。
    [_timer invalidate];//定时器暂停
    _timer = nil;
    
}

//拖拽结束时,通过拖拽内容视图 设置当前的页码号
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    CGPoint point = _topScrollView.contentOffset;
    _pageControl.currentPage = point.x/WIDTH;
    
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    //获取最终的偏移位置
    CGFloat pageWith = CGRectGetWidth(self.topScrollView.frame);
    //floor() 这个函数的意思是向下取整
    NSInteger page = floor((self.topScrollView.contentOffset.x - pageWith/2)/pageWith)+1;
    self.pageControl.currentPage = page;
    self.topScrollView.contentOffset = CGPointMake(page * WIDTH, 0);
    //定时器重新开启
    _timer = [NSTimer scheduledTimerWithTimeInterval:2.5 target:self selector:@selector(scrollPages) userInfo:nil repeats:YES];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
