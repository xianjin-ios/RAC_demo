//
//  LoginVC.h
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/13.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "BaseViewController.h"
#import <CommonCrypto/CommonDigest.h>

//登录后的调用
@protocol loginDelegate <NSObject>
@optional
- (void)finishLogin;
- (void)failedLogin;
- (void)cancelLogin;
@end

@interface LoginVC : BaseViewController

//登录代理
@property (nonatomic, assign) id <loginDelegate> delegate;


@end
