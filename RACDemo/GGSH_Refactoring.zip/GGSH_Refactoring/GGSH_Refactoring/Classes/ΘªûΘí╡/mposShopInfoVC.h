//
//  mposShopInfoVC.h
//  GGSH
//
//  Created by siqiyang on 15/11/5.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface mposShopInfoVC : BaseViewController

@property (nonatomic,retain) NSDictionary *dicData;

@end
