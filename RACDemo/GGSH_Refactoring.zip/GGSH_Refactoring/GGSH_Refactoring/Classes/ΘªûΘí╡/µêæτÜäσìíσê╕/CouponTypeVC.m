//
//  CouponTypeVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/20.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "CouponTypeVC.h"
#import "MyMessageVC.h"
#import "qiangquanVC.h"
#import "youhuiViewController.h"
#import "GGCouponListViewController.h"
#import "cardVC.h"

@interface CouponTypeVC (){
    IBOutlet UILabel *lbIntro;
    
    IBOutlet UILabel *ggCouponLabel;
    
    IBOutlet UILabel *lbCard;
    
    UIImageView *imageAlert;
}

@end

@implementation CouponTypeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的卡券";
    
    //右边消息按钮
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0.0, 0.0, 16, 16);
    [rightBtn addTarget:self action:@selector(my_message:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButtonItem2 = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    rightBarButtonItem2.style = UIBarButtonItemStylePlain;
    //判断是否要添加红点提示
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(10, -4, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [rightBarButtonItem2.customView addSubview:imageAlert];
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
    self.navigationItem.rightBarButtonItem = rightBarButtonItem2;

    
    [self refreshCouponData];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshCouponData) name:@"HaveNoRead" object:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)refreshCouponData{
    //提示有未使用文字
#warning 全局的未读标记
    NSString *tempStr = MyAppDelegate.couponNumForUse;
    if(0 == tempStr.length){
        tempStr = @"0";
    }
    NSString *numStr = [NSString stringWithFormat:@"您有%@张店铺优惠券待使用",tempStr];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:numStr];
    [str addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(2,tempStr.length)];
    
    lbIntro.attributedText = str;
    
    NSString *tempStr1 = MyAppDelegate.ecpcardnum;
    if(0 == tempStr1.length){
        tempStr1 = @"0";
    }
    NSString *numStr1 = [NSString stringWithFormat:@"您有%@张新卡密",tempStr1];
    NSMutableAttributedString *str1 = [[NSMutableAttributedString alloc] initWithString:numStr1];
    [str1 addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(2,tempStr1.length)];
    
    lbCard.attributedText = str1;
    
    NSString *tempStr2 = MyAppDelegate.ggCouponNum;
    if (tempStr2.length == 0) {
        tempStr2 = @"0";
    }
    NSString *numStr2 = [NSString stringWithFormat:@"您有%@张逛逛优惠券待使用",tempStr2];
    
    NSMutableAttributedString *str2 = [[NSMutableAttributedString alloc]initWithString:numStr2];
    [str2 addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(2, tempStr2.length)];
    ggCouponLabel.attributedText = str2;
    
}

//消息
- (IBAction)my_message:(id)sender {
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];
    
}

//抢券
- (IBAction)gotoQiangquanVC:(id)sender{
    qiangquanVC *vc = [[qiangquanVC alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}
//逛逛优惠券列表
- (IBAction)gotoGGCouponList:(id)sender {
    GGCouponListViewController *ggCouponListVC = [[GGCouponListViewController alloc]init];
    
    [self.navigationController pushViewController:ggCouponListVC animated:YES];
    
    
}

//优惠券列表
- (IBAction)gotoCouponList:(id)sender{
    youhuiViewController *youhV = [[youhuiViewController alloc]init];
    youhV.flag = 1;
    [self.navigationController pushViewController:youhV animated:YES];
}

//去卡密界面
- (IBAction)gotoCardView:(id)sender {
    cardVC *vc = [[cardVC alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
    
}
@end
