//
//  MposSearchProductViewController.m
//  GGSH
//
//  Created by siqiyang on 16/3/22.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "MposSearchProductViewController.h"
#import "lookGoodsCell.h"
#import "proDetailViewController.h"

#define SCREEN_Width [UIScreen mainScreen].bounds.size.width

@interface MposSearchProductViewController ()<UITextFieldDelegate,UICollectionViewDataSource,UICollectionViewDelegate,MJRefreshBaseViewDelegate>
{
    int pageindex;
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
}

@end

@implementation MposSearchProductViewController

static NSString *cellId = @"lookCell";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.searchProductionArr = [[NSMutableArray alloc]init];
    pageindex = 1;
    [self addSearchModules];
    [self addCancelBtn];
    [self.productCollectionView registerNib:[UINib nibWithNibName:@"lookGoodsCell" bundle:nil] forCellWithReuseIdentifier:cellId];
    
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _productCollectionView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _productCollectionView;
    _footer.delegate = self;
    
    //解决商品没有占满屏幕无法下拉的问题
    _productCollectionView.alwaysBounceVertical = YES;
    self.productCollectionView.scrollEnabled = YES;
    self.productCollectionView.alwaysBounceVertical = YES;
    self.productCollectionView.showsHorizontalScrollIndicator = NO;
    self.productCollectionView.showsVerticalScrollIndicator = NO;
    
}
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(0 == [xkNetwork checkNetStatus]){
        [self showalertString:@"无网络连接"];
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        return;
    }
    
    if(refreshView == _header) {// 下拉刷新
        pageindex = 1;
        [self doSearchWithWords:_lbSearch.text];
    }else if (refreshView == _footer){//上拉加载更多
        if(self.searchProductionArr.count%10 == 0){
            pageindex += 1;
             [self doSearchWithWords:_lbSearch.text];
        }
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    return;
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}


- (void)addCancelBtn{
    
    UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    cancelBtn.frame = CGRectMake(0, 0, 60, 30);
    [cancelBtn setTitle:@" 取消" forState:UIControlStateNormal];
    [cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [cancelBtn addTarget:self action:@selector(cancelsearch:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barItem = [[UIBarButtonItem alloc]initWithCustomView:cancelBtn];
    
    self.navigationItem.rightBarButtonItem = barItem;
    
}
//取消
- (void)cancelsearch:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (void)addSearchModules{
   
    UIView *bgview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_Width - 130, 28)];
    bgview.backgroundColor = [UIColor clearColor];
    bgview.center = CGPointMake(SCREEN_Width/2, 44/2);
    
    UIImageView *imgSearBg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_Width - 130, 28)];
    imgSearBg.image = [UIImage imageNamed:@"search_mid.png"];
    [bgview addSubview:imgSearBg];
    //
    UIImageView *imgSear = [[UIImageView alloc] initWithFrame:CGRectMake(9, 8, 11, 11)];
    imgSear.image = [UIImage imageNamed:@"search_red.png"];
    [bgview addSubview:imgSear];
    
    //输入框
    _lbSearch = [[UITextField alloc] initWithFrame:CGRectMake(26, 8, SCREEN_Width - 160, 12)];
    _lbSearch.textColor = [UIColor lightGrayColor];
    _lbSearch.placeholder = @"搜索店铺内商品";
    _lbSearch.font = [UIFont systemFontOfSize:12];
    [bgview addSubview:_lbSearch];
    _lbSearch.returnKeyType = UIReturnKeySearch;
    _lbSearch.delegate = self;
    
    [_lbSearch becomeFirstResponder];
    
    self.navigationItem.titleView = bgview;

    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
   
    if (textField == _lbSearch) {
        [self doSearchWithWords:textField.text];
        [_lbSearch resignFirstResponder];
    }
   
    return YES;
}

- (void)doSearchWithWords:(NSString *)text{
    
    NSLog(@"shopInfo = %@",self.shopInfo);
      [self showHUD];
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    if ([self.shopInfo objectForKey:@"id"]) {
        [item setObject:[NSString stringWithFormat:@"%@",[self.shopInfo objectForKey:@"id"]] forKey:@"shopid"];
        
    }else{
        [item setObject:self.shopInfo forKey:@"shopid"];
    }
    
    [item setObject:[NSNumber numberWithInt:pageindex] forKey:@"pageindex"];
    [item setObject:[NSNumber numberWithInt:20] forKey:@"pagesize"];
    [item setObject:text forKey:@"keyword"];
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"GoodsSel",@"Mod",@"GoodsList",@"Act",item,@"Content", nil];

    [self showHUD];
    [xkNetwork xk_requstWithDic:dict withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        ZLog(@"responseString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        
        if([[responseDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            if(1 == pageindex){
                self.searchProductionArr = [[responseDic objectForKey:@"DetailInfo"]mutableCopy];
            }else{
                //上拉增加新数据
                [self.searchProductionArr addObjectsFromArray:[responseDic objectForKey:@"DetailInfo"]];
            }
        }else{
            //
            self.searchProductionArr = [responseDic objectForKey:@"DetailInfo"];
        }
        [_productCollectionView reloadData];
        
        if (self.searchProductionArr.count == 0) {
            //无数据提示
            if (!_noView) {
                _noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                _noView.backgroundColor = [UIColor clearColor];
                _noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 52);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [_noView addSubview:bigbeen];
                [_productCollectionView addSubview:_noView];
            }
        }else{
            if (_noView) {
                [_noView removeFromSuperview];
                _noView = nil;
            }
        }
    
    }];
    
    


   
}
////没有数据时的提示
//
//- (void)isShowNoDataView:(BOOL)isShow{
//    if (isShow == NO) {
//        if (_noView) {
//            [_noView removeFromSuperview];
//            _noView = nil;
//        }
//    }
//    else
//    if (!_noView) {
//        _noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
//        _noView.backgroundColor = [UIColor clearColor];
//        _noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
//        UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
//        bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
//        UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
//        labela.backgroundColor = [UIColor clearColor];
//        labela.text = @"暂无内容";
//        labela.textAlignment = 1;
//        labela.font = [UIFont systemFontOfSize:15];
//        labela.textColor = [UIColor lightGrayColor];
//        [bigbeen addSubview:labela];
//        [_noView addSubview:bigbeen];
//        [_productCollectionView addSubview:_noView];
//    }
//    
//}
//    


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//边框
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

#pragma mark -- UICollectionViewDelegate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return self.searchProductionArr.count;

    
}

- (UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dic = self.searchProductionArr[indexPath.row];
    lookGoodsCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellId forIndexPath:indexPath];
    cell.dicCell = dic;
    [cell awakeFromNib];
//    cell.productImageView.image = [UIImage imageNamed:@"goodsListDefaultImage"];
//    [cell.productImageView loadImageFromURL:[NSURL URLWithString:[dic objectForKey:@"listpic"]]];
//    
//    cell.presLabel.numberOfLines = 0;
//    cell.presLabel.text = [NSString stringWithFormat:@"%@",dic[@"goodsname"]];
//    
//    //价格
//    if([[dic objectForKey:@"pircestatus"] isEqualToString:@"1"]){
//        //区间价格
//        int begprc = ((NSString*)[dic objectForKey:@"initialprice"]).intValue;
//        int endprc = ((NSString*)[dic objectForKey:@"endprice"]).intValue;
//       cell.priceLabel.text = [NSString stringWithFormat:@"¥%.2f-%.2f", begprc/100.0 ,endprc/100.0];
//        cell.priceLabel.adjustsFontSizeToFitWidth = YES;
//    }else if ([[dic objectForKey:@"pircestatus"] isEqualToString:@"2"]){
//        //发布价格
//        NSString *prc = [dic objectForKey:@"goodsprice"];
//        cell.priceLabel.text = [NSString stringWithFormat:@"￥%.2f", prc.intValue/100.0f];
//        
//    }else if ([[dic objectForKey:@"pircestatus"] isEqualToString:@"3"]){
//        //定制服务
//        //定制服务单位？没确定所以先不添加
//        NSString *unitStr = [[dic objectForKey:@"unit"] isEqualToString:@"1"]?@"人":@"间";//1:人 2:间
//        
//        NSString *prc = [dic objectForKey:@"goodsprice"];
//        cell.priceLabel.text = [NSString stringWithFormat:@"￥%.2f/%@", prc.intValue/100.0f,unitStr];
//        
//    }
//    cell.priceLabel.adjustsFontSizeToFitWidth = YES;
//    
//    NSString *numStr = [dic objectForKey:@"sellnum"];
//    cell.saledLabel.text = [NSString stringWithFormat:@"已售%@笔", numStr];
    
    
    return cell;
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    proDetailViewController *proDetailVC = [[proDetailViewController alloc]init];
    proDetailVC.detailInfo = [self.searchProductionArr objectAtIndex:indexPath.row];
    proDetailVC.proId = [[self.searchProductionArr objectAtIndex:indexPath.row] objectForKey:@"id"];
    proDetailVC.merDic = self.shopInfo;
    [self.navigationController pushViewController:proDetailVC animated:YES];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
