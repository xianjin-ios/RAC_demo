//
//  AddWantBuyVC.m
//  GGSH
//  添加我要购买
//  Created by 任春宁 on 15/6/4.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "AddWantBuyVC.h"
#import "LoginVC.h"
#import "IWantBuyVC.h"
@interface AddWantBuyVC ()<loginDelegate, UITextViewDelegate>{
    //需求描述的 placeholder
    IBOutlet UILabel *_lbIntroLabel;
    
    //弹出提示用户最多只能输入50字，但只弹一次，弹后该值变为yes
    BOOL isShowAlert;
}

@end

@implementation AddWantBuyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"我要买";
    
    //右上角按钮
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0.0, 0.0, 65, 25);
    [rightBtn addTarget:self action:@selector(clickRightButton) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setTitle:@"愿望清单" forState:UIControlStateNormal];
    [rightBtn.titleLabel setFont:[UIFont systemFontOfSize:15]];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    rightBarButtonItem.style = UIBarButtonItemStylePlain;
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
    
    //调整滚动区域
    _scrollView.contentSize = CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT);

    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapView:)];
    [_scrollView addGestureRecognizer:singleTap];

}

//
-(void)textViewDidChange:(UITextView *)textView
{
    ZLog(@"%@",textView.text);
    if (textView.text.length == 0) {
        _lbIntroLabel.hidden = NO;
    }else{
        _lbIntroLabel.hidden = YES;
        if(50 <= textView.text.length){
            [textView resignFirstResponder];
            if(!isShowAlert){
                isShowAlert = YES;
                [self showAlert:nil withTitle:@"最多输入50字" haveCancelButton:NO];
            }
        }
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView;{
    if(textView.text.length >= 50){
        textView.text = [textView.text substringToIndex:50];
    }
}

- (void)clickRightButton{
    
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    //愿望清单
    IWantBuyVC *ctrl = [[IWantBuyVC alloc]init];
    [self.navigationController pushViewController:ctrl animated:YES];
    
}

- (void)tapView:(id)sender{
    
    [self clearKeyboard];
}

#pragma mark -
#pragma mark 按钮点击事件

//选择省市
-(IBAction)selectProvince:(id)sender{
    
    [self clearKeyboard];
    
//    if (_selectCityCtrl == nil) {
//        _selectCityCtrl = [[SelectCityVC alloc] init];
//        _selectCityCtrl.delegate = self;
//    }
    
    _selectCityCtrl.view.frame = MyAppDelegate.window.bounds;
    
    [_selectCityCtrl.view removeFromSuperview];
    [MyAppDelegate.window addSubview:_selectCityCtrl.view];
    
}

//回收键盘
-(void)clearKeyboard{
    [_tfTitle resignFirstResponder];
    [_tfStartPrice resignFirstResponder];
    [_tfEndPrice resignFirstResponder];
    [_tvDesc resignFirstResponder];
}

//选择类别
-(IBAction)selectCategory:(id)sender{
    [self clearKeyboard];
    
    if (_selectTypeCtrl == nil) {
        _selectTypeCtrl = [[SelectBuyTypeVC alloc] init];
        _selectTypeCtrl.delegate = self;
        _selectTypeCtrl.view.backgroundColor = [UIColor clearColor];
    }
    
    _selectTypeCtrl.view.frame = MyAppDelegate.window.bounds;
    [_selectTypeCtrl.view removeFromSuperview];
    [MyAppDelegate.window addSubview:_selectTypeCtrl.view];
}


#pragma mark -
#pragma mark 城市选择代理
-(void)FinishSelect:(NSDictionary *)info{
    
    _dicSelectCity = info;
    [_selectCityCtrl.view removeFromSuperview];
    
    //
    NSString * strResult = [_dicSelectCity objectForKey:@"regionname"];
    NSDictionary * dicSelectedCity = [_dicSelectCity objectForKey:@"selectcity"];
    
    strResult = [NSString stringWithFormat:@"   %@ %@", strResult, [dicSelectedCity objectForKey:@"name" ]];
    
    
    //显示结果
    [_btnSelectProvince setTitle:strResult forState:UIControlStateNormal];
    [_btnSelectProvince setTitle:strResult forState:UIControlStateHighlighted];
    
}

-(void)CancelSelect{
    
    [_selectCityCtrl.view removeFromSuperview];
}

#pragma mark -
#pragma mark 分类选择代理
-(void)buyTypeSelectFinish:(NSDictionary *)dicInfo{
    
    _dicSelectType = dicInfo;
    [_selectTypeCtrl.view removeFromSuperview];
    
    NSString * strResult = [NSString stringWithFormat:@"   %@",[_dicSelectType objectForKey:@"explain"]];
    
    [_btnSelectType setTitle:strResult forState:UIControlStateNormal];
    [_btnSelectType setTitle:strResult forState:UIControlStateHighlighted];
}

-(void)buyTypeSelectCancel{
    
    [_selectTypeCtrl.view removeFromSuperview];
}


-(IBAction)submit:(id)sender{
    
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    
    //准备数据
    NSString * strTitle = _tfTitle.text;
    NSString * strProvince = [_dicSelectCity objectForKey:@"pcode"];
    
    NSDictionary * dicSelectCity = [_dicSelectCity objectForKey:@"selectcity"];
    NSString * strCity = [dicSelectCity objectForKey:@"pcode"];
    NSString * strTypeID = [_dicSelectType objectForKey:@"id"];
    NSString * strStartPrice = _tfStartPrice.text;
    NSString * strEndPrice = _tfEndPrice.text;
    NSString * strDesc = _tvDesc.text;
    
    //判断参数有效性
    if (strTitle.length == 0) {
        [self showAlert:nil withTitle:@"请填写需求主题" haveCancelButton:NO];
        return;
    }
    
    if (strCity.length == 0) {
        [self showAlert:nil withTitle:@"请选择地区" haveCancelButton:NO];
        return;
    }
    
    if (strTypeID.length == 0) {
        [self showAlert:nil withTitle:@"请填写需求类型" haveCancelButton:NO];
        return;
    }
    
    if (strStartPrice.length == 0 || strEndPrice.length == 0) {
        [self showAlert:nil withTitle:@"请填写期望价格" haveCancelButton:NO];
        return;
    }
    
    if (strDesc.length == 0) {
        [self showAlert:nil withTitle:@"请填写需求描述" haveCancelButton:NO];
        return;
    }
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Personal" forKey:@"Mod"];
    [dic setObject:@"buyGoods" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([SSKeychain passwordForService:keyChainAccessGroup account:keyChainUser]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];

    }
    [dicContent setObject:strTitle forKey:@"title"];
    
    [dicContent setObject:strProvince forKey:@"province"];
    [dicContent setObject:strCity forKey:@"city"];
    
    [dicContent setObject:strTypeID forKey:@"type"];
    [dicContent setObject:strStartPrice forKey:@"startprice"];
    [dicContent setObject:strEndPrice forKey:@"endprice"];
    [dicContent setObject:strDesc forKey:@"description"];
    
    
    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if (resultDic == nil) {
            [self showAlert:nil withTitle:@"操作失败" haveCancelButton:NO];
        }
        else if( [[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            [self showAlert:nil withTitle:@"操作成功" haveCancelButton:NO];
            //操作成功之后清空填写的数据
            [self clearInfoView];
            
            IWantBuyVC *ctrl = [[IWantBuyVC alloc]init];
            [self.navigationController pushViewController:ctrl animated:YES];
            
        }
        else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
        
    }];
}

//清空数据
- (void)clearInfoView{
    [self clearKeyboard];
    
    _tfTitle.text = @"";
    _tfStartPrice.text = @"";
    _tfEndPrice.text = @"";
    _tvDesc.text = @"";
    [_btnSelectProvince setTitle:@"   选择地区" forState:UIControlStateNormal];
    [_btnSelectType setTitle:@"   请选择您要购买的商品种类" forState:UIControlStateNormal];

}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    
    [self clearKeyboard];
}

@end
