//
//  BaseViewController.h
//  GGSH
//  添加我要购买
//  Created by 任春宁 on 15/6/4.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "SelectCityVC.h"
#import "SelectBuyTypeVC.h"
#import "IWantBuyVC.h"

@interface AddWantBuyVC : BaseViewController</*SelectCityDelegate,*/ BUY_TYPE_DELEGATE, UIScrollViewDelegate>{
    
    IBOutlet UIScrollView * _scrollView;
    
    //标题
    IBOutlet UITextField * _tfTitle;
    
    //开始价格
    IBOutlet UITextField * _tfStartPrice;
    
    //结束价格
    IBOutlet UITextField * _tfEndPrice;
    
    //描述，字数最多50字
    IBOutlet UITextView *_tvDesc;
    
    //选择省市
    IBOutlet UIButton * _btnSelectProvince;
    
    //选择类别
    IBOutlet UIButton * _btnSelectType;
    
    NSMutableArray *typeDefaultList;
    
    //选择城市
    SelectCityVC * _selectCityCtrl;
    NSDictionary * _dicSelectCity;
    //选择分类
    SelectBuyTypeVC * _selectTypeCtrl;
    //分类选择结果数据
    NSDictionary * _dicSelectType;
    
    

}

//选择省市
-(IBAction)selectProvince:(id)sender;


//选择类别
-(IBAction)selectCategory:(id)sender;


-(IBAction)submit:(id)sender;



@end
