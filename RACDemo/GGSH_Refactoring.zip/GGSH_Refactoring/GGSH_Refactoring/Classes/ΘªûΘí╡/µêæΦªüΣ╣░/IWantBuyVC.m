//
//  IWantBuyVC.m
//  GGSH
//  我要买列表
//  Created by 任春宁 on 15/6/4.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "IWantBuyVC.h"
#import "IWantBuyCell.h"


//每页多少条
#define PAGE_COUNT_IWANTBUY @"20"

@interface IWantBuyVC ()

@end

@implementation IWantBuyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"愿望清单";
    
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _tableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _tableView;
    _footer.delegate = self;
    
    //获取数据
    [self getDataOfPage:@"1" countOfPage:PAGE_COUNT_IWANTBUY];

}

- (void)endHeaderFooterLoading{
    [_header endRefreshing];
    [_footer endRefreshing];
}

#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    if( refreshView == _header ) {
        //获取数据
        [self getDataOfPage:@"1" countOfPage:PAGE_COUNT_IWANTBUY];
    }
    else{
        
        int pageIndex = (int)(_arrData.count / [PAGE_COUNT_IWANTBUY intValue]);
        pageIndex = pageIndex + 1;
        
        //获取数据
        [self getDataOfPage:[NSString stringWithFormat:@"%d", pageIndex] countOfPage:PAGE_COUNT_IWANTBUY];
    }
    
}

//获取数据
-(void)getDataOfPage:(NSString*)pageIndex countOfPage:(NSString*)count{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Personal" forKey:@"Mod"];
    [dic setObject:@"buyList" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:pageIndex forKey:@"pageindex"];
    [dicContent setObject:count forKey:@"pagesize"];
    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if (resultDic == nil) {
            [self showAlert:nil withTitle:@"操作失败" haveCancelButton:NO];
        }
        else if( [[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            if ([pageIndex intValue] > 1) {
                NSArray * arrTmp = [resultDic objectForKey:@"DetailInfo"];
                [self mergeData:arrTmp];
            }
            else{
                _arrData = [resultDic objectForKey:@"DetailInfo"];
            }
            [_tableView reloadData];
        }
        else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
        
        [self endHeaderFooterLoading];
        
    }];
}

//合并数据
-(void)mergeData:(NSArray*)arrNew{
    
    if (_arrData == nil) {
        _arrData = arrNew;
        return;
    }
    
    NSMutableArray * arrTmpNew = [[NSMutableArray alloc] initWithArray:_arrData];
    
    for (NSDictionary * dicNew in arrNew){
        NSString * strIDNew = [dicNew objectForKey:@"id"];
        
        BOOL find = NO;
        for( int i = 0; i < _arrData.count; i ++ ){
            NSDictionary * dicOld = [_arrData objectAtIndex:i];
            NSString * strIdOld = [dicOld objectForKey:@"id"];
            
            if ([strIDNew isEqualToString:strIdOld]) {
                find = YES;
                break;
            }
        }
        
        if (!find) {
            [arrTmpNew addObject:dicNew];
        }
    }
    
    _arrData = arrTmpNew;

}


#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arrData.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dic = [_arrData objectAtIndex:indexPath.row];
    NSString *desStr = [dic objectForKey:@"description"];
    CGSize  size = [NSString getHeight:desStr withFont:[UIFont systemFontOfSize:13] andWidth:SCREEN_WIDTH - 8];
    if(size.height > 21){
        return size.height + 151 - 21;
    }
    
    return 151;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //翻页CELL
    static NSString *CellIdentifier = @"COMMONCELL";
    
    IWantBuyCell *cell = (IWantBuyCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil){
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"IWantBuyCell" owner:self options:nil];
        for(id oneObject in nib){
            cell = (IWantBuyCell *)oneObject;
        }
    }
    
    NSDictionary * dic = [_arrData objectAtIndex:indexPath.row];
    
    //标题
    UILabel * lbTitle = (UILabel *)[cell.contentView viewWithTag:21];
    lbTitle.text = [dic objectForKey:@"title"];
    
    //目标区域
    UILabel * lbRegion = (UILabel *)[cell.contentView viewWithTag:22];
    lbRegion.text = [NSString stringWithFormat:@"目标区域：%@",[dic objectForKey:@"area"]];
    
    //需求类型
    UILabel * lbType = (UILabel *)[cell.contentView viewWithTag:23];
    lbType.text = [NSString stringWithFormat:@"需求类型：%@", [dic objectForKey:@"type"]];
    
    //期望价格
    UILabel * lbPrice = (UILabel *)[cell.contentView viewWithTag:26];
    NSString * strStartPrice = [dic objectForKey:@"startprice"];
    NSString * strEndPrice = [dic objectForKey:@"endprice"];
    lbPrice.text = [NSString stringWithFormat:@"期望价格：￥%.2f-￥%.2f", [strStartPrice floatValue] / 100, [strEndPrice floatValue] / 100 ];
    
    //联系方式
    UILabel * lbMobile = (UILabel *)[cell.contentView viewWithTag:25];
    lbMobile.text = [NSString stringWithFormat:@"联系方式：%@", [dic objectForKey:@"phone"]];
    
    //其他要求
    
    UILabel * lbOther = (UILabel *)[cell.contentView viewWithTag:27];
    NSString *desStr = [dic objectForKey:@"description"];
    CGSize size = [NSString getHeight:desStr withFont:[UIFont systemFontOfSize:13] andWidth:SCREEN_WIDTH - 83];
    lbOther.frame = CGRectMake(lbOther.frame.origin.x, lbOther.frame.origin.y, SCREEN_WIDTH - 83, size.height);
    lbOther.text = desStr;
    
    //时间
    UILabel * lbTime = (UILabel *)[cell.contentView viewWithTag:28];
    NSString * strTime = [dic objectForKey:@"ctime"];
    lbTime.text = [strTime substringWithRange:NSMakeRange(0, 10)];
    
    return cell;
    
    
}

-(void)add_wantbuy_success:(NSDictionary*)dic{
    
    NSMutableArray * arr = [[NSMutableArray alloc] initWithArray:_arrData];
    [arr addObject:dic];
    _arrData = arr;
    [_tableView reloadData];
    
}

@end
