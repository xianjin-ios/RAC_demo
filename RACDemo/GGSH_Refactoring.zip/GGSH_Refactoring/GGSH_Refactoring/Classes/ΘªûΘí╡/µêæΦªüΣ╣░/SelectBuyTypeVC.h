//
//  SelectBuyTypeVC.h
//  GGSH
//  选择产品类别-我要买
//  Created by 任春宁 on 15/6/8.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@protocol BUY_TYPE_DELEGATE <NSObject>

-(void)buyTypeSelectFinish:(NSDictionary *)dicInfo;

-(void)buyTypeSelectCancel;

@end

@interface SelectBuyTypeVC : BaseViewController<UITableViewDataSource, UITableViewDelegate>{
    
    IBOutlet UITableView * _tableView;
        
    //类型列表
    NSArray  * _arrTypeList;
    
    //选择结果
    NSDictionary * _dicSelected;
    
}


@property (nonatomic, strong) id< BUY_TYPE_DELEGATE> delegate;

//取消
-(IBAction)clickCancel:(id)sender;

//确定
-(IBAction)clickOK:(id)sender;

@end
