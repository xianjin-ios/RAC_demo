//
//  IWantBuyVC.h
//  GGSH
//  我要买列表
//  Created by 任春宁 on 15/6/4.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "MJRefresh.h"

@interface IWantBuyVC : BaseViewController<UITableViewDataSource, UITableViewDelegate, MJRefreshBaseViewDelegate>{
    
    //表
    IBOutlet UITableView * _tableView;
    
    
    //数据列表
    NSArray * _arrData;
    
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
}

@end
