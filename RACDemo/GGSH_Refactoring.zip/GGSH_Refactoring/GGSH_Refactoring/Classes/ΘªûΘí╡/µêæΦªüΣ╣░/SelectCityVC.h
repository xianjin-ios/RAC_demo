//
//  SelectCityVC.h
//  GGSH
//  选择省市-用于我要购买
//  Created by 任春宁 on 15/6/5.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "GYCityViewController.h"

@interface SelectCityVC : UIViewController<UITableViewDataSource, UITableViewDelegate>{
    
    //省
    IBOutlet UITableView * _tableViewProvince;
    //市
    IBOutlet UITableView * _tableViewCity;
    
    NSArray * _arrCityList;
    
    
    //被选中的省份的信息
    NSDictionary * _dicSelectProvince;
    
    //被选中的城市信息
    NSDictionary * _dicSelectCity;

    
    
}

//@property (nonatomic, retain) id<SelectCityDelegate> delegate;


-(IBAction)cancelClick:(id)sender;

-(IBAction)clickOK:(id)sender;

@end
