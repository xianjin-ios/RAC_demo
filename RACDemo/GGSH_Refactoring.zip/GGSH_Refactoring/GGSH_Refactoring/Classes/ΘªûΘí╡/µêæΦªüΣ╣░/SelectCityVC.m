//
//  SelectCityVC.m
//  GGSH
//  选择省市-用于我要购买
//  Created by 任春宁 on 15/6/5.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "SelectCityVC.h"

@interface SelectCityVC ()

@end

@implementation SelectCityVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView * vContainer = [self.view viewWithTag:111];
    vContainer.layer.borderColor = [UIColor lightGrayColor].CGColor;
    vContainer.layer.borderWidth = 0.5f;
    vContainer.layer.cornerRadius = 6;
    
    //获取城市列表
    [self getCityList];
    
    [_tableViewProvince reloadData];

}

//获取城市列表
-(void)getCityList{
    
    NSString *path = [[NSBundle mainBundle]  pathForResource:@"ProvinceAndCities" ofType:@"geojson"];
    NSData *jdata = [[NSData alloc] initWithContentsOfFile:path ];
    NSError* error;
    NSDictionary * dicCitys = [NSJSONSerialization JSONObjectWithData:jdata options:kNilOptions error:&error];
    
    _arrCityList = [dicCitys objectForKey:@"DetailInfo"];
    
}


#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == _tableViewProvince) {
        return _arrCityList.count;
    }
    
    if (tableView == _tableViewCity) {
        
        if (_dicSelectProvince == nil) {
            return 0;
        }
        
        NSArray * arrCitys = [_dicSelectProvince objectForKey:@"city"];
        return arrCitys.count;
    }
    
    return 0;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (tableView == _tableViewProvince) {
        _dicSelectProvince = [_arrCityList objectAtIndex:indexPath.row];
        [_tableViewCity reloadData];
    }
    
    if (tableView == _tableViewCity) {
        NSArray * arrCitys = [_dicSelectProvince objectForKey:@"city"];
        _dicSelectCity = [arrCitys objectAtIndex:indexPath.row];
    }
    

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //翻页CELL
    static NSString *CellIdentifier = @"commoncell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.contentView.clipsToBounds = YES;
        cell.textLabel.font = [UIFont systemFontOfSize:14];
    }
    
    if (tableView == _tableViewProvince) {
        NSLog(@"初始化：%ld", indexPath.row);
        
        NSDictionary * dic = [_arrCityList objectAtIndex:indexPath.row];
        NSString * strName = [dic objectForKey:@"regionname"];
        cell.textLabel.text = strName;
        
    }
    else if (_dicSelectProvince != nil) {
        
        NSArray * arrCitys = [_dicSelectProvince objectForKey:@"city"];
        NSDictionary * dic = [arrCitys objectAtIndex:indexPath.row];
        NSString * strName = [dic objectForKey:@"name"];
        cell.textLabel.text = strName;
    }
    
    return  cell;
    
}


-(IBAction)cancelClick:(id)sender{
    
//    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(CancelSelect)]) {
//        [self.delegate CancelSelect];
//    }
}

//点击确定
-(IBAction)clickOK:(id)sender{
    
//    if (_dicSelectProvince == nil || _dicSelectCity == nil) {
//        [MyAppDelegate showAlert:@"请选择城市"];
//        return;
//    }
//    
//    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(FinishSelect:)]) {
//        
//        //封装选择结果信息
//        NSMutableDictionary * dicInfo = [[NSMutableDictionary alloc] initWithDictionary:_dicSelectProvince];
//        [dicInfo setObject:_dicSelectCity forKey:@"selectcity"];
//        
//        [self.delegate FinishSelect:dicInfo];
//    }
}

@end
