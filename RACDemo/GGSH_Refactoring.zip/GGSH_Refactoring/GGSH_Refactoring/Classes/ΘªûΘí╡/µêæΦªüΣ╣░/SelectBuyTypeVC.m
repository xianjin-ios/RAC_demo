//
//  SelectBuyTypeVC.m
//  GGSH
//  选择产品分类-我要买
//  Created by 任春宁 on 15/6/8.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "SelectBuyTypeVC.h"

@interface SelectBuyTypeVC ()

@end

@implementation SelectBuyTypeVC

- (void)viewDidLoad {
    [super viewDidLoad];

    [self getData];
}

//取消
-(IBAction)clickCancel:(id)sender;{
    
    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(buyTypeSelectCancel)]) {
        [self.delegate buyTypeSelectCancel];
    }
}

//确定
-(IBAction)clickOK:(id)sender{
    
    if (_dicSelected == nil) {
        [self showAlert:nil withTitle:@"请选择分类" haveCancelButton:NO];
        return;
    }
    
    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(buyTypeSelectFinish:)]) {
        
        [self.delegate buyTypeSelectFinish:_dicSelected];
    }
}

-(void)getData{
        
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"ShopSelect",@"Mod",@"buyType",@"Act",item,@"Content", nil];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if ([results isKindOfClass:[NSDictionary class]]) {
            int code = [[results objectForKey:@"Code"] intValue];
            if (code == 0000) {
                
                _arrTypeList = [results objectForKey:@"DetailInfo"];
                [_tableView reloadData];
            }
        }
    }];
}


#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return _arrTypeList.count;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   _dicSelected = [_arrTypeList objectAtIndex:indexPath.row];

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //翻页CELL
    static NSString *CellIdentifier = @"commoncell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.contentView.clipsToBounds = YES;
        cell.textLabel.font = [UIFont systemFontOfSize:14];
    }
    
    NSDictionary * dic = [_arrTypeList objectAtIndex:indexPath.row];
    cell.textLabel.text = [dic objectForKey:@"explain"];
    
    return cell;
}

@end
