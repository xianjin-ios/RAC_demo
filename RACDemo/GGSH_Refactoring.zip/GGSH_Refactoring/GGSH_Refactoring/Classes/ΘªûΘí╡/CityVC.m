//
//  CityVC.m
//  cards
//
//  Created by STAR on 12-12-24.
//  Copyright (c) 2012年 STAR. All rights reserved.
//

#import "CityVC.h"
#import "AppDelegate.h"
//#import "Cityenty.h"
@interface CityVC (){
    NSMutableArray *dataArray;
}

@end

@implementation CityVC

-(IBAction)backAction{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"选择城市";
    dataArray = MyAppDelegate.citylist;

    [_iMyTableView reloadData];
}

#pragma network end
- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc]init];
    cell.textLabel.text = [[dataArray objectAtIndex:indexPath.row] cityname];
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    return cell;
}

//指定有多少个分区(Section)，默认为1
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

//指定每个分区中有多少行，默认为1
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return dataArray.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPat {
    return 40;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    MyAppDelegate.curcity = indexPath.row;
//    [[NSUserDefaults standardUserDefaults] setObject:[[MyAppDelegate.citylist objectAtIndex:indexPath.row] cityname] forKey:@"CityName"];
//    [NSUserDefaults setObject:[[MyAppDelegate.citylist objectAtIndex:indexPath.row] cityid] forKey:@"CityID"];
//
//    
//    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
//    [dic setObject:[[MyAppDelegate.citylist objectAtIndex:indexPath.row] cityname]  forKey:@"CityName"];
//    [dic setObject:[[MyAppDelegate.citylist objectAtIndex:indexPath.row] cityid] forKey:@"CityID"];
//    
//    //标记城市已经切换
//    MyAppDelegate.localflag = YES;
//    
//    if ( self.delegate != nil && [self.delegate respondsToSelector:@selector(FinishSelect:)]) {
//        [self.delegate FinishSelect:dic];
//    }
//    
//    [self.navigationController popViewControllerAnimated:YES];
//    MyAppDelegate.cityChangeFalg = YES;
//    MyAppDelegate.weiboCityChangeFlag = 1;
}
@end
