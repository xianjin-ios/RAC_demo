//
//  GGBtn.h
//  GGSH_Refactoring
//
//  Created by siqiyang on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef enum: NSInteger{
    FirstInMiddleType//首页中间的那几个按钮的类型
    
} GGButtonType;
@interface GGBtn : UIButton

@property (nonatomic,assign) GGButtonType ggButtonType;

@end
