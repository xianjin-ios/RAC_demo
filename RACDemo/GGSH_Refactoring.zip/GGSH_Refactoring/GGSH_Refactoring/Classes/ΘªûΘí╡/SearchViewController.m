//
//  SearchViewController.m
//  GGSH_Refactoring
//
//  Created by siqiyang on 16/9/30.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "SearchViewController.h"
#import "UIView+Extension.h"
#import "lookGoodsCell.h"
#import "GYShopCell.h"
#import "LineView.h"
@interface SearchViewController ()<UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UITextFieldDelegate>

{
    __weak IBOutlet UIView *topView;
    //搜索内容
    UITextField *_lbSearch;
     UITableView *iTableView;

    //三个分类按钮下边的线
    IBOutlet UIView *pinkLineView;
    
    //
    IBOutlet UICollectionView *iCollectionView;
    UIView *noView;
    MJRefreshHeaderView *_headerCollection;
    MJRefreshFooterView *_footerCollection;
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    
    IBOutlet UIButton *btnMerchant;
    IBOutlet UIButton *btnProduct;
    IBOutlet UIButton *btnShop;
    
    //当前页数
    int pageIndex;//商家
    int pageIndex2;//商品
    int pageIndex3;//商场
    
    //区域代码
    NSString *pcode;
    
    //商场数组
    NSMutableArray *_iProductArray;
    NSMutableArray *_iShopArray;

}

@property (nonatomic,strong) NSMutableArray *dataArray;


@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    _dataArray = [[NSMutableArray alloc]init];
    [self addMiddleSearch];
    [self createTableView];
    
    [iCollectionView registerClass:[lookGoodsCell class] forCellWithReuseIdentifier:@"lookCell"];
    
    pcode = @"010";
    [self getPcode];
}

//获取地区信息
- (void)getPcode{
    if ([MyAppDelegate.localDic objectForKey:MyAppDelegate.curcityname]) {
        pcode = [MyAppDelegate.localDic objectForKey:MyAppDelegate.curcityname];
    }
    ZLog(@"%@＝＝%@",MyAppDelegate.localDic,MyAppDelegate.curcityname);
    ZLog(@"pcodeStr == %@",pcode);
}

//标题栏为搜索框
- (void)addMiddleSearch{
    CGFloat width = SCREEN_WIDTH - 90;
    UIView *bgview = [[UIView alloc]initWithFrame:CGRectMake(0, 0,width, 28)];
    bgview.backgroundColor = [UIColor clearColor];
    bgview.center = CGPointMake(SCREEN_WIDTH/2, 44/2);
    self.navigationItem.titleView = bgview;
    CGFloat adjust = 25;
    UIImageView *imgSearBg = [[UIImageView alloc] initWithFrame:CGRectMake(-15 - adjust, 0,width, 28)];
    imgSearBg.image = [UIImage imageNamed:@"search_mid.png"];
    [bgview addSubview:imgSearBg];
    //
    UIImageView *imgSear = [[UIImageView alloc] initWithFrame:CGRectMake(-10-adjust, 8, 11, 11)];
    imgSear.image = [UIImage imageNamed:@"search_red.png"];
    [bgview addSubview:imgSear];
    
    //输入框
    _lbSearch = [[UITextField alloc] initWithFrame:CGRectMake(5-adjust, 8, width-25, 12)];
    _lbSearch.textColor = [UIColor lightGrayColor];
    _lbSearch.placeholder = @"输入商家名称、商品名称或商场名称";
    _lbSearch.font = [UIFont systemFontOfSize:12];
    [bgview addSubview:_lbSearch];
    _lbSearch.returnKeyType = UIReturnKeySearch;
    _lbSearch.clearButtonMode = UITextFieldViewModeWhileEditing;
    _lbSearch.delegate = self;
    [_lbSearch becomeFirstResponder];
    //cancel
    UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    cancelButton.frame = CGRectMake(width- 35, 0.0, 40, 25);
    [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    [cancelButton setTitle:@"取消" forState:UIControlStateHighlighted];
    [cancelButton addTarget:self action:@selector(gotoHome) forControlEvents:UIControlEventTouchUpInside];
    cancelButton.titleLabel.font = [UIFont systemFontOfSize:14];
    [bgview addSubview:cancelButton];
    
}

/**
 创建tableView视图
 */
- (void)createTableView{
    iTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, topView.M_bottom, SCREEN_WIDTH, SCREEN_HEIGHT- 64-topView.M_bottom) style:UITableViewStylePlain];
    iTableView.delegate =self;
    iTableView.dataSource = self;
    iTableView.tableFooterView = [[UIView alloc]init];
    
    
    [self.view addSubview:iTableView];
    
}
#pragma mark - 设置tab按钮状态
//设置所有按钮未选中
- (void)setAllBtnNoState{
    [btnMerchant setSelected:NO];
    [btnProduct setSelected:NO];
    [btnShop setSelected:NO];
    [_lbSearch resignFirstResponder];
}

- (IBAction)merchantBtnSelect:(id)sender{
    [self setAllBtnNoState];
    [btnMerchant setSelected:YES];
    
    pageIndex = 1;
    [self doSearchMerchant];
    
    //2个view显示1个
    [iCollectionView setHidden:YES];
    [iTableView setHidden:NO];
    
    //清网络获取期间旧数据
    [iTableView reloadData];
    
    //下划线移动
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    pinkLineView.frame = CGRectMake( 0, 42, SCREEN_WIDTH / 3, 2);
    [UIView commitAnimations];
}

- (IBAction)productBtnSelect:(id)sender{
    [self setAllBtnNoState];
    [btnProduct setSelected:YES];
    
    pageIndex2 = 1;
    [self doSearchProduct];
    
    [iCollectionView setHidden:NO];
    [iTableView setHidden:YES];
    
    //清网络获取期间旧数据
    [iCollectionView reloadData];
    
    //下划线移动
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    pinkLineView.frame = CGRectMake( SCREEN_WIDTH / 3, 42, SCREEN_WIDTH / 3, 2);
    [UIView commitAnimations];
}

- (IBAction)shopBtnSelect:(id)sender{
    [self setAllBtnNoState];
    [btnShop setSelected:YES];
    
    pageIndex3 = 1;
    [self doSearchShop];
    
    [iCollectionView setHidden:YES];
    [iTableView setHidden:NO];
    
    //清网络获取期间旧数据
    [iTableView reloadData];
    
    
    //下划线移动
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    pinkLineView.frame = CGRectMake( SCREEN_WIDTH / 3 * 2, 42, SCREEN_WIDTH / 3, 2);
    [UIView commitAnimations];
}
#pragma mark - 搜索
- (void)doSearchMerchant{
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [item setObject:@"" forKey:@"uid"];
        [item setObject:@"" forKey:@"logintoken"];
        
    }
    
    [item setObject:_lbSearch.text forKey:@"keyword"];
    [item setObject:[NSString stringWithFormat:@"%f",MyAppDelegate.ilongitude] forKey:@"longitude"];
    [item setObject:[NSString stringWithFormat:@"%f",MyAppDelegate.ilatitude] forKey:@"latitude"];
    
    [item setObject:[NSNumber numberWithInt:pageIndex] forKey:@"pageindex"];
    [item setObject:[NSNumber numberWithInt:20] forKey:@"pagesize"];
    
    [item setObject:[NSString stringWithFormat:@"%@",pcode] forKey:@"pcode"];
    [item setObject:@"" forKey:@"shoptype"];
    [item setObject:@"" forKey:@"distance"];
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
//
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:[NSDictionary dictionaryWithObjectsAndKeys:@"ShopSelect",@"Mod",@"Shoplist",@"Act",item,@"Content" ,nil]];

       [self showHUD];
    [xkNetwork xk_requstWithDic:dict withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        ZLog(@"%@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSMutableDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        if ([[results objectForKey:@"Code"]isEqualToString:@"0000"]) {
            if (pageIndex == 1) {
                if (self.dataArray.count != 0) {
                    [self.dataArray removeAllObjects];
                }
                self.dataArray = [results objectForKey:@"DetailInfo"];
            }
            else{
                NSMutableArray *tempArr = [results objectForKey:@"DetailInfo"];
                [self.dataArray addObjectsFromArray:tempArr];
            }
            
        }else{
            pageIndex -= 1;
            //                        [MyAppDelegate showAlert:[results objectForKey:@"Message"]];
        }
        
        [iTableView reloadData];
        
        if (self.dataArray.count == 0) {
            //无数据提示
            [self constructNoDataView];
            [iTableView addSubview:noView];
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }

        
        }
     
    }];

   
}
   
- (void)constructNoDataView{
         if (!noView) {
             noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
             noView.backgroundColor = [UIColor clearColor];
             noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
             UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
             bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
             UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
             labela.backgroundColor = [UIColor clearColor];
             labela.text = @"暂无内容";
             labela.textAlignment = 1;
             labela.font = [UIFont systemFontOfSize:15];
             labela.textColor = [UIColor lightGrayColor];
             [bigbeen addSubview:labela];
             [noView addSubview:bigbeen];
         }
     }
     
- (void)doSearchProduct{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"GoodsSel" forKey:@"Mod"];
    [dic setObject:@"homeGoodsList" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:pcode forKey:@"pcode"];
    if (_lbSearch.text.length) {
        [dicContent setObject:_lbSearch.text forKey:@"keyword"];
    }
    else
    [dicContent setObject:@"" forKey:@"keyword"];
    //筛选条件
    [dicContent setObject:@"" forKey:@"sortprice"];
    [dicContent setObject:@"" forKey:@"sortsell"];
    
    [dicContent setObject:[NSNumber numberWithInt:pageIndex2] forKey:@"pageindex"];
    [dicContent setObject:[NSNumber numberWithInt:10] forKey:@"pagesize"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
     [self showHUD];

    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        ZLog(@"responseString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        ZLog(@"message is:%@",[resultDic objectForKey:@"Message"]);
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            if(1 == pageIndex2){
                _iProductArray = [[resultDic objectForKey:@"DetailInfo"]mutableCopy];
            }else{
                //上拉增加新数据
                [_iProductArray addObjectsFromArray:[resultDic objectForKey:@"DetailInfo"]];
            }
        }else{
            //
            _iProductArray = [resultDic objectForKey:@"DetailInfo"];
        }
        [iCollectionView reloadData];
        
        if (_iProductArray.count == 0) {
            //无数据提示
            [self constructNoDataView];
            [iCollectionView addSubview:noView];
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }

        
    }];
}


- (void)doSearchShop{
    
    
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"searchShopList" forKey:@"Mod"];
    [dic setObject:@"searchShopList" forKey:@"Act"];
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"DeviceID"];

    //获取区域
    NSString * cityID = [USERDEFAULT objectForKey:@"CityID"];
    
    //设置区域
    if(cityID && cityID.length > 0){
        [item setObject:cityID forKey:@"RegionID"];
    }else{
        [item setObject:@"D0101" forKey:@"RegionID"];
    }
    
    [item setObject:_lbSearch.text forKey:@"Keywords"];
    [item setObject:@"1" forKey:@"ShopType"];
    [item setObject:[NSNumber numberWithInt:pageIndex3] forKey:@"PageIndex"];
    [item setObject:[NSNumber numberWithInt:20] forKey:@"PageSize"];
    [dic setObject:item forKey:@"Content"];
    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:kSearch withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        ZLog(@"responseString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSMutableDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        
        if ([results isKindOfClass:[NSDictionary class]]) {
            
            if ([[[results objectForKey:@"Result"] objectForKey:@"ListInfo"] isKindOfClass:[NSArray class]]) {
                int code = [[[results objectForKey:@"Result"] objectForKey:@"ErrorCode"] intValue];
                if (code == 0000) {
                    if (pageIndex3 == 1) {
                        if (_iShopArray.count != 0) {
                            [_iShopArray removeAllObjects];
                        }
                        _iShopArray = [[[results objectForKey:@"Result"] objectForKey:@"ListInfo"] mutableCopy];
                    }else{
                        NSMutableArray *tempArr = [[results objectForKey:@"Result"] objectForKey:@"ListInfo"];
                        [_iShopArray addObjectsFromArray:tempArr];
                    }
                    
                }else{
                    pageIndex3 -= 1;
                    [self showalertString:[[results objectForKey:@"Result"] objectForKey:@"Message"]];
                }
                
            }else
                pageIndex3 = 1;
            
            [iTableView reloadData];
            
            if (_iShopArray.count == 0) {
                //无数据提示
                [self constructNoDataView];
                [iTableView addSubview:noView];
            }else{
                if (noView) {
                    [noView removeFromSuperview];
                    noView = nil;
                }
            }
        }

        
    }];
    
}



//取消搜索，返回到前一页面
- (void)gotoHome{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (btnMerchant.selected) {//商家
        [self doSearchMerchant];
    }
    if (btnProduct.selected) {//商品
        [self doSearchProduct];
    }
    if (btnShop.selected) {//商场
        [self doSearchShop];
    }
   
    return YES;
}
#pragma mark - tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if([btnShop isSelected]){
        return _iShopArray.count;
    }else if([btnMerchant isSelected]){
        return self.dataArray.count;
    }else
        return _iProductArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

//商场cell
- (UITableViewCell *)tableViewShop:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"GYShopCell";
    GYShopCell *cell = (GYShopCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[GYShopCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.dataSource = [_iShopArray objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if([btnShop isSelected]){
        //商场cell
        return [self tableViewShop:tableView cellForRowAtIndexPath:indexPath];
    }
    if (tableView == iTableView) {
        static NSString *identifier = @"mposMerchantCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
        }
        
        //防止cell重叠
        while ([cell.contentView.subviews lastObject] ) {
            [(UIView *)[cell.contentView.subviews lastObject] removeFromSuperview];
        }
        
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        //        UIImageView *cellBg = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0,SCREEN_WIDTH, 60)];
        //        cellBg.image = _cellImage;
        //        [cell.contentView addSubview:cellBg];
        [cell.contentView setBackgroundColor:[UIColor whiteColor]];
        
        UIImageView *merchantIcon = [[UIImageView alloc]initWithFrame:CGRectMake(15, 7, 45, 45)];

        //        merchantIcon.image = _merchantDefault;
        [cell.contentView addSubview:merchantIcon];
        
        UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(65, 5, 240, 20)];
        titleLabel.font = [UIFont systemFontOfSize:15];
        titleLabel.textColor = [UIColor blackColor];
        titleLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:titleLabel];
        
        UILabel *detailLabel = [[UILabel alloc]initWithFrame:CGRectMake(65, 35, 180, 20)];
        detailLabel.font = [UIFont systemFontOfSize:14];
        detailLabel.textColor = [UIColor lightGrayColor];
        detailLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:detailLabel];
        
        UILabel *distanceLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width-10-80, 35, 80, 20)];
        distanceLabel.textAlignment = 2;
        distanceLabel.font = [UIFont systemFontOfSize:14];
        distanceLabel.textColor = [UIColor darkGrayColor];
        distanceLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:distanceLabel];
        
        LineView *downLine = [[LineView alloc]initWithFrame:CGRectMake(0, 59.5, SCREEN_WIDTH, 0.5)];
        downLine.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:downLine];
        
        //
        ZLog(@"%@",self.dataArray);
        
        if (self.dataArray.count != 0) {
            NSString *urlStr = [[self.dataArray objectAtIndex:indexPath.row]objectForKey:@"listpic"];
            [merchantIcon XK_setImageWithURL:urlStr placeholderImage:nil];
            
            titleLabel.text = [NSString stringWithFormat:@"%@",[[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"shopname"]];
            detailLabel.text = [NSString stringWithFormat:@"%@",[[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"address"]];
            
            float distance = [[[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"distance"] floatValue];
            ZLog(@"distance = %f",distance);
            if (distance * 0.001 > 1) {
                distanceLabel.text = [NSString stringWithFormat:@"%.2fkm",distance * 0.001];
            }else
                distanceLabel.text = [NSString stringWithFormat:@"%.2fm",distance];
            
        }
        return cell;
    }
    
    return nil;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if (tableView == iTableView) {
//        if([btnMerchant isSelected]){
//            //商家
//            mposDetailViewController *detailV = [[mposDetailViewController alloc]init];
//            detailV.merDic = [self.dataArray objectAtIndex:indexPath.row];
//            [self.navigationController pushViewController:detailV animated:YES];
//            [detailV release];
//        }
//        if([btnShop isSelected]){
//            //商户
//            GYShopDetailViewController *idetailView = [[GYShopDetailViewController alloc] init];
//            idetailView.shopID = [[_iShopArray objectAtIndex:indexPath.row]objectForKey:@"ShopID"];
//            [self.navigationController pushViewController:idetailView animated:YES];
//        }
//    }
}

#pragma mark - collectionView
- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section;
{
    return _iProductArray.count;
}

//边框
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    lookGoodsCell *cell = [cv dequeueReusableCellWithReuseIdentifier:@"lookCell" forIndexPath:indexPath];
    
    ZLog(@"%@",_iProductArray);
    NSDictionary *dic = [_iProductArray objectAtIndexedSubscript:indexPath.row];
    cell.dicCell = dic;
    [cell awakeFromNib];
    
    return cell;
}



@end
