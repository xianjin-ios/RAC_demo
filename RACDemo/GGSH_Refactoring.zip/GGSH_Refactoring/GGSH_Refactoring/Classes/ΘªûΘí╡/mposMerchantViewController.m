//
//  mposMerchantViewController.m
//  GGSH
//
//  Created by heyddo on 15/3/13.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "mposMerchantViewController.h"
#import "MJRefresh.h"
#import "mposDetailViewController.h"
//#import "MapViewController.h"
#import "MyMessageVC.h"
#import "LoginVC.h"
#import "LineView.h"
#import "SearchViewController.h"

@interface mposMerchantViewController ()<MJRefreshBaseViewDelegate,loginDelegate>
{
    UIView *baseView;
    UIView *noView;
    
    NSInteger selectRow;
    NSInteger selectRow1;
    NSInteger selectRow2;
    NSInteger selectRow3;
    
    int pageIndex;
    
    BOOL type1_Select;
    
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    
    NSString *pcode;
    NSString *order;
    NSString *_selectCityName;
    
    UIImage *_cellImage;
    UIImage *_merchantDefault;
    UIImage *_type_cell;
    UIImage *_type_select;
    UIImage *_type_line;
    
    NSArray *distanceList;
    NSMutableArray *typeDefaultList;
    
    NSMutableArray *noDataArr;
    
    UIImageView *imageAlert;
    
    IBOutlet UITableView *iTableView;
    NSDate *date;
    
    NSMutableArray *dataArray;
}
@end

@implementation mposMerchantViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"逛云商";
    [self cancelTapHideKeyBoard:YES];
    _header = [MJRefreshHeaderView header];
    _header.scrollView = iTableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = iTableView;
    _footer.delegate = self;
    
    //添加导航栏右边按钮
    UIButton *searchButton = [UIButton buttonWithType:UIButtonTypeCustom];
    searchButton.frame = CGRectMake(0.0, 0.0, 16, 16);
    [searchButton addTarget:self action:@selector(gotoSearchView) forControlEvents:UIControlEventTouchUpInside];
    [searchButton setBackgroundImage:[UIImage imageNamed:@"nav_search.png"] forState:UIControlStateNormal];
    searchButton.titleLabel.font = [UIFont systemFontOfSize:13];
    UIBarButtonItem *rightBarButtonItem1 = [[UIBarButtonItem alloc] initWithCustomView:searchButton];
    rightBarButtonItem1.style = UIBarButtonItemStylePlain;

    UIButton *editButton = [UIButton buttonWithType:UIButtonTypeCustom];
    editButton.frame = CGRectMake(0.0, 0.0, 16, 16);
    [editButton addTarget:self action:@selector(gotoMessage) forControlEvents:UIControlEventTouchUpInside];
    [editButton setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    editButton.titleLabel.font = [UIFont systemFontOfSize:13];
    UIBarButtonItem *rightBarButtonItem2 = [[UIBarButtonItem alloc] initWithCustomView:editButton];
    rightBarButtonItem2.style = UIBarButtonItemStylePlain;
    //判断是否要添加红点提示
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(10, -4, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [rightBarButtonItem2.customView addSubview:imageAlert];
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
    self.navigationItem.rightBarButtonItems =  @[rightBarButtonItem2, rightBarButtonItem1];

    //初始化数据
    self.localtionNearByDic = [NSMutableDictionary dictionaryWithCapacity:2];
    self.typeArray = [NSMutableArray arrayWithCapacity:2];
    self.typeDetailArray = [NSMutableArray arrayWithCapacity:2];
    
    //创建topview
    [self setTopView];

    //创建一个底层半透明 view,作为条件选择的 tableview 载体
    baseView = [[UIView alloc]init];
    [baseView setFrame:CGRectMake(0, 45, self.view.frame.size.width, 0)];
    baseView.backgroundColor = [UIColor blackColor];
    baseView.alpha = 0.6;
    [self.view addSubview:baseView];
    
//增加一个手势，取消显示选择列表
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(cancelShowBaseView:)];
    [baseView addGestureRecognizer:tap1];
    
    self.typeTableView = [[UITableView alloc]init];
    self.typeTableView.delegate = self;
    self.typeTableView.dataSource = self;
    self.typeTableView.backgroundColor = [UIColor colorAndAlphaWithHexString:@"#f6f6f6"];
    self.typeTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width/3, 0)];
    [self.view addSubview:self.typeTableView];
    
    self.typeDetailTableView = [[UITableView alloc]init];
    self.typeDetailTableView.delegate = self;
    self.typeDetailTableView.dataSource = self;
    self.typeDetailTableView.backgroundColor = [UIColor clearColor];
    self.typeDetailTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.typeDetailTableView setFrame:CGRectMake(self.view.frame.size.width/3, 45, self.view.frame.size.width/3*2, 0)];
    [self.view addSubview:self.typeDetailTableView];
  
    
    [iTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width, SCREEN_HEIGHT - 64 - 45)];
    
    _cellImage = [UIImage imageNamed:@"mpos_cell.png"];
    _merchantDefault = [UIImage imageNamed:@"mpos_icon.png"];
    _type_cell = [UIImage imageNamed:@"around_topcellselect.png"];
    _type_select = [UIImage imageNamed:@"around_topcellBg.png"];
    _type_line = [UIImage imageNamed:@"around_topcellLine.png"];
    
    distanceList = @[@"500M",@"1000M",@"1500M"];

    [self resetNear];
    [self getNetWork];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getNetWork) name:kGotLocation object:nil];

    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
}

- (void)refreshNavBtn{
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
}

- (void)setTopView{
    
    //地区按钮
    pcodeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [pcodeBtn setBackgroundColor:[UIColor clearColor]];
    [pcodeBtn setFrame:CGRectMake(0, 0, SCREEN_WIDTH/3 - 25, 44.5)];
    [pcodeBtn addTarget:self action:@selector(pcodeBtn:) forControlEvents:UIControlEventTouchUpInside];
    pcodeBtnLabel  = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH/3 - 30, 44.5)];
    [pcodeBtnLabel setBackgroundColor:[UIColor clearColor]];
    [pcodeBtnLabel setTextAlignment:NSTextAlignmentRight];
    [pcodeBtnLabel setFont:[UIFont systemFontOfSize:15]];
    [pcodeBtnLabel setTextColor:[UIColor darkTextColor]];
    [pcodeBtnLabel setText:@"全部地区"];
    pcodeBtn.tag = 301;
    UIImageView *selectImg = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH/3 - 20, 20, 14, 6)];
    [selectImg setImage:[UIImage imageNamed:@"mpos_select.png"]];
    [selectImg setHighlightedImage:[UIImage imageNamed:@"mpos_unselect.png"]];
    selectImg.tag = 3011;
    [pcodeBtn addSubview:pcodeBtnLabel];
    [pcodeBtn addSubview:selectImg];
    [_scrollview addSubview:pcodeBtn];
    
    //分类
    typeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [typeBtn setBackgroundColor:[UIColor clearColor]];
    [typeBtn setFrame:CGRectMake(SCREEN_WIDTH/3, 0, SCREEN_WIDTH/3, 44.5)];
    [typeBtn addTarget:self action:@selector(typeBtn:) forControlEvents:UIControlEventTouchUpInside];
    typeBtnLabel  = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH/3 - 30, 44.5)];
    [typeBtnLabel setBackgroundColor:[UIColor clearColor]];
    [typeBtnLabel setTextAlignment:NSTextAlignmentRight];
    [typeBtnLabel setFont:[UIFont systemFontOfSize:15]];
    [typeBtnLabel setTextColor:[UIColor darkTextColor]];
    [typeBtnLabel setText:@"全部分类"];

    typeBtn.tag = 302;
    UIImageView *selectImg1 = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH/3-20, 20, 14, 6)];
    [selectImg1 setImage:[UIImage imageNamed:@"mpos_select.png"]];
    [selectImg1 setHighlightedImage:[UIImage imageNamed:@"mpos_unselect.png"]];
    selectImg1.tag = 3021;
    [typeBtn addSubview:typeBtnLabel];
    [typeBtn addSubview:selectImg1];
    [_scrollview addSubview:typeBtn];
    
    //距离
    distanceBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [distanceBtn setBackgroundColor:[UIColor clearColor]];
    [distanceBtn setFrame:CGRectMake(SCREEN_WIDTH/3*2, 0, SCREEN_WIDTH/3, 44.5)];
    [distanceBtn addTarget:self action:@selector(distanceBtn:) forControlEvents:UIControlEventTouchUpInside];
    distanceBtnLabel  = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH/3 - 30, 44.5)];
    [distanceBtnLabel setBackgroundColor:[UIColor clearColor]];
    [distanceBtnLabel setTextAlignment:NSTextAlignmentRight];
    [distanceBtnLabel setFont:[UIFont systemFontOfSize:15]];
    [distanceBtnLabel setTextColor:[UIColor darkTextColor]];
    [distanceBtnLabel setText:@"距离"];
    distanceBtn.tag = 303;
    UIImageView *selectImg2 = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH/3-20, 20, 14, 6)];
    [selectImg2 setImage:[UIImage imageNamed:@"mpos_select.png"]];
    [selectImg2 setHighlightedImage:[UIImage imageNamed:@"mpos_unselect.png"]];
    selectImg2.tag = 3031;
    [distanceBtn addSubview:distanceBtnLabel];
    [distanceBtn addSubview:selectImg2];
    [_scrollview addSubview:distanceBtn];
    
    UIImageView *downLine = [[UIImageView alloc]initWithFrame:CGRectMake(0, 44.5, SCREEN_WIDTH, 0.5)];
    [downLine setImage:[UIImage imageNamed:@"mpos_line_off1.png"]];
    [_scrollview addSubview:downLine];
    
    downLineIn = [[UIView alloc]init];
    [downLineIn setBackgroundColor:[UIColor whiteColor]];
    [downLineIn setFrame:CGRectMake(0, 0, 17, 8)];
    UIImageView *downImg = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"mpos_line_in.png"]];
    [downImg setFrame:CGRectMake(0, 0, 17, 8)];
    [downLineIn addSubview:downImg];
    [downLineIn setHidden:YES];
    [_scrollview addSubview:downLineIn];
    iTableView.frame = CGRectMake(0, 44.5, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    
    
}

//跳转搜索界面
- (void)gotoSearchView{
    SearchViewController *controller = [[SearchViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];

}

//跳转到消息列表
-(void)gotoMessage{
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];
    
}

- (void)resetNear
{
    //初始化数据
    selectRow1 = 0;
    selectRow2 = 0;
    selectRow3 = 0;
    selectRow = 0;
    
    pageIndex = 1;
    pcode = @"010";
    order = @"";
    MyAppDelegate.mySelectType = 0;//全部分类
    
    [pcodeBtnLabel setText:MyAppDelegate.curcityname?MyAppDelegate.curcityname:@"全部地区"];
    [typeBtnLabel setText:@"全部分类"];
    [distanceBtnLabel setText:@"智能排序"];

}

- (void)getNetWork{
    [self getPcode];
    
    [self getLocalDic];
    
    [self GetTypeNetData];
    
    [self GetShoplistNetData];
}

- (void)getPcode
{
        
    if ([MyAppDelegate.localDic objectForKey:MyAppDelegate.curcityname]) {
        pcode = [MyAppDelegate.localDic objectForKey:MyAppDelegate.curcityname];
    }
    ZLog(@"%@＝＝%@",MyAppDelegate.localDic,MyAppDelegate.curcityname);
    ZLog(@"pcodeStr == %@",pcode);
}

- (void)getLocalDic
{
    NSString *path = [[NSBundle mainBundle]  pathForResource:@"ProvinceAndCities" ofType:@"geojson"];
    NSData *jdata = [[NSData alloc] initWithContentsOfFile:path ];
    NSError* error;
    NSDictionary* Adata = [NSJSONSerialization JSONObjectWithData:jdata options:kNilOptions error:&error];
    self.localtionNearByDic = Adata;
    
    [self setPcodeData];
}

- (void)setPcodeData{
    
    if (self.typeArray.count != 0) {
        [self.typeArray removeAllObjects];
        [self.typeDetailArray removeAllObjects];
    }
    ZLog(@"%@",self.localtionNearByDic);
    
    if ([[self.localtionNearByDic objectForKey:@"DetailInfo"] isKindOfClass:[NSArray class]]) {
        for (int i = 0; i < [[self.localtionNearByDic objectForKey:@"DetailInfo"] count]; i++) {
            NSString *typeName = [NSString stringWithFormat:@"%@",[[[self.localtionNearByDic objectForKey:@"DetailInfo"] objectAtIndex:i] objectForKey:@"regionname"]];
            [self.typeArray addObject:typeName];
        }
    }
    
    self.typeDetailArray = [NSMutableArray arrayWithArray:[[[self.localtionNearByDic objectForKey:@"DetailInfo"] objectAtIndex:selectRow1] objectForKey:@"city"]];
    
    
    [self.typeTableView reloadData];
    [self.typeDetailTableView reloadData];
}
#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(refreshView == _header) {// 下拉刷新
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        //5秒内不能重复发起网络请求，只是界面上闪动下正在加载，就1s。
        if(date){
            NSDate *tenMiniteLater = [date dateByAddingTimeInterval:5];
            NSDate *currentDate = [NSDate date];
            if(NSOrderedDescending == [tenMiniteLater compare:currentDate]){
                ZLog(@"ascending");
                date = [NSDate date];
                [self performSelector:@selector(OneSecondElapse) withObject:nil afterDelay:1];
                [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
                return;
            }
            
            //网络请求
            pageIndex = 1;
            [self GetShoplistNetData];
            
        }else{
            date = [NSDate date];
            //网络请求
            pageIndex = 1;
            [self GetShoplistNetData];
            
        }
        
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    }else if (refreshView == _footer){//上拉加载更多
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        pageIndex += 1;
        
        //网络请求
        [self GetShoplistNetData];
        
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        
    }
}

//1s的假loading，取消正在加载就好
- (void)OneSecondElapse{
    [self hideHUD];
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - network
- (void)GetShoplistNetData{
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];

    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [item setObject:@"" forKey:@"uid"];
        [item setObject:@"" forKey:@"logintoken"];
        
    }

    [item setObject:[NSString stringWithFormat:@"%f",MyAppDelegate.ilongitude] forKey:@"longitude"];
    [item setObject:[NSString stringWithFormat:@"%f",MyAppDelegate.ilatitude] forKey:@"latitude"];

    [item setObject:[NSNumber numberWithInt:pageIndex] forKey:@"pageindex"];
    [item setObject:[NSNumber numberWithInt:20] forKey:@"pagesize"];
    
    [item setObject:[NSString stringWithFormat:@"%@",pcode] forKey:@"pcode"];
    [item setObject:[NSNumber numberWithInteger:MyAppDelegate.mySelectType] forKey:@"shoptype"];
    [item setObject:[NSString stringWithFormat:@"%@",order] forKey:@"distance"];
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"ShopSelect",@"Mod",@"Shoplist",@"Act",item,@"Content", nil];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        

            
        if (pageIndex == 1) {
            if (dataArray.count != 0) {
                [dataArray removeAllObjects];
            }
        }
        if ([results isKindOfClass:[NSDictionary class]]) {
            
            if ([[results objectForKey:@"DetailInfo"] isKindOfClass:[NSArray class]]) {
                int code = [[results objectForKey:@"Code"] intValue];
                if (code == 0000) {
                    if (pageIndex == 1) {
                        
                        dataArray = [[results objectForKey:@"DetailInfo"]mutableCopy];
                    }else{
                        NSMutableArray *tempArr = [results objectForKey:@"DetailInfo"];
                        [dataArray addObjectsFromArray:tempArr];
                    }
                    
                }else{
                    //无数据
                    if (pageIndex == 1 && [[results objectForKey:@"Code"] intValue] == 9998) {
                        noDataArr = [[results objectForKey:@"DetailInfo"] mutableCopy];
                        
                    }
                    pageIndex -= 1;
                    if (pageIndex < 0) {
                        pageIndex = 1;
                    }
                }
                
            }
            
            [iTableView reloadData];
            
            if (dataArray.count == 0) {
                
                //无数据提示
                if (!noView) {
                    noView = [[UIView alloc]initWithFrame:CGRectMake(30, 50, SCREEN_WIDTH - 60, 150)];
                    noView.backgroundColor = [UIColor clearColor];
                    UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 53, 55)];
                    bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                    [noView addSubview:bigbeen];
                    
                    UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(65, 15, SCREEN_WIDTH - 110, 20)];
                    labela.backgroundColor = [UIColor clearColor];
                    labela.text = @"本地区或分类暂无商家，";
                    labela.textAlignment = NSTextAlignmentLeft;
                    labela.font = [UIFont systemFontOfSize:15];
                    labela.textColor = [UIColor colorWithHexString:@"#595757"];
                    [noView addSubview:labela];
                    
                    UILabel *labelb = [[UILabel alloc]initWithFrame:CGRectMake(65, 40, SCREEN_WIDTH - 110, 20)];
                    labelb.backgroundColor = [UIColor clearColor];
                    labelb.text = @"为您推荐以下商家";
                    labelb.textAlignment = NSTextAlignmentLeft;
                    labelb.font = [UIFont systemFontOfSize:15];
                    labelb.textColor = [UIColor colorWithHexString:@"#595757"];
                    [noView addSubview:labelb];
                    
                    //创建按钮
                    int cityX = 10;
                    for (int i = 0; i < noDataArr.count; i ++) {
                        UIButton *cityBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                        [cityBtn setFrame:CGRectMake(cityX, 75, 75, 37)];
                        NSString *cityName = [[noDataArr objectAtIndex:i] objectForKey:@"cityname"];
                        [cityBtn setTitle:cityName forState:UIControlStateNormal];
                        [cityBtn.titleLabel setFont:[UIFont systemFontOfSize:15]];
                        [cityBtn setTitleColor:[UIColor colorWithHexString:@"#595757"] forState:UIControlStateNormal];
                        [cityBtn setTag:2000+i];
                        cityBtn.layer.borderWidth = 0.5;
                        cityBtn.layer.borderColor = [UIColor colorWithHexString:@"#c6c6c6"].CGColor;
                        [cityBtn addTarget:self action:@selector(selectCity:) forControlEvents:UIControlEventTouchUpInside];
                        [noView addSubview:cityBtn];
                        cityX += 85;
                    }
                    
                    
                    [iTableView addSubview:noView];
                }
            }else{
                if (noView) {
                    [noView removeFromSuperview];
                    noView = nil;
                }
            }
        }
    }];
}

//点击无数据推荐城市
- (void)selectCity:(UIButton *)sender{
    UIButton *btn = (UIButton *)sender;
    ZLog(@"%ld",(long)btn.tag);
    NSInteger index = btn.tag - 2000;
    
    //重置地区索引
    [self resetNear];
    
    [pcodeBtnLabel setText:[[noDataArr objectAtIndex:index] objectForKey:@"cityname"]];
    pcode = [[noDataArr objectAtIndex:index] objectForKey:@"city"];
    
    //刷新数据
    pageIndex = 1;
    [self GetShoplistNetData];
}

//获取分类信息
- (void)GetTypeNetData{
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"ShopSelect",@"Mod",@"ShopType",@"Act",item,@"Content", nil];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        int code = [[results objectForKey:@"Code"] intValue];
        if (code == 0000) {
            
            NSArray *tempArr = [results objectForKey:@"DetailInfo"];
            typeDefaultList = [tempArr mutableCopy];
            NSDictionary *allDic = [NSDictionary dictionaryWithObjectsAndKeys:
                                    @"0",@"id",
                                    @"全部分类",@"exp",
                                    nil];
            [typeDefaultList insertObject:allDic atIndex:0];
            //将数据保存到本地?
            [USERDEFAULT setObject:typeDefaultList forKey:@"typeList"];
            [USERDEFAULT synchronize];
            
            
        }else
            [self showAlert:nil withTitle:[results objectForKey:@"Message"] haveCancelButton:NO];
        
    }];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSInteger row = 0;
    if (tableView == self.typeTableView) {
        if (self.typeArray.count != 0) {
            row = self.typeArray.count;
        }else
            row = 0;
    }else if (tableView == self.typeDetailTableView) {
        if (self.typeDetailArray.count != 0) {
            row = self.typeDetailArray.count;
        }else
            row = 0;
    }else if (tableView == iTableView){
        if (dataArray.count != 0) {
            row = dataArray.count;
        }else
            row = 0;
    }else
        row = 0;
    
    return row;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == iTableView) {
        return 55;
    }else
        return 45;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (tableView == iTableView) {
        static NSString *identifier = @"mposMerchantCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            [cell.contentView setBackgroundColor:[UIColor whiteColor]];
            
            UIImageView *merchantIcon = [[UIImageView alloc]initWithFrame:CGRectMake(10, 5, 45, 45)];
            merchantIcon.tag = 11;
            merchantIcon.image = _merchantDefault;
            [cell.contentView addSubview:merchantIcon];
            
            UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(65, 10, SCREEN_WIDTH - 100, 20)];
            titleLabel.font = [UIFont systemFontOfSize:14];
            titleLabel.textColor = [UIColor colorWithHexString:@"#000000"];
            titleLabel.tag = 13;
            titleLabel.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:titleLabel];
            
            //建行mpos图标
            UIImageView *ismposIcon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 100 + 65, 5, 19, 19)];
            ismposIcon.tag = 12;
            ismposIcon.hidden = YES;
            ismposIcon.image = [UIImage imageNamed:@"ismpos.png"];
            [cell.contentView addSubview:ismposIcon];
            
            UILabel *addressLabel = [[UILabel alloc]initWithFrame:CGRectMake(65, 30, SCREEN_WIDTH - 130, 20)];
            addressLabel.font = [UIFont systemFontOfSize:13];
            addressLabel.textColor = [UIColor colorWithHexString:@"#636363"];
            addressLabel.tag = 14;
            addressLabel.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:addressLabel];
            
            UILabel *distanceLabel = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH-10-50, 30, 50, 20)];
            distanceLabel.textAlignment = 2;
            distanceLabel.font = [UIFont systemFontOfSize:13];
            distanceLabel.textColor = [UIColor colorWithHexString:@"#636363"];
            distanceLabel.tag = 15;
            distanceLabel.backgroundColor = [UIColor clearColor];

            [cell.contentView addSubview:distanceLabel];
            
            LineView *downLine = [[LineView alloc]initWithFrame:CGRectMake(0, 54.5, SCREEN_WIDTH, 0.5)];
            downLine.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:downLine];
        }
        
        UIImageView *merchantIcon = (UIImageView *)[cell.contentView viewWithTag:11];
        UIImageView *ismposIcon = (UIImageView *)[cell.contentView viewWithTag:12];
        UILabel *titleLabel = (UILabel *)[cell.contentView viewWithTag:13];
        UILabel *addressLabel = (UILabel *)[cell.contentView viewWithTag:14];
        UILabel *distanceLabel = (UILabel *)[cell.contentView viewWithTag:15];

        //
        NSString *urlStr = [[dataArray objectAtIndex:indexPath.row]objectForKey:@"listpic"];
        [merchantIcon XK_setImageWithURL:[NSURL URLWithString:urlStr] placeholderImage:nil];
        
        
        NSString *shopNameStr = [[dataArray objectAtIndex:indexPath.row] objectForKey:@"shopname"];
        titleLabel.text = [NSString stringWithFormat:@"%@",shopNameStr];

        int ismpos = [[[dataArray objectAtIndex:indexPath.row]objectForKey:@"ismpos"] intValue];
        ZLog(@"%d",ismpos);
        if (ismpos == 1) {
            //加字数判断
            CGSize curSize = titleLabel.frame.size;
            CGSize ss = [NSString getHeight:shopNameStr withFont:[UIFont systemFontOfSize:14] andWidth:curSize.width];
            titleLabel.numberOfLines = 0;
            
            NSInteger MaxWidth = SCREEN_WIDTH - 10 - 65 - 20;
            if (ss.width < MaxWidth) {
                titleLabel.frame = CGRectMake(65, 5, ss.width, 20);
            }else{
                [titleLabel setFrame:CGRectMake(65, 5, MaxWidth, 20)];
            }
            
            [ismposIcon setFrame:CGRectMake(titleLabel.frame.size.width + titleLabel.frame.origin.x + 10, 5, 20, 20)];
            
            ismposIcon.hidden = NO;
        }else{
            [titleLabel setFrame:CGRectMake(65, 5, SCREEN_WIDTH - 100, 20)];
            [ismposIcon setFrame:CGRectMake(SCREEN_WIDTH - 100 + 65, 5, 19, 19)];
            ismposIcon.hidden = YES;

        }
        
        addressLabel.text = [NSString stringWithFormat:@"%@",[[dataArray objectAtIndex:indexPath.row] objectForKey:@"address"]];
        
        float distance = [[[dataArray objectAtIndex:indexPath.row] objectForKey:@"distance"] floatValue];
        ZLog(@"distance = %f",distance);
        if (distance * 0.001 > 1) {
            if(distance *0.001 *0.1>1){
                 distanceLabel.text = [NSString stringWithFormat:@"%.1fkm",distance * 0.001];
            }
           else if(distance *0.001 *0.01>1){
                distanceLabel.text = [NSString stringWithFormat:@"%.0fkm",distance * 0.001];
            }
            else
            distanceLabel.text = [NSString stringWithFormat:@"%.2fkm",distance * 0.001];
        }else
            distanceLabel.text = [NSString stringWithFormat:@"%.1fm",distance];
        
        
        return cell;
    }else if (tableView == self.typeTableView){
        static NSString *identifier = @"typeCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
        }
        //防止cell重叠
        while ([cell.contentView.subviews lastObject] ) {
            [(UIView *)[cell.contentView.subviews lastObject] removeFromSuperview];
        }
        
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIImageView *typebgImg= [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.typeTableView.frame.size.width, 45)];
        typebgImg.image = _type_cell;
        typebgImg.tag = indexPath.row+100;
        [cell.contentView addSubview:typebgImg];
        
        UILabel *titlelabel = [[UILabel alloc]init];
        titlelabel.frame = CGRectMake(5, 10, self.typeTableView.frame.size.width, 20);
        titlelabel.backgroundColor = [UIColor clearColor];
        titlelabel.font = [UIFont systemFontOfSize:13];
        titlelabel.textAlignment = 0;
        titlelabel.textColor = [UIColor colorAndAlphaWithHexString:@"#595767"];
        [cell.contentView addSubview:titlelabel];
        
        if (self.typeArray.count != 0) {
            
            if (pcodeBtn.selected == YES) {
                selectRow = selectRow1;
            }else if (typeBtn.selected == YES){
                selectRow = selectRow2;
            }else if (distanceBtn.selected == YES){
                selectRow = selectRow3;
            }
            if (indexPath.row == selectRow) {
                typebgImg.image = _type_select;
            }
            if (typeBtn.selected == YES) {
                titlelabel.text = [NSString stringWithFormat:@"  %@",[[self.typeArray objectAtIndex:indexPath.row] objectForKey:@"exp"]];

            }else{
                titlelabel.text = [NSString stringWithFormat:@"  %@",[self.typeArray objectAtIndex:indexPath.row]];
            }
        }
        
        return cell;
    }else if (tableView == self.typeDetailTableView){
        static NSString *identifier = @"typeDetailCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
        }
        //防止cell重叠
        while ([cell.contentView.subviews lastObject] ) {
            [(UIView *)[cell.contentView.subviews lastObject] removeFromSuperview];
        }
        
        cell.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIImageView *bgImg= [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.typeDetailTableView.frame.size.width, 44)];
        bgImg.image = _type_select;
        [cell.contentView addSubview:bgImg];
        
        UIImageView *cellLine= [[UIImageView alloc]initWithFrame:CGRectMake(15, 44, self.typeDetailTableView.frame.size.width - 15, 1)];
        cellLine.image = _type_line;
        [cell.contentView addSubview:cellLine];

        UILabel *titlelabel = [[UILabel alloc]init];
        titlelabel.frame = CGRectMake(5, 10, self.typeDetailTableView.frame.size.width, 20);
        titlelabel.backgroundColor = [UIColor clearColor];
        titlelabel.font = [UIFont systemFontOfSize:13];
        titlelabel.textAlignment = 0;
        titlelabel.textColor = [UIColor colorAndAlphaWithHexString:@"#595767"];
        [bgImg addSubview:titlelabel];
        
        if (self.typeDetailArray.count != 0) {
            
            if (pcodeBtn.isSelected) {
                titlelabel.text = [NSString stringWithFormat:@"  %@",[[self.typeDetailArray objectAtIndex:indexPath.row] objectForKey:@"name"]];
                if ([[[self.typeDetailArray objectAtIndex:indexPath.row] objectForKey:@"name"] isEqualToString:pcodeBtnLabel.text]) {
                    titlelabel.textColor = [UIColor colorWithHexString:@"#064ea8"];
                }

            }else if (distanceBtn.isSelected){
                titlelabel.text = [NSString stringWithFormat:@"  %@",[self.typeDetailArray objectAtIndex:indexPath.row]];

                if ([[self.typeDetailArray objectAtIndex:indexPath.row] isEqualToString:distanceBtnLabel.text]) {
                    titlelabel.textColor = [UIColor colorWithHexString:@"#064ea8"];
                }
            }
        }
        
        return cell;
    }else
        return nil;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == iTableView) {
        mposDetailViewController *detailV = [[mposDetailViewController alloc]init];
        detailV.merDic = [dataArray objectAtIndex:indexPath.row];
        detailV.isFromMpos = YES;
        [self.navigationController pushViewController:detailV animated:YES];
        return;
    }else if (tableView == self.typeTableView){
        
        for (int i = 0; i< self.typeArray.count; i++) {
            if (i == indexPath.row) {
                UIImageView *cellBg = (UIImageView *)[self.view viewWithTag:indexPath.row+100];
                cellBg.image = [UIImage imageNamed:@"around_topcellBg.png"];
            }else{
                UIImageView *cellBg = (UIImageView *)[self.view viewWithTag:i+100];
                cellBg.image = [UIImage imageNamed:@"around_topcellselect.png"];
            }
            
        }
        
        if (pcodeBtn.selected == YES) {
            selectRow1 = indexPath.row;
            if (self.typeDetailArray.count != 0) {
                [self.typeDetailArray removeAllObjects];
            }
            self.typeDetailArray = [NSMutableArray arrayWithArray:[[[self.localtionNearByDic objectForKey:@"DetailInfo"] objectAtIndex:indexPath.row] objectForKey:@"city"]];
            
            ZLog(@"%@",self.localtionNearByDic);
            ZLog(@"%@",self.typeDetailArray);
            
            [self.typeDetailTableView reloadData];
            
        }else if (typeBtn.selected == YES){
            
            selectRow2 = indexPath.row;
            
            MyAppDelegate.mySelectType = indexPath.row;
            [typeBtnLabel setText:[[self.typeArray objectAtIndex:indexPath.row] objectForKey:@"exp"]];
            [self typeBtn:typeBtn];
            
            pageIndex = 1;
            
            //条件筛选
            [self GetShoplistNetData];
            
        }else if (distanceBtn.selected == YES){
            
            selectRow3 = indexPath.row;
            
            [distanceBtnLabel setText:[self.typeArray objectAtIndex:indexPath.row]];
            if (indexPath.row == 3) {
                [_typeDetailArray removeAllObjects];
                for(int i = 0; i < distanceList.count; i++){
                    NSString *distanceStr = [distanceList objectAtIndex:i];
                    [_typeDetailArray addObject:distanceStr];
                }
                [_typeDetailTableView reloadData];
            }else{
                if(0 == indexPath.row){//智能
                    order = @"";
                }else if(1 == indexPath.row){//人气
                    order = @"";
                }else if(2 == indexPath.row){//销量
                    order = @"";
                }
                
                [self distanceBtn:distanceBtn];
                
                pageIndex = 1;
                
                //条件筛选
                [self GetShoplistNetData];
                
            }
            
            
        }
        
    }else if (tableView == self.typeDetailTableView){
        
        
        if (typeBtn.isSelected) {
            pcode  = [NSString stringWithFormat:@"%@",[[self.typeDetailArray objectAtIndex:indexPath.row] objectForKey:@"pcode"]] ;
            
            [pcodeBtnLabel setText:[[self.typeDetailArray objectAtIndex:indexPath.row] objectForKey:@"name"]];
            [self pcodeBtn:nil];

        }else if (distanceBtn.isSelected){
            if(0 == indexPath.row){
                order = @"500";
            }else if(1 == indexPath.row){
                order = @"1000";
            }else if(2 == indexPath.row){
                order = @"1500";
            }
            
            [self distanceBtn:distanceBtn];
        }else if(pcodeBtn.isSelected){
            pcode  = [NSString stringWithFormat:@"%@",[[self.typeDetailArray objectAtIndex:indexPath.row] objectForKey:@"pcode"]] ;
            
            [pcodeBtnLabel setText:[[self.typeDetailArray objectAtIndex:indexPath.row] objectForKey:@"name"]];
            [self pcodeBtn:pcodeBtn];
        }
        
        pageIndex = 1;

        //条件筛选
        [self GetShoplistNetData];
    }
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_MPOS_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_MPOS_VIEW"];
    
}

#pragma mark - buttonTarget

- (IBAction)pcodeBtn:(id)sender {
    pcodeBtn.selected = !pcodeBtn.selected;
    [typeBtn setSelected:NO];
    [distanceBtn setSelected:NO];
    
    UIImageView *btnImg = (UIImageView *)[sender viewWithTag:3011];
    UIImageView *btnImg1 = (UIImageView *)[[sender superview] viewWithTag:3021];
    UIImageView *btnImg2 = (UIImageView *)[[sender superview] viewWithTag:3031];
    [btnImg1 setHighlighted:NO];
    [btnImg2 setHighlighted:NO];
    
    if (pcodeBtn.selected == YES) {
        
        [downLineIn setFrame:CGRectMake(SCREEN_WIDTH/3 * 0.5, 45-8, 17, 8)];
        [downLineIn setHidden:NO];
        
        [btnImg setHighlighted:YES];
        [self setPcodeData];
        
        [baseView setFrame:CGRectMake(0,  45, self.view.frame.size.width, self.view.frame.size.height-45)];
        
        [UIView beginAnimations:nil context:nil];
        [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width/3, self.view.frame.size.height-200)];
        [self.typeDetailTableView setFrame:CGRectMake(self.view.frame.size.width/3, 45, self.view.frame.size.width/3*2, self.view.frame.size.height-200)];
        [UIView commitAnimations];
        
    }else{
        
        [downLineIn setHidden:YES];
        [btnImg setHighlighted:NO];
        
        [baseView setFrame:CGRectMake(0, 45, self.view.frame.size.width, 0)];
        
        [UIView beginAnimations:nil context:nil];
        [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width/3, 0)];
        [self.typeDetailTableView setFrame:CGRectMake(self.view.frame.size.width/3, 45, self.view.frame.size.width/3*2, 0)];
        
        [UIView commitAnimations];
    }
}

- (IBAction)typeBtn:(id)sender {
    typeBtn.selected = !typeBtn.selected;
    [pcodeBtn setSelected:NO];
    [distanceBtn setSelected:NO];
    
    UIImageView *btnImg = (UIImageView *)[sender viewWithTag:3021];
    UIImageView *btnImg1 = (UIImageView *)[[sender superview] viewWithTag:3011];
    UIImageView *btnImg2 = (UIImageView *)[[sender superview] viewWithTag:3031];
    [btnImg1 setHighlighted:NO];
    [btnImg2 setHighlighted:NO];
    
    if (typeBtn.selected == YES) {
        
        [downLineIn setFrame:CGRectMake(SCREEN_WIDTH/3 * 0.5 + SCREEN_WIDTH/3, 45-8, 17, 8)];
        [downLineIn setHidden:NO];
        
        [btnImg setHighlighted:YES];
        
        [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width, 0)];
        [self.typeDetailTableView setFrame:CGRectMake(self.view.frame.size.width/3, 45, self.view.frame.size.width/3*2, 0)];
        
        [UIView beginAnimations:nil context:nil];
        [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width, self.view.frame.size.height-200)];
        [baseView setFrame:CGRectMake(0, 45, self.view.frame.size.width, self.view.frame.size.height-45)];
        
        [UIView commitAnimations];
        
        if (self.typeArray.count != 0) {
            [self.typeArray removeAllObjects];
        }
        [self.typeArray addObjectsFromArray:typeDefaultList];
        
        [self.typeTableView reloadData];
        
    }else{
        
        [downLineIn setHidden:YES];
        [btnImg setHighlighted:NO];
        
        [baseView setFrame:CGRectMake(0, 45, self.view.frame.size.width, 0)];
        [self.typeDetailTableView setFrame:CGRectMake(self.view.frame.size.width/3, 45, self.view.frame.size.width/3*2, 0)];
        
        [UIView beginAnimations:nil context:nil];
        [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width, 0)];
        
        [UIView commitAnimations];
    }
    
}

- (IBAction)distanceBtn:(id)sender {
    distanceBtn.selected = !distanceBtn.selected;
    [pcodeBtn setSelected:NO];
    [typeBtn setSelected:NO];
    
    UIImageView *btnImg = (UIImageView *)[sender viewWithTag:3031];
    UIImageView *btnImg1 = (UIImageView *)[[sender superview] viewWithTag:3021];
    UIImageView *btnImg2 = (UIImageView *)[[sender superview] viewWithTag:3011];
    [btnImg1 setHighlighted:NO];
    [btnImg2 setHighlighted:NO];
    
    if (distanceBtn.selected == YES) {
        
        [downLineIn setFrame:CGRectMake(SCREEN_WIDTH/3 * 0.5 + SCREEN_WIDTH/3*2, 45-8, 17, 8)];
        [downLineIn setHidden:NO];
        
        [btnImg setHighlighted:YES];
        
        [baseView setFrame:CGRectMake(0,  45, self.view.frame.size.width, self.view.frame.size.height-45)];
        
        [UIView beginAnimations:nil context:nil];
        [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width/3, self.view.frame.size.height-200)];
        [self.typeDetailTableView setFrame:CGRectMake(self.view.frame.size.width/3, 45, self.view.frame.size.width/3*2, self.view.frame.size.height-200)];
        [UIView commitAnimations];
        
        if (self.typeArray.count != 0) {
            [self.typeArray removeAllObjects];
            [self.typeDetailArray removeAllObjects];
            
        }
        
        [self.typeArray addObject:@"智能排序"];
        [self.typeArray addObject:@"按人气排"];
        [self.typeArray addObject:@"按销量排"];
        [self.typeArray addObject:@"按距离排"];
        
        [self.typeTableView reloadData];
        [self.typeDetailTableView reloadData];
        
    }else{
        
        [downLineIn setHidden:YES];
        [btnImg setHighlighted:NO];
        
        [baseView setFrame:CGRectMake(0, 45, self.view.frame.size.width, 0)];
        
        [UIView beginAnimations:nil context:nil];
        [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width/3, 0)];
        [self.typeDetailTableView setFrame:CGRectMake(self.view.frame.size.width/3, 45, self.view.frame.size.width/3*2, 0)];
        
        [UIView commitAnimations];
    }
    
}
- (void)cancelShowBaseView:(UITapGestureRecognizer *)tap{
    
    if (pcodeBtn.selected ) {
        [self pcodeBtn:pcodeBtn];
    }
    else if (typeBtn.selected){
        [self typeBtn:typeBtn];
    }
    else if (distanceBtn.selected){
        [self distanceBtn:distanceBtn];
    }
    
}

@end
