//
//  proDetailViewController.h
//  GGSH
//
//  Created by heyddo on 15/3/13.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "proTopVC.h"

@interface proDetailViewController : BaseViewController<UIAlertViewDelegate>{
    proTopVC *_topVC;
    
}

@property (nonatomic,retain) NSMutableDictionary *merDic;
@property (nonatomic,retain) NSMutableDictionary *detailInfo;
@property (nonatomic,strong) NSString *proId;

@end
