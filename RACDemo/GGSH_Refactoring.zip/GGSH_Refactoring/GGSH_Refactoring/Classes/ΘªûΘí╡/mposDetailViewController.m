//
//  mposDetailViewController.m
//  GGSH
//
//  Created by heyddo on 15/3/13.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "mposDetailViewController.h"
#import "shopCartViewController.h"
#import "proDetailViewController.h"
#import "LoginVC.h"
#import "chatVC.h"
#import "lookGoodsCell.h"
#import "MyMessageVC.h"
//#import "GYShopDetailViewController.h"
#import "LineView.h"
#import "mposShopInfoVC.h"
#import "MposSearchProductViewController.h"


@interface mposDetailViewController ()<MJRefreshBaseViewDelegate,loginDelegate>
{
    NSMutableArray *_dataArray;
    IBOutlet UIScrollView *_scrollview;
    UIImage *_cellImage;
    UIImage *_merchantDefault;
    
    IBOutlet UILabel *goodsLabel;
    UIView *noView;
    
    int pageIndex;
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;

    IBOutlet UIView *showMoreView;
    BOOL isShowMore;
    
    IBOutlet UIImageView *messageIcon;
    
    BOOL isFinishLogin;
    
    UITapGestureRecognizer *tap1;
    UIImageView *imageAlertCart;
    UILabel *alertLabel;
    UIImageView *imageAlert;

}
@property (nonatomic,assign) NSInteger selectIndex;
@end

@implementation mposDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.title = @"店铺详情";
    [self cancelTapHideKeyBoard:YES];
    //导航栏右边图标
    [self addNavBtn];
    _dataArray = [[NSMutableArray alloc]init];
    //默认图
    _cellImage = [UIImage imageNamed:@"shopDetail_cellLine.png"];
    _merchantDefault = [UIImage imageNamed:@"shopDetail_proIcon.png"];

    _header = [MJRefreshHeaderView header];
    _header.scrollView = iCollectionView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = iCollectionView;
    _footer.delegate = self;

    //解决商品没有占满屏幕无法下拉的问题
    iCollectionView.alwaysBounceVertical = YES;
    
    UINib *nib = [UINib nibWithNibName:@"lookGoodsCell" bundle:[NSBundle mainBundle]];
    [iCollectionView registerNib:nib forCellWithReuseIdentifier:@"lookCell"];
    
    //获取店铺信息
    [self getShopInfo];
    
    //网络获取
    pageIndex = 1;
    [self GetListNetData];
    
    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
    [self addSearchModules];
 
}
/**
 *  新增搜索模块
 */
- (void)addSearchModules{
    
    
    UIView *bgview = [[UIView alloc]initWithFrame:CGRectMake(-60, 0, SCREEN_WIDTH - 150, 28)];
    bgview.backgroundColor = [UIColor clearColor];
    bgview.center = CGPointMake(SCREEN_WIDTH/2, 44/2);
    
    UIImageView *imgSearBg = [[UIImageView alloc] initWithFrame:CGRectMake(-25, 0, SCREEN_WIDTH - 130, 28)];
    imgSearBg.image = [UIImage imageNamed:@"search_mid.png"];
    [bgview addSubview:imgSearBg];
    
    UIImageView *imgSear = [[UIImageView alloc] initWithFrame:CGRectMake(-19, 8, 11, 11)];
    imgSear.image = [UIImage imageNamed:@"search_red.png"];
    [bgview addSubview:imgSear];
    
    UILabel *searLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 4, SCREEN_WIDTH - 150, 20)];
    searLabel.textColor = [UIColor lightGrayColor];
    searLabel.text = @"搜索店铺内商品";
    searLabel.font = [UIFont systemFontOfSize:12];
    [bgview addSubview:searLabel];
    
    //跳转
    UIButton *jumpBtn = [[UIButton alloc] initWithFrame:bgview.bounds];
    [jumpBtn addTarget:self action:@selector(jumpToSearchAction) forControlEvents:UIControlEventTouchUpInside];
    [bgview addSubview:jumpBtn];
    
    self.navigationItem.titleView = bgview;
  
    
    
}
/**
 *  跳转到搜索界面
 */
- (void)jumpToSearchAction{
    if (_dataArray.count == 0) {
        [self GetListNetData];
    }
    MposSearchProductViewController *search = [[MposSearchProductViewController alloc]init];
    search.hideBackButton = NO;
    search.productDataArray = _dataArray;
    search.shopInfo = self.merDic;
    [self.navigationController pushViewController:search animated:YES];
    
}
- (void)refreshNavBtn{
    if (MyAppDelegate.shopCartNumber && MyAppDelegate.shopCartNumber.integerValue > 0) {
        [imageAlertCart setHidden:NO];
        [alertLabel setText:MyAppDelegate.shopCartNumber];
    }else{
        [imageAlertCart setHidden:YES];
    }
    
}


- (void)addNavBtn{
    UIButton *trolleyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [trolleyBtn setFrame:CGRectMake(0, 0, 16, 16)];
    UIImageView *trolleyIcon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 16, 16)];
    trolleyIcon.image = [UIImage imageNamed:@"shopping_s.png"];
    [trolleyBtn setBackgroundImage:trolleyIcon.image forState:UIControlStateNormal];
    [trolleyBtn addTarget:self action:@selector(doTrolley:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:trolleyBtn];
    
    imageAlertCart = [[UIImageView alloc]initWithFrame:CGRectMake(8, -4, 18, 13)];
    [imageAlertCart setBackgroundColor:[UIColor whiteColor]];
    imageAlertCart.layer.cornerRadius = 6;
    imageAlertCart.layer.borderWidth = 0.5f;
    imageAlertCart.layer.borderColor = [UIColor redColor].CGColor;
    [trolleyBtn addSubview:imageAlertCart];
    
    alertLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 18, 13)];
    [alertLabel setTextAlignment:NSTextAlignmentCenter];
    [alertLabel setFont:[UIFont systemFontOfSize:8]];
    [alertLabel setTextColor:[UIColor redColor]];
    [imageAlertCart addSubview:alertLabel];
    [imageAlertCart setHidden:YES];
    
    UIButton *moreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [moreBtn setFrame:CGRectMake(0, 0, 27, 27)];
    UIImageView *moreIcon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 27, 27)];
    moreIcon.image = [UIImage imageNamed:@"more.png"];
    [moreBtn setBackgroundImage:moreIcon.image forState:UIControlStateNormal];
    [moreBtn addTarget:self action:@selector(moreInfo:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarButtonItemShare = [[UIBarButtonItem alloc] initWithCustomView:moreBtn];
    
    self.navigationItem.rightBarButtonItems = @[rightBarButtonItemShare,rightBarButtonItem];
}
-(void)backAction{
    if (self.isFromMail) {
        if (self.isFromMpos) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
        }else{
            [self.navigationController popViewControllerAnimated:YES];
        }
        
        return;

    }
    if (self.shopId) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (IBAction)gotoDetailInfo:(id)sender {
    
    mposShopInfoVC *ctrl = [[mposShopInfoVC alloc]init];
    ctrl.dicData = self.merDic;
    [self.navigationController pushViewController:ctrl animated:YES];
}

#pragma mark - network
//设置商铺信息
-(void)setTitleInfo{
    [self.merchantIcon XK_setImageWithURL:[NSURL URLWithString:[self.merDic objectForKey:@"listpic"]] placeholderImage:nil];
    
    //9.8新需求，店铺名称和地址可以显示两行
    NSString *shopNameStr = [NSString stringWithFormat:@"%@",[self.merDic objectForKey:@"shopname"]];
    CGSize ss = [NSString getHeight:shopNameStr withFont:[UIFont systemFontOfSize:13] andWidth:SCREEN_WIDTH - 150];
    self.shopName.numberOfLines = 0;
    NSInteger MaxWidth = SCREEN_WIDTH - 150;
    if (ss.width < MaxWidth) {
        self.shopName.frame = CGRectMake(65, 20, ss.width, 21);
    }else{
        [self.shopName setFrame:CGRectMake(65, 10, MaxWidth, 41)];
    }
    self.shopName.text = shopNameStr;
    if (self.shopName.frame.size.width + 10 > MaxWidth) {
        [gotoDetailImage setFrame:CGRectMake(SCREEN_WIDTH - 95, 22, 15, 15)];
    }else{
        [gotoDetailImage setFrame:CGRectMake(self.shopName.frame.size.width + self.shopName.frame.origin.x + 10, 22, 15, 15)];
    }
    
    NSString *shopAddressStr = [NSString stringWithFormat:@"%@",[self.merDic objectForKey:@"address"]];
    [self.addressLabel setText:shopAddressStr];
    
    ZLog(@"%@",self.merDic);
    
    if ([[self.merDic objectForKey:@"attent"] intValue] == 0) {
        [attentBtn setSelected:NO];
        if (isFinishLogin) {
            [self followShop:[self.merDic objectForKey:@"id"]];
        }
    }else{
        [attentBtn setSelected:YES];
        if (isFinishLogin) {
            [self showAlert:nil withTitle:@"已关注！" haveCancelButton:NO];
        }
    }
    
    if ([[self.merDic objectForKey:@"ggmallid"] intValue] != 0) {
        UIView *mailView = [[UIView alloc]initWithFrame:CGRectMake(0, 100, SCREEN_WIDTH, 40)];
        [mailView setBackgroundColor:[UIColor whiteColor]];
        [_scrollview addSubview:mailView];
        
        UIView *line1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 0.5)];
        [line1 setBackgroundColor:[UIColor colorWithHexString:@"#dfdfdf"]];
        [mailView addSubview:line1];
        UIView *line2 = [[UIView alloc]initWithFrame:CGRectMake(0, 39.5, SCREEN_WIDTH, 0.5)];
        [line2 setBackgroundColor:[UIColor colorWithHexString:@"#dfdfdf"]];
        [mailView addSubview:line2];
        
        UIImageView *mailIcon = [[UIImageView alloc]initWithFrame:CGRectMake(10, 11, 18, 18)];
        [mailIcon setImage:[UIImage imageNamed:@"mposDetail_owner.png"]];
        [mailView addSubview:mailIcon];
        
        UILabel *lbmail = [[UILabel alloc]initWithFrame:CGRectMake(40, 10, SCREEN_WIDTH - 80, 20)];
        [lbmail setBackgroundColor:[UIColor clearColor]];
        [lbmail setTextAlignment:NSTextAlignmentLeft];
        [lbmail setTextColor:[UIColor blackColor]];
        [lbmail setFont:[UIFont systemFontOfSize:12]];
        [lbmail setText:[self.merDic objectForKey:@"ggmall_name"]];
        [mailView addSubview:lbmail];

        UIImageView *nextIcon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 15, 13, 9, 13)];
        [nextIcon setImage:[UIImage imageNamed:@"app_next.png"]];
        [mailView addSubview:nextIcon];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setFrame:CGRectMake(0, 0, SCREEN_WIDTH, 40)];
        [btn setBackgroundColor:[UIColor clearColor]];
        [btn addTarget:self action:@selector(gotoMailView) forControlEvents:UIControlEventTouchUpInside];
        [mailView addSubview:btn];
        
        [goodsLabel setFrame:CGRectMake(10, 150, 100, 20)];
        [iCollectionView setFrame:CGRectMake(0, 180, SCREEN_WIDTH, SCREEN_VIEW_HEIGHT - 180)];
    }else{
        
    }
    
}

- (void)gotoMailView{
//    GYShopDetailViewController *idetailView = [[GYShopDetailViewController alloc] init];
//    idetailView.shopID = [self.merDic objectForKey:@"ggmallid"];
//    idetailView.isFromMpos = self.isFromMpos;
//    idetailView.isFromMail = self.isFromMail;
//    [self.navigationController pushViewController:idetailView animated:YES];
}

#pragma mark - network
//网络接口
- (void)getShopInfo{
    
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"ShopSelect" forKey:@"Mod"];
    [dic setObject:@"selectShop" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];

    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
    }
    
    if ([self.merDic objectForKey:@"id"]) {
        [dicContent setObject:[self.merDic objectForKey:@"id"] forKey:@"shopid"];
    }else{
        [dicContent setObject:self.shopId forKey:@"shopid"];

    }
    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        if ([[results objectForKey:@"Code"] isEqualToString:@"0000"]) {
            self.merDic = [results objectForKey:@"DetailInfo"];
            [self setTitleInfo];
        }
    }];
}

//网络接口
- (void)GetListNetData{
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    if ([self.merDic objectForKey:@"id"]) {
        [item setObject:[NSString stringWithFormat:@"%@",[self.merDic objectForKey:@"id"]] forKey:@"shopid"];

    }else{
        [item setObject:self.shopId forKey:@"shopid"];
    }
    
    [item setObject:[NSNumber numberWithInt:pageIndex] forKey:@"pageindex"];
    [item setObject:[NSNumber numberWithInt:20] forKey:@"pagesize"];
    [item setObject:@"" forKey:@"keyword"];
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"GoodsSel",@"Mod",@"GoodsList",@"Act",item,@"Content", nil];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];

        if([[results objectForKey:@"Code"] isEqualToString:@"0000"]){
            if(1 == pageIndex){
                _dataArray = [[results objectForKey:@"DetailInfo"]mutableCopy];
            }else{
                //上拉增加新数据
                [_dataArray addObjectsFromArray:[results objectForKey:@"DetailInfo"]];
            }
        }else{
            _dataArray = [results objectForKey:@"DetailInfo"];
        }
        [iCollectionView reloadData];
        
        if (_dataArray.count == 0) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 52);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [iCollectionView addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
    }];
}

#pragma mark - 刷新的代理方法进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(0 == [MyAppDelegate reachBility]){
        [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        return;
    }
    
    if(refreshView == _header) {// 下拉刷新
        pageIndex = 1;
        [self GetListNetData];
    }else if (refreshView == _footer){//上拉加载更多
        if(_dataArray.count%10 == 0){
            pageIndex += 1;
            [self GetListNetData];
        }
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    return;
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

#pragma mark - moreView
- (IBAction)doHome:(id)sender {
    [self hideMoreView];

    [self.navigationController popToRootViewControllerAnimated:YES];
    

}

- (IBAction)doMessage:(id)sender {
    [self hideMoreView];

    if (!MyAppDelegate.userInfo) {
         [self login];
  
        return;
    }
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];


}
/**
 *  分享
 *
 *  @param sender 分享按钮
 */
- (IBAction)doShare:(id)sender {
    
    //友盟统计
    [MobClick event:@"G_SHOP_SHARE"];

    [self hideMoreView];

    [self shareInfo:nil];

}

- (IBAction)doContact:(id)sender {
    [self hideMoreView];

    //登陆判断
    if (!MyAppDelegate.userInfo) {
        [self login];
        return;
    }
    
    //由于数据格式不统一，此处统一shopid命名
    NSMutableDictionary * dicNew = [[NSMutableDictionary alloc] initWithDictionary:self.merDic];
    [dicNew setObject:[self.merDic objectForKey:@"id"] forKey:@"shopid"];
    
    chatVC * ctrl = [[chatVC alloc] init];
    ctrl.dicChatInfo = dicNew;
    [self.navigationController pushViewController:ctrl animated:YES];

}
#pragma mark- 跳转到登录
- (void)login{
    LoginVC *loginV = [[LoginVC alloc]init];
    loginV.delegate = self;
    UINavigationController *navc = [[UINavigationController alloc]initWithRootViewController:loginV];
    [self presentViewController:navc animated:YES completion:nil];
    
}

- (IBAction)doSearch:(id)sender {
    //
    
    [self hideMoreView];
}
#pragma mark - end

//购物车
- (void)doTrolley:(UIButton *)sender
{
    if (MyAppDelegate.userInfo) {
        shopCartViewController *shopCartV = [[shopCartViewController alloc]init];
        [self.navigationController pushViewController:shopCartV animated:YES];
    }else{
        _selectIndex = 2;//购物车
        [self login];
    }
}

- (void)moreInfo:(UIButton *)sender{
    isShowMore = !isShowMore;
    if (isShowMore == YES) {
        [showMoreView setFrame:CGRectMake(200, 50, 106, 154)];
        [MyAppDelegate.window addSubview:showMoreView];
        tap1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapClickTocancelShare:)];
        [self.view addGestureRecognizer:tap1];
        if (MyAppDelegate.isHaveNoReadMessage) {
            if (!imageAlert) {
                imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(16, 5, 9, 9)];
            }
            [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
            [messageIcon addSubview:imageAlert];
          
        }else{
            if (imageAlert) {
                [imageAlert removeFromSuperview];
                imageAlert = nil;
            }
        }
        
    }else{
        [self hideMoreView];
    }
  
    
}
- (void)tapClickTocancelShare:(UITapGestureRecognizer *)tap{
    if (isShowMore == YES) {
        [self hideMoreView];
    }
    else{
        if (tap1) {
             [self.view removeGestureRecognizer:tap1];
        }
    }
}

- (void)hideMoreView{
    isShowMore = NO;
    [UIView beginAnimations:nil context:nil];
    [showMoreView setFrame:CGRectMake(200, 50, 106, 0)];
    [UIView commitAnimations];
    [showMoreView removeFromSuperview];
    [self.view removeGestureRecognizer:tap1];
}

- (void)shareInfo:(UIButton *)sender {
    
    NSString *shareUrl = [NSString stringWithFormat:@"%@/index.php/Api/Share/shareshop?g=home&m=dealshop&a=index&shopid=%@",kMposHeadUrl,[self.merDic objectForKey:@"id"]];
    NSDictionary *shareDic = [NSDictionary dictionaryWithObjectsAndKeys:
                              [self.merDic objectForKey:@"shopname"],@"title",
                              self.merchantIcon.image,@"image",
                              @"@我：我在逛逛生活上发现了一个好店，推荐给你，赶快来逛逛吧！",@"content",
                              shareUrl,@"url",
                              nil];
    
    [MyAppDelegate shareContext:shareDic];
    
}

#pragma mark - collectionViewDelegate
- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section;
{
    return _dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    
    lookGoodsCell *cell = [cv dequeueReusableCellWithReuseIdentifier:@"lookCell" forIndexPath:indexPath];

    ZLog(@"%@",_dataArray);
    NSDictionary *dic = [_dataArray objectAtIndexedSubscript:indexPath.row];
    
    cell.dicCell = dic;
    [cell awakeFromNib];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    //商品详情
    proDetailViewController *proV = [[proDetailViewController alloc]init];
    proV.detailInfo = [_dataArray objectAtIndex:indexPath.row];
    proV.proId = [[_dataArray objectAtIndex:indexPath.row] objectForKey:@"id"];
    proV.merDic = self.merDic;
    [self.navigationController pushViewController:proV animated:YES];
    
}

#pragma other

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_SHOP_VIEW"];
    
    if (MyAppDelegate.shopCartNumber && MyAppDelegate.shopCartNumber.integerValue > 0) {
        [imageAlertCart setHidden:NO];
        [alertLabel setText:MyAppDelegate.shopCartNumber];
    }else{
        [imageAlertCart setHidden:YES];
    }
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self hideMoreView];

    //友盟统计
    [MobClick endLogPageView:@"G_SHOP_VIEW"];
    
}

- (IBAction)daohang:(id)sender {
    
    NSString *urlStr = [NSString stringWithFormat:@"baidumap://map/"];//iosamap://
    ZLog(@"是否安装百度地图：%d",[[UIApplication sharedApplication]canOpenURL:[NSURL URLWithString:urlStr]]);
    if ([[UIApplication sharedApplication]canOpenURL:[NSURL URLWithString:urlStr]]) {
        //初始化调启导航时的参数管理类
        BMKNaviPara* para = [[BMKNaviPara alloc]init];
        //指定导航类型
        para.naviType = BMK_NAVI_TYPE_NATIVE;
        
        //初始化终点节点
        BMKPlanNode* end = [[BMKPlanNode alloc]init];
        //指定终点经纬度
        CLLocationCoordinate2D coor2;
        coor2.latitude = [[self.merDic objectForKey:@"latitude"] floatValue];
        coor2.longitude = [[self.merDic objectForKey:@"longitude"] floatValue];
        end.pt = coor2;
        //指定终点名称
        end.name = [self.merDic objectForKey:@"address"];
        //指定终点
        para.endPoint = end;
        
        //指定返回自定义scheme，具体定义方法请参考常见问题
        para.appScheme = @"ggshAPP://";//@"baidumapsdk://mapsdk.baidu.com";
        //调启百度地图客户端导航
        [BMKNavigation openBaiduMapNavigation:para];
      
    }else{
        //初始化调启导航时的参数管理类
        BMKNaviPara* para = [[BMKNaviPara alloc]init];
        //指定导航类型
        para.naviType = BMK_NAVI_TYPE_WEB;
        
        //初始化起点节点
        BMKPlanNode* start = [[BMKPlanNode alloc]init];
        //指定起点经纬度
        CLLocationCoordinate2D coor1;
        coor1.latitude = MyAppDelegate.ilatitude;
        coor1.longitude = MyAppDelegate.ilongitude;
        start.pt = coor1;
        //指定起点名称
        start.name = @"我的位置";
        //指定起点
        para.startPoint = start;
        
        //初始化终点节点
        BMKPlanNode* end = [[BMKPlanNode alloc]init];
        CLLocationCoordinate2D coor2;
        coor2.latitude = [[self.merDic objectForKey:@"latitude"] floatValue];
        coor2.longitude = [[self.merDic objectForKey:@"longitude"] floatValue];
        end.pt = coor2;
        para.endPoint = end;
        //指定终点名称
        end.name = [self.merDic objectForKey:@"address"];
        //指定调启导航的app名称
        para.appName = [NSString stringWithFormat:@"%@", @"testAppName"];
        
        if ([[self.merDic objectForKey:@"latitude"] floatValue] > 0 && coor1.latitude > 0) {
            //调启web导航
            [BMKNavigation openBaiduMapNavigation:para];
        }else{
            [self showAlert:nil withTitle:@"数据错误" haveCancelButton:NO];
        }
    }
    
}

- (IBAction)attenShop:(id)sender {
    
    //友盟统计
    [MobClick event:@"G_SHOP_ATTENTION"];
    
    if (!MyAppDelegate.userInfo) {
        _selectIndex = 1;//关注
        [self login];
        return;
    }
    
    NSString *shopid = [self.merDic objectForKey:@"id"]?:self.shopId;
    if (!shopid) {
        [self showAlert:nil withTitle:@"店铺信息出错，请稍后再试" haveCancelButton:NO];
        return;
    }
    if ([[self.merDic objectForKey:@"attent"] intValue] == 0) {
        
        [self followShop:shopid];
    }
    else{
        [self unFollowShop:shopid];
    }
    
    
}

#pragma mark - 登录成功的回调
-(void)finishLogin{
/*    _selectIndex = 2 购物车
      _selectIndex = 1 关注
 
 */
 isFinishLogin = YES;
    
    //刷新店铺状态
    [self getShopInfo];
    
    
}

//取消关注店铺
-(void)unFollowShop:(NSString *)shopid{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Show" forKey:@"Mod"];
    [dic setObject:@"cancelAttend" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:[NSString stringWithFormat:@"%@",shopid] forKey:@"shopid"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        int code = [[resultDic objectForKey:@"Code"] intValue];
        if (code == 0000) {
            [self showAlert:nil withTitle:@"取消成功！" haveCancelButton:NO];
            [attentBtn setSelected:NO];
            
            NSMutableDictionary * dicNew = [[NSMutableDictionary alloc] initWithDictionary:self.merDic];
            [dicNew setObject:@"0" forKey:@"attent"];
            self.merDic = dicNew;
            
            //发送通知刷新关注页面
            [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshAttention" object:nil];
        }else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
    }];
}


//关注店铺
-(void)followShop:(NSString *)shopid{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Show" forKey:@"Mod"];
    [dic setObject:@"Attent" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:[NSString stringWithFormat:@"%@",shopid] forKey:@"shopid"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        int code = [[resultDic objectForKey:@"Code"] intValue];
        if (code == 0000) {
            [self showAlert:nil withTitle:@"关注成功！" haveCancelButton:NO];
            [attentBtn setSelected:YES];
            
            NSMutableDictionary * dicNew = [[NSMutableDictionary alloc] initWithDictionary:self.merDic];
            [dicNew setObject:@"1" forKey:@"attent"];
            self.merDic = dicNew;
            
            //发送通知刷新关注页面
            [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshAttention" object:nil];
            
        }else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
    }];
}

@end
