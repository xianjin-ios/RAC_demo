//
//  SignedpurchaseVC.m
//  CcbCloudPay
//  
//  Created by Gary on 15/8/12.
//  Copyright (c) 2015年 xkdx. All rights reserved.
//

#import "SignedpurchaseVC.h"
#import <JBigConverterKit/JBigConverter/JBigConverter.h>

@interface SignedpurchaseVC (){
    IBOutlet UIView *_bgViewTop;
    IBOutlet UIView *_bgViewBottom;
    
    IBOutlet UILabel *_lbName;
    IBOutlet UILabel *_lbOrder;
    IBOutlet UILabel *_lbCard;
    IBOutlet UILabel *_lbTime;
    IBOutlet UILabel *_lbMoney;
    
    //签名图片
    IBOutlet UIImageView *_signPicView;
    
    //新增的快捷支付的页面
    IBOutlet UIView *KJZFUView;
    
    
    IBOutlet UIView *infoView;//信息页
    
    IBOutlet UIView *signView;//签名页
    
    IBOutlet UILabel *merName;//商户名称
    
    IBOutlet UILabel *cardNum;//卡号
    
    IBOutlet UILabel *dateTime;//交易时间
    
    
    IBOutlet UILabel *tradeMoney;//交易金额
   
    IBOutlet UIImageView *signImageView;//签名图片
    
}

@end

@implementation SignedpurchaseVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"交易提示单详情";
    if ([self.identifier isEqualToString:@"SPGM"]) {
        self.shopName = [self.infoDic objectForKey:@"mername"];
        self.orderNumber = [self.infoDic objectForKey:@"num"];
        self.cardNumber = [self.infoDic objectForKey:@"bankcardnum"];
        self.timeStr = [self.infoDic objectForKey:@"trantime"];
        self.moneyStr = [self.infoDic objectForKey:@"tranmoney"];
        self.picStr = [self.infoDic objectForKey:@"userimg_code"];

        //商品购买
        _bgViewTop.layer.borderWidth = 1;
        _bgViewTop.layer.cornerRadius = 3;
        _bgViewTop.layer.borderColor = [UIColor colorWithRed:124/255.0f green:80/255.0f blue:68/255.0f alpha:1].CGColor;
        
        _bgViewBottom.layer.borderWidth = 1;
        _bgViewBottom.layer.cornerRadius = 3;
        _bgViewBottom.layer.borderColor = [UIColor colorWithRed:124/255.0f green:80/255.0f blue:68/255.0f alpha:1].CGColor;
        
        [self loadInfo];
    }
    else if([self.identifier isEqualToString:@"KJZF"]){
        //快捷支付
        self.view = KJZFUView;
        infoView.layer.borderWidth = 1;
        infoView.layer.cornerRadius = 3;
        infoView.layer.borderColor = [UIColor colorWithRed:124/255.0f green:80/255.0f blue:68/255.0f alpha:1].CGColor;
        
        signView.layer.borderWidth = 1;
        signView.layer.cornerRadius = 3;
        signView.layer.borderColor = [UIColor colorWithRed:124/255.0f green:80/255.0f blue:68/255.0f alpha:1].CGColor;

        self.picStr = [self.infoDic objectForKey:@"userimg_code"];
        [self loadKJInfo];
    }
    
}

- (void)loadInfo{
    
    _lbName.text = self.shopName;
    _lbOrder.text = self.orderNumber;
    _lbCard.text = self.cardNumber;
    _lbTime.text = self.timeStr;
    _lbMoney.text = [NSString stringWithFormat:@"¥%.2f",self.moneyStr.intValue/100.0f];
    
    NSString *hexString = self.picStr;
    [_signPicView setImage:[JBigConverter convertImageWithJBigData:[self transformSignString:hexString] error:nil]];
    
}
- (void)loadKJInfo{
    merName.text = [self.infoDic objectForKey:@"mername"];
    cardNum.text = [self.infoDic objectForKey:@"bankcardnum"];
   
    NSString *timeStr = [self.infoDic objectForKey:@"trantime"];

    NSDate *date = [NSDate dateWithTimeIntervalSince1970:[timeStr integerValue]];
    NSDateFormatter  *dateformatter = [[NSDateFormatter alloc] init];
    [dateformatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    [dateformatter setTimeZone:[NSTimeZone systemTimeZone]];
    NSString *  locationString = [dateformatter stringFromDate:date];
    dateTime.text = locationString;
    NSString *moneyString = [self.infoDic objectForKey:@"tranmoney"];
    tradeMoney.text = [NSString stringWithFormat:@"￥%.2f",moneyString.intValue/100.f];
     NSString *hexString = self.picStr;
    [signImageView setImage:[JBigConverter convertImageWithJBigData:[self transformSignString:hexString] error:nil]];
    

}
//将16进制字符串转换成16进制data
- (NSData *)transformSignString:(NSString *)hexString{

    int j=0;
    NSInteger desLength = hexString.length/2;
    if (hexString.length%2 != 0) {
        
        return nil;
    }
    Byte bytes[desLength]; ///3ds key的Byte 数组， 128位
    for(int i=0;i<[hexString length];i++)
    {
        int int_ch; /// 两位16进制数转化后的10进制数
        unichar hex_char1 = [hexString characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
        i++;
        unichar hex_char2 = [hexString characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            int_ch2 = hex_char2-87; //// a 的Ascll - 97
        
        
        int_ch = int_ch1+int_ch2;
        NSLog(@"int_ch=%d",int_ch);
        bytes[j] = int_ch;  ///将转化后的数放入Byte数组里
        j++;
    }
    NSData *newData = [[NSData alloc] initWithBytes:bytes length:desLength];
    NSLog(@"newData=%@",newData);
    return newData;
}

@end
