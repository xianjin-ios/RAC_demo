//
//  mySignViewController.h
//  GGSH
//
//  Created by Mac on 16-10-21.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface mySignViewController : BaseViewController
{
    
    IBOutlet UITableView *_signTableView;
    
}
@property (nonatomic,strong) NSString *orderType;//订单类型(商品购买、快捷支付)
@property (nonatomic,strong) UILabel *numLabel;
@property (nonatomic,strong) UILabel *moneyLabel;
@property (nonatomic,strong) UILabel *timeLabel;

@end
