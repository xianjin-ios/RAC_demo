//
//  mySignViewController.m
//  GGSH
//
//  Created by Mac on 15-3-26.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "mySignViewController.h"
#import "MyMessageVC.h"
#import "SignedpurchaseVC.h"
#import "LoginVC.h"
#import <JBigConverterKit/JBigConverter/JBigConverter.h>

#define labelWidth _signTableView.frame.size.width/3
//每页的数量为10
#define Pagesize 10
@interface mySignViewController ()<MJRefreshBaseViewDelegate,loginDelegate>
{
    UIView *topView;
    
    UISegmentedControl *segmentControl;
    
    UIView *noView;
    
    int pageIndex;//商品购买的页码号
    int KJ_pageIndex;//快捷支付的页码号
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    
    //    签购单信息
    IBOutlet UIView *bilView;
    IBOutlet UIImageView *bilImage;
    
    IBOutlet UILabel *shopnameLabel;
    IBOutlet UILabel *shopnumberLabel;
    IBOutlet UILabel *zhongduanLabel;
    IBOutlet UILabel *pinzhengLabel;
    IBOutlet UILabel *cankaoLabel;
    IBOutlet UILabel *liushuiLabel;
    IBOutlet UILabel *kahaoLabel;
    IBOutlet UILabel *piciLabel;
    IBOutlet UILabel *shijianLabel;
    IBOutlet UILabel *jineLabel;
    
    NSMutableArray *KjzfArray;
    
    UIImageView *imageAlert;
    
    NSDate *date;
    NSMutableArray *dataArray;
}
@end

@implementation mySignViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self cancelTapHideKeyBoard:YES];
    KjzfArray = [[NSMutableArray alloc]init];
    [self setTopView];
    [self initSegmentControl];
    self.orderType = @"SPGM";
    pageIndex = 1;
    KJ_pageIndex = 1;
    [self getSignOrderListWithOrderType:self.orderType];
    
    //右边消息按钮
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0.0, 0.0, 16, 16);
    [rightBtn addTarget:self action:@selector(my_message:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    rightBarButtonItem.style = UIBarButtonItemStylePlain;
    //判断是否要添加红点提示
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(10, -4, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [rightBarButtonItem.customView addSubview:imageAlert];
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
    
    
    //下拉刷新
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _signTableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _signTableView;
    _footer.delegate = self;
    
    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
}
- (void)initSegmentControl{
    NSArray *segmentData = [[NSArray alloc]initWithObjects:@"商品购买",@"快捷支付", nil];
    segmentControl = [[UISegmentedControl alloc]initWithItems:segmentData];
    segmentControl.frame = CGRectMake(SCREEN_WIDTH *0.5-75, 10, 150, 30);
    
    //设置按下按钮时的颜色
    segmentControl.tintColor = [UIColor colorWithHexString:@"ff0181"];
    segmentControl.layer.masksToBounds = YES;
    segmentControl.layer.cornerRadius = 2;
    segmentControl.selectedSegmentIndex = 0;//默认选中的按钮索引
    //下面是正常状态下和按下状态的属性控制，比如字体的大小和颜色
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:12],NSFontAttributeName,[UIColor whiteColor],NSForegroundColorAttributeName,nil, nil];
    [segmentControl setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [segmentControl setTitleTextAttributes:attributes forState:UIControlStateSelected];
    
    //设置分段控件的相应的点击事件
    [segmentControl addTarget:self action:@selector(segmentClick:) forControlEvents:UIControlEventValueChanged];
    [self.navigationController.navigationBar addSubview:segmentControl];
    
}
- (void)segmentClick:(UISegmentedControl *)seg{
    NSLog(@"%s",__func__);
    NSInteger index = seg.selectedSegmentIndex;
    
    if (noView) {
        [noView removeFromSuperview];
        noView = nil;
    }
#warning 编译不过
//    if ([HUD taskInProgress]) {
//        return;
//    }
    
    switch (index) {
        case 0://商品购买
        {
            
            self.numLabel.text = @"订单编号";
          
            
            self.orderType = @"SPGM";//商品购买的标识
            if (KjzfArray.count > 0) {
                [_signTableView reloadData];
                
            }else{
                [self getSignOrderListWithOrderType:self.orderType];
                [_signTableView reloadData];

            }
            
            break;
            
        }
        case 1://快捷支付
        {
            self.numLabel.text = @"商户名称";
            
            self.orderType = @"KJZF";
            
            if (KjzfArray.count > 0) {
                [_signTableView reloadData];
                
            }else{
                
                KJ_pageIndex = 1;
                
                [self getSignOrderListWithOrderType:self.orderType];
            }
            
            break;
        }
        default:
            
            break;
    }
    
}

- (void)refreshNavBtn{
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
}

#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(refreshView == _header) {// 下拉刷新
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        //5秒内不能重复发起网络请求，只是界面上闪动下正在加载，就1s。
        if(date){
            NSDate *tenMiniteLater = [date dateByAddingTimeInterval:5];
            NSDate *currentDate = [NSDate date];
            if(NSOrderedDescending == [tenMiniteLater compare:currentDate]){
                ZLog(@"ascending");
                date = [NSDate date];
                [self performSelector:@selector(OneSecondElapse) withObject:nil afterDelay:1];
                [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
                return;
            }
            
            //网络请求
            pageIndex = 1;
            KJ_pageIndex = 1;
            
            [self getSignOrderListWithOrderType:self.orderType];
            
        }else{
            date = [NSDate date];
            //网络请求
            pageIndex = 1;
            [self getSignOrderListWithOrderType:self.orderType];
            
        }
        
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    }else if (refreshView == _footer){//上拉加载更多
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        if ([self.orderType isEqualToString:@"SPGM"]) {
            if (dataArray.count%Pagesize ==0) {
                pageIndex ++;
                //网络请求
                [self getSignOrderListWithOrderType:self.orderType];
            }
        }
        else
            if (KjzfArray.count%Pagesize ==0) {
                KJ_pageIndex ++;
                //网络请求
                [self getSignOrderListWithOrderType:self.orderType];
            }
        
        
        
        
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        
    }
}

//1s的假loading，取消正在加载就好
- (void)OneSecondElapse{
    [self hideHUD];
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (segmentControl != nil) {
        segmentControl.alpha = 1.0;
    }
    //友盟统计
    [MobClick beginLogPageView:@"G_SIGNORDER_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    segmentControl.alpha = 0.0;
    //友盟统计
    [MobClick endLogPageView:@"G_SIGNORDER_VIEW"];
    
}

- (IBAction)my_message:(id)sender {
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];
    
}

- (void)setTopView{
    //背景
    topView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 45)];
    topView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:topView];
    
    NSInteger rowHeight = 0;
    if (SCREEN_HEIGHT == 480) {
        rowHeight = 88;
    }
    //调整tableView的Frame
    [_signTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width, SCREEN_HEIGHT - 45 + rowHeight)];
    
    //标签
    self.numLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, _signTableView.frame.size.width*0.3, 35)];
    self.numLabel.tag = 101;
    self.numLabel.textColor = [UIColor colorWithHexString:@"#000000"];
    self.numLabel.textAlignment = 2;
    self.numLabel.font = [UIFont systemFontOfSize:13];
    [topView addSubview:self.numLabel];
    [self.numLabel setText:@"订单编号"];
    UILabel *moneyLabel = [[UILabel alloc]initWithFrame:CGRectMake(labelWidth+20, 5, labelWidth, 35)];
    self.moneyLabel = moneyLabel;
    moneyLabel.tag = 102;
    moneyLabel.textColor = [UIColor blackColor];
    moneyLabel.font = [UIFont systemFontOfSize:13];
    moneyLabel.textAlignment = 2;
    [topView addSubview:moneyLabel];
    moneyLabel.text = @"交易金额(元)";
    
    UILabel *timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(labelWidth*2+10, 5, labelWidth, 35)];
    self.timeLabel = timeLabel;
    timeLabel.tag = 103;
    timeLabel.textColor = [UIColor blackColor];
    timeLabel.font = [UIFont systemFontOfSize:13];
    timeLabel.textAlignment = 1;
    [topView addSubview:timeLabel];
    timeLabel.text = @"交易时间";
    
    UIView *downLine = [[UIView alloc]initWithFrame:CGRectMake(0, 44.5, SCREEN_WIDTH, 0.5)];
    downLine.backgroundColor = [UIColor colorWithHexString:@"#dfdfdf"];
    [topView addSubview:downLine];
    
}

- (IBAction)closeBill:(id)sender {
    [bilView setHidden:YES];
    [topView setHidden:NO];
}

//将16进制字符串转换成16进制data
- (NSData *)transformSignString:(NSString *)hexString{
    int j=0;
    NSInteger desLength = hexString.length/2;
    if (hexString.length%2 != 0) {
        
        return nil;
    }
    Byte bytes[desLength]; ///3ds key的Byte 数组， 128位
    for(int i=0;i<[hexString length];i++)
    {
        int int_ch; /// 两位16进制数转化后的10进制数
        unichar hex_char1 = [hexString characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
        i++;
        unichar hex_char2 = [hexString characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            int_ch2 = hex_char2-87; //// a 的Ascll - 97
        
        
        int_ch = int_ch1+int_ch2;
        NSLog(@"int_ch=%d",int_ch);
        bytes[j] = int_ch;  ///将转化后的数放入Byte数组里
        j++;
    }
    NSData *newData = [[NSData alloc] initWithBytes:bytes length:desLength];
    NSLog(@"newData=%@",newData);
    return newData;
}

- (void)showBilView:(NSDictionary *)detailDic
{
    [bilView setHidden:NO];
    [topView setHidden:YES];
    
    //填写签购单 金融交易信息。
    NSString *cardStr = [detailDic objectForKey:@"bankcardnum"];
    NSUInteger len = cardStr.length;
    if(len >= 16){
        cardStr = [cardStr stringByReplacingCharactersInRange:NSMakeRange(7, len - 12) withString:@"******"];
    }
    kahaoLabel.text = cardStr;
    cankaoLabel.text = [detailDic objectForKey:@"retrefno"];
    
    //时间拼接 = 日期+时间，时间中间：分割
    NSString *strH = @"";
    NSString *tempStr = [detailDic objectForKey:@"trandate"];
    if (tempStr.length == 8) {
        NSString *year = [tempStr substringToIndex:4];
        NSString *month = [tempStr substringWithRange:NSMakeRange(4, 2)];
        NSString *day = [tempStr substringFromIndex:6];
        strH  = [NSString stringWithFormat:@"%@-%@-%@",year,month,day];
    }else
        strH = tempStr;
    
    NSString *strT = [detailDic objectForKey:@"trantime"];
    if(strT.length == 6){
        strT = [NSString stringWithFormat:@"%@:%@:%@", [strT substringWithRange:NSMakeRange(0, 2)], [strT substringWithRange:NSMakeRange(2, 2)], [strT substringWithRange:NSMakeRange(4, 2)]];
    }
    NSString *timeStr = [NSString stringWithFormat:@"%@ %@",strH ,strT];
    shijianLabel.text = timeStr;
    pinzhengLabel.text = [detailDic objectForKey:@"voucher"];
    piciLabel.text = [detailDic objectForKey:@"batchno"];
    zhongduanLabel.text = [detailDic objectForKey:@"tid"];
    shopnumberLabel.text = [detailDic objectForKey:@"merid"];
    if([[detailDic objectForKey:@"mername"] isKindOfClass:[NSString class]]){
        shopnameLabel.text = [detailDic objectForKey:@"mername"];
    }
    liushuiLabel.text = [detailDic objectForKey:@"trace"];
    jineLabel.text = [NSString stringWithFormat:@"%.2f", [[detailDic objectForKey:@"paymoney"] doubleValue]/100.0];
    
    //签名图片
    //解压jBig图片
    NSString *hexString = [detailDic objectForKey:@"userimg_code"];
    [bilImage setImage:[JBigConverter convertImageWithJBigData:[self transformSignString:hexString] error:nil]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)getSignOrderListWithOrderType:(NSString *)orderType{
    if ([orderType isEqualToString:@"SPGM"]) {
        [self getSignOrderList];//商品购买的数据
    }
    if ([orderType isEqualToString:@"KJZF"]) {
        //快捷支付的数据
        [self getKjzfOrderListWithPage:KJ_pageIndex];
    }
}

//获取商品购买单列表
-(void)getSignOrderList{
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"MySwipeCard" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"user_login_name"];
    [dicContent setObject:[NSNumber numberWithInt:pageIndex] forKey:@"pageindex"];
    [dicContent setObject:[NSNumber numberWithInt:10] forKey:@"pagesize"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if (pageIndex == 1) {
            [dataArray removeAllObjects];
        }
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            if (pageIndex == 1) {
                dataArray = [[resultDic objectForKey:@"DetailInfo"]mutableCopy];
                
            }else{
                
                NSArray *tempArr = [resultDic objectForKey:@"DetailInfo"];
                [dataArray addObjectsFromArray:tempArr];
            }
            
        }
        else{
            pageIndex --;
            if (pageIndex < 0) {
                pageIndex = 1;
            }
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
        
        [_signTableView reloadData];
        
        [self hideHUD];
        
        if (dataArray.count == 0) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [_signTableView addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
        
    }];
}

//获取快捷支付的订单列表
- (void)getKjzfOrderListWithPage:(int)page{
    
    NSMutableDictionary *contentDic = [[NSMutableDictionary alloc]init];
    [contentDic setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];//账号id
    [contentDic setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];//logintoken
    NSLog(@"%@",MyAppDelegate.userInfo);
    [contentDic setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"pmobile"];//手机号
    [contentDic setObject:@"1" forKey:@"devidetype"];//设备类型
    [contentDic setObject:[NSNumber numberWithInt:page] forKey:@"pageindex"];//页码
    [contentDic setObject:[NSNumber numberWithInt:Pagesize] forKey:@"pagesize"];//每页的个数
    [contentDic setObject:@"1" forKey:@"devicetype"];
    [contentDic setObject:KVERSION forKey:@"version_name"];
    
    NSMutableDictionary * dic = [[NSMutableDictionary alloc]init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"quickPaymentSelect" forKey:@"Act"];
    [dic setObject:contentDic forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if (page == 1) {
            [KjzfArray removeAllObjects];
        }
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            if (page == 1) {
                KjzfArray = [[resultDic objectForKey:@"DetailInfo"]mutableCopy];
                
            }else{
                
                NSArray *tempArr = [resultDic objectForKey:@"DetailInfo"];
                [KjzfArray addObjectsFromArray:tempArr];
            }
            
        }
        else{
            KJ_pageIndex --;
            if (KJ_pageIndex < 0) {
                KJ_pageIndex = 1;
            }
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
        
        if (KjzfArray.count == 0) {
            //无数据提示
            if (!noView) {
                
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [_signTableView addSubview:noView];
            }
        }
        else
        {
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
        [_signTableView reloadData];
        [self hideHUD];
        
    }];
}

-(void)getSignOrderDetail:(NSString *)pid{//pid -- 签购单id
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Signedorder" forKey:@"Mod"];
    [dic setObject:@"Sel" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    //20150804163199505110  4631
    [dicContent setObject:pid forKey:@"pid"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSDictionary *dicInfo = [resultDic objectForKey:@"DetailInfo"];
            //[self showBilView:dicInfo];
            //跳转到签购单页面
            SignedpurchaseVC *controller = [[SignedpurchaseVC alloc] init];
            controller.identifier = self.orderType;
            controller.infoDic = [dicInfo mutableCopy];
            
            [self.navigationController pushViewController:controller animated:YES];
        }
        else{
            if ([resultDic objectForKey:@"Message"]) {
                [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
            }else{
                [self showAlert:nil withTitle:@"解析错误，请稍后再试！" haveCancelButton:NO];
            }
        }
    }];
}

#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([self.orderType isEqualToString:@"SPGM"]) {
        return dataArray.count;
    }
    else
        return KjzfArray.count;
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //显示详情
    if ([self.orderType isEqualToString:@"SPGM"]) {
        [self getSignOrderDetail:[[dataArray objectAtIndex:indexPath.row] objectForKey:@"id"]];
    }
    else if ([self.orderType isEqualToString:@"KJZF"]){
        //跳转到签购单页面
        
        SignedpurchaseVC *controller = [[SignedpurchaseVC alloc] init];
        controller.identifier = self.orderType;
        NSDictionary *infoDict = [KjzfArray objectAtIndex:indexPath.row];
        controller.infoDic = [infoDict mutableCopy];
        
        [self.navigationController pushViewController:controller animated:YES];
        
        
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //翻页CELL
    static NSString *CellIdentifier = nil;
    if ([self.orderType isEqualToString:@"SPGM"]) {
        CellIdentifier = @"SPGMCell";
    }
    if ([self.orderType isEqualToString:@"KJZF"]) {
        CellIdentifier = @"KJZFCell";
    }
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        UIView *cellBgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 50)];
        cellBgView.backgroundColor = [UIColor whiteColor];
        [cell.contentView addSubview:cellBgView];
        
        UILabel *numLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, 150, 40)];
        numLabel.tag = 201;
        numLabel.textColor = [UIColor colorWithHexString:@"#000000"];
        numLabel.font = [UIFont systemFontOfSize:12];
        numLabel.numberOfLines = 0;
        numLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:numLabel];
        numLabel.text = @"20150325202428679677";
        
        UILabel *moneyLabel = [[UILabel alloc]initWithFrame:CGRectMake(167, 5, _signTableView.frame.size.width-100-162, 40)];
        moneyLabel.tag = 202;
        moneyLabel.textColor = [UIColor colorWithHexString:@"#fc0000"];
        moneyLabel.font = [UIFont systemFontOfSize:12];
        moneyLabel.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:moneyLabel];
        moneyLabel.text = @"￥13600.00";
        
        UILabel *timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(_signTableView.frame.size.width-90, 5, 80, 40)];
        timeLabel.tag = 203;
        timeLabel.textColor = [UIColor colorWithHexString:@"#636363"];
        timeLabel.font = [UIFont systemFontOfSize:12];
        timeLabel.backgroundColor = [UIColor clearColor];
        timeLabel.textAlignment = 1;
        timeLabel.numberOfLines = 3;
        [cell.contentView addSubview:timeLabel];
        timeLabel.text = @"2015-3-15 16:23:22";
        
        UIView *downLine = [[UIView alloc]initWithFrame:CGRectMake(0, 49.5, SCREEN_WIDTH, 0.5)];
        downLine.backgroundColor = [UIColor colorWithHexString:@"#dfdfdf"];
        [cell.contentView addSubview:downLine];
        
    }
    
    UILabel *numLabel = (UILabel *)[cell.contentView viewWithTag:201];
    UILabel *moneyLabel = (UILabel *)[cell.contentView viewWithTag:202];
    UILabel *timeLabel = (UILabel *)[cell.contentView viewWithTag:203];
    
    if ([self.orderType isEqualToString:@"SPGM"]) {
        numLabel.text = [[dataArray objectAtIndex:indexPath.row] objectForKey:@"num"];
        moneyLabel.text = [NSString stringWithFormat:@"￥%.2f",[[[dataArray objectAtIndex:indexPath.row] objectForKey:@"paymoney"] doubleValue]/100.0];
        
        NSString *timeStr = [[dataArray objectAtIndex:indexPath.row] objectForKey:@"ctime"];
        NSDate *idate = [NSDate dateWithTimeIntervalSince1970:[timeStr integerValue]];
        NSDateFormatter  *dateformatter = [[NSDateFormatter alloc] init];
        [dateformatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        [dateformatter setTimeZone:[NSTimeZone systemTimeZone]];
        NSString *locationString = [dateformatter stringFromDate:idate];
        timeLabel.text = locationString;
        
        return cell;
    }
    else{
        numLabel.text = [[KjzfArray objectAtIndex:indexPath.row] objectForKey:@"mername"];//商户名
        moneyLabel.text = [NSString stringWithFormat:@"￥%.2f",[[[KjzfArray objectAtIndex:indexPath.row] objectForKey:@"tranmoney"] doubleValue]/100.0];//交易额
        
        NSString *timeStr = [[KjzfArray objectAtIndex:indexPath.row] objectForKey:@"trantime"];
        NSDate *idate = [NSDate dateWithTimeIntervalSince1970:[timeStr integerValue]];
        NSDateFormatter  *dateformatter = [[NSDateFormatter alloc] init];
        [dateformatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        [dateformatter setTimeZone:[NSTimeZone systemTimeZone]];
        NSString *  locationString = [dateformatter stringFromDate:idate];
        timeLabel.text = locationString;
        
        return cell;
    }
    
}

@end
