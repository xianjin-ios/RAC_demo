//
//  SignedpurchaseVC.h
//  CcbCloudPay
//  签购单页面
//  Created by STAR on 15/8/12.
//  Copyright (c) 2015年 xkdx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface SignedpurchaseVC : BaseViewController

@property (nonatomic,strong) NSMutableDictionary *infoDic;//存储信息
@property (nonatomic,strong) NSString *identifier;//标识类型
@property (nonatomic, strong) NSString *shopName;  /**< 商铺名称 */
@property (nonatomic, strong) NSString *orderNumber; /**< 订单号 */
@property (nonatomic, strong) NSString *cardNumber; /**< 卡号 */
@property (nonatomic, strong) NSString *timeStr; /**< 交易时间 */
@property (nonatomic, strong) NSString *moneyStr; /**< 交易金额 */
@property (nonatomic, strong) NSString *picStr; /**< 签名图片地址 */

@end
