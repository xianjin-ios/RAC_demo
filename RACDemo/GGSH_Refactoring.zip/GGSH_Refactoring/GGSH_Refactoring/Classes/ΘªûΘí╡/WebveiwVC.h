//
//  WebveiwVC.h
//  cards
//
//  Created by STAR on 16-10-19.
//  Copyright (c) 2016年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChromeProgressBar.h"
#import "IMTWebView.h"
#import "BaseViewController.h"

@interface WebveiwVC :  BaseViewController<UIWebViewDelegate, IMTWebViewProgressDelegate>{
    UIProgressView *chromeBar;
}
@property (nonatomic, retain) IBOutlet IMTWebView *webview;
@property (nonatomic, copy) NSString *url;
-(void)loadurl: (NSString*)url;
- (void)setTetle:(NSString *)title;
@end
