//
//  proTopVC.m
//  GGSH
//
//  Created by siqiyang on 15/9/21.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "proTopVC.h"

@interface proTopVC ()
{
    NSTimer * timer;

}
@end

@implementation proTopVC

- (void)viewDidLoad {
    [super viewDidLoad];

    //初始化翻页控件
    _pageController.frame = CGRectMake(_pageController.frame.origin.x, _pageController.frame.origin.y, _pageController.frame.size.width, 16);
    _pageController.backgroundColor = [UIColor blackColor];
    _pageController.currentPage = 0;
    _pageController.numberOfPages = 1;
    _pageController.layer.cornerRadius = 8;
    
    //启动定时器
    timer = [NSTimer scheduledTimerWithTimeInterval: 10.0
                                             target: self
                                           selector: @selector(handleTimer:)
                                           userInfo: nil
                                            repeats: YES];
    
}

- (void)loadInfoView{
    
    [self getNews:_scrollView page:_pageController];

}

//获取轮播信息
-(void)getNews:(UIScrollView*)scrollView page:(UIPageControl*)pageCtrl{
    
    __weak UIScrollView * sv = scrollView;
    __weak UIPageControl * pCtrl = pageCtrl;
    
    if (self.arrImages.count == 0) {
        UIImageView * imgView = [[UIImageView alloc] init];
        imgView.frame = CGRectMake(0, 0, sv.frame.size.width, sv.frame.size.height);
        imgView.image = [UIImage imageNamed:@"goodsDefaultImage.png"];
        imgView.backgroundColor = [UIColor clearColor];
        [sv addSubview:imgView];
        
        return;
    }
    self.shareImage = [[UIImageView alloc] init];
    NSURL *url = [NSURL URLWithString:[self.arrImages objectAtIndex:0]];
    [self.shareImage XK_setImageWithURL:url placeholderImage:nil];
    //初始化数据
    if (sv == nil) {
        return;
    }
    sv.contentSize = CGSizeMake(sv.frame.size.width* [self.arrImages count], sv.frame.size.height);
    sv.pagingEnabled = YES;
    
    pCtrl.numberOfPages = [self.arrImages count];
    
    double width = [self.arrImages count] * 20;
    [pCtrl setFrame:CGRectMake((SCREEN_WIDTH-width)/2, pCtrl.frame.origin.y, width, pCtrl.frame.size.height)];

    for (int i = 0; i < [self.arrImages count]; i ++) {
        
        //创建图片控件
        UIImageView * imgView = [[UIImageView alloc] init];
        imgView.frame = CGRectMake(i * sv.frame.size.width, 0, sv.frame.size.width, sv.frame.size.height);
        imgView.backgroundColor = [UIColor clearColor];
        [sv addSubview:imgView];
        
        UIImageView * imgnameView = [[UIImageView alloc] init];
        imgnameView.frame = CGRectMake(0, 0, imgView.frame.size.width, sv.frame.size.height);
        imgnameView.backgroundColor = [UIColor clearColor];
        [imgView addSubview:imgnameView];
        
        NSURL *url = [NSURL URLWithString:[self.arrImages objectAtIndex:i]];
        [imgnameView XK_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"goodsListDefaultImage.png"]];
        
        
        UIButton *btnImageDetail = [UIButton buttonWithType:UIButtonTypeCustom];
        btnImageDetail.tag = 2000 + i;
        btnImageDetail.frame = CGRectMake(i * sv.frame.size.width, 0, sv.frame.size.width, sv.frame.size.height);
        btnImageDetail.backgroundColor = [UIColor clearColor];
        [btnImageDetail addTarget:self action:@selector(clickNews:) forControlEvents:UIControlEventTouchUpInside];
        [sv addSubview:btnImageDetail];
        
    }

    
}

//点击图片
-(void)clickNews:(id)sender{
    
    UIButton * btn = (UIButton *)sender;
    NSInteger index = btn.tag - 2000;
    ZLog(@"%ld",(long)index);
}

#pragma mark -
#pragma mark 轮播新闻

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if(!decelerate)
    {
        [self _updatePageIndex:scrollView];
    }
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [self _updatePageIndex:scrollView];
}

-(void)_updatePageIndex:(UIScrollView*)scrollView
{
    int page = (int)scrollView.contentOffset.x / (int)scrollView.frame.size.width;
    
    _pageController.currentPage = page;
    
}

- (void)handleTimer: (NSTimer *) atimer
{
    
    ////滚动最新资讯
    //获取当前位置
    UIScrollView * scrollView = _scrollView;
    
    CGPoint offsetPos = scrollView.contentOffset;
    
    //如果当前用户正在操作，则不自动滚屏
    if ((int)offsetPos.x % (int)scrollView.frame.size.width  != 0) {
        return;
    }
    
    int pageCount = scrollView.contentSize.width / SCREEN_WIDTH;
    
    float offsetX = 0.0;
    if ((int)offsetPos.x != (pageCount - 1)*(int)scrollView.frame.size.width) {
        //如果不是最后一页，那页数加一
        offsetX = offsetPos.x + scrollView.frame.size.width;
    }
    
    if (offsetX == 0.0 ) {
        [scrollView scrollRectToVisible:CGRectMake(offsetX, 0, scrollView.frame.size.width, scrollView.frame.size.height) animated:NO];
    }
    else {
        [scrollView scrollRectToVisible:CGRectMake(offsetX, 0, scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    
    NSLog(@"the offset x is:%d", (int)offsetX);
    
    int page = (int)offsetX / (int)scrollView.frame.size.width;
    
    _pageController.currentPage = page;
    
    
}


@end
