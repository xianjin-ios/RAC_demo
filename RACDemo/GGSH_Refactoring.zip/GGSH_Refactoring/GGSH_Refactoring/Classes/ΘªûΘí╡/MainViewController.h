//
//  MainViewController.h
//  GGSH_Refactoring
//
//  Created by huadong on 16/9/14.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface MainViewController : BaseViewController

@end
