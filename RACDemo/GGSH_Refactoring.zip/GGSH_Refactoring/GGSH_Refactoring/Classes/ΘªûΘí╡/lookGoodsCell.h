//
//  lookGoodsCell.h
//  GGSH
//
//  Created by siqiyang on 15/7/1.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface lookGoodsCell : UICollectionViewCell
{
    
}
@property (nonatomic,retain) NSDictionary *dicCell;

@property (strong, nonatomic) IBOutlet UIImageView *image;
@property (strong, nonatomic) IBOutlet UILabel *label;

@property (strong, nonatomic) IBOutlet UILabel *lbPrc;
@property (strong, nonatomic) IBOutlet UILabel *lbNum;
@property (retain, nonatomic) IBOutlet UILabel *lbOldPrc;


@end
