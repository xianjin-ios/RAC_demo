//
//  youhuiDetailViewController.h
//  GGSH
//
//  Created by siqiyang on 15/7/8.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface youhuiDetailViewController : BaseViewController<UICollectionViewDataSource,UICollectionViewDelegate>
{
    
    IBOutlet UIView *topView;
    IBOutlet UIView *middleView;
    IBOutlet UIView *downView;
    
    //店铺信息及二维码
    IBOutlet UIImageView *shopIcon;
    IBOutlet UILabel *lbShopName;
    IBOutlet UIImageView *codeIcon;
    
    //商品信息
    IBOutlet UICollectionView *iCollectionView;
    
    
    IBOutlet UIView *showMoreView;
    
}
@property (nonatomic,retain) NSMutableDictionary *infoDic;



- (IBAction)gotoShop:(id)sender;



@end
