//
//  myOrderVC.h
//  GGSH
//  我的订单
//  Created by 任春宁 on 15/3/18.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "oneOrderVC.h"


@interface myOrderVC : BaseViewController<UITableViewDataSource, UITableViewDelegate,toDetailDelegate, MJRefreshBaseViewDelegate>{
    //生活服务类订单
    IBOutlet UITableView * _tableLifeService;
    MJRefreshFooterView *_footerLifeService;
    
    
    
    IBOutlet UITableView * _tableView;
    
    //服务器获取的订单列表数据
    NSMutableArray * _arrOrderList;
    
    //订单的UIViewController列表
    NSMutableDictionary * _dicOrderCtrl;
    
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    
    
    //下划横线
    IBOutlet UIView * _vLine;
    
    IBOutlet UIButton * _btnTab1;
    IBOutlet UIButton * _btnTab2;
    IBOutlet UIButton * _btnTab3;
    
    
    
}

@property (retain, nonatomic) IBOutlet UIButton *btn_status;
@property (retain, nonatomic) IBOutlet UIButton *btn_type;
@property (retain, nonatomic) IBOutlet UIImageView *img_status;
@property (retain, nonatomic) IBOutlet UIImageView *img_type;


@property (retain, nonatomic) NSString * TradeStatus;
@property (assign, nonatomic) NSInteger user_order_type;//1代付预付款2待收货/自取3已完成

@property (nonatomic,assign) BOOL isPaying;


//订单状态初始化
-(id)initWithTradeStatus:(NSString*)strStatus;

@end
