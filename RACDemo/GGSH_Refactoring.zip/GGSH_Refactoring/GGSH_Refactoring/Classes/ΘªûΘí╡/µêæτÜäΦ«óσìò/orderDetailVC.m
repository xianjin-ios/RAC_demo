//
//  orderDetailVC.m
//  GGSH
//
//  Created by heyddo on 15/3/18.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "orderDetailVC.h"

@interface orderDetailVC ()
{
    IBOutlet UIView *bilView;
    IBOutlet UIImageView *bilImage;
    IBOutlet UILabel *prclab;
    
    //订单信息保留
    NSDictionary *backupDic;
    
    NSMutableArray *_dataArray;
}
@end

@implementation orderDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"订单详情";
    
    ZLog(@"%@",self.dicOrder);
    [self.bScrollView setContentSize:CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT+20)];
    
    [self performSelector:@selector(getOrderData) withObject:nil afterDelay:0.1];

}

#pragma mark - 获取订单详情

-(void)getOrderData{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"Order" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:[[self.dicOrder objectForKey:@"num"] objectForKey:@"id"] forKey:@"pid"];
    
    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            _dataArray = [resultDic objectForKey:@"DetailInfo"];
            NSDictionary *detailInfo = [resultDic objectForKey:@"DetailInfo"];
            
            //保存，在支付时用
            backupDic = detailInfo;
            
            _timeLabel.text = [[detailInfo objectForKey:@"payInfo"] objectForKey:@"ctime"];
            _orderLabel.text = [[detailInfo objectForKey:@"payInfo"] objectForKey:@"num"];
            _phoneLabel.text = [[detailInfo objectForKey:@"payInfo"] objectForKey:@"phone"];
            NSString *payWay = [[detailInfo objectForKey:@"payInfo"] objectForKey:@"payway"];
            if([@"3" isEqualToString:payWay])
                payWay = @"银联";
            else if ([@"2" isEqualToString:payWay])
                payWay = @"支付宝";
            else if ([@"1" isEqualToString:payWay])
                payWay = @"MPOS";
            else if ([@"4" isEqualToString:payWay])
                payWay = @"现金支付";
            else if ([@"5" isEqualToString:payWay])
                payWay = @"未支付";
            //支付状态
            NSString *status = nil;
            NSInteger staint = [[[[detailInfo objectForKey:@"goodsDetail"] objectAtIndex:0] objectForKey:@"tradestatus"] integerValue];
            if(1 == staint)
                status = @"未支付";
            else if(2 == staint)
                status = @"支付失败";
            else if(3 == staint){
                status = @"支付成功";
                UIButton *btn = (UIButton*)[self.view viewWithTag:110];
                [btn setTitle:@"查看详情" forState:UIControlStateNormal];
            }
            else if (4 == staint)
                status = @"预订状态";
            
            if ([[[[detailInfo objectForKey:@"goodsDetail"] objectAtIndex:0] objectForKey:@"prepay"] integerValue] > 0) {
                status = @"部分支付";
                
            }
            
            _payStatusLabel.text = status;
            _payMothordLabel.text = payWay;
            
            NSUInteger count = [[detailInfo objectForKey:@"goodsDetail"] count];
            _proNumLabel.text = [NSString stringWithFormat:@"共%ld种商品",count];
            
            
            NSInteger totlePrc = 0;
            NSInteger prePay = 0;
            for(int i = 0; i < count; i++){
                //计算价格
                totlePrc += [[[[detailInfo objectForKey:@"goodsDetail"] objectAtIndex:i] objectForKey:@"sunmprice"] integerValue];
                prePay += [[[[detailInfo objectForKey:@"goodsDetail"] objectAtIndex:i] objectForKey:@"prepay"] integerValue];
                
                //多商品名称
                UILabel *nameLabel = [[UILabel alloc] initWithFrame:_goodNameLabel.frame];
                nameLabel.center = CGPointMake(_goodNameLabel.center.x, _goodNameLabel.center.y + i*21);
                nameLabel.font = [UIFont systemFontOfSize:15];
                nameLabel.textColor = [UIColor darkGrayColor];
                
                nameLabel.text = [NSString stringWithFormat:@"%@    x%ld",[[[detailInfo objectForKey:@"goodsDetail"] objectAtIndex:i] objectForKey:@"goodsname"],[[[[detailInfo objectForKey:@"goodsDetail"] objectAtIndex:i] objectForKey:@"goodsnum"] integerValue]];
                [_nameScrollBg addSubview:nameLabel];
            }
            _nameScrollBg.contentSize = CGSizeMake(_nameScrollBg.frame.size.width, 52+ 10*count);
            
            if (prePay > 0) {
                NSString *needPayStr = [NSString stringWithFormat:@"还需支付¥%.2f", (totlePrc-prePay)/100.0];
                NSString *prePayStr = [NSString stringWithFormat:@"已支付¥%.2f", prePay/100.0];
                
                _moneyLabel.text = [NSString stringWithFormat:@"%@  %@",prePayStr,needPayStr];
            }else{
                _moneyLabel.text = [NSString stringWithFormat:@"支付金额¥%.2f",totlePrc/100.0];
                
            }
            prclab.text = _moneyLabel.text;
            
            NSDictionary *dic1 = [[detailInfo objectForKey:@"goodsDetail"] objectAtIndex:0];
            
            //配送信息
            if([dic1 objectForKey:@"acceptname"] != [NSNull null]){
                self.hName.text = [NSString stringWithFormat:@"姓名:%@",[dic1 objectForKey:@"acceptname"]];
            }
            if([dic1 objectForKey:@"contact"] != [NSNull null]){
                self.hPhone.text = [NSString stringWithFormat:@"联系方式:%@",[dic1 objectForKey:@"contact"]];
            }
            if([dic1 objectForKey:@"address"] != [NSNull null]){
                self.hAddress.text = [NSString stringWithFormat:@"配送地址:%@",[dic1 objectForKey:@"address"]];
            }
            
            //支付二维码图片
            NSString *imgUrl = [[detailInfo objectForKey:@"payInfo"] objectForKey:@"code"];
            [self.payGateImage XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:nil];
            
        }
        else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
        
    }];
}

//获取签购单 可能是支付按钮。
- (IBAction)showQiangouBil:(id)sender{
    UIButton *btn = (UIButton *)sender;
    if([[btn titleForState:UIControlStateNormal] isEqualToString:@"支付"]){
        [self showAlert:nil withTitle:@"请到商户版支付" haveCancelButton:NO];
        return;
    }
    NSString *tocken = @"";
    NSString *userid = @"";
    if (MyAppDelegate.userInfo) {
        tocken = [[MyAppDelegate.userInfo objectForKey:@"logintoken"] objectForKey:@"logintoken"];
        userid = [[MyAppDelegate.userInfo objectForKey:@"id"] objectForKey:@"id"];

    }
    
    NSDictionary *contentDic = [NSDictionary dictionaryWithObjectsAndKeys:userid,@"admid",[[self.dicOrder objectForKey:@"num"] objectForKey:@"id"],@"pid",tocken,@"logintoken",@"1",@"devicetype",KVERSION,@"version_name", nil];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"Signedorder",@"Mod",@"Sel",@"Act",contentDic,@"Content", nil];
    [self showHUD];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            [bilView setHidden:NO];
            NSString *urlstr = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"userimg"];
            
            [bilImage XK_setImageWithURL:[NSURL URLWithString:urlstr] placeholderImage:nil];
            [bilImage setContentMode:UIViewContentModeScaleAspectFill];
            bilImage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:urlstr]]];
        }
        
    }];
}

- (IBAction)delBilBtn:(id)sender {
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Signedorder" forKey:@"Mod"];
    [dic setObject:@"Delorder" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    ZLog(@"%@",self.dicOrder);
    //购买商品的串
    NSArray *tempArr = [self.dicOrder objectForKey:@"goodsDetail"];
    NSString *buyStr = [NSString string];
    for(int i = 0; i < tempArr.count; i++){
        buyStr = [buyStr stringByAppendingString:[NSString stringWithFormat:@"%@-%@,", [[tempArr objectAtIndex:i] objectForKey:@"goodsid"], [[tempArr objectAtIndex:i] objectForKey:@"goodsnum"]]];
    }
    if([[buyStr substringFromIndex:(buyStr.length-1)] isEqualToString:@","])
        buyStr = [buyStr substringToIndex:(buyStr.length - 1)];
    
    [dicContent setObject:[[self.dicOrder objectForKey:@"num"] objectForKey:@"num"] forKey:@"num"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            [self showAlert:nil withTitle:@"删除成功" haveCancelButton:NO];
#warning 订单
//            MyAppDelegate.isdel = YES;
            [self .navigationController popViewControllerAnimated:YES];
        }
    }];
}

- (IBAction)closeBil:(id)sender{
    [bilView setHidden:YES];
}

@end
