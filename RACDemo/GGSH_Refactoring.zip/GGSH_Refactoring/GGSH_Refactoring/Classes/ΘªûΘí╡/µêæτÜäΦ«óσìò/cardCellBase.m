//
//  cardCellBase.m
//  GGSH
//
//  Created by huadong on 16/1/6.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "cardCellBase.h"

@interface cardCellBase ()
{
    
    IBOutlet UITableView *_iTableView;
    
    //卡密信息
    NSDictionary * _dicECardInfo;
    NSMutableArray *_dataArray;
    
    NSString *isCheck;
    NSInteger _index;
}
@end

@implementation cardCellBase

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _iTableView.scrollEnabled = NO;
    
}

+(double)getHeight:(NSDictionary *)dicInfo{
    
    NSString *isCheck = [dicInfo objectForKey:@"ischeck"];
    NSArray *arr = [dicInfo objectForKey:@"detail"];
    if ([isCheck isEqualToString:@"1"]) {
        return 93 + 76 * arr.count;
    }else{
        return 124;
    }
}

-(void)loadData:(NSDictionary *)dicInfo withIndex:(NSInteger)index{
    _index = index;
    _dicECardInfo = dicInfo;
    _dataArray = [dicInfo objectForKey:@"detail"];
    isCheck = [dicInfo objectForKey:@"ischeck"];
    
    
    [_iTableView reloadData];
}

#pragma mark - tableView
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([isCheck isEqualToString:@"0"]) {
        return 2;
    }else{
        return _dataArray.count + 1;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return 93;
    }else{
        if ([isCheck isEqualToString:@"1"]) {
            return 76;
        }else{
            return 31;
        }
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        NSDictionary * dic = _dicECardInfo;
        
        static NSString *CellIdentifier = @"COMMONCELL";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.clipsToBounds = YES;
            
            //背景
            UIImageView * cellImage = [[UIImageView alloc] init];
            cellImage.tag = 111;
            cellImage.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:cellImage];
            cellImage.frame = CGRectMake(10, 10, _iTableView.frame.size.width - 20, 83);
            
            //标题
            UILabel * lbTitle1 = [[UILabel alloc] init];
            lbTitle1.tag = 101;
            lbTitle1.backgroundColor = [UIColor clearColor];
            lbTitle1.font = [UIFont systemFontOfSize:12];
            lbTitle1.textColor = [UIColor whiteColor];
            [cell.contentView addSubview:lbTitle1];
            lbTitle1.frame = CGRectMake(20, 20, 200, 12 );
            lbTitle1.text = @"逛逛生活-生活服务";
            
            //提示标识
            UIImageView *imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(12, 11, 9, 9)];
            [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
            [imageAlert setTag:1011];
            [cell.contentView addSubview:imageAlert];
            
            if ([dic objectForKey:@"isread"] && [[dic objectForKey:@"isread"] integerValue] != 1) {
                [imageAlert setHidden:NO];
            }else{
                [imageAlert setHidden:YES];
                
            }
            
            //时间
            UILabel * lbTime = [[UILabel alloc] init];
            lbTime.tag = 102;
            lbTime.textAlignment = NSTextAlignmentRight;
            lbTime.backgroundColor = [UIColor clearColor];
            lbTime.font = [UIFont systemFontOfSize:12];
            lbTime.textColor = [UIColor blackColor];
            lbTime.alpha = 0.5f;
            [cell.contentView addSubview:lbTime];
            lbTime.frame = CGRectMake(self.view.frame.size.width - 120, 20, 100, 12);
            NSString * strTime = [dic objectForKey:@"time" ];
            if (strTime == nil) {
                lbTime.text = @"";
            }
            else{
                
                lbTime.text = strTime;
                
            }
            
            //类型
            UILabel * lbType = [[UILabel alloc] init];
            lbType.tag = 104;
            lbType.backgroundColor = [UIColor clearColor];
            lbType.font = [UIFont systemFontOfSize:12];
            lbType.textColor = [UIColor blackColor];
            lbType.alpha = 0.5f;
            lbType.textAlignment = NSTextAlignmentRight;
            [cell.contentView addSubview:lbType];
            lbType.frame = CGRectMake(20, 38, _iTableView.frame.size.width - 40, 12 );
            lbType.text = @"店铺赠送";
            
            //摘要
            UILabel * lbContent = [[UILabel alloc] init];
            lbContent.tag = 103;
            lbContent.backgroundColor = [UIColor clearColor];
            lbContent.font = [UIFont systemFontOfSize:15];
            lbContent.textColor = [UIColor whiteColor];
            [cell.contentView addSubview:lbContent];
            lbContent.frame = CGRectMake(20, 62, _iTableView.frame.size.width - 40, 15 );
            lbContent.text = @"京东限量电子卡券";
            
        }
        
        //背景和是否显示店铺类型
        UIImageView * cellImage = (UIImageView*)[cell.contentView viewWithTag:111];
        UILabel * lbType = (UILabel*)[cell.contentView viewWithTag:104];
        
        NSString *source = [dic objectForKey:@"source"];
        NSString *channel = [dic objectForKey:@"channel"];
        UILabel *lbTitle1 = (UILabel *)[cell.contentView viewWithTag:101];
        
        
        [cellImage setImage:[UIImage imageNamed:@"kami_1.png"]];
        
        lbTitle1.text = [dic objectForKey:@"source_name"];
        //来源，0是逛逛生活，大于0是店铺
        if ([source integerValue] == 0) {
            [lbType setHidden:YES];
        }else{
            //是否店铺赠送，1购买 2赠送
            if ([channel integerValue] == 1) {
                [lbType setHidden:YES];
            }else if ([channel integerValue] == 2){
                [lbType setHidden:NO];
            }
            
        }
        
        //未读提示
        UIImageView *imageAlert = (UIImageView *)[cell.contentView viewWithTag:1011];
        if ([dic objectForKey:@"isread"] && [[dic objectForKey:@"isread"] integerValue] != 1) {
            [imageAlert setHidden:NO];
        }else{
            [imageAlert setHidden:YES];
            
        }
        
        //标题
        UILabel *lbContent = (UILabel *)[cell.contentView viewWithTag:103];
        lbContent.text = [dic objectForKey:@"cardname"];
        
        //时间
        UILabel * lbTime = (UILabel*)[cell.contentView viewWithTag:102];
        NSString * dateStr = [dic objectForKey:@"ctime" ];
        if (dateStr == nil) {
            lbTime.text = @"";
            
        }else{
            
            NSDate *date = [NSDate dateWithTimeIntervalSince1970:[dateStr integerValue]];
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            NSString *time = [dateFormatter stringFromDate:date];
            if(time.length > 10){
                time = [time substringToIndex:10];
            }
            
            lbTime.text = time;
            
        }
        
        return cell;
        
    }else{
        
        if ([isCheck isEqualToString:@"1"]) {
            NSDictionary * dicMessage = [_dataArray objectAtIndex:indexPath.row-1];
            
            static NSString *CellIdentifier = @"COMMONCELL1";
            
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil)
            {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                cell.backgroundColor = [UIColor clearColor];
                cell.contentView.backgroundColor = [UIColor clearColor];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                cell.contentView.clipsToBounds = YES;
                
                //背景
                UIImageView * cellImage = [[UIImageView alloc] init];
                cellImage.tag = 211;
                cellImage.backgroundColor = [UIColor clearColor];
                [cell.contentView addSubview:cellImage];
                cellImage.frame = CGRectMake(10, 0, _iTableView.frame.size.width - 20, 76);
                
                //标题
                UILabel * lbTitle1 = [[UILabel alloc] init];
                lbTitle1.tag = 201;
                lbTitle1.backgroundColor = [UIColor clearColor];
                lbTitle1.font = [UIFont systemFontOfSize:12];
                lbTitle1.textColor = [UIColor colorWithHexString:@"#636363"];
                [cell.contentView addSubview:lbTitle1];
                lbTitle1.frame = CGRectMake(20, 10, _iTableView.frame.size.width - 40, 12 );
                lbTitle1.text = @"卡号：";
                
                //密码
                UILabel * lbTitle2 = [[UILabel alloc] init];
                lbTitle2.tag = 202;
                lbTitle2.backgroundColor = [UIColor clearColor];
                lbTitle2.font = [UIFont systemFontOfSize:12];
                lbTitle2.textColor = [UIColor colorWithHexString:@"#636363"];
                [cell.contentView addSubview:lbTitle2];
                lbTitle2.frame = CGRectMake(20, 32, _iTableView.frame.size.width - 40, 12 );
                lbTitle2.text = @"密码：";
                
                //有效期
                UILabel * lbTitle3 = [[UILabel alloc] init];
                lbTitle3.tag = 203;
                lbTitle3.backgroundColor = [UIColor clearColor];
                lbTitle3.font = [UIFont systemFontOfSize:12];
                lbTitle3.textColor = [UIColor colorWithHexString:@"#636363"];
                [cell.contentView addSubview:lbTitle3];
                lbTitle3.frame = CGRectMake(20, 54, _iTableView.frame.size.width - 40, 12 );
                lbTitle3.text = @"有效期至：";
                
                //line
                UIImageView * cellLine = [[UIImageView alloc] init];
                cellLine.tag = 221;
                cellLine.backgroundColor = [UIColor clearColor];
                cellLine.image = [UIImage imageNamed:@"kami_line.png"];
                [cell.contentView addSubview:cellLine];
                cellLine.frame = CGRectMake(22, 75, _iTableView.frame.size.width - 44, 0.5 );
            }
            
            //背景
            UIImageView * cellImage = (UIImageView*)[cell.contentView viewWithTag:211];
            //line
            UIImageView * cellLine = (UIImageView*)[cell.contentView viewWithTag:221];
            if (indexPath.row == _dataArray.count) {
                UIImage *image = [UIImage imageNamed:@"kami_bottom.png"];
                UIEdgeInsets insets = UIEdgeInsetsMake(0, 0, 8, 0);
                image = [image resizableImageWithCapInsets:insets resizingMode:UIImageResizingModeStretch];
                cellImage.image = image;
                
                [cellLine setHidden:YES];
                
            }else{
                UIImage *image = [UIImage imageNamed:@"kami_middle.png"];
                UIEdgeInsets insets = UIEdgeInsetsMake(0, 0, 8, 0);
                image = [image resizableImageWithCapInsets:insets resizingMode:UIImageResizingModeStretch];
                cellImage.image = image;
                
                [cellLine setHidden:NO];
            }
            //卡号
            UILabel * lbTitle1 = (UILabel*)[cell.contentView viewWithTag:201];
            NSString *sequence_no;
            if ([dicMessage objectForKey:@"sequence_no"]) {
                sequence_no = [dicMessage objectForKey:@"sequence_no"];
            }else{
                sequence_no = @"";
            }
            lbTitle1.text = [NSString stringWithFormat:@"卡号：%@",sequence_no];
            
            //密码
            UILabel * lbTitle2 = (UILabel*)[cell.contentView viewWithTag:202];
            NSString *activation_code;
            if ([dicMessage objectForKey:@"activation_code"]) {
                activation_code = [dicMessage objectForKey:@"activation_code"];
            }else{
                activation_code = @"";
            }
            lbTitle2.text = [NSString stringWithFormat:@"密码：%@",activation_code];
            
            //有效期
            UILabel * lbTitle3 = (UILabel*)[cell.contentView viewWithTag:203];
            NSString *validity_time;
            if ([dicMessage objectForKey:@"validity_time"]) {
                NSString *timeStr = [dicMessage objectForKey:@"validity_time"];
                if ([timeStr integerValue] > 0) {
                    NSDate *date = [NSDate dateWithTimeIntervalSince1970:[timeStr integerValue]];
                    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                    validity_time = [dateFormatter stringFromDate:date];
                    if(validity_time.length > 10){
                        validity_time = [validity_time substringToIndex:10];
                    }
                }else{
                    validity_time = @"";
                }
            }else{
                validity_time = @"";
            }
            
            lbTitle3.text = [NSString stringWithFormat:@"有效期至：%@",validity_time];
            
            return cell;
            
        }else{
            
            static NSString *CellIdentifier = @"COMMONCELL0";
            
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil)
            {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                cell.backgroundColor = [UIColor clearColor];
                cell.contentView.backgroundColor = [UIColor clearColor];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                cell.contentView.clipsToBounds = YES;
                
                //背景
                UIImageView * cellImage = [[UIImageView alloc] init];
                cellImage.tag = 311;
                cellImage.backgroundColor = [UIColor clearColor];
                [cell.contentView addSubview:cellImage];
                cellImage.frame = CGRectMake(10, 0, _iTableView.frame.size.width - 20, 31);
                
                //标题
                UILabel * lbTitle = [[UILabel alloc] init];
                lbTitle.tag = 301;
                lbTitle.backgroundColor = [UIColor clearColor];
                lbTitle.font = [UIFont systemFontOfSize:11];
                lbTitle.textColor = [UIColor colorWithHexString:@"#d2016e"];
                lbTitle.textAlignment = NSTextAlignmentCenter;
                [cell.contentView addSubview:lbTitle];
                lbTitle.frame = CGRectMake(0, 8, _iTableView.frame.size.width, 11 );
                lbTitle.text = @"查看卡密";
                
                
            }
            
            //背景
            UIImageView * cellImage = (UIImageView*)[cell.contentView viewWithTag:311];
            UIImage *image = [UIImage imageNamed:@"kami_bottom.png"];
            UIEdgeInsets insets = UIEdgeInsetsMake(0, 0, 8, 0);
            image = [image resizableImageWithCapInsets:insets resizingMode:UIImageResizingModeStretch];
            cellImage.image = image;
            
            //标题
            UILabel * lbTitle = (UILabel*)[cell.contentView viewWithTag:301];
            lbTitle.text = @"查看卡密";
            
            
            return cell;
        }
        
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.delegate respondsToSelector:@selector(changeCheck:withIndex:)]) {
        if ([isCheck isEqualToString:@"1"]) {
            [self.delegate changeCheck:@"0" withIndex:_index];
        }else{
            [self.delegate changeCheck:@"1" withIndex:_index];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
