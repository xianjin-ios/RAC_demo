//
//  cardVC.m
//  GGSH
//
//  Created by huadong on 16/1/6.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "cardVC.h"
#import "ProductOrderBaseCell.h"
#import "cardCellBase.h"

@interface cardVC ()<CHECKDETAIL,MJRefreshBaseViewDelegate>
{
    IBOutlet UITableView *_iTableView;
    
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;

    
    UIView *noView;
    
    NSMutableArray *ecardArray;
    
    NSDate *date;
    NSMutableArray *_dataArray;
}
@end

@implementation cardVC

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我收到的电子卡密";
    
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _iTableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _iTableView;
    _footer.delegate = self;

    [MyAppDelegate getNoReadInfo];
    
    ecardArray = [[NSMutableArray alloc]init];
    [self getListFromServerWithIndex:1];
    
}

#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(refreshView == _header) {// 下拉刷新
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        //5秒内不能重复发起网络请求，只是界面上闪动下正在加载，就1s。
        if(date){
            NSDate *tenMiniteLater = [date dateByAddingTimeInterval:5];
            NSDate *currentDate = [NSDate date];
            if(NSOrderedDescending == [tenMiniteLater compare:currentDate]){
                ZLog(@"ascending");
                date = [NSDate date];
                [self performSelector:@selector(OneSecondElapse) withObject:nil afterDelay:1];
                [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
                return;
            }
            
            //网络请求
            [self getListFromServerWithIndex:1];
            
        }else{
            date = [NSDate date];
            //网络请求
            [self getListFromServerWithIndex:1];
            
        }
        
    }else if (refreshView == _footer){//上拉加载更多
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        if (ecardArray.count % 20 == 0) {
            NSInteger Index = ecardArray.count / 20 + 1;
            [self getListFromServerWithIndex:Index];
        }
        
    }
    
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];

}

//1s的假loading，取消正在加载就好
- (void)OneSecondElapse{
    [self hideHUD];
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

#pragma mark - 网络请求 获取卡密列表
- (void)getListFromServerWithIndex:(NSInteger)index{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Coupon" forKey:@"Mod"];
    [dic setObject:@"myEcpcard" forKey:@"Act"];
    
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];//54688
        [dicContent setObject:@"" forKey:@"logintoken"];//5db9314fa8e005d0a2105e827f93beff2c43e3f685077b24
    }
    [dicContent setObject:[NSNumber numberWithInteger:index] forKey:@"pageindex"];
    [dicContent setObject:[NSNumber numberWithInteger:20] forKey:@"pagesize"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dic setObject:dicContent forKey:@"Content"];
    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if(index == 1){
            [_dataArray removeAllObjects];
        }
        
        if([resultDic objectForKey:@"DetailInfo"] && [[resultDic objectForKey:@"DetailInfo"] isKindOfClass:[NSArray class]]){
            
            if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
                if (index == 1) {
                    _dataArray = [[resultDic objectForKey:@"DetailInfo"] mutableCopy];
                }else{
                    NSMutableArray *arr = [[resultDic objectForKey:@"DetailInfo"] mutableCopy];
                    [_dataArray addObjectsFromArray:arr];
                }
                
                [self makeECardInfo];
                
            }else{
                
                [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
                
            }
            
        }
        
        if (_dataArray.count == 0) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [_iTableView addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
    }];
}

- (void)makeECardInfo{
    [ecardArray removeAllObjects];
    ecardArray = [_dataArray mutableCopy];
    for (int i = 0; i < _dataArray.count; i ++) {
        NSMutableDictionary *dic = [[_dataArray objectAtIndex:i] mutableCopy];
        [dic setObject:@"0" forKey:@"ischeck"];
        [ecardArray replaceObjectAtIndex:i withObject:dic];
    }
    
    [_iTableView reloadData];
}

#pragma mark - tableView
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return ecardArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dicOrder = [ecardArray objectAtIndex:indexPath.row];
    
    return [cardCellBase getHeight:dicOrder];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //翻页CELL
    static NSString *CellIdentifier = @"COMMONCELL";
    
    ProductOrderBaseCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[ProductOrderBaseCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor colorWithHexString:@"#F8F8F8"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        //添加自定义View
        cardCellBase * ctrl = [[cardCellBase alloc] init];
        ctrl.delegate = self;
        ctrl.view.autoresizingMask = UIViewAutoresizingNone;
        ctrl.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, cell.frame.size.height);
        [cell.contentView addSubview:ctrl.view];
        
        cell.ctrl = ctrl;
        ctrl.navigationController = self.navigationController;
        
    }
    
    NSDictionary * dic = [ecardArray objectAtIndex:indexPath.row];
    cardCellBase * bb = (cardCellBase*)cell.ctrl;
    int height = [cardCellBase getHeight:dic];
    bb.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, height);
    [bb loadData:dic withIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
}

-(void)changeCheck:(NSString *)check withIndex:(NSInteger)index{
    NSMutableArray *tempArr = [ecardArray mutableCopy];
    for (int i = 0; i < tempArr.count; i ++) {
        if (i == index) {
            NSMutableDictionary *dic = [[tempArr objectAtIndex:i] mutableCopy];
            [dic setObject:check forKey:@"ischeck"];
            [dic setObject:@"1" forKey:@"isread"];
            [ecardArray replaceObjectAtIndex:i withObject:dic];
        }else{
            NSMutableDictionary *dic = [[tempArr objectAtIndex:i] mutableCopy];
            [dic setObject:@"0" forKey:@"ischeck"];
            [ecardArray replaceObjectAtIndex:i withObject:dic];

        }
    }
    
    [_iTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
