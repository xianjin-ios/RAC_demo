//
//  oneOrderVC.h
//  GGSH
//  我的订单-一个订单， CELL
//  Created by 任春宁 on 15/3/18.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol toDetailDelegate <NSObject>

- (void)gotoDetail:(NSInteger)index;

@end
@interface oneOrderVC : UIViewController<UITableViewDataSource, UITabBarDelegate>{
    
    IBOutlet UITableView * _tableView;
    
    //商品列表
    NSMutableArray * _arrProductList;
    
    id<toDetailDelegate> _toDelegate;
}

@property (nonatomic,strong) id<toDetailDelegate> toDelegate;

//订单数据
@property (nonatomic, strong) NSDictionary * dicOrder;

//数据索引
@property (nonatomic, assign) int index;

//计算cell的高度
+(int)getheight:(NSDictionary *)dicOrder;

@end
