//
//  GGCouponListViewController.h
//  GGSH
//
//  Created by siqiyang on 16/3/22.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface GGCouponListViewController : BaseViewController

@property (retain, nonatomic) IBOutlet UITableView *ggCouponListTableView;

@property (nonatomic,strong) UIView *noView;

@end
