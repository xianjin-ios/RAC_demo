//
//  mySubOrderVC.h
//  GGSH
//
//  Created by yanli on 16/10/25.
//  Copyright © 2016年 YL. All rights reserved.
//

#import "BaseVCWithPay.h"

@interface mySubOrderVC : BaseVCWithPay

@property (nonatomic, strong) NSString *ordertype;
@property (nonatomic,strong) NSDictionary *orderDic;


//设置需要刷新后，viewWillAppear 会重新拉取数据
- (void)setNeedRefresh : (BOOL) bRefresh;

@end
