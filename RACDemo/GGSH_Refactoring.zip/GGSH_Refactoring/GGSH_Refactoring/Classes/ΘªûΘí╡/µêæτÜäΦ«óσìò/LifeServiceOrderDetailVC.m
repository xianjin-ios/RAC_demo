//
//  LifeServiceOrderDetailVC.m
//  GGSH
//
//  Created by STAR on 15/10/12.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "LifeServiceOrderDetailVC.h"
#import "PayResultVC.h"
#import "UPPayPlugin.h"
#import "UPPayPluginDelegate.h"
#import "LineView.h"
#import "BookSuccessViewController.h"

@interface LifeServiceOrderDetailVC ()<UPPayPluginDelegate>
{
    IBOutlet UIScrollView *_scrollview;
    
    //网络返回的详情
    NSDictionary *dicGood;
    
    IBOutlet UILabel *_lbNum;
    
    IBOutlet UIView *_vIconBg;
    IBOutlet UIImageView *_imgIcon;
}
@property (nonatomic, strong) IBOutlet UILabel *lbOrderNum; /**< 编号 */
@property (nonatomic, strong) IBOutlet UILabel *lbPhoneNum; /**< 手机号 */
@property (nonatomic, strong) IBOutlet UILabel *lbPayWay; /**< 支付方式 */
@property (nonatomic, strong) IBOutlet UILabel *lbStatus; /**< 编号 */
@property (nonatomic, strong) IBOutlet UILabel *lbName; /**< 名称 */
@property (nonatomic, strong) IBOutlet UILabel *lbMoney; /**< 单价 */
@property (nonatomic, strong) IBOutlet UILabel *lbMoneyTotle; /**< 商品总额 */
@property (nonatomic, strong) IBOutlet UILabel *lbMoneyPay; /**< 实际支付 */


@property (nonatomic, strong) IBOutlet UILabel *lbOrderTime; /**< 下单时间 */
@end

@implementation LifeServiceOrderDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"订单详情";
    [self performSelector:@selector(getOrderDetail) withObject:nil afterDelay:0.1];
}

//京东E卡订单和爱奇艺没有充值手机号字段
- (void)setViewStype{
    _vIconBg.backgroundColor = [UIColor clearColor];
    _vIconBg.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _vIconBg.layer.borderWidth = ONEPIXL;

    [_imgIcon XK_setImageWithURL:[NSURL URLWithString:[self.dicData objectForKey:@"listpic"]] placeholderImage:nil];
    UIView *topView = (UIView *)[self.view viewWithTag:1101];
    topView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 80);
    [topView viewWithTag:1111].hidden = YES;
    [topView viewWithTag:1112].hidden = YES;
    [topView viewWithTag:1113].hidden = YES;
    [topView viewWithTag:1114].frame = CGRectOffset([topView viewWithTag:1114].frame, 0, -40);
    [topView viewWithTag:1115].frame = CGRectOffset([topView viewWithTag:1115].frame, 0, -40);
    
    [self.view viewWithTag:1102].frame = CGRectOffset([self.view viewWithTag:1102].frame, 0, -50);
    
    UIView *bottomView = (UIView *)[self.view viewWithTag:1103];
    bottomView.frame = CGRectOffset(bottomView.frame, 0, -60);
    bottomView.frame = CGRectMake(0, bottomView.frame.origin.y, SCREEN_WIDTH, bottomView.frame.size.height + 65);
    LineView *lineView = [[LineView alloc] initWithFrame:CGRectMake(0, 40, SCREEN_WIDTH, 1)];
    lineView.backgroundColor = [UIColor clearColor];
    [bottomView addSubview:lineView];
    
    UILabel *lbComment = [[UILabel alloc] initWithFrame:CGRectMake(20, 50, 60, 20)];
    [bottomView addSubview:lbComment];
    lbComment.text = @"备注说明";
    lbComment.font = [UIFont systemFontOfSize:13];
    
    UILabel *lbCommentText  = [[UILabel alloc] initWithFrame:CGRectMake(90, 45, SCREEN_WIDTH - 90, 55)];
    lbCommentText.tag = 2001;
    [bottomView addSubview:lbCommentText];
    lbCommentText.numberOfLines = 3;
    lbCommentText.font = [UIFont systemFontOfSize:13];
    lbCommentText.text = @"";

}

- (void)getOrderDetail{
    //设置京东E卡、爱奇艺的显示样式
    if(![[self.dicData objectForKey:@"order_sub_type"] isEqualToString:@"1"]){
        [self setViewStype];
    }
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"userOrder" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:[self.dicData objectForKey:@"id"] forKey:@"pid"];
    [dicContent setObject:[self.dicData objectForKey:@"num"] forKey:@"num"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    [self showHUD];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        [self hideHUD];
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            //设置显示参数
            //话费只有1件商品
            dicGood = [[[[resultDic objectForKey:@"DetailInfo"]objectForKey:@"goodsDetail"] objectAtIndex:0] copy];
            NSDictionary *payDic = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"payInfo"];
            
            [self loadDetailViewWithPayInfo:payDic];
            
        }
        
    }];
}

- (void)loadDetailViewWithPayInfo:(NSDictionary *)payDic{
    self.lbOrderNum.text = [payDic objectForKey:@"num"];
    self.lbPhoneNum.text = [payDic objectForKey:@"ecp_ext"];
    _lbNum.text = [NSString stringWithFormat:@"x%@",[dicGood objectForKey:@"goodsnum"] ];
    
    NSArray *tempArr = [payDic objectForKey:@"payway_list"];
    if (tempArr.count > 0) {
        self.lbPayWay.text = [[tempArr objectAtIndex:0] objectForKey:@"payway"];
    }else{
        //支付方式 1Mpos,2支付宝,3银联
        if ([[payDic objectForKey:@"payway"] isEqualToString:@"3"]) {
            self.lbPayWay.text = @"银联";
        }else if ([[payDic objectForKey:@"payway"] isEqualToString:@"2"]){
            self.lbPayWay.text = @"支付宝";

        }else if ([[payDic objectForKey:@"payway"] isEqualToString:@"1"]){
            self.lbPayWay.text = @"MPOS";

        }
        else if ([[payDic objectForKey:@"payway"] isEqualToString:@"6"])
            self.lbPayWay.text = @"微信支付";
    }
    
    if([[payDic objectForKey:@"tradestatus"] isEqualToString:@"1"]){
        self.lbStatus.text = @"待付款";
        self.lbStatus.textColor = [UIColor orangeColor];
    }else if([[payDic objectForKey:@"tradestatus"] isEqualToString:@"2"]){
        self.lbStatus.text = @"支付失败";
    }else if([[payDic objectForKey:@"tradestatus"] isEqualToString:@"3"]){
        self.lbStatus.text = @"已完成";
        NSString *ordersubtype = [self.dicData objectForKey:@"order_sub_type"];
        if(![ordersubtype isEqualToString:@"1"]){
            //除了话费订单，都是分发货状态的
            if([[payDic objectForKey:@"shipping_status"] isEqualToString:@"0"] ||
               [[payDic objectForKey:@"shipping_status"] isEqualToString:@"3"]){
                self.lbStatus.text = @"备货中";
            }else if([[payDic objectForKey:@"shipping_status"] isEqualToString:@"1"]||
                     [[payDic objectForKey:@"shipping_status"] isEqualToString:@"2"]){
                self.lbStatus.text = @"发货成功";
            }else if([[payDic objectForKey:@"shipping_status"] isEqualToString:@"4"]){
                self.lbStatus.text = @"发货失败";
            }
        }
    }
    
    self.lbName.text = [dicGood objectForKey:@"goodsname"];
    self.lbMoney.text = [NSString stringWithFormat:@"¥%.2f", ((NSString*)[dicGood objectForKey:@"goodsprice"]).intValue/100.0f];
    self.lbMoneyTotle.text = [NSString stringWithFormat:@"¥%.2f", ((NSString*)[dicGood objectForKey:@"sunmprice"]).intValue/100.0f];
    self.lbMoneyPay.text = [NSString stringWithFormat:@"¥%.2f", ((NSString*)[payDic objectForKey:@"paymoney"]).intValue/100.0f];
    
    //时间
    self.lbOrderTime.text = [payDic objectForKey:@"ctime"];
    
    //备注说明，只有京东E卡和爱奇艺有
    UILabel *lbComment = [self.view viewWithTag:2001];
    if(lbComment){
        lbComment.text = @"购买的商品将以电子卡密的形式发送到“我的卡券\\我收到的电子卡密“中，请注意查看。";//[payDic objectForKey:@"remark"];
    }
    
    if([[payDic objectForKey:@"tradestatus"] isEqualToString:@"1"]){
        
        UIView *downView = [[UIView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 50 - 64, SCREEN_WIDTH, 50)];
        [downView setBackgroundColor:[UIColor whiteColor]];
        [_scrollview addSubview:downView];
        
        LineView *downLine = [[LineView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 0.5)];
        downLine.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
        [downView addSubview:downLine];
        
        //支付按钮
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setFrame:CGRectMake(SCREEN_WIDTH/2, 0, SCREEN_WIDTH/2, 50)];
        [btn setBackgroundColor:[UIColor colorWithHexString:@"#ff0084"]];
        [btn setTitle:@"立即支付" forState:UIControlStateNormal];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:15]];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(confirm:) forControlEvents:UIControlEventTouchUpInside];
        [downView addSubview:btn];
        
        //取消订单按钮
        UIButton *btnCancel = [UIButton buttonWithType:UIButtonTypeCustom];
        [btnCancel setFrame:CGRectMake(0, 0, SCREEN_WIDTH/2, 50)];
        [btnCancel setBackgroundColor:[UIColor colorWithHexString:@"#848484"]];
        [btnCancel setTitle:@"取消订单" forState:UIControlStateNormal];
        [btnCancel.titleLabel setFont:[UIFont systemFontOfSize:15]];
        [btnCancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btnCancel addTarget:self action:@selector(cancelOrder:) forControlEvents:UIControlEventTouchUpInside];
        [downView addSubview:btnCancel];
    }
}

//取消订单
- (void)cancelOrder : (NSString*)str{
    [self showHUD];
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Porder" forKey:@"Mod"];
    [dic setObject:@"userCancelEcpOrder" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
        
    }
    [dicContent setObject:[self.dicData objectForKey:@"num"] forKey:@"num"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dic setObject:dicContent forKey:@"Content"];
    
    
    [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            [[NSNotificationCenter defaultCenter]postNotificationName:@"RefreshProductionList" object:[NSString stringWithFormat:@"%ld",(long)self.indexRow]];
            [self.navigationController popViewControllerAnimated:YES];
        }
        
    }];
}

- (void)confirm:(UIButton *)sender{
    if (self.dicData != nil) {
        if ([[self.dicData objectForKey:@"payway"]isEqualToString:@"6"])
        {
            
            if (MyAppDelegate.isCharging == YES) {
                return;
            }
            //判断用户是否安装了微信
            if ([WXApi isWXAppInstalled]) {
                //微信支付
                [self payOnlineByWX:self.dicData withBrandCode:_brandCode];
            }else{
                [self showAlert:nil withTitle:@"尚未安装微信" haveCancelButton:NO];
            }
        }else{
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.dicData];
            [dic setObject:[self.dicData objectForKey:@"goodsname"] forKey:@"product_name"];
            [dic setObject:_brandCode forKey:@"brand_code"];
            [self payEcpWith:dic];
        }
    }
}

#pragma mark - 支付delegate
- (void)UPPayPluginResult:(NSString *)result
{
    if ([result isEqualToString:@"fail"]) {
        ZLog(@"%@失败",result);
        [self showAlert:nil withTitle:@"订单支付未完成，请重新支付" haveCancelButton:NO];
        //返回主页
        [self backToHome];
        
    }else if ([result isEqualToString:@"success"]){
        ZLog(@"%@成功",result);
        
        [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
        NSString *type = [self.dicData objectForKey:@"order_sub_type"];
        if([type isEqualToString:@"1"]){
            //支付类 新增结果页面,话费类
            PayResultVC *ctrl = [[PayResultVC alloc]init];
            ctrl.hideBackButton = YES;
            [self.navigationController pushViewController:ctrl animated:YES];
            
        }
        else if([type isEqualToString:@"2"]||[type isEqualToString:@"3"]||[type isEqualToString:@"4"]) {//卡密类暂时只有京东、爱奇艺、逛逛礼品卡
            //新增结果页面
            BookSuccessViewController  *ctrl = [[BookSuccessViewController alloc]init];
            ctrl.hideBackButton = YES;
            [self.navigationController pushViewController:ctrl animated:YES];
        }
        else{
            //未知类型
        }
        
    }else if ([result isEqualToString:@"cancel"]){
        ZLog(@"%@取消订单",result);
        [self showAlert:nil withTitle:@"订单支付未完成，请重新支付" haveCancelButton:NO];
        
    }
    
}



@end
