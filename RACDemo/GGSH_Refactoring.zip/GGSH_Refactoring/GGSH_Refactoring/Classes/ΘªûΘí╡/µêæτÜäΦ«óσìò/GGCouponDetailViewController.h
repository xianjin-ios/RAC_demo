//
//  GGCouponDetailViewController.h
//  GGSH
//
//  Created by siqiyang on 16/10/25.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface GGCouponDetailViewController : BaseViewController

@property (retain, nonatomic) UITableView *couponTableView;

@property (nonatomic,strong) NSString *couponId;//优惠券id

@property (nonatomic,copy) NSMutableDictionary *ggCouponInfo;

@end
