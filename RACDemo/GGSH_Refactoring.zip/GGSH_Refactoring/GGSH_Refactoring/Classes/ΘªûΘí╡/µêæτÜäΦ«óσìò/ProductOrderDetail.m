//
//  ProductOrderDetail.m
//  GGSH
//  订单详情
//  Created by 任春宁 on 15/7/4.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "ProductOrderDetail.h"
#import "orderResultViewController.h"

@interface ProductOrderDetail ()
{
}

@end

@implementation ProductOrderDetail

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"订单详情";
    
    [self getOrderData];
    
    //初始化界面效果
    [self initViewEffect];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_ORDERDETAIL_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_ORDERDETAIL_VIEW"];
    
}

-(void)initViewEffect{
    
    //加边线
    _vProductList.layer.borderColor = [UIColor colorWithHexString:@"#dfdfdf"].CGColor;
    _vProductList.layer.borderWidth = 0.5f;
    
    _vPayInfo.layer.borderColor = [UIColor colorWithHexString:@"#dfdfdf"].CGColor;
    _vPayInfo.layer.borderWidth = 0.5f;
    
    _vOrder.layer.borderColor = [UIColor colorWithHexString:@"#dfdfdf"].CGColor;
    _vOrder.layer.borderWidth = 0.5f;
    
    
    _vOrderHeader.view.layer.borderColor = [UIColor colorWithHexString:@"#dfdfdf"].CGColor;
    _vOrderHeader.view.layer.borderWidth = 0.5f;
    
    //
    
    
    _vBarcodeContainer.layer.borderColor = [UIColor colorWithHexString:@"#dfdfdf"].CGColor;
    _vBarcodeContainer.layer.borderWidth = 0.5f;
    
    _scrollViewMain.contentSize = CGSizeMake(SCREEN_WIDTH, 600);
    
}


#pragma mark - 获取订单详情

-(void)getOrderData{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"userOrder" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:[[self.dicOrderInfo objectForKey:@"num"] objectForKey:@"id"] forKey:@"pid"];
    
    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            _dicOrderDetail = [resultDic objectForKey:@"DetailInfo"];
            
            [self refresh];
        }
    }];
}

//刷新界面数据
-(void)refresh{
    
    if (_dicOrderInfo == nil) {
        return;
    }
    
    NSDictionary * dicPayInfo = [_dicOrderDetail objectForKey:@"payInfo"];
    
    //已完成订单详情页中的立即预订、订单取消功能键不显示，待收货/待自取订单详情中的立即预订和订单取消功能键也不显示 BUG 0000564
    if ([self.payStatus isEqualToString:@"已完成"] || [self.payStatus isEqualToString:@"待收货"] || [self.payStatus isEqualToString:@"待自取"]) {
        _vBtnContainer.hidden = YES;
        
        _scrollViewMain.frame = CGRectMake(_scrollViewMain.frame.origin.x, _scrollViewMain.frame.origin.y, SCREEN_WIDTH, _scrollViewMain.frame.size.height + _vBtnContainer.frame.size.height);
    }
    
    //加载订单头视图
    if (_vOrderHeader == nil) {
        _vOrderHeader = [[orderHeaderVC alloc] init];
        _vOrderHeader.view.autoresizingMask = UIViewAutoresizingNone;
    }
    int topHeight = [orderHeaderVC getHeight:dicPayInfo];
    [_orderHeaderVC setFrame:CGRectMake(0, 0, SCREEN_WIDTH, topHeight)];
    
    //加载详情
    [_vOrderHeader loadData:dicPayInfo AndPayStatus:self.payStatus];

    _vOrderHeader.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, topHeight );
    [_orderHeaderVC addSubview:_vOrderHeader.view];
    
    //显示商品列表
    if (_productVC == nil) {
        _productVC = [[ProductOrderBaseVC alloc] init];
        _productVC.view.autoresizingMask = UIViewAutoresizingNone;
        _productVC.navigationController = self.navigationController;
        [_productVC hideChatButtton:NO];
        [_productVC setHideBuyView:NO];
    }
    
    int height = [ProductOrderBaseVC getHeight:_dicOrderDetail];
    _vProductList.frame = CGRectMake(0, topHeight+5, SCREEN_WIDTH, height - 60);
    
    ZLog(@"%@",_dicOrderDetail);
    [_productVC loadData:_dicOrderDetail];
    
    _productVC.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, height);
    [_vProductList addSubview:_productVC.view];
    
    [self adjustViewFrame];
    
    //商品总额
    NSString * strPayMoney = [dicPayInfo objectForKey:@"selffee" ];
    float fPayMoney = [strPayMoney floatValue ] / 100.0;
    _lbPayMoney.text = [NSString stringWithFormat:@"￥%.2f", fPayMoney];
    
    //服务费
    NSString * strServiceFee = [dicPayInfo objectForKey:@"servicefee" ];
    float fServiceFee = [strServiceFee floatValue ] / 100.0;
    _lbServiceFee.text = [NSString stringWithFormat:@"￥%.2f", fServiceFee];
    
    //预付款金额
    NSString * strPrePay = [dicPayInfo objectForKey:@"prepay" ];
    float fPrePay = [strPrePay floatValue ] / 100.0;
    _lbPrePay.text = [NSString stringWithFormat:@"￥%.2f", fPrePay];
    
    //红包抵扣金额
    NSString * strCouponFee = [dicPayInfo objectForKey:@"couponfee" ];
    float fCouponFee = [strCouponFee floatValue ] / 100.0;
    _lbCoupon.text = [NSString stringWithFormat:@"￥%.2f", fCouponFee];
    
    //商品实付
    NSString * strShifu = [dicPayInfo objectForKey:@"paymoney" ];
    float fShifu = [strShifu floatValue ] / 100.0;
    _lbShifu.text = [NSString stringWithFormat:@"￥%.2f", fShifu];

    NSString *remarkStr = [dicPayInfo objectForKey:@"remark"];
    CGSize size = [remarkStr boundingRectWithSize:CGSizeMake(_lbRemark.frame.size.width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15]} context:nil].size;
    _lbRemark.numberOfLines = 0;
    _lbRemark.lineBreakMode = NSLineBreakByCharWrapping;
    [_lbRemark setFrame:CGRectMake(_lbRemark.frame.origin.x, _lbRemark.frame.origin.y, size.width, size.height)];
    _lbRemark.text = remarkStr;
    
    
    //下单时间
    NSString * strTime = [dicPayInfo objectForKey:@"ctime"];
    _lbTime.text = strTime;
    
    //显示二维码
    NSString * strBarcodeUrl = [dicPayInfo objectForKey:@"code"];
    if (strBarcodeUrl.length > 0) {
        [_imgViewBarcode XK_setImageWithURL:[NSURL URLWithString:strBarcodeUrl] placeholderImage:nil];
    }
    
}


//由于每个view的内容都可能发生变化，需要重新调整布局
-(void)adjustViewFrame{
    
    _vPayInfo.frame = CGRectMake(0, _vProductList.frame.origin.y + _vProductList.frame.size.height, SCREEN_WIDTH, _vPayInfo.frame.size.height);
    
    _vOrder.frame = CGRectMake(0, _vPayInfo.frame.origin.y + _vPayInfo.frame.size.height + 5, SCREEN_WIDTH, _vOrder.frame.size.height);
    
    _scrollViewMain.contentSize = CGSizeMake(SCREEN_WIDTH, _vOrder.frame.origin.y + _vOrder.frame.size.height );
    
    
    
}

//删除订单
- (IBAction)delBilBtn:(id)sender {
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Signedorder" forKey:@"Mod"];
    [dic setObject:@"Delorder" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
    }
    
    //获取订单号
    NSDictionary * dicPayInfo = [_dicOrderDetail objectForKey:@"payInfo"];
    
    [dicContent setObject:[dicPayInfo objectForKey:@"num"] forKey:@"num"];
    [dicContent setObject:[dicPayInfo objectForKey:@"shopid"] forKey:@"shopid"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    
    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            [self showalertString:@"取消成功"];
            MyAppDelegate.isdel = YES;
            [self .navigationController popViewControllerAnimated:YES];
        }
    }];
}

//支付预付款
- (IBAction)payBtn:(id)sender {
     if ([[[_dicOrderDetail objectForKey:@"payInfo"] objectForKey:@"payway"] isEqualToString:@"6"]){
         if (MyAppDelegate.isCharging == YES) {
             return;
         }
       //微信支付
         //判断用户是否安装了微信
         if ([WXApi isWXAppInstalled]) {
             //微信支付
             NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:self.infoDic];
             [dic addEntriesFromDictionary:_dicOrderInfo[@"payInfo"]];
             [dic setObject:@"" forKey:@"fromFlag"];
             
             //购买的商品
             NSDictionary *goodsInfo = [dic[@"goodsDetail"]objectAtIndex:0];
             NSString *goods = [NSString stringWithFormat:@"%@-%@",goodsInfo[@"goodsid"],goodsInfo[@"goodsnum"]];
             [dic setObject:goods forKey:@"goods"];
             
             [self payWXWith:dic];
         }
         else{
             
             [self showalertString:@"尚未安装微信"];
         }
     
         return;
    }
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"PaySign" forKey:@"Mod"];
    [dic setObject:@"PayOnline" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
    }
    
    //支付方式 1Mpos,2支付宝,3银联,4.现金支付5 未支付
    NSString *platform = [NSString string];
    if ([[[_dicOrderDetail objectForKey:@"payInfo"] objectForKey:@"payway"] isEqualToString:@"2"]) {
        platform = @"alipay";
    }else if ([[[_dicOrderDetail objectForKey:@"payInfo"] objectForKey:@"payway"] isEqualToString:@"3"]){
        platform = @"upmppay";
    }
    else {
        platform = @"";
    }
    [dicContent setObject:platform forKey:@"platform"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"phone"];
    
    if ([_dicOrderInfo objectForKey:@"shopid"]) {
        [dicContent setObject:[_dicOrderInfo objectForKey:@"shopid"] forKey:@"shopid"];
        [dicContent setObject:[_dicOrderInfo objectForKey:@"shopname"] forKey:@"shopname"];
    }else{
        [dicContent setObject:@"" forKey:@"shopid"];
        [dicContent setObject:@"" forKey:@"shopname"];
    }
    
    [dicContent setObject:[[_dicOrderDetail objectForKey:@"payInfo"] objectForKey:@"num"] forKey:@"num"];

    
    
    NSString *enStr = [AESCrypt encrypt:[dicContent JSONRepresentation] password:KENCRYPTKEY];
    [dic setObject:enStr forKey:@"Content"];
    
    
    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if( [[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSString *deStr1 = [AESCrypt decrypt:[resultDic objectForKey:@"DetailInfo"] password:KDECRYPTKEY];
            ;
            NSDictionary *detailDic = [NSJSONSerialization JSONObjectWithData:[deStr1 dataUsingEncoding:NSASCIIStringEncoding] options:NSJSONReadingMutableLeaves error:nil];
            
            if ([[detailDic objectForKey:@"url"] isKindOfClass:[NSString class]] && [[detailDic objectForKey:@"url"] length] > 0) {
                ZLog(@"支付宝");
                
                ZLog(@"%@",[detailDic objectForKey:@"para"]);
                MyAppDelegate.orderNum = [detailDic objectForKey:@"num"];
                
                [[UIApplication sharedApplication]openURL:[NSURL URLWithString:[detailDic objectForKey:@"url"]]];
                
                //通知刷新？
                [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
                
                //返回主页
                [self.navigationController popToRootViewControllerAnimated:NO];
                
            }else{
                ZLog(@"银联");
                /**
                 *  mode:@"00" 正式版本
                 *  mode:@"01" 开发测试版
                 */
                ZLog(@"%@",[detailDic objectForKey:@"tn"]);
                MyAppDelegate.orderNum = [detailDic objectForKey:@"num"];
                
                [UPPayPlugin startPay:[NSString stringWithFormat:@"%@",[detailDic objectForKey:@"tn"]] mode:@"00" viewController:self delegate:self];
                
            }
            
        }
    }];
}
#pragma mark - 支付delegate
- (void)UPPayPluginResult:(NSString *)result
{
    if ([result isEqualToString:@"fail"]) {
        ZLog(@"%@失败",result);
        [self showalertString:@"支付未成功，请重新支付"];

    }else if ([result isEqualToString:@"success"]){
        ZLog(@"%@成功",result);
        [self showalertString:@"支付成功"];

        [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
        
        //新增结果页面
        orderResultViewController *ctrl = [[orderResultViewController alloc]init];
        ctrl.orderNum = MyAppDelegate.orderNum;
        ctrl.hideBackButton = YES;
        [self.navigationController pushViewController:ctrl animated:YES];
        
    }else if ([result isEqualToString:@"cancel"]){
        ZLog(@"%@取消订单",result);
        [self showalertString:@"支付未成功，请重新支付"];

    }
    
}

- (void)WXPayResultHandle:(NSNotification *)notify{
    
    if ([notify.object isEqualToString:WX_PAY_FAIL]) {
        //失败
        [self showalertString:@"订单支付未完成，请在”我的订单“中重新支付"];
      
    }
    else{//成功
        [self showalertString:@"支付成功"];
        
        [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
        //新增结果页面
        orderResultViewController *ctrl = [[orderResultViewController alloc]init];
        ctrl.orderNum = MyAppDelegate.orderNum;
        ctrl.hideBackButton = YES;
        [self.navigationController pushViewController:ctrl animated:YES];
    }
     [[NSNotificationCenter defaultCenter]removeObserver:self name:WX_PAY_RESULT object:nil];
}
- (void)backToHome{
    //返回主页
    [self.navigationController popToRootViewControllerAnimated:NO];
    [MyAppDelegate.mainTabVC setSelectedIndex:0];
    [MyAppDelegate.mainTabVC.selectImage setFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
    
}

@end
