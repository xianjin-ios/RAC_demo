//
//  youhuiCell.h
//  GGSH
//
//  Created by siqiyang on 15/7/9.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface youhuiCell : UICollectionViewCell


@property (retain, nonatomic) IBOutlet UIImageView *goodsIcon;

@property (retain, nonatomic) IBOutlet UILabel *goodsLabel;


@end
