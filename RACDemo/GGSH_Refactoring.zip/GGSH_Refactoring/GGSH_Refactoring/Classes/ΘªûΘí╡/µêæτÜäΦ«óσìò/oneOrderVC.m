//
//  oneOrderVC.m
//  GGSH
//
//  Created by 任春宁 on 15/3/18.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "oneOrderVC.h"
#import "orderDetailVC.h"

@interface oneOrderVC ()

@end

@implementation oneOrderVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor clearColor];
    _tableView.backgroundColor = [UIColor clearColor];
    
    //添加header
    {
        UIView * vHeader = [[UIView alloc] init];
        vHeader.backgroundColor = [UIColor whiteColor];
        vHeader.frame = CGRectMake(0, 0, SCREEN_WIDTH - 2*5 ,34);
        _tableView.tableHeaderView = vHeader;
        
        //商户名称
        UILabel * lbNum = [[UILabel alloc] init];
        lbNum.backgroundColor = [UIColor clearColor];
        lbNum.font = [UIFont systemFontOfSize:12];
        lbNum.textColor = [UIColor grayColor];
        lbNum.frame = CGRectMake(10, 0, 140, vHeader.frame.size.height);
        [vHeader addSubview:lbNum];
        lbNum.text = [NSString stringWithFormat:@"%@",[self.dicOrder objectForKey:@"shopname"]];
        
        //时间
        UILabel * lbDate = [[UILabel alloc] init];
        lbDate.backgroundColor = [UIColor clearColor];
        lbDate.font = [UIFont systemFontOfSize:12];
        lbDate.textColor = [UIColor grayColor];
        lbDate.frame = CGRectMake(lbNum.frame.origin.x + lbNum.frame.size.width + 2, 0, 70, vHeader.frame.size.height);
        [vHeader addSubview:lbDate];
        lbDate.textAlignment = NSTextAlignmentRight;
        NSString * strTime = [[self.dicOrder objectForKey:@"num"] objectForKey:@"ctime"];
        lbDate.text = [strTime substringWithRange:NSMakeRange(0, 11)];
        
        //交易状态
        UILabel * lbState = [[UILabel alloc] init];
        lbState.backgroundColor = [UIColor clearColor];
        lbState.font = [UIFont systemFontOfSize:12];
        lbState.textColor = [UIColor colorWithHexString:@"#217500"];
        lbState.frame = CGRectMake(SCREEN_WIDTH - 80, 0, 60, vHeader.frame.size.height);
        lbState.textAlignment = NSTextAlignmentRight;
        [vHeader addSubview:lbState];
        
        //    交易状态1未支付2支付失败3支付成功4预订状态
        //    交易类型 1Mpos,2支付宝,3银联
        NSString *tradeStr;
        
        switch ([[[self.dicOrder objectForKey:@"num"] objectForKey:@"tradestatus"] intValue]) {
            case 1:
                tradeStr = @"未支付";
                
                break;
                
            case 2:
                tradeStr = @"支付失败";
                break;
                
            case 3:
                tradeStr = @"支付成功";
                break;
                
            case 4:{
                if ([[[self.dicOrder objectForKey:@"num"] objectForKey:@"prepaystu"] isEqualToString:@"1"]) {
                    tradeStr = @"预付成功";
                }else if ([[[self.dicOrder objectForKey:@"num"] objectForKey:@"prepaystu"] isEqualToString:@"0"]){
                    tradeStr = @"预订成功";
                }
            }
                break;
                
            default:
                break;
        }
        lbState.text = tradeStr;
        
        //添加横线
        UIImageView * imgViewLine = [[UIImageView alloc] init];
        imgViewLine.frame = CGRectMake(10, 33, vHeader.frame.size.width - 30, 0.5);
        imgViewLine.clipsToBounds = YES;
        imgViewLine.backgroundColor = [UIColor clearColor];
        [vHeader addSubview:imgViewLine];
        imgViewLine.image = [UIImage imageNamed:@"myorder_11"];
        
    }
    
    //添加footer
    {
        UIView * vFooter = [[UIView alloc] init];
        vFooter.backgroundColor = [UIColor whiteColor ];
        vFooter.frame = CGRectMake(0, 0, SCREEN_WIDTH - 2*5 ,42);
        _tableView.tableFooterView = vFooter;
        
        //件数
        UILabel * lbProductCount = [[UILabel alloc] init];
        lbProductCount.backgroundColor = [UIColor clearColor];
        lbProductCount.font = [UIFont systemFontOfSize:12];
        lbProductCount.textColor = [UIColor grayColor];
        lbProductCount.frame = CGRectMake(115, 0, 40, vFooter.frame.size.height);
        [vFooter addSubview:lbProductCount];
        lbProductCount.text = [NSString stringWithFormat:@"共%@件",[self.dicOrder objectForKey:@"product_num"]];
        
        //支付金额
        UILabel * lbMoney = [[UILabel alloc] init];
        lbMoney.backgroundColor = [UIColor clearColor];
        lbMoney.font = [UIFont systemFontOfSize:12];
        lbMoney.textColor = [UIColor grayColor];
        lbMoney.textAlignment = 2;
        lbMoney.frame = CGRectMake(SCREEN_WIDTH - 180, 0, 160, vFooter.frame.size.height);
        [vFooter addSubview:lbMoney];
        lbMoney.text = [NSString stringWithFormat:@"支付金额:￥%.2f", [[[self.dicOrder objectForKey:@"num"] objectForKey:@"paymoney"] doubleValue]/100.0];
        
    }
    
    //加载数据
    _arrProductList = [self.dicOrder objectForKey:@"goodsDetail"];
    [_tableView reloadData];
    
}

+(int)getheight:(NSDictionary *)dicOrder{
    
    NSArray *tempArr = [dicOrder objectForKey:@"goodsDetail"];
    
    int product_num = (int)tempArr.count;

    return 34 + 42 + 75 * product_num;
    
}


#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arrProductList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //需要根据数量计算高度
    return 75;
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ZLog(@"去详情 ");
    ZLog(@"%d",self.index);
    [self.toDelegate gotoDetail:self.index];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //翻页CELL
    static NSString *CellIdentifier = @"COMMONCELL";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        //缩略图
        UIImageView * imgViewThum = [[UIImageView alloc] init];
        imgViewThum.frame = CGRectMake(12, (75-56)/2, 80, 56);
        imgViewThum.tag = 11;
        [cell.contentView addSubview:imgViewThum];
        imgViewThum.layer.borderColor = [UIColor lightGrayColor].CGColor;
        imgViewThum.layer.borderWidth = 0.5f;
        imgViewThum.contentMode = UIViewContentModeScaleToFill;
        
        //名称
        UILabel * lbName = [[UILabel alloc] init];
        lbName.backgroundColor = [UIColor clearColor];
        lbName.font = [UIFont systemFontOfSize:14];
        lbName.textColor = [UIColor blackColor];
        lbName.frame = CGRectMake(imgViewThum.frame.origin.x + imgViewThum.frame.size.width + 5, 10, 166, 20);
        lbName.tag = 12;
        [cell.contentView addSubview:lbName];
        lbName.text = @"大疆精灵***";
        
        //价格
        UILabel * lbPrice = [[UILabel alloc] init];
        lbPrice.backgroundColor = [UIColor clearColor];
        lbPrice.font = [UIFont systemFontOfSize:12];
        lbPrice.textColor = [UIColor colorWithHexString:@"#ff5a00"];
        lbPrice.frame = CGRectMake(_tableView.frame.size.width - 100, 10, 90, 20);
        lbPrice.textAlignment = NSTextAlignmentRight;
        lbPrice.tag = 13;
        [cell.contentView addSubview:lbPrice];
        lbPrice.text = @"$****";
        
        //颜色
        UILabel * lbColor = [[UILabel alloc] init];
        lbColor.backgroundColor = [UIColor clearColor];
        lbColor.font = [UIFont systemFontOfSize:12];
        lbColor.textColor = [UIColor grayColor];
        lbColor.frame = CGRectMake(imgViewThum.frame.origin.x + imgViewThum.frame.size.width + 5, 35, 30, 20);
        lbColor.tag = 14;
        [lbColor setHidden:YES];
        [cell.contentView addSubview:lbColor];
        lbColor.text = @"黑色*";
        
        //型号
        UILabel * lbSize = [[UILabel alloc] init];
        lbSize.backgroundColor = [UIColor clearColor];
        lbSize.font = [UIFont systemFontOfSize:12];
        lbSize.textColor = [UIColor grayColor];
        lbSize.frame = CGRectMake(lbColor.frame.origin.x + lbColor.frame.size.width + 5, 35, 30, 20);
        lbSize.tag = 15;
        [lbSize setHidden:YES];
        [cell.contentView addSubview:lbSize];
        lbSize.text = @"M号*";
        
        //数量
        UILabel * lbCount = [[UILabel alloc] init];
        lbCount.backgroundColor = [UIColor clearColor];
        lbCount.font = [UIFont systemFontOfSize:12];
        lbCount.textColor = [UIColor grayColor];
        lbCount.frame = CGRectMake(lbSize.frame.origin.x + lbSize.frame.size.width + 5, 35, 30, 20);
        lbCount.tag = 16;
        [lbCount setHidden:YES];
        [cell.contentView addSubview:lbCount];
        lbCount.text = @"x件";
        
        //添加横线
        UIImageView * imgViewLine = [[UIImageView alloc] init];
        imgViewLine.backgroundColor = [UIColor clearColor];
        imgViewLine.frame = CGRectMake(10, 74, _tableView.frame.size.width - 20, 0.5);
        [cell.contentView addSubview:imgViewLine];
        imgViewLine.image = [UIImage imageNamed:@"myorder_11.png"];
        
    }
    
    UIImageView * imgViewThum = (UIImageView *)[cell.contentView viewWithTag:11];
    UILabel *lbName = (UILabel *)[cell.contentView viewWithTag:12];
    UILabel *lbPrice = (UILabel *)[cell.contentView viewWithTag:13];
    UILabel *lbColor = (UILabel *)[cell.contentView viewWithTag:14];
    UILabel *lbSize = (UILabel *)[cell.contentView viewWithTag:15];
    UILabel *lbCount = (UILabel *)[cell.contentView viewWithTag:16];
    
    lbColor.text = @"";
    lbSize.text = @"";
    
    //数据加载
    ZLog(@"%@",[_arrProductList objectAtIndex:indexPath.row]);
    if (_arrProductList.count > 0) {
        [imgViewThum XK_setImageWithURL:[NSURL URLWithString:[[_arrProductList objectAtIndex:indexPath.row] objectForKey:@"listpic"]] placeholderImage:nil];
        lbName.text = [NSString stringWithFormat:@"%@",[[_arrProductList objectAtIndex:indexPath.row] objectForKey:@"goodsname"]];
        lbPrice.text = [NSString stringWithFormat:@"%.2f元",[[[_arrProductList objectAtIndex:indexPath.row] objectForKey:@"goodsprice"] floatValue]/100.0];
        lbCount.text = [NSString stringWithFormat:@"%@件",[[_arrProductList objectAtIndex:indexPath.row] objectForKey:@"goodsnum"]];

    }
    
    
    return cell;
}


@end
