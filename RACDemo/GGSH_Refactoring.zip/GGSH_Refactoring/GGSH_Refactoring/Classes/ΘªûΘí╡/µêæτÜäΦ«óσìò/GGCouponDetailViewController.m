//
//  GGCouponDetailViewController.m
//  GGSH
//
//  Created by siqiyang on 16/3/22.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "GGCouponDetailViewController.h"
#import "mposDetailViewController.h"
#import "LineView.h"

@interface GGCouponDetailViewController ()<UITableViewDataSource,UITableViewDelegate,MJRefreshBaseViewDelegate>
{
    UIView *_noView;
    int pageindex;
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    //bug 1197 上拉刷新页面，可用时间和适用店铺错位
    int index ;
    
    NSMutableArray *_dataArray;
}

@property (nonatomic,strong) NSMutableArray *couponDataArray;

@end

@implementation GGCouponDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"优惠券详情";
    [self cancelTapHideKeyBoard:YES];
    index = 0;
    pageindex = 1;
    self.couponDataArray = [[NSMutableArray alloc]init];
    [self getDatafromNet];
    self.view.backgroundColor = [UIColor colorWithHexString:@"#d3016e"];
    self.ggCouponInfo = [[NSMutableDictionary alloc]init];
    NSInteger height = 0;
    if (curDevice > 7.0) {
        height = 64;
    }
    self.couponTableView = [[UITableView alloc]initWithFrame:CGRectMake(30, 30, SCREEN_WIDTH -60, SCREEN_HEIGHT -40 - height)];
    _couponTableView.delegate = self;
    _couponTableView.dataSource = self;
    _couponTableView.backgroundColor = [UIColor clearColor];
    _couponTableView.showsVerticalScrollIndicator = NO;
    self.couponTableView.tableFooterView = [[UIView alloc]init];
    self.couponTableView.tableHeaderView = [[UIView alloc]init];
    self.couponTableView.separatorColor = [UIColor clearColor];
    
    [self.view addSubview:_couponTableView];
    _header = [MJRefreshHeaderView header];
    _header.scrollView = self.couponTableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = self.couponTableView;
    _footer.delegate = self;
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
   
    ZLog(@"%@",self.ggCouponInfo);
    
}
#pragma mark - 刷新的代理方法进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(0 == [MyAppDelegate reachBility]){
        [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        return;
    }
    
    if(refreshView == _header) {// 下拉刷新
        pageindex = 1;
        [self getDatafromNet];
    }else if (refreshView == _footer){//上拉加载更多
        if(_dataArray.count%10 == 0){//每页有10个数据
            pageindex += 1;
            [self getDatafromNet];
        }
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    return;
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

- (void)getDatafromNet{
    [self showHUD];
    NSDictionary *dic = @{
                          @"Mod":@"Coupon",
                          @"Act":@"ggCouponDetail",
                          @"Content":@{
                                  @"uid":[MyAppDelegate.userInfo objectForKey:@"id"],
                                  @"logintoken":[MyAppDelegate.userInfo objectForKey:@"logintoken"],
                                  @"pageindex":[NSString stringWithFormat:@"%d",pageindex],
                                  @"pagesize":@"20",
                                  @"longitude":[NSNumber numberWithDouble:MyAppDelegate.ilongitude],//经度
                                  @"latitude":[NSNumber numberWithDouble:MyAppDelegate.ilatitude],//纬度
                                  @"version_name":KVERSION,//版本号
                                  @"id":self.couponId
                                  }
                          };
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        [self hideHUD];
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* responseDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if ([[responseDic objectForKey:@"Code"] isEqualToString:@"0000"]) {
            NSArray *shops = [[responseDic objectForKey:@"DetailInfo"] objectForKey:@"shopInfo"];
            self.ggCouponInfo = [[responseDic objectForKey:@"DetailInfo"] objectForKey:@"couponInfo"];
            if(pageindex == 1){
                
                [self.couponDataArray removeAllObjects];
                [self.couponDataArray addObjectsFromArray:shops];
                
            }
            else {
                
                [self.couponDataArray addObjectsFromArray:shops];
                
            }
            [self.couponTableView reloadData];
        }else{
            [self showAlert:nil withTitle:responseDic[@"Message"] haveCancelButton:NO];
        }
    }];
}
////没有数据时的提示
//- (void)isShowNoDataView:(BOOL)isShow{
//    if (isShow == NO) {
//        if (_noView) {
//            [_noView removeFromSuperview];
//            _noView = nil;
//        }
//    }
//    else
//        if (!_noView) {
//            _noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
//            _noView.backgroundColor = [UIColor clearColor];
//            _noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT * 0.5 - 22);
//            UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
//            bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
//            UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
//            labela.backgroundColor = [UIColor clearColor];
//            labela.text = @"暂无内容";
//            labela.textAlignment = 1;
//            labela.font = [UIFont systemFontOfSize:15];
//            labela.textColor = [UIColor lightGrayColor];
//            [bigbeen addSubview:labela];
//            [_noView addSubview:bigbeen];
//            [self.couponTableView addSubview:_noView];
//        }
//}

#pragma mark -- UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.couponDataArray.count + 2 ;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
       float width = _couponTableView.frame.size.width;
    if (indexPath.row == 0) {
        return 40;
    }
    else if(indexPath.row ==1){
        
        NSString *condition = self.ggCouponInfo[@"coupondesc"];
        NSString *conditionStr =[NSString stringWithFormat:@"使用条件：%@",condition];

        CGSize size = [NSString getHeight:conditionStr withFont:[UIFont systemFontOfSize:10] andWidth:width];
        int height = (size.height/10 + 1) * 10;
        return 305 + height;
    }
    
    else
        return 45;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    float width = _couponTableView.frame.size.width;
        if (indexPath.row == 0) {
        static NSString *cellId  = @"first";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            cell.userInteractionEnabled = NO;
            //产品图
            UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(10, 5, 25, 25)];
            imageView.image = [UIImage imageNamed:@"ggcoupon_detail"];
            [cell.contentView addSubview:imageView];
            imageView.tag = 101;
            //产品名称
            UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(45, 10, 70, 15)];
            nameLabel.font = [UIFont systemFontOfSize:12];
            
            [cell.contentView addSubview:nameLabel];
            nameLabel.tag = 102;
            //产品状态
            UILabel *stateLabel = [[UILabel alloc]initWithFrame:CGRectMake(width - 70, 10, 60, 15)];
            stateLabel.font = [UIFont systemFontOfSize:12];
            stateLabel.textAlignment = NSTextAlignmentRight;
            stateLabel.textColor = [UIColor colorWithHexString:@"#b0b0b0"];
            [cell.contentView addSubview:stateLabel];
            stateLabel.tag = 103;
            UIImageView *lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 34,width, 1)];
            lineImageView.image = [UIImage imageNamed:@"line_dotted"];
            [cell.contentView addSubview:lineImageView];
            
            cell.selected = NO;
        }
        UILabel *nameLabel = (UILabel *)[cell.contentView viewWithTag:102];
        nameLabel.text = [NSString stringWithFormat:@"%@",@"逛逛优惠券"];
        //判断优惠券状态 isuse 是否使用 0已转增 1使用 2未使用
        
        UILabel *stateLabel = (UILabel *)[cell.contentView viewWithTag:103];
        NSString *isuse = self.ggCouponInfo[@"isuse"];
        if ([isuse isEqualToString:@"0"]) {
            stateLabel.text = [NSString stringWithFormat:@"%@",@"已转赠"];
        }
        if ([isuse isEqualToString:@"1"]) {
            
            stateLabel.text = [NSString stringWithFormat:@"%@",@"已使用"];
        }
        
        if ([isuse isEqualToString:@"2"]) {
            if ([self.ggCouponInfo[@"is_pass"] isEqualToString:@"1"]) {//is_pass 是否过期 0过期 1不过期
                
                if ([self.ggCouponInfo[@"is_start"] isEqualToString:@"0"]) {
                    stateLabel.text = [NSString stringWithFormat:@"%@",@"未使用"];
                }
                else
                    stateLabel.text = [NSString stringWithFormat:@"%@",@"未使用"];
                
            }
            else{
                
                stateLabel.text = [NSString stringWithFormat:@"%@",@"已过期"];
                
            }
        }
        return cell;
    }
    if(indexPath.row == 1){
        
        static NSString *cellId  = @"second";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
      

        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            cell.userInteractionEnabled = NO;
//            //产品名称
            UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,0, width, 40)];
            nameLabel.textAlignment = NSTextAlignmentCenter;
            nameLabel.numberOfLines = 0;
            nameLabel.adjustsFontSizeToFitWidth = YES;
            nameLabel.font = [UIFont systemFontOfSize:18];
          
            [cell.contentView addSubview:nameLabel];
            nameLabel.tag = 201;
            
            //优惠券价格
            UILabel *priceLabel = [[UILabel alloc]initWithFrame:CGRectMake(width *0.5 - 75,40 , 150, 20)];
            priceLabel.font = [UIFont systemFontOfSize:18];
            priceLabel.textAlignment = NSTextAlignmentCenter;
            [cell.contentView addSubview:priceLabel];
            priceLabel.tag = 202;
            
            //二维码
            UIImageView *codeImageView = [[UIImageView alloc]initWithFrame:CGRectMake(width *0.5 - 80, 65, 160, 160)];
            codeImageView.image = [UIImage imageNamed:@"goodsListDefaultImage.png"];
            [cell.contentView addSubview:codeImageView];
            codeImageView.tag = 203;
            
            //使用条件
            UILabel *conditionLabel = [[UILabel alloc]initWithFrame:CGRectMake(15, 225, width - 30, 30)];
            conditionLabel.numberOfLines = 0;
            conditionLabel.font = [UIFont systemFontOfSize:10];
            conditionLabel.textColor = [UIColor colorWithHexString:@"#636363"];
//            conditionLabel.text = [NSString stringWithFormat:@"使用条件：消费满99元可用；全场通用，不限品类"];
            [cell.contentView addSubview:conditionLabel];
            conditionLabel.tag = 204;
            
            //可用时间
            UILabel *timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(15, 245, width -30, 12)];
            timeLabel.font = [UIFont systemFontOfSize:10];
            timeLabel.textColor = [UIColor colorWithHexString:@"#636363"];
            timeLabel.tag = 205;
//            NSString *timeStr = [NSString stringWithFormat:@"可用时间：2015.01.15-2015.02.10"];
//            timeLabel.text = timeStr;
            [cell.contentView addSubview:timeLabel];
            
            //虚线
            UIImageView *lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 265,width, 1)];
            lineImageView.image = [UIImage imageNamed:@"line_dotted"];
            [cell.contentView addSubview:lineImageView];
            lineImageView.tag = 206;
            
            //适用店铺
            UILabel *shopsLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 275, 60, 15)];
            shopsLabel.text = @"适用店铺";
            shopsLabel.font = [UIFont systemFontOfSize:12];
            [cell.contentView addSubview:shopsLabel];
            shopsLabel.tag = 207;
//            cell.shouldIndentWhileEditing = NO;
            
        }
        if (![self.ggCouponInfo isEqual: @{}]) {
         
            if (index == 0) {
                //优惠券名称
                UILabel *nameLabel = (UILabel *)[cell.contentView viewWithTag:201];
                nameLabel.text = self.ggCouponInfo[@"couponname"];
                CGFloat money = [self.ggCouponInfo[@"money"] floatValue]/100;
                //优惠券价格
                NSString *priceStr = [NSString stringWithFormat:@"%.0f元",money];
                UILabel *priceLabel = (UILabel *)[cell.contentView viewWithTag:202];
                priceLabel.text = priceStr;
                //二维码
                UIImageView *codeImageView = (UIImageView *)[cell.contentView viewWithTag:203];
                [codeImageView XK_setImageWithURL:[NSURL URLWithString:self.ggCouponInfo[@"codeurl"]] placeholderImage:nil];
                
                //使用条件
                NSString *condition = self.ggCouponInfo[@"coupondesc"];
                NSString *conditionStr =[NSString stringWithFormat:@"使用条件：%@",condition];
                UILabel *conditionLabel = (UILabel *)[cell.contentView viewWithTag:204];

                CGSize size = [NSString getHeight:conditionStr withFont:[UIFont systemFontOfSize:10] andWidth:width];
                int height = (size.height/10 + 1) * 10;
                conditionLabel.text = conditionStr;
                conditionLabel.frame = CGRectMake(conditionLabel.frame.origin.x, conditionLabel.frame.origin.y, conditionLabel.frame.size.width, conditionLabel.frame.size.height + height);
                //            if (height !=0) {
                //                height = height - 5;
                //            }
                
                UILabel *timeLabel = (UILabel *)[cell.contentView viewWithTag:205];
                NSString *start = self.ggCouponInfo[@"starttime"];
                NSString *endtime = self.ggCouponInfo[@"endtime"];
                
                //       timeLabel.text = [NSString stringWithFormat:@"可用时间：2015.01.15-2015.02.10"];
                timeLabel.text = [NSString stringWithFormat:@"可用时间：%@",start];
                
                NSString * timeStr = [NSString stringWithFormat:@"可用时间：%@-%@",start,endtime];
                timeLabel.text = timeStr;
                timeLabel.frame =  CGRectMake(timeLabel.frame.origin.x, timeLabel.frame.origin.y + height , timeLabel.frame.size.width, timeLabel.frame.size.height);
                //虚线
                UIImageView *lineImageView = (UIImageView *)[cell.contentView viewWithTag:206];
                lineImageView.frame =  CGRectMake(lineImageView.frame.origin.x, lineImageView.frame.origin.y + height, lineImageView.frame.size.width, lineImageView.frame.size.height);
                
                //适用店铺
                UILabel *shopsLabel = (UILabel *)[cell.contentView viewWithTag:207];
                shopsLabel.frame =  CGRectMake(shopsLabel.frame.origin.x, shopsLabel.frame.origin.y + height,shopsLabel.frame.size.width,shopsLabel.frame.size.height);
                
                index = 1;
            }
            
        }

        return cell;
        
    }
    else{
        
        static NSString *cellId  = @"shops";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            //店铺图片
            UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(10, 5, 28, 28)];
            imageView.image = [UIImage imageNamed:@"goodsListDefaultImage"];
            [cell.contentView addSubview:imageView];
            imageView.tag = 301;
            
            //店铺名称
            UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(45, 5, width *0.7, 15)];
            nameLabel.font = [UIFont systemFontOfSize:12];
            [cell.contentView addSubview:nameLabel];
            nameLabel.tag = 302;
            
            //店铺地址
            UILabel *addressLabel = [[UILabel alloc]initWithFrame:CGRectMake(45, 22, width - 65, 15)];
            addressLabel.font = [UIFont systemFontOfSize:10];
            addressLabel.textColor = [UIColor colorWithHexString:@"b0b0b0"];
            
            [cell.contentView addSubview:addressLabel];
            addressLabel.tag = 303;
            
            //
            UIImageView *arrow = [[UIImageView  alloc]initWithFrame:CGRectMake(width - 20, 15, 6, 14)];
            [arrow setImage:[UIImage imageNamed:@"arrow.png"]];
            
            [cell.contentView addSubview:arrow];
            
        }
        NSDictionary *shopDic = self.couponDataArray[indexPath.row - 2];
        //店铺图片
        UIImageView *shopImageView = (UIImageView *)[cell.contentView viewWithTag:301];
        [shopImageView XK_setImageWithURL:[NSURL URLWithString:shopDic[@"listpic"]] placeholderImage:nil];
        
        UILabel *nameLabel = (UILabel *)[cell.contentView viewWithTag:302];
        nameLabel.text = [NSString stringWithFormat:@"%@",shopDic[@"shopname"]];
        
        UILabel *addressLabel = (UILabel *)[cell.contentView viewWithTag:303];
        addressLabel.text = [NSString stringWithFormat:@"%@",shopDic[@"address"]];
        
        return cell;
        
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    //进入店铺
    mposDetailViewController *detailV = [[mposDetailViewController alloc]init];
    NSInteger indexs = indexPath.row - 2;
    detailV.merDic = [self.couponDataArray objectAtIndex:indexs];
    
    [self.navigationController pushViewController:detailV animated:YES];
    
    
}
-(NSUInteger) unicodeLengthOfString: (NSString *) text {
    NSUInteger asciiLength = 0;
    for (NSUInteger i = 0; i < text.length; i++) {
        unichar uc = [text characterAtIndex: i];
        asciiLength += isascii(uc) ? 1 : 2;
    }
    NSUInteger unicodeLength = asciiLength / 2;
    if(asciiLength % 2) {
        unicodeLength++;
    }
    return unicodeLength;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
