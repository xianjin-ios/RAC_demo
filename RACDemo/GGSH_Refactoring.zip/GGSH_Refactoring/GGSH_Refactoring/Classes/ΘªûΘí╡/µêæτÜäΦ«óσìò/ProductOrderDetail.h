//
//  ProductOrderDetail.h
//  GGSH
//  订单详情
//  Created by geng on 16/12/4.
//  Copyright (c) 2016年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseVCWithPay.h"
#import "ProductOrderBaseVC.h"
#import "UPPayPlugin.h"
#import "UPPayPluginDelegate.h"
#import "orderHeaderVC.h"

@interface ProductOrderDetail : BaseVCWithPay<UPPayPluginDelegate>{
    
    
    //商品列表
    ProductOrderBaseVC * _productVC;
    
    //订单头
    orderHeaderVC *_vOrderHeader;

    IBOutlet UIView *_orderHeaderVC;
    
    //订单详情
    NSDictionary * _dicOrderDetail;
    
    //
    IBOutlet UIScrollView * _scrollViewMain;
    
    //二维码
    IBOutlet UIView * _vBarcodeContainer;
    IBOutlet UIImageView * _imgViewBarcode;
    
    //下单时间
    IBOutlet UILabel * _lbTime;
    
    //商品列表
    IBOutlet UIView * _vProductList;
    
    //支付信息
    IBOutlet UIView * _vPayInfo;
    
    //订单
    IBOutlet UIView * _vOrder;
    
    //商品总额
    IBOutlet UILabel * _lbPayMoney;
    
    //服务费
    IBOutlet UILabel * _lbServiceFee;
    
    //预付款金额
    IBOutlet UILabel * _lbPrePay;
    
    //红包金额
    IBOutlet UILabel * _lbCoupon;
    
    //商品实付
    IBOutlet UILabel * _lbShifu;
    
    //备注
    IBOutlet UILabel *_lbRemark;
    
    //底部按钮
    
    IBOutlet UIButton *_payBtn;
    
    //底部按钮托盘
    IBOutlet UIView * _vBtnContainer;
    
    
}
@property (nonatomic,strong) NSDictionary *infoDic;
@property (nonatomic,strong) NSString *payStatus;
@property (nonatomic, strong) NSDictionary * dicOrderInfo;

- (IBAction)payBtn:(id)sender;

@end
