//
//  LifeServiceOrderDetailVC.h
//  GGSH
//
//  Created by yanli on 16/10/25.
//  Copyright (c) 2015年 YL. All rights reserved.
//

#import "BaseVCWithPay.h"
#import "mySubOrderVC.h"

@class mySubOrderVC;

@interface LifeServiceOrderDetailVC : BaseVCWithPay

@property (nonatomic,retain) NSDictionary *dicData;
@property (nonatomic,strong) NSString *brandCode;
@property (nonatomic, retain) mySubOrderVC *subOrderdelegate;
@property (nonatomic, assign) NSInteger indexRow;


@end
