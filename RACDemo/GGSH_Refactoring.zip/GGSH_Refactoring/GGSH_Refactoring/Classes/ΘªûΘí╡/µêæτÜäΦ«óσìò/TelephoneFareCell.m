//
//  TelephoneFareCell.m
//  GGSH
//
//  Created by STAR on 15/10/9.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "TelephoneFareCell.h"

@implementation TelephoneFareCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self setCellStyle];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setCellStyle{
    
    //支付
    _btnPay.layer.borderWidth = ONEPIXL;
    _btnPay.layer.borderColor = [UIColor colorWithHexString:@"#FB0072"].CGColor;
    _btnPay.layer.cornerRadius = 4;
    
    //取消
    _btnCancel.layer.borderWidth = ONEPIXL;
    _btnCancel.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _btnCancel.layer.cornerRadius = 4;
}

- (IBAction)toPay:(id)sender {
 
    if ([self.payWay isEqualToString:@"WX"]) {
        if ([self.delegate respondsToSelector:@selector(payOnlineWXWithInfo:)]) {
            [self.delegate payOnlineWXWithInfo:self.dicData];
        }
    }
    else
    if([self.delegate respondsToSelector:@selector(telephonePay:)]){
        
        [self.delegate telephonePay:self.dicData];
    }
    
}

- (IBAction)cancel:(id)sender{
    if([self.delegate respondsToSelector:@selector(cancelOrder:)]){
        [self.delegate cancelOrder:self.dicData];
    }
}
@end
