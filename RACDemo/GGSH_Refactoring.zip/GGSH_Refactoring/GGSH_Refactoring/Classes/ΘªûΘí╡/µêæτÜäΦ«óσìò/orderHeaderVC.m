//
//  orderHeaderVC.m
//  GGSH
//
//  Created by siqiyang on 15/9/22.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "orderHeaderVC.h"

@interface orderHeaderVC ()
{
}
@end

@implementation orderHeaderVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _address.numberOfLines = 0;
    _address.lineBreakMode = NSLineBreakByWordWrapping;
    
    for (int i = 21; i < 25 ; i ++) {
        UIView * v1 = [self.view viewWithTag:i];
        [v1 setFrame:CGRectMake(0, 0, SCREEN_WIDTH, 0.5)];

    }
}

+(double)getHeight:(NSDictionary *)dicInfo{
    
    double downHeight = 0;
    
    //地址长度
    NSString *type = [dicInfo objectForKey:@"type"];
    if (type != nil && [[dicInfo objectForKey:@"type"] intValue] == 0) {
        //来源MPOS
        if ([[dicInfo objectForKey:@"order_type"] intValue] == 2) {
            //虚拟
            NSString *addressStr = [dicInfo objectForKey:@"ecp_ext"];
            CGSize size;
            UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
            
            size=[addressStr sizeWithFont:nameFont constrainedToSize:CGSizeMake(SCREEN_WIDTH - 78, 200) lineBreakMode:NSLineBreakByCharWrapping];
            NSInteger row = (int)size.height/15;
            if (row != 1) {
                downHeight += row * 20 + 10;
            }else{
                downHeight += row * 40;
            }
            
        }else if ([[dicInfo objectForKey:@"order_type"] intValue] == 1) {
            //实物订单
            
            if ([[dicInfo objectForKey:@"transport"] intValue] == 1) {
                
                NSString *addressStr = [dicInfo objectForKey:@"shopaddress"];
                CGSize size;
                UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
                
                size=[addressStr sizeWithFont:nameFont constrainedToSize:CGSizeMake(SCREEN_WIDTH - 78, 200) lineBreakMode:NSLineBreakByCharWrapping];
                
                NSInteger row = (int)size.height/15;
                if (row != 1) {
                    downHeight += row * 20 + 10;
                }else{
                    downHeight += row * 40;
                }
                
                
            }else{
                
                NSString *addressStr = [dicInfo objectForKey:@"address"];
                CGSize size;
                UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
                
                size=[addressStr sizeWithFont:nameFont constrainedToSize:CGSizeMake(SCREEN_WIDTH - 78, 200) lineBreakMode:NSLineBreakByCharWrapping];
                
                downHeight += 40;
                
                NSInteger row = (int)size.height/15;
                if (row != 1) {
                    downHeight += row * 20 + 10;
                }else{
                    downHeight += row * 40;
                }
            }
        }
        
    }else{
        //来源客户端
        //是否收货自取
        if ([[dicInfo objectForKey:@"transport"] intValue] == 1) {
            
            NSString *addressStr = [dicInfo objectForKey:@"shopaddress"];
            CGSize size;
            UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
            
            size=[addressStr sizeWithFont:nameFont constrainedToSize:CGSizeMake(SCREEN_WIDTH - 78, 200) lineBreakMode:NSLineBreakByCharWrapping];
            
            NSInteger row = (int)size.height/15;
            if (row != 1) {
                downHeight += row * 20 + 10;
            }else{
                downHeight += row * 40;
            }
            
            
        }else{
            
            NSString *addressStr = [dicInfo objectForKey:@"address"];
            CGSize size;
            UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
            
            size=[addressStr sizeWithFont:nameFont constrainedToSize:CGSizeMake(SCREEN_WIDTH - 78, 200) lineBreakMode:NSLineBreakByCharWrapping];
            
            downHeight += 40;

            NSInteger row = (int)size.height/15;
            if (row != 1) {
                downHeight += row * 20 + 10;
            }else{
                downHeight += row * 40;
            }
        }
        
    }
    
    //支付方式
    NSArray *payList = [dicInfo objectForKey:@"payway_list"];
    if (payList.count > 0) {
        switch (payList.count) {
            case 1:{
                downHeight += 40;
            }
                break;
            case 2:{
                downHeight += 80;
            }
                break;
                
            default:
                break;
        }
    }else{
        downHeight += 40;
    }
    
    return 40 + 40 + downHeight;
}

-(void)loadData:(NSDictionary *)dicInfo AndPayStatus:(NSString *)paystatus{
    
    int topPos = 0;
    
    //订单状态
    _orderStatus.text = paystatus;
    topPos += 40;
    
    //订单编号
    _orderNum.text = [dicInfo objectForKey:@"num"];
    topPos += 40;
    
    NSString *type = [dicInfo objectForKey:@"type"];
    
    if (type != nil && [[dicInfo objectForKey:@"type"] intValue] == 0) {
        //来源MPOS
        if ([[dicInfo objectForKey:@"order_type"] intValue] == 2) {
            //虚拟
            _lbShouOrQU.text = @"订购人";
            
            if ([[dicInfo objectForKey:@"order_sub_type"] intValue] == 1) {
                //话费
                _lbShouOrQuAddress.text = @"充值手机号";

            }else{
                //爱奇艺和京东e卡
                _lbShouOrQuAddress.text = @"接收手机号";

            }
            _lbShouOrQuAddress.adjustsFontSizeToFitWidth = YES;

            _acceptName.text = [dicInfo objectForKey:@"contact"];
            _contact.text = @"";
            
            NSString *addressStr = [dicInfo objectForKey:@"ecp_ext"];
            CGSize size;
            UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
            
            size=[addressStr sizeWithFont:nameFont constrainedToSize:CGSizeMake(SCREEN_WIDTH - 78, 200) lineBreakMode:NSLineBreakByCharWrapping];
            [_address setFrame:CGRectMake(70, 10, SCREEN_WIDTH - 78, size.height)];
            
            _address.text = addressStr;
            [_address sizeToFit];
            
            //调整视图
            _phoneView.hidden = NO;
//                topPos += 40;
            NSInteger height = 0;
            NSInteger row = (int)size.height/15;
            if (row != 1) {
                height += row * 20 + 10;
            }else{
                height += row * 40;
            }
            
            [_addressView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, height)];
            topPos += height;
            
            
        }else if ([[dicInfo objectForKey:@"order_type"] intValue] == 1) {
            if ([[dicInfo objectForKey:@"transport"] intValue] == 1) {
                _lbShouOrQU.text = @"订购人";
                _lbShouOrQuAddress.text = @"取货地址";
                
                _acceptName.text = [dicInfo objectForKey:@"contact"];
                _contact.text = @"";
                
                NSString *addressStr = [dicInfo objectForKey:@"shopaddress"];
                CGSize size;
                UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
                
                size=[addressStr sizeWithFont:nameFont constrainedToSize:CGSizeMake(SCREEN_WIDTH - 78, 200) lineBreakMode:NSLineBreakByCharWrapping];
                [_address setFrame:CGRectMake(70, 10, SCREEN_WIDTH - 78, size.height)];
                
                _address.text = addressStr;
                [_address sizeToFit];
                
                //调整视图
                _phoneView.hidden = NO;
                //            topPos += 40;//不显示联系电话所以不加40
                NSInteger height = 0;
                NSInteger row = (int)size.height/15;
                if (row != 1) {
                    height += row * 20 + 10;
                }else{
                    height += row * 40;
                }
                
                [_addressView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, height)];
                topPos += height;
                
                
            }else{
                _lbShouOrQU.text = @"收货人";
                _lbShouOrQuAddress.text = @"收货地址";
                
                _acceptName.text = [dicInfo objectForKey:@"acceptname"];
                _contact.text = [dicInfo objectForKey:@"contact"];
                
                NSString *addressStr = [dicInfo objectForKey:@"address"];
                CGSize size;
                UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
                
                size=[addressStr sizeWithFont:nameFont constrainedToSize:CGSizeMake(SCREEN_WIDTH - 78, 200) lineBreakMode:NSLineBreakByCharWrapping];
                [_address setFrame:CGRectMake(70, 10, SCREEN_WIDTH - 78, size.height)];
                
                _address.text = addressStr;
                [_address sizeToFit];
                
                //调整视图
                _phoneView.hidden = NO;
                topPos += 40;
                NSInteger height = 0;
                NSInteger row = (int)size.height/15;
                if (row != 1) {
                    height += row * 20 + 10;
                }else{
                    height += row * 40;
                }
                
                [_addressView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, height)];
                topPos += height;
            }
        }

    }else{
        //来源客户端
        //是否收货自取
        if ([[dicInfo objectForKey:@"transport"] intValue] == 1) {
            _lbShouOrQU.text = @"订购人";
            _lbShouOrQuAddress.text = @"取货地址";
            
            _acceptName.text = [dicInfo objectForKey:@"contact"];
            _contact.text = @"";
            
            NSString *addressStr = [dicInfo objectForKey:@"shopaddress"];
            CGSize size;
            UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
            
            size=[addressStr sizeWithFont:nameFont constrainedToSize:CGSizeMake(SCREEN_WIDTH - 78, 200) lineBreakMode:NSLineBreakByCharWrapping];
            [_address setFrame:CGRectMake(70, 10, SCREEN_WIDTH - 78, size.height)];

            _address.text = addressStr;
            [_address sizeToFit];
            
            //调整视图
            _phoneView.hidden = NO;
//            topPos += 40;//不显示联系电话所以不加40
            NSInteger height = 0;
            NSInteger row = (int)size.height/15;
            if (row != 1) {
                height += row * 20 + 10;
            }else{
                height += row * 40;
            }
            
            [_addressView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, height)];
            topPos += height;
            
            
        }else{
            _lbShouOrQU.text = @"收货人";
            _lbShouOrQuAddress.text = @"收货地址";
            
            _acceptName.text = [dicInfo objectForKey:@"acceptname"];
            _contact.text = [dicInfo objectForKey:@"contact"];
            
            NSString *addressStr = [dicInfo objectForKey:@"address"];
            CGSize size;
            UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:15];
            
            size=[addressStr sizeWithFont:nameFont constrainedToSize:CGSizeMake(SCREEN_WIDTH - 78, 200) lineBreakMode:NSLineBreakByCharWrapping];
            [_address setFrame:CGRectMake(70, 10, SCREEN_WIDTH - 78, size.height)];

            _address.text = addressStr;
            [_address sizeToFit];
            
            //调整视图
            _phoneView.hidden = NO;
            topPos += 40;
            NSInteger height = 0;
            NSInteger row = (int)size.height/15;
            if (row != 1) {
                height += row * 20 + 10;
            }else{
                height += row * 40;
            }
            
            [_addressView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, height)];
            topPos += height;
        }

    }
    
    //支付方式
    //支付方式 1Mpos,2支付宝,3银联
    NSArray *payList = [dicInfo objectForKey:@"payway_list"];
    if (payList.count > 0) {
        switch (payList.count) {
            case 1:{
                _payList.text = [NSString stringWithFormat:@"%@-%@",[[payList objectAtIndex:0] objectForKey:@"payway"],[[payList objectAtIndex:0] objectForKey:@"feetype"]];
                [_payInfo setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 40)];
                topPos += 40;
                [_payInfo setBackgroundColor:[UIColor whiteColor]];

            }
                break;
            case 2:{
                _payList.text = [NSString stringWithFormat:@"%@-%@",[[payList objectAtIndex:0] objectForKey:@"payway"],[[payList objectAtIndex:0] objectForKey:@"feetype"]];
                _payList2.text = [NSString stringWithFormat:@"%@-%@",[[payList objectAtIndex:1] objectForKey:@"payway"],[[payList objectAtIndex:1] objectForKey:@"feetype"]];
                
                [_payInfo setBackgroundColor:[UIColor whiteColor]];
                [_payInfo setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 80)];
                topPos += 80;
            }
                break;
                
            default:
                break;
        }
    }else{
        _payList.text = @"预付款-无";
        _payList2.text = @"";
        [_payInfo setBackgroundColor:[UIColor whiteColor]];
        [_payInfo setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 40)];
        topPos += 40;
    }
    
    [_baseView setFrame:CGRectMake(0, 0, SCREEN_WIDTH, topPos)];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
