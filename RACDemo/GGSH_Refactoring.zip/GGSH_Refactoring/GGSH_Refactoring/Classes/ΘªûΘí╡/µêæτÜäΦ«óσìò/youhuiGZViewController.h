//
//  youhuiGZViewController.h
//  GGSH
//
//  Created by siqiyang on 15/7/8.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface youhuiGZViewController : BaseViewController<UIWebViewDelegate>
{
    UIActivityIndicatorView *activityIndicator;

    IBOutlet UIView *showMoreView;
    
}

@property (nonatomic,retain)UIWebView *webView;

@end
