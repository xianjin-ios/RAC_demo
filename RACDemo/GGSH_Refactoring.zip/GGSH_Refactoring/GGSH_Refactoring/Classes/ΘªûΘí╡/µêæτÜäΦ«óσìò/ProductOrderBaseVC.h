//
//  ProductOrderBaseVC.h
//  GGSH
//
//  Created by 任春宁 on 15/7/3.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UPPayPlugin.h"
#import "UPPayPluginDelegate.h"
#import "LineView.h"
#import "BaseVCWithPay.h"

@protocol PAY_DELEGATE <NSObject>

- (void)payover;

@end
@interface ProductOrderBaseVC : BaseVCWithPay<UITableViewDataSource, UITableViewDelegate,UPPayPluginDelegate>{

    IBOutlet LineView *line1;
    
    IBOutlet LineView *line2;
    IBOutlet UITableView * _tableView;
    
    IBOutlet UIButton * _rightButton;
    
    IBOutlet UIButton * _btnPayPrePay;
    
    IBOutlet UILabel * _lbTitle;
    
    IBOutlet UILabel * _lbFooter;
    
    IBOutlet UILabel * _lbState;
    
    //右侧尖头
    IBOutlet UIImageView * _imgViewNext;
    
    //订单信息
    NSDictionary * _dicOrderInfo;
    
    //联系卖家
    IBOutlet UIButton * _btnChat;
    
    
    IBOutlet UIView *buyView;
    
    //预付功能
    IBOutlet UILabel *_lbYuFu;
    IBOutlet UILabel *_lbYuFuMoney;
    
}
@property (nonatomic,strong) NSDictionary *infoDic;
@property (nonatomic,assign) id <PAY_DELEGATE> delegate;

@property (nonatomic, strong) UINavigationController * navigationController;

@property (retain, nonatomic) IBOutlet UIView *downView;

//获取高度
+(double)getHeight:(NSDictionary *) dicInfo;

-(void)loadData:(NSDictionary *)dicInfo;

- (void)setHideBuyView:(BOOL)isShow;

-(void)hideChatButtton:(BOOL)flat;

@end





