//
//  myOrderVC.m
//  GGSH
//  我的订单
//  Created by 任春宁 on 15/3/18.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "myOrderVC.h"
#import "oneOrderVC.h"
#import "orderDetailVC.h"
#import "ProductOrderBaseCell.h"
#import "ProductOrderBaseVC.h"
#import "LoginVC.h"
#import "MyMessageVC.h"
#import "ProductOrderDetail.h"
#import "TelephoneFareCell.h"
#import "PayResultVC.h"
#import "mySubOrderVC.h"

@interface myOrderVC ()<PAY_DELEGATE,TELEPHONE_PAY,UPPayPluginDelegate,loginDelegate>
{
    NSString *tradeStatus;
    NSString *payway;
    int pageIndex;
    
    int selectStatus;
    int selectType;
    
    UIView *noView;
    
    UISegmentedControl *segControl;
    
    //是否是生活服务订单
    BOOL isLifeService;
    //生活服务的背景，
    IBOutlet UIView *_viewLifeService;
    NSMutableArray *_lifeServiceArray;
    
    UIImageView *imageAlert;
}
@end

@implementation myOrderVC
@synthesize  TradeStatus = tradeStatus;

-(id)initWithTradeStatus:(NSString*)strStatus{
    self = [super init];
    if (self) {
        
        tradeStatus = strStatus;
    }
    
    return self;
}


//重写back方法，返回首页
-(void)backAction{
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.title = @"我的订单";
    [self addMiddleSegment];
    
    [self cancelTapHideKeyBoard:YES];
    
    _viewLifeService.hidden = YES;
    
    //下拉刷新
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _tableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _tableView;
    _footer.delegate = self;
    
    _footerLifeService = [MJRefreshFooterView footer];
    _footerLifeService.scrollView = _tableLifeService;
    _footerLifeService.delegate = self;
    
    //添加右边按钮
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0.0, 0.0, 16, 16);
    [rightBtn addTarget:self action:@selector(my_message:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    rightBarButtonItem.style = UIBarButtonItemStylePlain;
    //判断是否要添加红点提示
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(10, -4, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [rightBarButtonItem.customView addSubview:imageAlert];
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
    
    if (self.user_order_type == 2) {
        self.user_order_type = 2;
        
        [_btnTab1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_btnTab1 setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
        [_btnTab2 setTitleColor:[UIColor colorWithHexString:@"#D2016E"] forState:UIControlStateNormal];
        [_btnTab2 setTitleColor:[UIColor colorWithHexString:@"#D2016E"] forState:UIControlStateHighlighted];
        _vLine.frame = CGRectMake( 1 * SCREEN_WIDTH / 3, _vLine.frame.origin.y, SCREEN_WIDTH / 3, 2);

    }else{
        self.user_order_type = 1;
    }
    
    //设置背景颜色
    self.view.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
    _tableView.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
    
    //初始化数据
    _dicOrderCtrl = [[NSMutableDictionary alloc] init];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getOrderList) name:@"refreshDFYFK" object:nil];
    
    pageIndex = 1;
    
    //获取订单列表
    [self getOrderList];
    
    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
}

- (void)refreshNavBtn{
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
}



//顶部分类筛选按钮
- (void)addMiddleSegment{
    //初始化UISegmentedControl
    NSArray *segmentedArray = [[NSArray alloc] initWithObjects:@"店铺订单",@"生活服务",nil];
    segControl = [[UISegmentedControl alloc]initWithItems:segmentedArray];
    segControl.frame = CGRectMake(0, 0, 150, 30);
    segControl.selectedSegmentIndex = 0;//设置默认选择项索引
    NSDictionary *colorAttr = [NSDictionary dictionaryWithObject:[UIColor whiteColor] forKey:NSForegroundColorAttributeName];
    [segControl setTitleTextAttributes:colorAttr forState:UIControlStateNormal];
    [segControl setTitleTextAttributes:colorAttr forState:UIControlStateSelected];
    segControl.tintColor = [UIColor colorWithHexString:@"#ff0083"];
    
    [segControl addTarget:self action:@selector(segmentAction:)forControlEvents:UIControlEventValueChanged];
    self.navigationItem.titleView = segControl;
}

//用户选择seg的按钮
- (void)segmentAction : (UISegmentedControl*) seg{
    ZLog(@"%ld",seg.selectedSegmentIndex);
    if(1 == seg.selectedSegmentIndex){
        isLifeService = YES;
        _viewLifeService.hidden = NO;
        [_tableLifeService reloadData];
        [self getLifeServiceOrder];
    }else{
        isLifeService = NO;
        _viewLifeService.hidden = YES;
    }
}

- (void)my_message:(UIButton *)sender{
    
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    
    if (MyAppDelegate.isdel == YES) {
        [self getOrderList];
        MyAppDelegate.isdel = NO;
    }
    
    //友盟统计
    [MobClick beginLogPageView:@"G_MYORDER_VIEW"];

}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_MYORDER_VIEW"];
    
}

//获取订单列表
-(void)getOrderList{
    if(!MyAppDelegate.userInfo){
        return;
    }
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"Porder" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"user_login_name"];
    if (![payway isEqualToString:@""]) {
        [dicContent setObject:@"" forKey:@"payway"];
    }

    [dicContent setObject:@"" forKey:@"tradestatus"];
    
    [dicContent setObject:[NSNumber numberWithInt:pageIndex] forKey:@"pageindex"];
    [dicContent setObject:@"40" forKey:@"pagesize"];
    
    [dicContent setObject:[NSString stringWithFormat:@"%ld",(long)self.user_order_type] forKey:@"user_order_type"];
    
    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if (pageIndex == 1) {
            [_arrOrderList removeAllObjects];
        }
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            //??此处需要判断翻页
            if (pageIndex == 1) {
                _arrOrderList = [[resultDic objectForKey:@"DetailInfo"]mutableCopy];
            }else
            {
                NSArray *tempArr = [resultDic objectForKey:@"DetailInfo"];
                [_arrOrderList addObjectsFromArray:tempArr];
            }
        }
        else{
            pageIndex --;
            if (pageIndex <= 1) {
                pageIndex = 1;
            }
        }
        
        [_tableView reloadData];
        
        if (_arrOrderList.count == 0) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [_tableView addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
        
        [self endHeaderFooterLoading];
        
    }];
    
}

//生活服务订单分类
- (void)getLifeServiceOrder{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Goods" forKey:@"Mod"];
    [dic setObject:@"gOrderTypeEcp" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dic setObject:dicContent forKey:@"Content"];
    [self showHUD];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        [self hideHUD];
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            _lifeServiceArray = [[resultDic objectForKey:@"DetailInfo"] mutableCopy];
        }
        [_tableLifeService reloadData];
        
    }];
}

#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(isLifeService){
        return _lifeServiceArray.count;
    }
    return _arrOrderList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(isLifeService){
        return 50;
    }
    
    NSDictionary * dicOrder = [_arrOrderList objectAtIndex:indexPath.row];
    
    return [ProductOrderBaseVC getHeight:dicOrder] + 3;
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(isLifeService){
        //动态类别使用后，Ordertype就没用处了 tel：aiqiyi：JDEK
        NSDictionary *dic = [_lifeServiceArray objectAtIndex:indexPath.row];
        mySubOrderVC *vc = [[mySubOrderVC alloc]init];
        vc.title = [dic objectForKey:@"category_name"];
        vc.ordertype = [dic objectForKey:@"orderType"];
        vc.orderDic = dic;
        [self.navigationController pushViewController:vc animated:YES];
        return;
    }
    
    NSDictionary * dicOrder = [_arrOrderList objectAtIndex:indexPath.row];
    ProductOrderDetail *orderDetailV = [[ProductOrderDetail alloc]init];
    orderDetailV.dicOrderInfo = dicOrder;
    orderDetailV.infoDic = dicOrder;
    if (self.user_order_type == 1) {
        orderDetailV.payStatus = @"待付预付款";
    }else if (self.user_order_type == 2) {
        if ([[[dicOrder objectForKey:@"num"] objectForKey:@"transport"] intValue] == 1) {
            orderDetailV.payStatus = @"待自取";
        }else if ([[[dicOrder objectForKey:@"num"] objectForKey:@"transport"] intValue] == 2){
            orderDetailV.payStatus = @"待收货";
        }
    }else if (self.user_order_type == 3) {
        orderDetailV.payStatus = @"已完成";
    }
    
    [self.navigationController pushViewController:orderDetailV animated:YES];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(isLifeService){
        //话费、京东E卡、爱奇艺、
        static NSString *CellIdentifierRight = @"commonCell";
        UITableViewCell *cellr = [tableView dequeueReusableCellWithIdentifier:CellIdentifierRight];
        if (cellr == nil)
        {
            cellr = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifierRight];
            cellr.backgroundColor = [UIColor clearColor];
            cellr.contentView.backgroundColor = [UIColor colorWithHexString:@"#F8F8F8"];
            cellr.selectionStyle = UITableViewCellSelectionStyleNone;
            cellr.contentView.clipsToBounds = YES;
            //分割线
            LineView *vLine = [[ LineView alloc]initWithFrame:CGRectMake(0, 49, SCREEN_WIDTH, 1)];
            vLine.backgroundColor = [UIColor clearColor];
            [cellr.contentView addSubview:vLine];
            
            //图标
            UIImageView *imgHead = [[UIImageView alloc] initWithFrame:CGRectMake(12, 12, 25, 25)];
            imgHead.image = [UIImage imageNamed:@"icon_huafei.png"];
            [cellr.contentView addSubview:imgHead];
            
            //标题
            UILabel *lbTitle = [[UILabel alloc] initWithFrame:CGRectMake(46, 15, 150, 20)];
            [cellr.contentView addSubview:lbTitle];
            lbTitle.font = [UIFont systemFontOfSize:15];
            lbTitle.tag = 1003;
            
            //箭头
            UIImageView *pointerview = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"arrow.png"]];
            pointerview.frame = CGRectMake(SCREEN_WIDTH - 14, 18, 7, 14);
            [cellr.contentView addSubview:pointerview];
        }
        
        NSDictionary *dic = [_lifeServiceArray objectAtIndex:indexPath.row];
        
        UILabel *lbTitle = (UILabel*)[cellr.contentView viewWithTag:1003];
        lbTitle.text = [dic objectForKey:@"category_name"];
        
        return cellr;
    }
    
    
    static NSString *CellIdentifier = @"selectCELL";
    
    ProductOrderBaseCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[ProductOrderBaseCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor colorWithHexString:@"#F8F8F8"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        //添加自定义View
        ProductOrderBaseVC * ctrl = [[ProductOrderBaseVC alloc] init];
        ctrl.delegate = self;
        ctrl.view.autoresizingMask = UIViewAutoresizingNone;
        ctrl.view.frame = CGRectMake(0, 1, SCREEN_WIDTH, cell.frame.size.height - 1);
        [cell.contentView addSubview:ctrl.view];

        cell.ctrl = ctrl;
        
        ctrl.navigationController = self.navigationController;

    }
    
    NSDictionary * dicOrderInfo = [_arrOrderList objectAtIndex:indexPath.row];
    ProductOrderBaseVC * bb = (ProductOrderBaseVC*)cell.ctrl;
    int height = [ProductOrderBaseVC getHeight:dicOrderInfo];
    bb.view.frame = CGRectMake(0, 1, SCREEN_WIDTH, height - 1);
    [bb loadData:dicOrderInfo];
    
    if (self.user_order_type == 1) {
        [bb setHideBuyView:YES];
    }else{
        [bb setHideBuyView:NO];
    }
    
    return cell;

}

- (void)gotoDetail:(NSInteger)index
{
    NSDictionary * dicOrder = [_arrOrderList objectAtIndex:index];
    orderDetailVC *orderDetailV = [[orderDetailVC alloc]init];
    orderDetailV.dicOrder = dicOrder;
    [self.navigationController pushViewController:orderDetailV animated:YES];

}

//银联支付的时候有时候会列表重叠，支付的时候刷新一下列表
-(void)payover{
    [_tableView reloadData];

}

- (void)backToHome{
    //返回主页
    [self.navigationController popToRootViewControllerAnimated:NO];
//    [MyAppDelegate.mainTab setSelectedIndex:0];
//    [MyAppDelegate.mainTab.selectImage setFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
//    
}

#pragma mark - 支付delegate
- (void)UPPayPluginResult:(NSString *)result
{
    if ([result isEqualToString:@"fail"]) {
        ZLog(@"%@失败",result);
        [self showAlert:nil withTitle:@"支付未成功，请重新支付" haveCancelButton:NO];
        //返回主页
        [self backToHome];
        
    }else if ([result isEqualToString:@"success"]){
        ZLog(@"%@成功",result);
        
        [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
        
        //新增结果页面
        PayResultVC *ctrl = [[PayResultVC alloc]init];
        ctrl.hideBackButton = YES;
        [self.navigationController pushViewController:ctrl animated:YES];
        
    }else if ([result isEqualToString:@"cancel"]){
        ZLog(@"%@取消订单",result);
        [self showAlert:nil withTitle:@"支付未成功，请重新支付" haveCancelButton:NO];
        //返回主页
        [self backToHome];
        
    }
    
}

#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)endHeaderFooterLoading{
    
    [_header endRefreshing];
    [_footer endRefreshing];
    [_footerLifeService endRefreshing];
}

- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    if (refreshView == _footer) {
        pageIndex ++;
        
    }else if (refreshView == _header){
        pageIndex = 1;
    }
    
    if (isLifeService) {
//        [self getLifeServiceOrder];
    }else{
        //获取订单列表
        [self getOrderList];

    }
}

#pragma mark -
#pragma 切换事件

-(IBAction)clickTab:(id)sender{
    
    [_btnTab1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnTab1 setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    
    [_btnTab2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnTab2 setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    
    [_btnTab3 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnTab3 setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    
    UIButton * btn = (UIButton*)sender;
    NSInteger index = btn.tag - 111;
    
    self.user_order_type = btn.tag - 110;
    
    [btn setTitleColor:[UIColor colorWithHexString:@"#D2016E"] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor colorWithHexString:@"#D2016E"] forState:UIControlStateHighlighted];

    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    
    _vLine.frame = CGRectMake( index * SCREEN_WIDTH / 3, _vLine.frame.origin.y, SCREEN_WIDTH / 3, 2);

    [UIView commitAnimations];
    
    pageIndex = 1;
    
    //获取订单列表
    [self getOrderList];
    
}




@end
