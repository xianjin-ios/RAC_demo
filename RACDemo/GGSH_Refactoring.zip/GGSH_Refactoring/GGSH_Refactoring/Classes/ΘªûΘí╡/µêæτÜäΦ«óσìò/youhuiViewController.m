//
//  youhuiViewController.m
//  GGSH
//
//  Created by heyddo on 15/3/26.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "youhuiViewController.h"
#import "MyMessageVC.h"
#import "youhuiGZViewController.h"
#import "youhuiDetailViewController.h"

@interface youhuiViewController ()<MJRefreshBaseViewDelegate>
{
    UIView *noView;
    
    //cell 白色背景
    UIImage *imgCellBg;
    
    UIImage *red1Icon;
    UIImage *red0Icon;
    UIImage *conp1Icon;
    UIImage *conp0Icon;
    
    int pageIndex;
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;

    
    UIImageView *imageAlert;
    
    NSMutableArray *_dataArray;
    NSDate *_date;
}
@end

@implementation youhuiViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"店铺优惠券";
    [self cancelTapHideKeyBoard:YES];
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _youhuiTableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _youhuiTableView;
    _footer.delegate = self;
    
    //右边消息按钮
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0.0, 0.0, 16, 16);
    [rightBtn addTarget:self action:@selector(my_message:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButtonItem2 = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    rightBarButtonItem2.style = UIBarButtonItemStylePlain;
    //判断是否要添加红点提示
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(10, -4, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [rightBarButtonItem2.customView addSubview:imageAlert];
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
//    [MyAppDelegate addRightBtn:self AndBtnArr:@[rightBarButtonItem2]];
    
    //设置图片缓存
    red1Icon = [UIImage imageNamed:@"red_1.png"];
    red0Icon = [UIImage imageNamed:@"red_0.png"];
    conp1Icon = [UIImage imageNamed:@"conp_1.png"];
    conp0Icon = [UIImage imageNamed:@"conp_0.png"];
    
    imgCellBg = [UIImage imageNamed:@"red_bg.png"];
    
    //网络请求

    pageIndex = 1;
    [self getyouhuiList];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getyouhuiList) name:@"refreshYouhuiList" object:nil];
    
    [self refreshNavBtn];
    
    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
}

- (void)refreshNavBtn{
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_MYPACKET_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_MYPACKET_VIEW"];
    
}

//规则
- (IBAction)gotoGZ:(id)sender {
    youhuiGZViewController *ctrl = [[youhuiGZViewController alloc]init];
    [self.navigationController pushViewController:ctrl animated:YES];

}

//消息
- (IBAction)my_message:(id)sender {
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];
    
}

#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(refreshView == _header) {// 下拉刷新
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        //5秒内不能重复发起网络请求，只是界面上闪动下正在加载，就1s。
        if(_date){
            NSDate *tenMiniteLater = [_date dateByAddingTimeInterval:5];
            NSDate *currentDate = [NSDate date];
            if(NSOrderedDescending == [tenMiniteLater compare:currentDate]){
                ZLog(@"ascending");
                _date = [NSDate date];
                [self performSelector:@selector(OneSecondElapse) withObject:nil afterDelay:1];
                [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
                return;
            }
            
            //网络请求
            pageIndex = 1;
            [self getyouhuiList];
            
        }else{
            _date = [NSDate date];
            //网络请求
            pageIndex = 1;
            [self getyouhuiList];
            
        }
        
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    }else if (refreshView == _footer){//上拉加载更多
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        pageIndex += 1;
        
        //网络请求
        [self getyouhuiList];
        
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        
    }
}

//1s的假loading，取消正在加载就好
- (void)OneSecondElapse{
    [self hideHUD];
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

//获取优惠券列表
-(void)getyouhuiList{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Coupon" forKey:@"Mod"];
    [dic setObject:@"MyCoupon_v1" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
    }
    [dicContent setObject:[NSNumber numberWithInt:pageIndex] forKey:@"pageindex"];
    [dicContent setObject:[NSNumber numberWithInt:20] forKey:@"pagesize"];
    [dicContent setObject:[NSNumber numberWithInt:self.flag] forKey:@"flag"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        [self hideHUD];
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if (pageIndex == 1) {
            [_dataArray removeAllObjects];
        }
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            if ([[resultDic objectForKey:@"DetailInfo"] isKindOfClass:[NSArray class]]) {
                if (pageIndex == 1) {
                    _dataArray = [[resultDic objectForKey:@"DetailInfo"] mutableCopy];
                }else{
                    NSArray *tempArr = [resultDic objectForKey:@"DetailInfo"];
                    [_dataArray addObjectsFromArray:tempArr];
                }
            }
            
        }else{
            pageIndex --;
            if (pageIndex < 1) {
                pageIndex = 1;
            }
            
            //可用的数据正好是20的时候
            if (self.flag == 1 && _dataArray.count %20 == 0) {
                NSDictionary *tempDic = nil;
                [_dataArray addObject:tempDic];
            }
        }
        
        [_youhuiTableView reloadData];
        
        if (_dataArray.count == 0 && self.flag == 2) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [_youhuiTableView addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
        
    }];
}

- (void)doTap:(UIButton *)sender{
    //获取过期卡卷
    self.flag = 2;
    pageIndex = 1;
    
// huad， bug 1084 定位首行
    [_youhuiTableView setContentOffset:CGPointMake(0, 0)];
    [self getyouhuiList];
}

#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.flag == 1 && (_dataArray.count % 20 != 0 || _dataArray.count == 0)) {
        return _dataArray.count + 1;
    }else{
        return _dataArray.count;
    }
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 56;
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    ZLog(@"%ld",indexPath.row);
    if (indexPath.row == _dataArray.count) {
        //过期卡券标识
        return;
    }
    //红包详情
    youhuiDetailViewController *ctrl = [[youhuiDetailViewController alloc]init];
    ctrl.infoDic = [_dataArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:ctrl animated:YES];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //翻页CELL
    static NSString *CellIdentifier = @"CONPCELL";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        //背景
        UIImageView *cellBg = [[UIImageView alloc]initWithFrame:CGRectMake(12, 10, _youhuiTableView.frame.size.width-24, 46)];
        cellBg.image = imgCellBg;
        cellBg.tag = 105;
        [cell.contentView addSubview:cellBg];
        
        //类别图 优惠券、折扣券等
        UIImageView *headImage = [[UIImageView alloc] initWithFrame:CGRectMake(15, 15, 34, 34)];
        headImage.tag = 101;
        [cell.contentView addSubview:headImage];
        
        UIImageView *imageAlertCell = [[UIImageView alloc]initWithFrame:CGRectMake(25, -4, 9, 9)];
        [imageAlertCell setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
        [imageAlertCell setTag:1011];
        [headImage addSubview:imageAlertCell];
        [imageAlertCell setHidden:YES];
        
        //尾部的详情背景图
        UIImageView *titView = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 93, 10, 84, 46)];
        titView.tag = 1002;
        [cell.contentView addSubview:titView];
        
        
        //优惠券名称
        UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 15, SCREEN_WIDTH - 100 - 50, 20)];
        titleLabel.tag = 102;
        titleLabel.text = @"哈根达斯优惠券";
        titleLabel.numberOfLines = 0;
        titleLabel.textAlignment = NSTextAlignmentLeft;
        titleLabel.textColor = [UIColor darkGrayColor];
        titleLabel.font = [UIFont systemFontOfSize:12];
        [cell.contentView addSubview:titleLabel];
        
        //详情
        UILabel *detailLabel = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 220, 17, 205, 30)];
        detailLabel.tag = 103;
        detailLabel.textAlignment = 2;
        detailLabel.font = [UIFont systemFontOfSize:18];
        detailLabel.textColor = [UIColor whiteColor];
        [cell.contentView addSubview:detailLabel];

        //时间
        UILabel *timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 38, SCREEN_WIDTH-145, 20)];
        timeLabel.tag = 104;
        timeLabel.text = @"有效期：2015.01.15-2015.02.10";
        timeLabel.textAlignment = 0;
        timeLabel.textColor = [UIColor lightGrayColor];
        timeLabel.font = [UIFont systemFontOfSize:11];
        [cell.contentView addSubview:timeLabel];
    }
    
    UIImageView *headImage = (UIImageView *)[cell.contentView viewWithTag:101];
    UIImageView *imageAlertCell = (UIImageView *)[cell.contentView viewWithTag:1011];
    UILabel *titleLabel = (UILabel *)[cell.contentView viewWithTag:102];
    UILabel *detailLabel = (UILabel *)[cell.contentView viewWithTag:103];
    UILabel *timeLabel = (UILabel *)[cell.contentView viewWithTag:104];
    UIImageView *titImageV = (UIImageView *)[cell.contentView viewWithTag:1002];
    UIImageView *cellBg = (UIImageView *)[cell.contentView viewWithTag:105];
    
    NSDictionary *dic;
    if (_dataArray.count != indexPath.row) {
        dic = [_dataArray objectAtIndex:indexPath.row];
    }else{
        dic = nil;
    }
    
    if (dic) {
        [headImage setHidden:NO];
        [titleLabel setHidden:NO];
        [detailLabel setHidden:NO];
        [timeLabel setHidden:NO];
        [titImageV setHidden:NO];
        [cellBg setHidden:NO];
        
        if ([[dic objectForKey:@"is_read"] integerValue] == 1) {
            [imageAlertCell setHidden:YES];
        }else{
            [imageAlertCell setHidden:NO];
        }
        
        UILabel *label = (UILabel *)[cell.contentView viewWithTag:106];
        UILabel *label1 = (UILabel *)[cell.contentView viewWithTag:107];
        UIButton *btn = (UIButton *)[cell.contentView viewWithTag:108];
        if (label) {
            [label removeFromSuperview];
            label = nil;
        }
        if (label1) {
            [label1 removeFromSuperview];
            label1 = nil;
        }
        if (btn) {
            [btn removeFromSuperview];
            btn = nil;
        }
        
        if ([[dic objectForKey:@"coupontype"] isEqualToString:@"2"]) {
            //红包
            UILabel *introLabel = (UILabel*)[cell.contentView viewWithTag:106];
            introLabel.hidden = YES;
            NSString *detailStr = [NSString stringWithFormat:@"￥%.1f",[[dic objectForKey:@"money"] doubleValue]/100];
            if(detailStr.length > 2){
                //功能：去掉四舍五入
                detailStr = [detailStr substringToIndex:(detailStr.length - 2)];
            }
            //背景
            titImageV.image = [UIImage imageNamed:@"red_001.png"];
            detailLabel.textColor = [UIColor whiteColor];
            detailLabel.font = [UIFont systemFontOfSize:18];
            
            if ([[dic objectForKey:@"is_pass"] isEqualToString:@"0"]) {
                //过期
                detailStr = @"已过期";
                titImageV.image = [UIImage imageNamed:@"red_005.png"];
                detailLabel.textColor = [UIColor darkGrayColor];
                detailLabel.font = [UIFont systemFontOfSize:12];
            }
            
            if([[dic objectForKey:@"isuse"] isEqualToString:@"0"]){
                detailStr = @"已转赠";
                titImageV.image = [UIImage imageNamed:@"red_005.png"];
                detailLabel.textColor = [UIColor whiteColor];
                detailLabel.font = [UIFont systemFontOfSize:12];
                
            }
            if([[dic objectForKey:@"isuse"] isEqualToString:@"1"]){
                detailStr = @"已使用";
                titImageV.image = [UIImage imageNamed:@"red_005.png"];
                detailLabel.textColor = [UIColor darkGrayColor];
                detailLabel.font = [UIFont systemFontOfSize:12];
                
            }
            
            headImage.image = [UIImage imageNamed:@"red_02.png"];
            
            //优惠额度
            detailLabel.text = detailStr;
            
        }else if ([[dic objectForKey:@"coupontype"] isEqualToString:@"1"]){
            //折扣
            UILabel *introLabel = (UILabel*)[cell.contentView viewWithTag:106];
            introLabel.hidden = NO;
            NSString *detailStr = [NSString stringWithFormat:@"%.1f折",[[dic objectForKey:@"discount"] doubleValue]*10];
            
            titImageV.image = [UIImage imageNamed:@"red_003.png"];
            detailLabel.textColor = [UIColor whiteColor];
            detailLabel.font = [UIFont systemFontOfSize:18];
            
            if ([[dic objectForKey:@"is_pass"] isEqualToString:@"0"]) {
                //过期
                detailStr = @"已过期";
                titImageV.image = [UIImage imageNamed:@"red_005.png"];
                detailLabel.textColor = [UIColor darkGrayColor];
                detailLabel.font = [UIFont systemFontOfSize:12];
                
            }
            
            if([[dic objectForKey:@"isuse"] isEqualToString:@"0"]){
                detailStr = @"已转赠";
                titImageV.image = [UIImage imageNamed:@"red_005.png"];
                detailLabel.textColor = [UIColor whiteColor];
                detailLabel.font = [UIFont systemFontOfSize:12];
                
            }
            if([[dic objectForKey:@"isuse"] isEqualToString:@"1"]){
                detailStr = @"已使用";
                titImageV.image = [UIImage imageNamed:@"red_005.png"];
                detailLabel.textColor = [UIColor darkGrayColor];
                detailLabel.font = [UIFont systemFontOfSize:12];
                
            }
            headImage.image = [UIImage imageNamed:@"red_01.png"];
            //优惠额度
            detailLabel.text = detailStr;
        }
        
        //优惠券名称
        titleLabel.frame = CGRectMake(50, 15, SCREEN_WIDTH - 100 - 50, 20);
        titleLabel.text = [NSString stringWithFormat:@"%@",[dic objectForKey:@"couponname"]];
        [titleLabel sizeToFit];
        if(titleLabel.frame.size.height > 40){
            //最多显示2行
            titleLabel.frame = CGRectMake(50, 15, SCREEN_WIDTH - 100 - 50, 30);
        }
        
        //时间
        NSString *startTime = [[dic objectForKey:@"starttime"] substringToIndex:10];
        NSString *endtime = [[dic objectForKey:@"endtime"] substringToIndex:10];
        timeLabel.text = [NSString stringWithFormat:@"有效期:%@-%@",startTime,endtime];
    }else{
        //增加的获取过期cell
        [headImage setHidden:YES];
        [imageAlertCell setHidden:YES];
        [titleLabel setHidden:YES];
        [detailLabel setHidden:YES];
        [timeLabel setHidden:YES];
        [titImageV setHidden:YES];
        [cellBg setHidden:YES];
        
        UILabel *label = (UILabel *)[cell.contentView viewWithTag:106];
        UILabel *label1 = (UILabel *)[cell.contentView viewWithTag:107];
        UIButton *btn = (UIButton *)[cell.contentView viewWithTag:108];

        if (!label) {
            label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 173, 56)];
        }
        [label setTextAlignment:NSTextAlignmentRight];
        [label setTextColor:[UIColor colorWithHexString:@"#b7b7b7"]];
        [label setFont:[UIFont systemFontOfSize:12]];
        [label setText:@"没有更多可用卡券了"];
        [label setTag:106];
        [cell.contentView addSubview:label];
        
        if (!label1) {
            label1 = [[UILabel alloc]initWithFrame:CGRectMake(178, 0, SCREEN_WIDTH - 178, 56)];
        }
        [label1 setTextAlignment:NSTextAlignmentLeft];
        [label1 setTextColor:[UIColor colorWithHexString:@"#f88626"]];
        [label1 setFont:[UIFont systemFontOfSize:12]];
        [label1 setText:@"查看已失效卡券》"];
        [label1 setTag:107];
        [cell.contentView addSubview:label1];
        
        if (!btn) {
            btn = [UIButton buttonWithType:UIButtonTypeCustom];
        }
        [btn setFrame:CGRectMake(178, 0, SCREEN_WIDTH - 178, 56)];
        [btn setBackgroundColor:[UIColor clearColor]];
        [btn addTarget:self action:@selector(doTap:) forControlEvents:UIControlEventTouchUpInside];
        [btn setTag:108];
        [cell.contentView addSubview:btn];
        
    }
    
    
    return cell;
    
}

//左划删除优惠
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSString *tocken = [MyAppDelegate.userInfo objectForKey:@"logintoken"];
        NSString *userid = [MyAppDelegate.userInfo objectForKey:@"id"];
        NSString *couponid = [[_dataArray objectAtIndex:indexPath.row] objectForKey:@"id"];
        
        NSDictionary *contentDic = @{@"uid":userid,@"logintoken":tocken,@"coupid":couponid,@"devicetype":@"1",@"version_name":KVERSION};
        NSDictionary *dic = @{@"Mod":@"Coupon",@"Act":@"coupDel",@"Content":contentDic};
        
        [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
            if (data == nil || error != nil) {
                NSLog(@"kong");
                return;
            }
            NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
            
            NSLog(@"str : %@",tempStr);
            
            NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            
            if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
                //重新请求数据
                [self getyouhuiList];
                
            }else{
                [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
            }
            
        }];
    }
}

@end
