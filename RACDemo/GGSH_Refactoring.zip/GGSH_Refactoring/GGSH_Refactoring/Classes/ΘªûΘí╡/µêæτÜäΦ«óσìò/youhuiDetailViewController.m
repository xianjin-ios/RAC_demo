//
//  youhuiDetailViewController.m
//  GGSH
//
//  Created by siqiyang on 15/7/8.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "youhuiDetailViewController.h"
#import "proDetailViewController.h"
#import "youhuiCell.h"
#import "mposDetailViewController.h"
#import "youhuiGZViewController.h"
#import "MyMessageVC.h"

@interface youhuiDetailViewController ()<MJRefreshBaseViewDelegate>
{
    NSMutableDictionary *_merInfo;
    
    UIImage *red1Icon;
    UIImage *red0Icon;
    UIImage *conp1Icon;
    UIImage *conp0Icon;

    
    IBOutlet UIButton *_btn1;
    IBOutlet UIButton *_btn2;
    
    BOOL isShowMore;
    
    int pageIndex;
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;

    NSMutableDictionary *couDic;
    
    IBOutlet UIImageView *messageIcon;
    UIImageView *imageAlert;
}
@property (nonatomic,strong) NSMutableArray * dataArray;
@end

@implementation youhuiDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"优惠券详情";
    [self cancelTapHideKeyBoard:YES];
    _dataArray = [[NSMutableArray alloc]init];
    //初始化字典
    _merInfo = [NSMutableDictionary dictionary];
    
    //设置图片缓存
    red1Icon = [UIImage imageNamed:@"red_1.png"];
    red0Icon = [UIImage imageNamed:@"red_0.png"];
    conp1Icon = [UIImage imageNamed:@"conp_1.png"];
    conp0Icon = [UIImage imageNamed:@"conp_0.png"];

    _header = [MJRefreshHeaderView header];
    _header.scrollView = iCollectionView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = iCollectionView;
    _footer.delegate = self;

    //解决商品没有占满屏幕无法下拉的问题
    iCollectionView.alwaysBounceVertical = YES;

    UIButton *moreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [moreBtn setFrame:CGRectMake(0, 0, 27, 27)];
    UIImageView *moreIcon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 27, 27)];
    moreIcon.image = [UIImage imageNamed:@"more.png"];
    [moreBtn setBackgroundImage:moreIcon.image forState:UIControlStateNormal];
    [moreBtn addTarget:self action:@selector(moreInfo:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarButtonItemShare = [[UIBarButtonItem alloc] initWithCustomView:moreBtn];
    self.navigationItem.rightBarButtonItem = rightBarButtonItemShare;

    ZLog(@"%@",self.infoDic);
    [self loadDetailView];
    
    pageIndex = 1;
    [self getDetailList];
    
}

- (void)loadDetailView{
    
    //发送通知刷新列表
    [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshYouhuiList" object:nil];
    [MyAppDelegate getNoReadInfo];
    
    //topView
    //背景
    UIImageView *cellBg = [[UIImageView alloc]initWithFrame:CGRectMake(12, 10, SCREEN_WIDTH-24, 46)];
    cellBg.image = [UIImage imageNamed:@"red_bg.png"];
    [topView addSubview:cellBg];
    
    //类别图 优惠券、折扣券等
    UIImageView *headImage = [[UIImageView alloc] initWithFrame:CGRectMake(15, 15, 34, 34)];
    headImage.tag = 101;
    [topView addSubview:headImage];
    
    //尾部的详情背景图
    UIImageView *titImageV = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 93, 10, 84, 46)];
    titImageV.tag = 1002;
    [topView addSubview:titImageV];
    
    //优惠券名称
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 15, SCREEN_WIDTH - 100 - 50, 15)];
    titleLabel.tag = 102;
    titleLabel.numberOfLines = 0;
    titleLabel.text = @"哈根达斯优惠券";
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.textColor = [UIColor darkGrayColor];
    titleLabel.font = [UIFont systemFontOfSize:12];
    [topView addSubview:titleLabel];
    
    UILabel *detailLabel = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 220, 17, 205, 30)];
    detailLabel.tag = 103;
    detailLabel.textAlignment = 2;
    detailLabel.textColor = [UIColor whiteColor];
    detailLabel.font = [UIFont systemFontOfSize:18];
    [topView addSubview:detailLabel];
    
    //时间
    UILabel *timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 40, SCREEN_WIDTH-145, 20)];
    timeLabel.tag = 104;
    timeLabel.text = @"有效期：2015.01.15-2015.02.10";
    timeLabel.textAlignment = NSTextAlignmentLeft;
    timeLabel.textColor = [UIColor lightGrayColor];
    timeLabel.font = [UIFont systemFontOfSize:11];
    [topView addSubview:timeLabel];
    
    //状态图
    UIImageView *stateImg = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH-75, 10, 61, 41)];
    [topView addSubview:stateImg];
    
    if ([[self.infoDic objectForKey:@"coupontype"] isEqualToString:@"2"]) {
        //背景
        NSString *detailStr = [NSString stringWithFormat:@"￥%.1f",[[self.infoDic objectForKey:@"money"] doubleValue]/100];
        if(detailStr.length > 2){
            //功能：去掉四舍五入
            detailStr = [detailStr substringToIndex:(detailStr.length - 2)];
        }
        titImageV.image = [UIImage imageNamed:@"red_001.png"];

        if ([[self.infoDic objectForKey:@"is_pass"] isEqualToString:@"0"]) {
            //过期
            detailStr = @"已过期";
            titImageV.image = [UIImage imageNamed:@"red_005.png"];
            detailLabel.textColor = [UIColor darkGrayColor];
            detailLabel.font = [UIFont systemFontOfSize:12];
            
            [_btn1 setUserInteractionEnabled:NO];
            [_btn1 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn1 setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
            [_btn2 setUserInteractionEnabled:NO];
            [_btn2 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn2 setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];

        }
        
        if([[self.infoDic objectForKey:@"isuse"] isEqualToString:@"0"]){
            detailStr = @"已转赠";
            titImageV.image = [UIImage imageNamed:@"red_005.png"];
            detailLabel.textColor = [UIColor whiteColor];
            detailLabel.font = [UIFont systemFontOfSize:12];
            [_btn1 setUserInteractionEnabled:NO];
            [_btn1 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [_btn2 setUserInteractionEnabled:NO];
            [_btn2 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];

            
        }
        if([[self.infoDic objectForKey:@"isuse"] isEqualToString:@"1"]){
            detailStr = @"已使用";
            titImageV.image = [UIImage imageNamed:@"red_005.png"];
            detailLabel.textColor = [UIColor darkGrayColor];
            detailLabel.font = [UIFont systemFontOfSize:12];
            [_btn1 setUserInteractionEnabled:NO];
            [_btn1 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn1 setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
            [_btn2 setUserInteractionEnabled:NO];
            [_btn2 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn2 setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
        }
        
        headImage.image = [UIImage imageNamed:@"red_02.png"];
        //优惠额度
        detailLabel.text = detailStr;
        
    }else if ([[self.infoDic objectForKey:@"coupontype"] isEqualToString:@"1"]){
        NSString *detailStr = [NSString stringWithFormat:@"%.1f折",[[self.infoDic objectForKey:@"discount"] doubleValue]*10];
        titImageV.image = [UIImage imageNamed:@"red_003.png"];

        if ([[self.infoDic objectForKey:@"is_pass"] isEqualToString:@"0"]) {
            //过期
            detailStr = @"已过期";
            titImageV.image = [UIImage imageNamed:@"red_005.png"];
            detailLabel.textColor = [UIColor darkGrayColor];
            detailLabel.font = [UIFont systemFontOfSize:12];
            [_btn1 setUserInteractionEnabled:NO];
            [_btn1 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn1 setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
            [_btn2 setUserInteractionEnabled:NO];
            [_btn2 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn2 setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];

        }
        
        if([[self.infoDic objectForKey:@"isuse"] isEqualToString:@"0"]){
            detailStr = @"已转赠";
            titImageV.image = [UIImage imageNamed:@"red_005.png"];
            detailLabel.textColor = [UIColor whiteColor];
            detailLabel.font = [UIFont systemFontOfSize:12];
            [_btn1 setUserInteractionEnabled:NO];
            [_btn1 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [_btn2 setUserInteractionEnabled:NO];
            [_btn2 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            
        }
        if([[self.infoDic objectForKey:@"isuse"] isEqualToString:@"1"]){
            detailStr = @"已使用";
            titImageV.image = [UIImage imageNamed:@"red_005.png"];
            detailLabel.textColor = [UIColor darkGrayColor];
            detailLabel.font = [UIFont systemFontOfSize:12];
            [_btn1 setUserInteractionEnabled:NO];
            [_btn1 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn1 setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
            [_btn2 setUserInteractionEnabled:NO];
            [_btn2 setBackgroundColor:[UIColor lightGrayColor]];
            [_btn2 setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
            
        }
        
        headImage.image = [UIImage imageNamed:@"red_01.png"];
        //优惠额度
        detailLabel.text = detailStr;
    }
    
    //优惠券名称
    titleLabel.text = [NSString stringWithFormat:@"%@",[self.infoDic objectForKey:@"couponname"]];
    [titleLabel sizeToFit];
    if(titleLabel.frame.size.height > 30){
        titleLabel.frame = CGRectMake(50, 15, SCREEN_WIDTH - 100 - 50, 30);
    }

    
    //时间
    NSString *startTime = [[self.infoDic objectForKey:@"starttime"] substringToIndex:10];
    NSString *endtime = [[self.infoDic objectForKey:@"endtime"] substringToIndex:10];
    timeLabel.text = [NSString stringWithFormat:@"有效期:%@-%@",startTime,endtime];
    
    //二维码
    NSString *codeIconUrl = [self.infoDic objectForKey:@"codeurl"];
    [codeIcon XK_setImageWithURL:[NSURL URLWithString:codeIconUrl] placeholderImage:nil];
    
}


- (void)loadMiddleView{
    
    //店铺名称
    lbShopName.text = [_merInfo objectForKey:@"shopname"];
    
    //店铺名称可以换行
    NSString *shopNameStr = [_merInfo objectForKey:@"shopname"];
    CGSize curSize = lbShopName.frame.size;
    CGSize ss = [shopNameStr sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(curSize.width, MAXFLOAT) lineBreakMode:NSLineBreakByWordWrapping];
    if(ss.height > 21){
        lbShopName.numberOfLines = 0;
        lbShopName.frame = CGRectMake(lbShopName.frame.origin.x, lbShopName.frame.origin.y, curSize.width, 40);
    }

    //店铺logo
    NSString *shopIconUrl = [_merInfo objectForKey:@"listpic"];
    [shopIcon XK_setImageWithURL:[NSURL URLWithString:shopIconUrl] placeholderImage:nil];

}

- (void)moreInfo:(UIButton *)sender{
    isShowMore = !isShowMore;
    if (isShowMore == YES) {
        [showMoreView setFrame:CGRectMake(200, 50, 106, 154)];
        UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapTohideMoreView:)];
        [self.view addGestureRecognizer:tap1];
        [MyAppDelegate.window addSubview:showMoreView];
        if (MyAppDelegate.isHaveNoReadMessage) {
            if (!imageAlert) {
                imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(16, 5, 9, 9)];
            }
            [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
            [messageIcon addSubview:imageAlert];
            
        }else{
            if (imageAlert) {
                [imageAlert removeFromSuperview];
                imageAlert = nil;
            }
        }
    }else{
        [self hideMoreView];
    }
}
- (void)tapTohideMoreView:(UITapGestureRecognizer *)tap1{
    
    [self hideMoreView];
    [self.view removeGestureRecognizer:tap1];
    
}
- (void)hideMoreView{
    isShowMore = NO;
    
    [UIView beginAnimations:nil context:nil];
    [showMoreView setFrame:CGRectMake(200, 50, 106, 0)];
    [UIView commitAnimations];
    
    [showMoreView removeFromSuperview];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_PACKETDETAIL_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self hideMoreView];

    //友盟统计
    [MobClick endLogPageView:@"G_PACKETDETAIL_VIEW"];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - network
//获取详情
-(void)getDetailList{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Coupon" forKey:@"Mod"];
    [dic setObject:@"couponDetails" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
    }
    [dicContent setObject:[self.infoDic objectForKey:@"id"] forKey:@"id"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    //??? 详情，怎么有页数
    [dicContent setObject:[NSNumber numberWithInt:pageIndex] forKey:@"pageindex"];
    [dicContent setObject:[NSNumber numberWithInt:12] forKey:@"pagesize"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    //转换为NSString
    NSData* result = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonString = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
    ZLog(@"jsonString = %@",jsonString);
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
           [self hideHUD];
        
          ZLog(@"%@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        ZLog(@"registe info:%@",[resultDic objectForKey:@"Message"]);
        
        if (pageIndex == 1) {
            [self.dataArray removeAllObjects];
        }
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            if ([[resultDic objectForKey:@"DetailInfo"] isKindOfClass:[NSDictionary class]]) {
                couDic = [[[resultDic objectForKey:@"DetailInfo"] objectForKey:@"coupon"] mutableCopy];
                _merInfo = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"shopinfo"];
                
                if (pageIndex == 1) {
                    self.dataArray = [[[resultDic objectForKey:@"DetailInfo"] objectForKey:@"goodslist"] mutableCopy];
                }else{
                    NSArray *tempArr = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"goodslist"];
                    [self.dataArray addObjectsFromArray:tempArr];
                }
            }
            
        }else{
            pageIndex --;
            if (pageIndex < 1) {
                pageIndex = 1;
            }
        }
        
        //设置商户信息
        [self loadMiddleView];
        
        [iCollectionView reloadData];
        
    }];
}

#pragma mark - 刷新的代理方法进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(0 == [xkNetwork checkNetStatus]){
        [self showalertString:@"无网络连接"];
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        return;
    }
    
    if(refreshView == _header) {// 下拉刷新
        pageIndex = 1;
        [self getDetailList];
    }else if (refreshView == _footer){//上拉加载更多
        if(self.dataArray.count%12 == 0){
            pageIndex += 1;
            [self getDetailList];
        }
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    return;
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section;
{
    return self.dataArray.count;
}

//边框
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    UINib *nib = [UINib nibWithNibName:@"youhuiCell" bundle:[NSBundle mainBundle]];
    [cv registerNib:nib forCellWithReuseIdentifier:@"youhuiCell"];
    youhuiCell *cell = [cv dequeueReusableCellWithReuseIdentifier:@"youhuiCell" forIndexPath:indexPath];
    
    ZLog(@"%@",self.dataArray);
    NSDictionary *dic = [self.dataArray objectAtIndexedSubscript:indexPath.row];
    
    cell.goodsLabel.text = [dic objectForKey:@"goodsname"];
    cell.goodsLabel.textColor = [UIColor colorWithHexString:@"#707070"];
    NSString *dicPath = [dic objectForKey:@"listpic"];
    [cell.goodsIcon XK_setImageWithURL:[NSURL URLWithString:dicPath] placeholderImage:nil];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    //商品详情
    proDetailViewController *proV = [[proDetailViewController alloc]init];
    proV.detailInfo = [self.dataArray objectAtIndex:indexPath.row];
    proV.proId = [[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"id"];
    proV.merDic = _merInfo;
    [self.navigationController pushViewController:proV animated:YES];
    
}

- (IBAction)gotoShop:(id)sender {
    
    mposDetailViewController *detailV = [[mposDetailViewController alloc]init];
    detailV.merDic = _merInfo;
    [self.navigationController pushViewController:detailV animated:YES];

}

//我要转赠  －  微信分享
- (IBAction)giveToOthers:(id)sender{
    //分享的内容标题是＊＊优惠券＋＊＊元
    UILabel *lbTit = (UILabel*)[topView viewWithTag:102];
    UILabel *lbDet = (UILabel*)[topView viewWithTag:103];
    NSString *shareStr = [NSString stringWithFormat:@"%@%@", lbTit.text, lbDet.text];
    
    //这个url将由尤杨提供
    NSString *shareUrl = [NSString stringWithFormat:@"%@",[couDic objectForKey:@"couponshareurl"]];
    
    //折扣券和红包传递的图片不同
    NSString *imagePath = @"red_02.png";
    if([[self.infoDic objectForKey:@"coupontype"] isEqualToString:@"1"]){
        imagePath = @"red_01.png";
    }
    
    NSDictionary *shareDic = [NSDictionary dictionaryWithObjectsAndKeys:
                              shareStr,@"title",
                              imagePath,@"image",
                              @"我抢到一张优惠券转赠给你，赶快来领取吧",@"content",
                              shareUrl,@"url",
                              nil];
    
    [MyAppDelegate shareContextOnlyWechat:shareDic];
}

- (IBAction)toHome:(id)sender {
    
    [self hideMoreView];
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}

- (IBAction)toMessage:(id)sender {
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];

}

- (IBAction)delThis:(id)sender {
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Coupon" forKey:@"Mod"];
    [dic setObject:@"coupDel" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
    }
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dicContent setObject:[self.infoDic objectForKey:@"id"] forKey:@"coupid"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    //转换为NSString
    NSData* result = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonString = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
    [self showHUD];
    ZLog(@"jsonString = %@",jsonString);
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
         [self hideHUD];
        ZLog(@"responseString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        
   
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        ZLog(@"registe info:%@",[resultDic objectForKey:@"Message"]);
        ZLog(@"%@",resultDic);
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            [self showalertString:@"删除成功"];
            
            //发送通知刷新数据
            [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshYouhuiList" object:nil];
            [self.navigationController popViewControllerAnimated:YES];
            
        }else{
            [self showalertString:[resultDic objectForKey:@"Message"]];
        }
    }];
}

- (IBAction)gotoGZ:(id)sender {
    youhuiGZViewController *ctrl = [[youhuiGZViewController alloc]init];
    [self.navigationController pushViewController:ctrl animated:YES];

}

@end
