//
//  mySubOrderVC.m
//  GGSH
//  myOrderVC的分身，把话费、京东E卡、爱奇艺的订单列表独立到这个页面。普通订单保留在myOrderVC
//  Created by STAR on 16/10/25.
//  Copyright © 2016年 GYL. All rights reserved.
//

#import "mySubOrderVC.h"
#import "oneOrderVC.h"
#import "MJRefresh.h"
#import "ProductOrderBaseVC.h"
#import "LifeServiceOrderDetailVC.h"
#import "BookSuccessViewController.h"
#import "TelephoneFareCell.h"
#import "PayResultVC.h"

@interface mySubOrderVC ()<UITableViewDataSource, UITableViewDelegate,toDetailDelegate, MJRefreshBaseViewDelegate,PAY_DELEGATE,TELEPHONE_PAY,UPPayPluginDelegate>{
    //生活服务类订单
    IBOutlet UITableView * _tableLifeService;
    
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    
    //生活服务的背景，
    NSMutableArray *_lifeServiceArray;
    int lifePageIndex;
    
    //无数据提示
    UIView *noView;
    
    //订单id，取消订单时使用
    NSString *orderId;
    
    BOOL _bNeedRefresh;
}


@end

@implementation mySubOrderVC

- (void)setNeedRefresh : (BOOL) bRefresh;{
    _bNeedRefresh = bRefresh;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if(_bNeedRefresh){
        [self getServiceOrder];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _lifeServiceArray = [[NSMutableArray alloc] init];
    
    [self cancelTapHideKeyBoard:YES];
    //下拉刷新
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _tableLifeService;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _tableLifeService;
    _footer.delegate = self;
    
    [self getServiceOrder];
    //注册通知，刷新列表
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshProductList:) name:@"RefreshProductionList" object:nil];
}
#pragma mark --- 刷新商品列表
- (void)refreshProductList:(NSNotification *)notify{
    
    NSString *indexRow = notify.object;
    [_lifeServiceArray removeObjectAtIndex:indexRow.integerValue];
    [_tableLifeService reloadData];
    
}
#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)endHeaderFooterLoading{
    [_header endRefreshing];
    [_footer endRefreshing];
}

- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    if (refreshView == _footer) {
        lifePageIndex ++;
        
    }else if (refreshView == _header){
        lifePageIndex = 1;
    }
    
    [self getServiceOrder];
    
}

#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _lifeServiceArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 141;
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic = [_lifeServiceArray objectAtIndex:indexPath.row];
    LifeServiceOrderDetailVC *vc = [[LifeServiceOrderDetailVC alloc] init];
    vc.brandCode = _orderDic[@"category_code"];
    vc.indexRow = indexPath.row;
    vc.subOrderdelegate = self;
    vc.dicData = dic;
    [self.navigationController pushViewController:vc animated:YES];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic = [_lifeServiceArray objectAtIndex:indexPath.row];
    
    static NSString *CellIdentifiers = @"fareCell";
    TelephoneFareCell *cell = [_tableLifeService dequeueReusableCellWithIdentifier:CellIdentifiers];
    if(nil == cell){
        [_tableLifeService registerNib:[UINib nibWithNibName:@"TelephoneFareCell" bundle:nil] forCellReuseIdentifier:CellIdentifiers];
        
        cell = [_tableLifeService dequeueReusableCellWithIdentifier:CellIdentifiers];
    }
    cell.delegate = self;
    if ([[dic objectForKey:@"payway"]isEqualToString:@"6"]) {
        cell.payWay = @"WX";//微信支付
    }
    else{
        cell.payWay = @"default";//其他
    }
    //小图标
    if(![self.ordertype isEqualToString:@"1"]){
        cell.headImageView.superview.backgroundColor = [UIColor clearColor];
        cell.headImageView.superview.layer.borderWidth = ONEPIXL;
        cell.headImageView.superview.layer.borderColor = [UIColor lightGrayColor].CGColor;
    }
    [cell.headImageView XK_setImageWithURL:[NSURL URLWithString:[dic objectForKey:@"listpic"]] placeholderImage:nil];

    
    cell.dicData = dic;
    
    //设置cell的数据  //1 待付款 2 支付失败 3 支付成功
    //shipping_status这个是话费充值的新的判断字段，下期修改
    cell.btnCancel.hidden = YES;
    if([[dic objectForKey:@"tradestatus"] isEqualToString:@"1"]){
        cell.lbStatus.text = @"待付款";
        cell.btnPay.hidden = NO;
        cell.btnCancel.hidden = NO;
    }else if([[dic objectForKey:@"tradestatus"] isEqualToString:@"2"]){
        cell.lbStatus.text = @"支付失败";
        cell.btnPay.hidden = NO;
        cell.btnCancel.hidden = NO;
    }else if([[dic objectForKey:@"tradestatus"] isEqualToString:@"3"]){
        cell.lbStatus.text = @"已完成";
        cell.btnPay.hidden = YES;
        cell.btnCancel.hidden = YES;
        if(![self.ordertype isEqualToString:@"1"]){
            if([[dic objectForKey:@"shipping_status"] isEqualToString:@"0"] ||
               [[dic objectForKey:@"shipping_status"] isEqualToString:@"3"]){
                cell.lbStatus.text = @"备货中";
            }else if([[dic objectForKey:@"shipping_status"] isEqualToString:@"1"]||
                     [[dic objectForKey:@"shipping_status"] isEqualToString:@"2"]){
                cell.lbStatus.text = @"发货成功";
            }else if([[dic objectForKey:@"shipping_status"] isEqualToString:@"4"]){
                cell.lbStatus.text = @"发货失败";
            }
        }
    }
    
    cell.lbTitle.text = [dic objectForKey:@"goodsname"];
    double money = ((NSString*)[dic objectForKey:@"goodsprice"]).doubleValue;
    double number = [[dic objectForKey:@"goodsnum"] doubleValue];
    cell.lbMoney.text = [NSString stringWithFormat:@"¥%.2f",money/100.0f];
    cell.lbTotMoney.text = [NSString stringWithFormat:@"¥%.2f",money*number/100.0f];
    cell.lbNum.text = [NSString stringWithFormat:@"x%@",[dic objectForKey:@"goodsnum"]];
    return cell;
}

//获取订单
- (void)getServiceOrder{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"pUserOrderEcp" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    //1:话费订单 2:京东E卡 3:爱奇艺
    [dicContent setObject:self.ordertype forKey:@"order_sub_type"];
    [dicContent setObject:[NSNumber numberWithInt:lifePageIndex] forKey:@"pageindex"];
    [dicContent setObject:@"40" forKey:@"pagesize"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        [self hideHUD];
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if (lifePageIndex == 1) {
            [_lifeServiceArray removeAllObjects];
        }
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            //??此处需要判断翻页
            if (lifePageIndex == 1) {
                _lifeServiceArray = [[resultDic objectForKey:@"DetailInfo"] mutableCopy];
            }else
            {
                NSArray *tempArr = [resultDic objectForKey:@"DetailInfo"];
                [_lifeServiceArray addObjectsFromArray:tempArr];
            }
        }
        else{
            lifePageIndex --;
            if (lifePageIndex < 0) {
                lifePageIndex = 1;
            }
            
        }
        
        [_tableLifeService reloadData];
        [self endHeaderFooterLoading];
        
        if (_lifeServiceArray.count == 0) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [_tableLifeService addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
        
    }];
}

#pragma mark - 虚拟累产品支付、取消代理及方法
-(void)telephonePay:(NSDictionary *)dic{
    ZLog(@"%@",dic);
    if (dic != nil) {
        NSMutableDictionary *idic = [NSMutableDictionary dictionaryWithDictionary:dic];
        [idic setObject:_orderDic[@"category_code"] forKey:@"brand_code"];
        [idic setObject:dic[@"goodsname"] forKey:@"product_name"];
        [self payEcpWith:idic];
    }
}

//订单取消
- (void)cancelOrder:(NSDictionary *)dic{
    ZLog(@"%@",dic);
    if (dic != nil) {
        orderId = [[dic objectForKey:@"num"] copy];
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"是否取消该订单？" message:nil delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
        [alert show];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(1 == buttonIndex){
        [self deleteOrder:orderId];
    }
}

//微信支付
- (void)payOnlineWXWithInfo:(NSDictionary *)dic
{
    [self payOnlineByWX:dic withBrandCode:[_orderDic objectForKey:@"category_code"]];
}

//取消订单接口
- (void)deleteOrder:(NSString *)orderIds{
    [self showHUD];
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Porder" forKey:@"Mod"];
    [dic setObject:@"userCancelEcpOrder" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
        
    }
    [dicContent setObject:[_orderDic objectForKey:@"category_code"] forKey:@"brand_code"];
    [dicContent setObject:orderIds forKey:@"num"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    [self showHUD];
    
    [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        [self hideHUD];
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            for(NSDictionary *dic in _lifeServiceArray){
                if([[dic objectForKey:@"num"] isEqualToString:orderIds]){
                    //删除订单
                    [_lifeServiceArray removeObject:dic];
                    if(_lifeServiceArray.count == 0){
                        //无数据提示
                        if (!noView) {
                            noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                            noView.backgroundColor = [UIColor clearColor];
                            noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                            UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                            bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                            UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                            labela.backgroundColor = [UIColor clearColor];
                            labela.text = @"暂无内容";
                            labela.textAlignment = 1;
                            labela.font = [UIFont systemFontOfSize:15];
                            labela.textColor = [UIColor lightGrayColor];
                            [bigbeen addSubview:labela];
                            [noView addSubview:bigbeen];
                            [_tableLifeService addSubview:noView];
                        }
                    }
                    else{
                        if (noView != nil) {
                            [noView removeFromSuperview];
                            noView = nil;
                        }
                        
                    }
                    [_tableLifeService reloadData];
                    break;
                }
            }
        }
        
    }];
    
}

#pragma mark - 支付delegate
- (void)UPPayPluginResult:(NSString *)result
{
    if ([result isEqualToString:@"fail"]) {
        ZLog(@"%@失败",result);
        [self showAlert:nil withTitle:@"支付未成功，请重新支付" haveCancelButton:NO];
        //返回主页
        [self backToHome];
        
    }else if ([result isEqualToString:@"success"]){
        ZLog(@"%@成功",result);
        
        [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
        
        //新增结果页面
        PayResultVC *ctrl = [[PayResultVC alloc]init];
        ctrl.hideBackButton = YES;
        [self.navigationController pushViewController:ctrl animated:YES];
        
    }else if ([result isEqualToString:@"cancel"]){
        ZLog(@"%@取消订单",result);
        [self showAlert:nil withTitle:@"支付未成功，请重新支付" haveCancelButton:NO];
        
    }
}

- (void)backToHome{
    //返回主页
    [self.navigationController popToRootViewControllerAnimated:NO];
    [MyAppDelegate setTabSelect:0];
    
}

@end
