//
//  orderHeaderVC.h
//  GGSH
//
//  Created by siqiyang on 15/9/22.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface orderHeaderVC : UIViewController
{
    IBOutlet UIView *_baseView;
    
    IBOutlet UILabel *_orderNum;
    IBOutlet UILabel *_orderStatus;
    IBOutlet UILabel *_lbShouOrQU;
    IBOutlet UILabel *_acceptName;
    IBOutlet UIView *_phoneView;
    IBOutlet UILabel *_contact;
    IBOutlet UIView *_addressView;
    IBOutlet UILabel *_lbShouOrQuAddress;
    IBOutlet UILabel *_address;
    IBOutlet UIView *_payInfo;
    IBOutlet UILabel *_payList;
    IBOutlet UILabel *_payList2;
    
}

//获取高度
+(double)getHeight:(NSDictionary *) dicInfo;

-(void)loadData:(NSDictionary *)dicInfo AndPayStatus:(NSString *)paystatus;

@end
