//
//  cardCellBase.h
//  GGSH
//
//  Created by huadong on 16/1/6.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CHECKDETAIL <NSObject>

- (void)changeCheck:(NSString *)check withIndex:(NSInteger )index;

@end
@interface cardCellBase : UIViewController

@property (nonatomic,assign) id <CHECKDETAIL> delegate;

@property (nonatomic, strong) UINavigationController * navigationController;

//获取高度
+(double)getHeight:(NSDictionary *) dicInfo;

-(void)loadData:(NSDictionary *)dicInfo withIndex:(NSInteger )index;

@end
