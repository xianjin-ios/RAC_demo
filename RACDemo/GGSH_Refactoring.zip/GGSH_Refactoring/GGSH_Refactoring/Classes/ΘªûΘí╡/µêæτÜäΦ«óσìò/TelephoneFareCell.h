//
//  TelephoneFareCell.h
//  GGSH
//
//  Created by STAR on 15/10/9.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TELEPHONE_PAY <NSObject>

-(void)telephonePay:(NSDictionary *)dic;
-(void)cancelOrder:(NSDictionary *)dic;
- (void)payOnlineWXWithInfo:(NSDictionary *)dic;//微信支付
@end
@interface TelephoneFareCell : UITableViewCell{
    

}

@property (nonatomic,retain) NSDictionary *dicData;

@property (nonatomic,assign) id<TELEPHONE_PAY> delegate;

@property (nonatomic, strong)    IBOutlet UILabel *lbStatus; /**< 交易状态 */
@property (nonatomic, strong)    IBOutlet UILabel *lbTitle;  /**< 订单标题 */
@property (nonatomic, strong)    IBOutlet UILabel *lbMoney;  /**< 金额 */
@property (nonatomic, strong)    IBOutlet UILabel *lbTotMoney;  /**< 总价，当前和金额一致 */
@property (nonatomic, strong)    IBOutlet UILabel *lbNum;   /**< 购买数量*/

@property (nonatomic, strong)    IBOutlet UIButton *btnPay;  /**< 支付按钮 */
@property (nonatomic, strong)    IBOutlet UIButton *btnCancel;  /**< 取消 */

@property (nonatomic, strong)  NSString *payWay;//支付方式
@property (nonatomic, strong) IBOutlet UIImageView *headImageView;  /**< 京东E卡图标、 爱奇艺图标 ... */

@end
