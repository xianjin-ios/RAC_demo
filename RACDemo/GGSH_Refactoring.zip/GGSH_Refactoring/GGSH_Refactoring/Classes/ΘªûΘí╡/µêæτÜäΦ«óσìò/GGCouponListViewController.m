//
//  GGCouponListViewController.m
//  GGSH
//
//  Created by siqiyang on 16/3/22.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import "GGCouponListViewController.h"
#import "GGCouponDetailViewController.h"

@interface GGCouponListViewController ()<UITableViewDataSource,UITableViewDelegate,MJRefreshBaseViewDelegate>
{
    int pageIndex;
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    
    NSMutableArray *_dataArray;
}

@property (nonatomic,strong) NSMutableArray *ggDataArr;
@end

@implementation GGCouponListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"逛逛优惠券";
     pageIndex = 1;
    [self cancelTapHideKeyBoard:YES];
    [self getDatafromNet];
    self.ggDataArr = [[NSMutableArray alloc]init];
    self.ggCouponListTableView.tableFooterView = [[UIView alloc]init];
    self.ggCouponListTableView.tableHeaderView = [[UIView alloc]init];
    self.ggCouponListTableView.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
    _header = [MJRefreshHeaderView header];
    _header.scrollView = self.ggCouponListTableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = self.ggCouponListTableView;
    _footer.delegate = self;

   
}
#pragma mark - 刷新的代理方法进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(0 == [MyAppDelegate reachBility]){
        [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        return;
    }
    
    if(refreshView == _header) {// 下拉刷新
        pageIndex = 1;
        [self getDatafromNet];
    }else if (refreshView == _footer){//上拉加载更多
        if(_dataArray.count%10 == 0){//每页有10个数据
            pageIndex += 1;
            [self getDatafromNet];
        }
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    return;
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

- (void)getDatafromNet{
    NSLog(@"%d页",pageIndex);
    NSDictionary *dic = @{
                 @"Mod":@"Coupon",
                 @"Act":@"ggCouponList",
                 @"Content":@{
                         @"version_name":KVERSION,
                        @"uid":[MyAppDelegate.userInfo objectForKey:@"id"],
                        @"logintoken":[MyAppDelegate.userInfo objectForKey:@"logintoken"],

                         @"pageindex":[NSString stringWithFormat:@"%d", pageIndex],
                         @"pagesize":@"20",
                         }
                 };
    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        [self hideHUD];
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* responseDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if ([[responseDic objectForKey:@"Code"]isEqualToString:@"0000"]) {
            //请求成功
            NSArray *arr = [responseDic objectForKey:@"DetailInfo"];
            if (pageIndex == 1) {
                [_ggDataArr removeAllObjects];
                [_ggDataArr addObjectsFromArray:arr];
            }
            
            else{
                if (arr.count == 0) {
                    [self showAlert:nil withTitle:@"没有更多内容了！" haveCancelButton:NO];
                }
                else
                    [arr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                        [self.ggDataArr addObject:obj];
                    }];
                
            }
            if (self.ggDataArr.count == 0) {
                //无数据时的提示
                [self isShowNoDataView:YES];
                
            }
            [self.ggCouponListTableView reloadData];
            [self hideHUD];
        }
        else{
            
            [self showAlert:nil withTitle:responseDic[@"Message"] haveCancelButton:NO];
        }
        
    }];
}
//没有数据时的提示

- (void)isShowNoDataView:(BOOL)isShow{
    if (isShow == NO) {
        if (_noView) {
            [_noView removeFromSuperview];
            _noView = nil;
        }
    }
    else
        if (!_noView) {
            _noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
            _noView.backgroundColor = [UIColor clearColor];
            _noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
            UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
            bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
            UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
            labela.backgroundColor = [UIColor clearColor];
            labela.text = @"暂无内容";
            labela.textAlignment = 1;
            labela.font = [UIFont systemFontOfSize:15];
            labela.textColor = [UIColor lightGrayColor];
            [bigbeen addSubview:labela];
            [_noView addSubview:bigbeen];
            [self.ggCouponListTableView addSubview:_noView];
        }
    
}


#pragma  mark -- 代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.ggDataArr.count;

    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    GGCouponDetailViewController *detailVC = [[GGCouponDetailViewController alloc]init];
    detailVC.couponId = [[self.ggDataArr objectAtIndex:indexPath.row] objectForKey:@"id"];
    [self.navigationController pushViewController:detailVC animated:YES];
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellID = @"GGCoupon";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
       //底层的imagView
        UIImageView *baseImageView = [[UIImageView alloc]initWithFrame:CGRectMake(5, 10, SCREEN_WIDTH - 10, 80)];
        [cell.contentView addSubview:baseImageView];
        baseImageView.tag = 11;
        //优惠券名称
        UILabel *productLabel = [[UILabel alloc]initWithFrame:CGRectMake(60, 10, SCREEN_WIDTH *0.6, 15)];
        productLabel.font = [UIFont systemFontOfSize:15];
        productLabel.tag = 22;
        [baseImageView addSubview:productLabel];
        
        //使用状态
        UILabel *stateLabel = [[UILabel alloc]initWithFrame:CGRectMake(65, 38, SCREEN_WIDTH *0.3, 15)];
        stateLabel.textColor = [UIColor colorWithHexString:@"b0b0b0"];
        stateLabel.font = [UIFont systemFontOfSize:10];
        stateLabel.tag = 33;
        [baseImageView addSubview:stateLabel];
        
        //优惠券价格
        UILabel *priceLabel = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH *0.6, 16, SCREEN_WIDTH * 0.4-20, 40)];
    
        priceLabel.textAlignment = NSTextAlignmentRight;
       priceLabel.font = [UIFont systemFontOfSize:23];
        priceLabel.tag = 44;
        [baseImageView addSubview:priceLabel];
        
        
        //时间
        UILabel * timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH * 0.5 - 20, 60, SCREEN_WIDTH *0.5 +15, 20)];
        timeLabel.tag = 55;
        timeLabel.font = [UIFont systemFontOfSize:10];
        timeLabel.textColor = [UIColor colorWithHexString:@"#b0b0b0"];
        [baseImageView addSubview:timeLabel];
    
    }
    NSDictionary *ggCouponDic = [self.ggDataArr objectAtIndex:indexPath.row];
    
    UIImageView *baseImageView = (UIImageView *)[cell.contentView viewWithTag:11];
   
    
     //优惠券名称
    UILabel *productLabel = (UILabel *)[baseImageView viewWithTag:22];
   
    productLabel.text = [NSString stringWithFormat:@"%@", ggCouponDic[@"couponname"]];
    UILabel *priceLabel = (UILabel *)[baseImageView viewWithTag:44];
    //价格颜色
    //设定base 的状态
    CGFloat money = [ggCouponDic[@"money"] floatValue]/100.00;
    NSString *price = [NSString stringWithFormat:@"%.0f元",money];
    priceLabel.text = [NSString stringWithFormat:@"%@",price];
    
    UILabel *stateLabel = (UILabel *)[baseImageView viewWithTag:33];
    //判断优惠券状态 isuse 是否使用 0已转增 1使用 2未使用
    if ([ggCouponDic[@"isuse"] isEqualToString:@"0"]) {
         stateLabel.text = [NSString stringWithFormat:@"%@",@"已转赠"];
    }
    if ([ggCouponDic[@"isuse"] isEqualToString:@"1"]) {
        priceLabel.textColor = [UIColor colorWithHexString:@"#b0b0b0"];
         baseImageView.image = [UIImage imageNamed:@"coupon_cannotUse"];
        stateLabel.text = [NSString stringWithFormat:@"%@",@"已使用"];
    }
    if ([ggCouponDic[@"isuse"] isEqualToString:@"2"]) {
        if ([ggCouponDic[@"is_pass"] isEqualToString:@"1"]) {//is_pass 是否过期 0过期 1不过期
            priceLabel.textColor = [UIColor colorWithHexString:@"#d2016e"];
            baseImageView.image = [UIImage imageNamed:@"coupon_canUse"];
            stateLabel.text = [NSString stringWithFormat:@"%@",@"未使用"];
        }
        else{
        priceLabel.textColor = [UIColor colorWithHexString:@"#b0b0b0"];
        stateLabel.text = [NSString stringWithFormat:@"%@",@"已过期"];
        baseImageView.image = [UIImage imageNamed:@"coupon_cannotUse"];
        }
    }
    
   //可用时间
    UILabel *timeLabel = (UILabel *)[baseImageView viewWithTag:55];
    timeLabel.text = [NSString stringWithFormat:@"可用时间：%@-%@", ggCouponDic[@"starttime"],ggCouponDic[@"endtime"]];
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 90;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
