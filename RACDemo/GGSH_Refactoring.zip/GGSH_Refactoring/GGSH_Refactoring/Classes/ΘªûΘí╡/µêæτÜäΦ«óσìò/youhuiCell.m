//
//  youhuiCell.m
//  GGSH
//
//  Created by siqiyang on 15/7/9.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "youhuiCell.h"

@implementation youhuiCell

- (void)awakeFromNib {
    // Initialization code
}

@end
