//
//  youhuiViewController.h
//  GGSH
//
//  Created by heyddo on 16/10/25.
//  Copyright (c) 2016年 YL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface youhuiViewController : BaseViewController
{
    IBOutlet UITableView *_youhuiTableView;
    
}
//1:可以使用 2：不能使用
@property (nonatomic,assign)int flag;

@end
