//
//  ProductOrderBaseVC.m
//  GGSH
//
//  Created by 任春宁 on 15/7/3.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "ProductOrderBaseVC.h"
#import "mposDetailViewController.h"
#import "chatVC.h"
//#import "orderResultViewController.h"

@interface ProductOrderBaseVC (){
    //是否有预付金额
    BOOL isPrePay;
    
}

@end

@implementation ProductOrderBaseVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self cancelTapHideKeyBoard:YES];
    UIView * v1 = [self.view viewWithTag:101];
    v1.layer.borderWidth = 0.5f;
    v1.layer.borderColor = [UIColor lightGrayColor].CGColor;
    v1.layer.cornerRadius = 4;
    
    UIView * v2 = [self.view viewWithTag:102];
    v2.layer.borderWidth = 0.5f;
    v2.layer.borderColor = [UIColor colorWithHexString:@"#F80074"].CGColor;
    v2.layer.cornerRadius = 4;

    [line1 setFrame:CGRectMake(0, 34, SCREEN_WIDTH, 0.5)];
    [line2 setFrame:CGRectMake(0, 0, SCREEN_WIDTH, 0.5)];
    
}


#pragma mark - uitableview
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
     NSArray * _arrGoods = [_dicOrderInfo objectForKey:@"goodsDetail"];
    
    return _arrGoods.count;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 59;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    //翻页CELL
    static NSString *CellIdentifier = @"COMMONCELL";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        int left = 18;
        int top = 5;
        
        //缩略图
        UIImageView * imgViewThumb = [[UIImageView alloc] init];
        imgViewThumb.tag = 11;
        imgViewThumb.layer.borderColor = [UIColor colorWithHexString:@"#dfdfdf"].CGColor;
        imgViewThumb.layer.borderWidth = 0.5f;
        
        imgViewThumb.frame = CGRectMake(left, top, 45, 45);
        imgViewThumb.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:imgViewThumb];
        
        left += 45 + 8;
        //产品名称
        UILabel * lbProductName = [[UILabel alloc] init];
        lbProductName.tag = 12;
        lbProductName.backgroundColor = [UIColor clearColor];
        lbProductName.font = [UIFont systemFontOfSize:13];
        lbProductName.frame = CGRectMake(left, top, 160, 45);
        lbProductName.numberOfLines = 0;
        lbProductName.lineBreakMode = NSLineBreakByCharWrapping;
        [cell.contentView addSubview:lbProductName];
        
        //价格
        UILabel * lbPrice = [[UILabel alloc] init];
        lbPrice.tag = 13;
        lbPrice.textAlignment = NSTextAlignmentRight;
        lbPrice.backgroundColor = [UIColor clearColor];
        lbPrice.font = [UIFont systemFontOfSize:13];
        lbPrice.frame = CGRectMake(SCREEN_WIDTH - 160, top, 150, 18);
        [cell.contentView addSubview:lbPrice];
        
        //数量
        UILabel * lbNum = [[UILabel alloc] init];
        lbNum.tag = 14;
        lbNum.textAlignment = NSTextAlignmentRight;
        lbNum.backgroundColor = [UIColor clearColor];
        lbNum.font = [UIFont systemFontOfSize:13];
        lbNum.frame = CGRectMake(SCREEN_WIDTH - 160, top + 18, 150, 18);
        [cell.contentView addSubview:lbNum];
        
        //预付
        UILabel * lbPrePay = [[UILabel alloc] init];
        lbPrePay.tag = 15;
        lbPrePay.textAlignment = NSTextAlignmentRight;
        lbPrePay.backgroundColor = [UIColor clearColor];
        lbPrePay.font = [UIFont systemFontOfSize:13];
        lbPrePay.frame = CGRectMake(SCREEN_WIDTH - 160, top + 18, 150, 18);
        [cell.contentView addSubview:lbPrePay];
        
    }
    
    
    NSArray * _arrGoods = [_dicOrderInfo objectForKey:@"goodsDetail"];
    NSDictionary * dicGoodInfo = [_arrGoods objectAtIndex:indexPath.row];
    
    //加载图片
    NSString * strThumbUrl = [dicGoodInfo objectForKey:@"listpic"];
    
    UIImageView * imgViewThumb = (UIImageView*)[cell.contentView viewWithTag:11];
    [imgViewThumb XK_setImageWithURL:[NSURL URLWithString:strThumbUrl] placeholderImage:nil];
    
    //商品价格
    UILabel * lbPrice = (UILabel*)[cell.contentView viewWithTag:13];
    NSString * strPrice = [dicGoodInfo objectForKey:@"goodsprice"];
    float fPrice = [strPrice floatValue ] / 100;
    lbPrice.text = [NSString stringWithFormat:@"售：￥%.2f", fPrice];
    
    //商品名称
    UILabel * lbGoodName = (UILabel *)[cell.contentView viewWithTag:12];
    lbGoodName.text = [dicGoodInfo objectForKey:@"goodsname"];
    //商品名称随着价格字段长度而变化
    lbGoodName.frame = CGRectMake(71, 5, SCREEN_WIDTH - 140 - (strPrice.length-2) * 9, 45);
    
    //数量
    UILabel * lbNum = (UILabel *)[cell.contentView viewWithTag:14];
    lbNum.text = [NSString stringWithFormat:@"x%@", [dicGoodInfo objectForKey:@"goodsnum"]];
    
    //预付
    UILabel *lbPrePay = (UILabel *)[cell.contentView viewWithTag:15];
    NSString *prePayMoney = [dicGoodInfo objectForKey:@"good_prepay"];
    lbPrePay.text = [NSString stringWithFormat:@"预：¥%.2f", [prePayMoney floatValue ] / 100];
    
    if(isPrePay){
        lbNum.frame = CGRectOffset(lbPrePay.frame, 0, 15);
        [lbPrePay setHidden:NO];
    }else{
        lbNum.frame = lbPrePay.frame;
        [lbPrePay setHidden:YES];
    }
    
    
    return cell;
    
    
}

//选择订单
-(void)clickState:(id)sender{
    
}

+(double)getHeight:(NSDictionary *) dicInfo{
    
    NSArray * _arrGoods = [dicInfo objectForKey:@"goodsDetail"];
    //huad,bug 398,408 初始化要赋值为0，否则会出现值不对的情况
    double downHeight = 0;
    //是否预订
    if (![[dicInfo objectForKey:@"user_order_type"] isEqualToString:@"1"]) {
        downHeight += 40;
    }
    //是否有预付金
    NSString *money = [[dicInfo objectForKey:@"num"] objectForKey:@"prepay"];
    if([money isEqualToString:@"0"] || [money isEqualToString:@""]){
        downHeight += 20;
    }
    
    return _arrGoods.count * 59 + 35 + 100 - downHeight;
}


-(void)loadData:(NSDictionary *)dicInfo{
    
    _dicOrderInfo = dicInfo;
    
    //设置订单状态
    NSString * strOrderState = [_dicOrderInfo objectForKey:@"user_order_type"];
    if ([strOrderState isEqualToString:@"1"]) {
        _lbState.text = @"待付预付款";
    }
    else if ([strOrderState isEqualToString:@"2"]) {
        if ([[[_dicOrderInfo objectForKey:@"num"] objectForKey:@"transport"] intValue] == 1) {
            _lbState.text = @"待自取";
        }else if ([[[_dicOrderInfo objectForKey:@"num"] objectForKey:@"transport"] intValue] == 2){
            _lbState.text = @"待收货";
        }
        
    }
    if ([strOrderState isEqualToString:@"3"]) {
        _lbState.text = @"已完成";
    }
    
    //设置订单信息
    NSString * strShopName = [_dicOrderInfo objectForKey:@"shopname"];
    if (strShopName == nil) {
        NSDictionary * dicPayinfo = [_dicOrderInfo objectForKey:@"payInfo"];
        if (dicPayinfo != nil) {
            strShopName = [dicPayinfo objectForKey:@"shopname"];
        }
    }
    if ([strShopName isKindOfClass:[NSString class]] && strShopName.length > 0) {
        _lbTitle.text = strShopName;
    }
    if (strShopName.length > 10) {
        [_lbTitle setFrame:CGRectMake(15, 7, 150, 20)];
    }else{
        [_lbTitle setFrame:CGRectMake(15, 7, strShopName.length*15, 20)];
    }

    _imgViewNext.frame = CGRectMake( _lbTitle.frame.origin.x + _lbTitle.frame.size.width , _imgViewNext.frame.origin.y, _imgViewNext.frame.size.width, _imgViewNext.frame.size.height);
    
    //商品金额合计
    NSDictionary * dicNum = [_dicOrderInfo objectForKey:@"num"];
    NSString * strPayMoney = [dicNum objectForKey:@"selffee"];
    float fPayMoney = [strPayMoney floatValue] / 100;
    _lbFooter.text = [NSString stringWithFormat:@"￥%.2f", fPayMoney];
    
    //预付金额
    NSString *money = [[_dicOrderInfo objectForKey:@"num"] objectForKey:@"prepay"];
    _lbYuFuMoney.text = [NSString stringWithFormat:@"¥ %.2f", money.intValue/100.0f];
    
    double downHeight = 0;
    //是否有预付金
    if([money isEqualToString:@"0"] || [money isEqualToString:@""]){
        [_lbYuFu setHidden:YES];
        [_lbYuFuMoney  setHidden:YES];
        isPrePay = NO;
        [_btnPayPrePay setHidden:YES];
        downHeight += 20;
    }else{
        [_lbYuFu setHidden:NO];
        [_lbYuFuMoney  setHidden:NO];
        isPrePay = YES;
        [_btnPayPrePay setHidden:NO];
    }
    //是否预订
    if (![[dicInfo objectForKey:@"user_order_type"] isEqualToString:@"1"]) {
        downHeight += 40;
    }
    
    NSArray * _arrGoods = [dicInfo objectForKey:@"goodsDetail"];

    [_downView setFrame:CGRectMake(0, _arrGoods.count * 59 + 35, 320, 100 -downHeight)];
   
    [_tableView reloadData];
    
}

- (void)setHideBuyView:(BOOL)isShow{
    if (isShow == NO) {
        buyView.hidden = YES;
    }else if (isShow == YES){
        buyView.hidden = NO;
    }
}

//去店铺
-(IBAction)goShop:(id)sender{
    
    NSDictionary * dicShopInfo = [_dicOrderInfo objectForKey:@"shopinfo"];
    if (nil == dicShopInfo) {
        NSDictionary * dicPayInfo = [_dicOrderInfo objectForKey:@"payInfo"];
        NSMutableDictionary * mudicShopInfo = [[NSMutableDictionary alloc] init];
        NSString * strShopId = [dicPayInfo objectForKey:@"shopid"];
        [mudicShopInfo setObject:strShopId forKey:@"id"];
        dicShopInfo = mudicShopInfo;
    }
    
    mposDetailViewController *detailV = [[mposDetailViewController alloc]init];
    detailV.merDic = [[NSMutableDictionary alloc] initWithDictionary:dicShopInfo];
    [self.navigationController pushViewController:detailV animated:YES];
    
}

//联系卖家
-(IBAction)chatToShopper:(id)sender{
    

    NSMutableDictionary * dicNewShopInfo = [[NSMutableDictionary alloc] init];
    
    NSDictionary * dicPayInfo = [_dicOrderInfo objectForKey:@"payInfo"];
    NSString * strShopName = [dicPayInfo objectForKey:@"shopname"];
    [dicNewShopInfo setObject:strShopName forKey:@"shopname"];
    
    NSArray * arrGoods = [_dicOrderInfo objectForKey:@"goodsDetail"];
    if (arrGoods.count > 0) {
        NSDictionary * dicGood = [arrGoods objectAtIndex:0];
        NSString * strShopID = [dicGood objectForKey:@"shopid"];
        [dicNewShopInfo setObject:strShopID forKey:@"shopid"];
    }
    
    //设置店铺名称和ID
    chatVC * ctrl = [[chatVC alloc] init];
    ctrl.dicChatInfo = dicNewShopInfo;
    [self.navigationController pushViewController:ctrl animated:YES];
}

-(void)hideChatButtton:(BOOL)flat{
    
    _btnChat.hidden = flat;
}

//取消订单
- (IBAction)cancelOrder:(id)sender {
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Signedorder" forKey:@"Mod"];
    [dic setObject:@"Delorder" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
    }
    
    //获取订单号
    [dicContent setObject:[[_dicOrderInfo objectForKey:@"num"] objectForKey:@"num"] forKey:@"num"];
    [dicContent setObject:[_dicOrderInfo objectForKey:@"shopid"] forKey:@"shopid"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];

    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        [self hideHUD];
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            [self showAlert:nil withTitle:@"取消成功" haveCancelButton:NO];
            [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshDFYFK" object:nil];
        }
        
    }];
}

//支付预付款
- (IBAction)goPay:(id)sender {
    
    if ([[_dicOrderInfo[@"num"]objectForKey:@"payway"] isEqualToString:@"6"]) {
      //微信支付
        //判断用户是否安装了微信
        if ([WXApi isWXAppInstalled]) {
            //微信支付
            [self payByWX];
        }
        else{
            [self showAlert:nil withTitle:@"尚未安装微信" haveCancelButton:NO];
        }
        return;
    }
    
    [self showHUD];
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"PaySign" forKey:@"Mod"];
    [dic setObject:@"PayOnline" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
    }
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    //支付方式 1Mpos,2支付宝,3银联,4.现金支付5 未支付
    NSString *platform = [NSString string];
    if ([[[_dicOrderInfo objectForKey:@"num"] objectForKey:@"payway"] isEqualToString:@"2"]) {
        platform = @"alipay";
    }else if ([[[_dicOrderInfo objectForKey:@"num"] objectForKey:@"payway"] isEqualToString:@"3"]){
        platform = @"upmppay";
    }else{
        platform = @"";
    }
    [dicContent setObject:platform forKey:@"platform"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"phone"];
    if ([_dicOrderInfo objectForKey:@"shopid"]) {
        [dicContent setObject:[_dicOrderInfo objectForKey:@"shopid"] forKey:@"shopid"];
        [dicContent setObject:[_dicOrderInfo objectForKey:@"shopname"] forKey:@"shopname"];
    }else{
        [dicContent setObject:@"" forKey:@"shopid"];
        [dicContent setObject:@"" forKey:@"shopname"];
    }
    //订单
    [dicContent setObject:[[_dicOrderInfo objectForKey:@"num"] objectForKey:@"num"] forKey:@"num"];
    
    NSString *enStr = [AESCrypt encrypt:[dicContent JSONRepresentation] password:KENCRYPTKEY];
    [dic setObject:enStr forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        [self hideHUD];
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if( [[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSString *deStr1 = [AESCrypt decrypt:[resultDic objectForKey:@"DetailInfo"] password:KDECRYPTKEY];
            ;
            NSDictionary *detailDic = [NSJSONSerialization JSONObjectWithData:[deStr1 dataUsingEncoding:NSASCIIStringEncoding] options:NSJSONReadingMutableLeaves error:nil];
            
            if ([[detailDic objectForKey:@"url"] isKindOfClass:[NSString class]] && [[detailDic objectForKey:@"url"] length] > 0) {
                ZLog(@"支付宝");
                
                ZLog(@"%@",[detailDic objectForKey:@"para"]);
                
                [[UIApplication sharedApplication]openURL:[NSURL URLWithString:[detailDic objectForKey:@"url"]]];
                
                //通知刷新？
                [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
                
                //返回主页
                [self.navigationController popToRootViewControllerAnimated:NO];
                
            }else{
                ZLog(@"银联");
                /**
                 *  mode:@"00" 正式版本
                 *  mode:@"01" 开发测试版
                 */
                ZLog(@"%@",[detailDic objectForKey:@"tn"]);
                
                [UPPayPlugin startPay:[NSString stringWithFormat:@"%@",[detailDic objectForKey:@"tn"]] mode:@"00" viewController:self delegate:self];
                
            }
            
        }
        
    }];
}

////微信支付
- (void)payByWX{
    if (![MyAppDelegate whetherHaveNet]) {
        //没有网
        [self showAlert:nil withTitle:@"请查看网络设置" haveCancelButton:NO];
        return;
    }
    NSDictionary *dic =
    @{@"Mod":@"Order",
      @"Act":@"userOrder",
      @"Content":
            @{@"uid":[MyAppDelegate.userInfo objectForKey:@"id"],
              @"devicetype":@"1",
              @"version_name":KVERSION,
              @"logintoken":[MyAppDelegate.userInfo objectForKey:@"logintoken"],
              @"pid":[[_dicOrderInfo objectForKey:@"num"]objectForKey:@"id"],
              @"num":[[_dicOrderInfo objectForKey:@"num"]objectForKey:@"num"],
              @"shopid":[[_dicOrderInfo objectForKey:@"num"]objectForKey:@"shopid"]
              }};
    
    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        [self hideHUD];
        NSLog(@"str : %@",tempStr);
        
        self.infoDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[self.infoDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:_dicOrderInfo];
            [dic addEntriesFromDictionary:[self.infoDic[@"DetailInfo"] objectForKey:@"payInfo"]];
            [dic setObject:@"" forKey:@"fromFlag"];
            
            //购买的商品
            NSDictionary *goodsInfo = [dic[@"goodsDetail"]objectAtIndex:0];
            NSString *goods = [NSString stringWithFormat:@"%@-%@",goodsInfo[@"goodsid"],goodsInfo[@"goodsnum"]];
            [dic setObject:goods forKey:@"goods"];
            
            [self payWXWith:dic];
        }
        else{
            [self hideHUD];
            [self showAlert:nil withTitle:self.infoDic[@"Message"] haveCancelButton:NO];
        }
        
    }];
}

- (void)handleWXPayIsDoing:(NSNotification *)noti{
    [self showAlert:nil withTitle:@"订单未支付完成，请重新支付" haveCancelButton:NO];
}

- (void)WXPayResultHandle:(NSNotification *)notify{
    
    if ([notify.object isEqualToString:WX_PAY_FAIL]) {
        //失败
        [self showAlert:nil withTitle:@"订单支付未完成，请重新支付" haveCancelButton:NO];
    }else{//成功
        [self showAlert:nil withTitle:@"支付成功" haveCancelButton:NO];
        //新增结果页面
#warning 支付
//        orderResultViewController *ctrl = [[orderResultViewController alloc]init];
//        ctrl.orderNum = MyAppDelegate.orderNum;
//        ctrl.hideBackButton = YES;
//        [self.navigationController pushViewController:ctrl animated:YES];
    }
    [[NSNotificationCenter defaultCenter]removeObserver:self name:WX_PAY_RESULT object:nil];
    
}
- (void)backToHome{
    //返回主页
    [self.navigationController popToRootViewControllerAnimated:NO];
//    [MyAppDelegate.mainTab setSelectedIndex:0];
//    [MyAppDelegate.mainTab.selectImage setFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
    
}

#pragma mark - 支付delegate
- (void)UPPayPluginResult:(NSString *)result
{
    //huad,bug 167 有重叠问题
    [self.delegate payover];
    
    if ([result isEqualToString:@"fail"]) {
        ZLog(@"%@失败",result);
        [self showAlert:nil withTitle:@"支付未成功，请重新支付" haveCancelButton:NO];

    }else if ([result isEqualToString:@"success"]){
        ZLog(@"%@成功",result);
        [self showAlert:nil withTitle:@"支付成功" haveCancelButton:NO];

        [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshChartData" object:nil];
        
        //新增结果页面
//        orderResultViewController *ctrl = [[orderResultViewController alloc]init];
//        ctrl.orderNum = MyAppDelegate.orderNum;
//        ctrl.hideBackButton = YES;
//        [self.navigationController pushViewController:ctrl animated:YES];
        
    }else if ([result isEqualToString:@"cancel"]){
        ZLog(@"%@取消订单",result);
        [self showAlert:nil withTitle:@"支付未成功，请重新支付" haveCancelButton:NO];

    }
}



@end
