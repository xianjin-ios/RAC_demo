//
//  orderDetailVC.h
//  GGSH
//
//  Created by heyddo on 16/10/24.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface orderDetailVC : BaseViewController

@property (nonatomic,strong) NSDictionary *dicOrder;

@property (retain, nonatomic) IBOutlet UIScrollView *bScrollView;

//商品名称滚动背景
@property (nonatomic) IBOutlet UIScrollView *nameScrollBg;

//标题信息
@property (nonatomic) IBOutlet UILabel *goodNameLabel;
@property (nonatomic) IBOutlet UILabel *payStatusLabel;
@property (nonatomic) IBOutlet UILabel *proNumLabel;
@property (nonatomic) IBOutlet UILabel *moneyLabel;



//支付信息
@property (nonatomic) IBOutlet UILabel *timeLabel;
@property (nonatomic) IBOutlet UILabel *orderLabel;
@property (nonatomic) IBOutlet UILabel *phoneLabel;
@property (nonatomic) IBOutlet UILabel *payMothordLabel;
@property (retain, nonatomic) IBOutlet UIImageView *payGateImage;

@property (retain, nonatomic) IBOutlet UILabel *hName;
@property (retain, nonatomic) IBOutlet UILabel *hPhone;
@property (retain, nonatomic) IBOutlet UILabel *hAddress;


@end
