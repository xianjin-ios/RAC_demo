//
//  youhuiGZViewController.m
//  GGSH
//
//  Created by siqiyang on 15/7/8.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "youhuiGZViewController.h"
//#import "newMessageViewController.h"

@interface youhuiGZViewController ()
{
    BOOL isShowMore;
    
    IBOutlet UIImageView *messageIcon;
    
    UIImageView *imageAlert;
}
@end

@implementation youhuiGZViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"规则";
    
    UIButton *moreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [moreBtn setFrame:CGRectMake(0, 0, 27, 27)];
    UIImageView *moreIcon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 27, 27)];
    moreIcon.image = [UIImage imageNamed:@"more.png"];
    [moreBtn setBackgroundImage:moreIcon.image forState:UIControlStateNormal];
    [moreBtn addTarget:self action:@selector(moreInfo:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarButtonItemShare = [[UIBarButtonItem alloc] initWithCustomView:moreBtn];
    self.navigationItem.rightBarButtonItem = rightBarButtonItemShare;

    self.webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, self.view.frame.size.height - 20)];
    self.webView.delegate = self;
    self.webView.scalesPageToFit = YES;
    [self.view addSubview:self.webView];

    NSURL *url = [[NSBundle mainBundle] URLForResource:@"rules" withExtension:@"html"];
    NSString *html = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
    NSURL *baseUrl = [NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]];
    [self.webView loadHTMLString:html baseURL:baseUrl];

}

- (void)moreInfo:(UIButton *)sender{
//    isShowMore = !isShowMore;
//    if (isShowMore == YES) {
//        [showMoreView setFrame:CGRectMake(200, 50, 106, 81)];
//        [GLBDELEGATE.window addSubview:showMoreView];
//        if (GLBDELEGATE.isHaveNoReadMessage) {
//            if (!imageAlert) {
//                imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(16, 5, 9, 9)];
//            }
//            [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
//            [messageIcon addSubview:imageAlert];
//        }else{
//            if (imageAlert) {
//                [imageAlert removeFromSuperview];
//                imageAlert = nil;
//            }
//        }
//    }else{
//        [self hideMoreView];
//    }
}

- (void)hideMoreView{
    isShowMore = NO;
    
    [UIView beginAnimations:nil context:nil];
    [showMoreView setFrame:CGRectMake(200, 50, 106, 0)];
    [UIView commitAnimations];
    
    [showMoreView removeFromSuperview];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self hideMoreView];
}

#pragma mark - webViewDelegate
- (void) webViewDidStartLoad:(UIWebView *)webView
{
    NSLog(@"webViewDidStartLoad");
    //创建UIActivityIndicatorView背底半透明View
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, self.webView.frame.size.height)];
    [view setTag:108];
    [view setBackgroundColor:[UIColor blackColor]];
    [view setAlpha:0.5];
    [self.view addSubview:view];
    
    activityIndicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    [activityIndicator setCenter:view.center];
    [activityIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleWhite];
    [view addSubview:activityIndicator];
    
    [activityIndicator startAnimating];
}
- (void) webViewDidFinishLoad:(UIWebView *)webView
{
    NSLog(@"webViewDidFinishLoad");
    [activityIndicator stopAnimating];
    UIView *view = (UIView*)[self.view viewWithTag:108];
    [view removeFromSuperview];
}
- (void) webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"didFailLoadWithError:%@", error);
    [activityIndicator stopAnimating];
    UIView *view = (UIView*)[self.view viewWithTag:108];
    [view removeFromSuperview];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doHome:(id)sender {
    [self hideMoreView];
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}

- (IBAction)doMessage:(id)sender {
//    [self hideMoreView];
//    newMessageViewController *newC = [[newMessageViewController alloc]init];
//    [self.navigationController pushViewController:newC animated:YES];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
