//
//  proDetailViewController.m
//  GGSH
//
//  Created by heyddo on 15/3/13.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "proDetailViewController.h"
#import "LoginVC.h"
#import "shopCartViewController.h"
#import "payConfirmViewController.h"
#import "chatVC.h"
#import "mposDetailViewController.h"
#import "MyMessageVC.h"
#import "LineView.h"

@interface proDetailViewController ()<loginDelegate>
{
    IBOutlet UIView *showMoreView;
    BOOL isShowMore;

    NSMutableArray *tempArr;
    UIImageView *pei1Icon;
    UIImageView *pei2Icon;
    
    int peiType;
    
    
    IBOutlet UIImageView *messageIcon;
    
    
    UITapGestureRecognizer *tap1;
    UIImageView *imageAlertCart;
    UILabel *alertLabel;
    UIImageView *imageAlert;

    
}
@property (nonatomic, strong)NSDictionary *infoDict;

@end

@implementation proDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"商品详情";
    
    //导航栏右边图标
    [self addNavBtn];
    
    ZLog(@"%@====%@",self.detailInfo,self.proId);
    
    tempArr = [NSMutableArray arrayWithCapacity:2];
    
    [self getDetail];
    
    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
}

- (void)refreshNavBtn{
    if (MyAppDelegate.shopCartNumber && MyAppDelegate.shopCartNumber.integerValue > 0) {
        [imageAlertCart setHidden:NO];
        [alertLabel setText:MyAppDelegate.shopCartNumber];
    }else{
        [imageAlertCart setHidden:YES];
    }
    
}

- (void)addNavBtn{
    UIButton *trolleyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [trolleyBtn setFrame:CGRectMake(0, 0, 16, 16)];
    UIImageView *trolleyIcon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 16, 16)];
    trolleyIcon.image = [UIImage imageNamed:@"shopping_s.png"];
    [trolleyBtn setBackgroundImage:trolleyIcon.image forState:UIControlStateNormal];
    [trolleyBtn addTarget:self action:@selector(doTrolley:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:trolleyBtn];
    
    imageAlertCart = [[UIImageView alloc]initWithFrame:CGRectMake(8, -4, 18, 13)];
    [imageAlertCart setBackgroundColor:[UIColor whiteColor]];
    imageAlertCart.layer.cornerRadius = 6;
    imageAlertCart.layer.borderWidth = 0.5f;
    imageAlertCart.layer.borderColor = [UIColor redColor].CGColor;
    [trolleyBtn addSubview:imageAlertCart];
    
    alertLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 18, 13)];
    [alertLabel setTextAlignment:NSTextAlignmentCenter];
    [alertLabel setFont:[UIFont systemFontOfSize:8]];
    [alertLabel setTextColor:[UIColor redColor]];
    [imageAlertCart addSubview:alertLabel];
    [imageAlertCart setHidden:YES];
    
    UIButton *moreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [moreBtn setFrame:CGRectMake(0, 0, 27, 27)];
    UIImageView *moreIcon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 27, 27)];
    moreIcon.image = [UIImage imageNamed:@"more.png"];
    [moreBtn setBackgroundImage:moreIcon.image forState:UIControlStateNormal];
    [moreBtn addTarget:self action:@selector(moreInfo:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightBarButtonItemShare = [[UIBarButtonItem alloc] initWithCustomView:moreBtn];
    
    self.navigationItem.rightBarButtonItems = @[rightBarButtonItemShare,rightBarButtonItem];
}
- (IBAction)doHome:(id)sender {
    [self hideMoreView];
    
    [self.navigationController popToRootViewControllerAnimated:YES];

}

- (IBAction)doMessage:(id)sender {
    [self hideMoreView];
    
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];

}
- (IBAction)doShare:(id)sender {
    //友盟统计
    [MobClick event:@"G_GOODS_SHARE"];

    [self hideMoreView];
    
    [self shareInfo:nil];

}

- (void)moreInfo:(UIButton *)sender{
    isShowMore = !isShowMore;
    if (isShowMore == YES) {
        [showMoreView setFrame:CGRectMake(200, 50, 106, 117)];
        [MyAppDelegate.window addSubview:showMoreView];
        tap1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapClickTocancelShare:)];
        [self.view addGestureRecognizer:tap1];
        ZLog(@"isHaveNoReadMessage : %d",MyAppDelegate.isHaveNoReadMessage);
        if (MyAppDelegate.isHaveNoReadMessage) {
            if (!imageAlert) {
                imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(16, 5, 9, 9)];
            }
            [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
            [messageIcon addSubview:imageAlert];
        }else{
            if (imageAlert) {
                [imageAlert removeFromSuperview];
                imageAlert = nil;
            }
        }
        
    }else{
        [self hideMoreView];
    }
}
- (void)tapClickTocancelShare:(UITapGestureRecognizer *)tap{
    if (isShowMore == YES) {
        [self hideMoreView];
    }
    else{
        if (tap1) {
            [self.view removeGestureRecognizer:tap1];
        }
    }
}
- (void)hideMoreView{
    isShowMore = NO;
    
    [UIView beginAnimations:nil context:nil];
    [showMoreView setFrame:CGRectMake(200, 50, 106, 0)];
    [UIView commitAnimations];
    
    [showMoreView removeFromSuperview];
}

- (void)shareInfo:(UIButton *)sender{
    
    NSString *shareUrl = [NSString stringWithFormat:@"%@/index.php/Api/Share/sharegoods?g=home&m=dealshop&a=deail&goodsid=%@",kMposHeadUrl,self.proId];
    NSDictionary *shareDic = [NSDictionary dictionaryWithObjectsAndKeys:
                              [self.infoDict objectForKey:@"goodsname"],@"title",
                              _topVC.shareImage.image,@"image",
                              @"@我：我发现了一个非常不错的宝贝，推荐给你，赶快来逛逛吧！",@"content",
                              shareUrl,@"url",
                              nil];
    
    [MyAppDelegate shareContext:shareDic];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//购物车
- (void)doTrolley:(UIButton *)sender
{
    if (MyAppDelegate.userInfo) {
        shopCartViewController *shopCartV = [[shopCartViewController alloc]init];
        [self.navigationController pushViewController:shopCartV animated:YES];
    }else{
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
    }
}

#pragma mark - Navigation

- (void)getDetail{
    ZLog(@"proid is:%@",self.proId);
    NSDictionary *contentDic = [NSDictionary dictionaryWithObjectsAndKeys:KVERSION,@"version_name",@"1",@"devicetype",self.proId,@"goodsid", nil];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"GoodsSel",@"Mod",@"GoodsSelect_v1",@"Act",contentDic,@"Content", nil];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            self.infoDict = [resultDic objectForKey:@"DetailInfo"];
            self.merDic = [self.infoDict objectForKey:@"shopinfo"];
            [self LoadDetailView];
        }
        
    }];
}

//加载显示。
- (void)LoadDetailView{
    int topPos = 0;
    
    UIScrollView *bgScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, self.view.frame.size.height-50)];
    bgScrollView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:bgScrollView];
    
    //    焦点大图
    ZLog(@"%@",self.infoDict);
    if (!_topVC) {
        _topVC = [[proTopVC alloc] init];
        _topVC.view.frame = CGRectMake(0, topPos, SCREEN_WIDTH, SCREEN_WIDTH);
        _topVC.view.autoresizingMask = UIViewAutoresizingNone;
        _topVC.navigationController = self.navigationController;
    }
    _topVC.arrImages = [self.infoDict objectForKey:@"mainpic"];
    [_topVC loadInfoView];
    [bgScrollView addSubview:_topVC.view];

    UIImageView *bigImage;
    if ([[self.infoDict objectForKey:@"mainpic"] count] == 0) {
        bigImage = [[UIImageView alloc] initWithFrame:CGRectMake(2, topPos+2, SCREEN_WIDTH, SCREEN_WIDTH)];
        [bigImage setImage:[UIImage imageNamed:@"goodsListDefaultImage.png"]];
        [bgScrollView addSubview:bigImage];
    }else{
        [bigImage removeFromSuperview];
        bigImage = nil;
    }
    
    topPos += SCREEN_WIDTH;
    //    商品名称
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, topPos, SCREEN_WIDTH - 30, 400)];
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont systemFontOfSize:17];
    titleLabel.numberOfLines = 0;
    titleLabel.lineBreakMode = NSLineBreakByCharWrapping;
    NSString *goodsname = [self.infoDict objectForKey:@"goodsname"];
    CGSize size = [NSString getHeight:goodsname withFont:[UIFont systemFontOfSize:17] andWidth:SCREEN_WIDTH - 30];
    titleLabel.text = goodsname;
    double goodsnameHeight = size.height;
    if (goodsnameHeight > 40) {
        goodsnameHeight = 60;
        [titleLabel sizeToFit];
    }else{
        goodsnameHeight = 40;
    }
    titleLabel.frame = CGRectMake(15, topPos, SCREEN_WIDTH - 30, goodsnameHeight);
    [bgScrollView addSubview:titleLabel];
    
    topPos += goodsnameHeight;
    
    //    商品描述
    NSString *descStr = [self.infoDict objectForKey:@"goodsdesc"];
    if (descStr.length > 0) {
        NSString *descStr = [self.infoDict objectForKey:@"goodsdesc"];
        CGSize size = [NSString getHeight:descStr withFont:[UIFont systemFontOfSize:15] andWidth:SCREEN_WIDTH - 30];
        int height = (size.height/10 + 1) * 10;
        
        UILabel *tdetailLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, topPos, SCREEN_WIDTH - 30, height)];
        tdetailLabel.backgroundColor = [UIColor clearColor];
        tdetailLabel.textColor = [UIColor lightGrayColor];
        tdetailLabel.font = [UIFont systemFontOfSize:15];
        tdetailLabel.numberOfLines = 0;
        tdetailLabel.lineBreakMode = NSLineBreakByWordWrapping;
        tdetailLabel.text = descStr;//[self.infoDict objectForKey:@"goodsdesc"];
        [bgScrollView addSubview:tdetailLabel];
        
        topPos += height + 2;

    }
    
    //    参数板块
    LineView *line1 = [[LineView alloc]initWithFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 0.5)];
    line1.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
    [bgScrollView addSubview:line1];
    topPos += 1;
    
    //所在地、已售
    //所在地
    UILabel *localLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, topPos + 5, (SCREEN_WIDTH - 30)/2, 35)];
    localLabel.font = [UIFont systemFontOfSize:15];
    NSString *localStr = [NSString stringWithFormat:@"所在地：%@",[self.merDic objectForKey:@"goodslocation"]];
    [localLabel setText:localStr];
    [bgScrollView addSubview:localLabel];
    
    //售出
    UILabel *soldLabel = [[UILabel alloc] initWithFrame:CGRectMake((SCREEN_WIDTH - 30)/2 + 15 , topPos + 5, (SCREEN_WIDTH - 30)/2, 35)];
    soldLabel.font = [UIFont systemFontOfSize:15];
    soldLabel.textAlignment = NSTextAlignmentRight;
    NSString *tempsoldStr = [NSString stringWithFormat:@"已售：%@",[self.infoDict objectForKey:@"sellnum"]];
    NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc]initWithString:tempsoldStr];
    [attStr addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(3, tempsoldStr.length-3)];
    [soldLabel setAttributedText:attStr];
    [bgScrollView addSubview:soldLabel];
    topPos += 45;
    
    LineView *line2 = [[LineView alloc]initWithFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 0.5)];
    line2.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
    [bgScrollView addSubview:line2];
    topPos += 1;

    //价格
    UILabel *prcLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, topPos + 5, (SCREEN_WIDTH-30)/2, 35)];
    prcLabel.backgroundColor = [UIColor clearColor];
    prcLabel.font = [UIFont systemFontOfSize:15];
    
    if ([[self.infoDict objectForKey:@"pircestatus"] intValue] == 2) {
        
        if ([[self.infoDict objectForKey:@"isprice"] intValue] == 1) {
            //正常价格
            double prc = [[self.infoDict objectForKey:@"goodsprice"] doubleValue];
            NSString *tempStr = [NSString stringWithFormat:@"售价：¥%.2f", prc/100.0];
            NSMutableAttributedString *prcStr = [[NSMutableAttributedString alloc]initWithString:tempStr];
            [prcStr addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(3, tempStr.length-3)];
            [prcLabel setAttributedText:prcStr];
        }else{
            NSString *tempStr = [NSString stringWithFormat:@"售价：---"];
            NSMutableAttributedString *prcStr = [[NSMutableAttributedString alloc]initWithString:tempStr];
            [prcStr addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(3, tempStr.length-3)];
            [prcLabel setAttributedText:prcStr];
        }
        
    }else if ([[self.infoDict objectForKey:@"pircestatus"] intValue] == 1){
        //区间价格
        if ([[self.infoDict objectForKey:@"isprice"] intValue] == 1) {
            double prc1 = [[self.infoDict objectForKey:@"initialprice"] doubleValue];
            double prc2 = [[self.infoDict objectForKey:@"endprice"] doubleValue];
            NSString *tempStr = [NSString stringWithFormat:@"售价：¥%.2f-¥%.2f", prc1/100.0,prc2/100];
            NSMutableAttributedString *prcStr = [[NSMutableAttributedString alloc]initWithString:tempStr];
            [prcStr addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(3, tempStr.length-3)];
            [prcLabel setAttributedText:prcStr];
            [prcLabel setAdjustsFontSizeToFitWidth:YES];
            
        }else{
            NSString *tempStr = [NSString stringWithFormat:@"售价：---"];
            NSMutableAttributedString *prcStr = [[NSMutableAttributedString alloc]initWithString:tempStr];
            [prcStr addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(3, tempStr.length-3)];
            [prcLabel setAttributedText:prcStr];
        }
    }else if ([[self.infoDict objectForKey:@"pircestatus"] intValue] == 3){
        //定制服务
        if ([[self.infoDict objectForKey:@"isprice"] intValue] == 1) {
            double prc = [[self.infoDict objectForKey:@"goodsprice"] doubleValue];
            //定制服务单位？没确定所以先不添加
            NSString *unitStr = [[self.infoDict objectForKey:@"unit"] isEqualToString:@"1"]?@"人":@"间";//1:人 2:间
            
            NSString *tempStr = [NSString stringWithFormat:@"售价：¥%.2f/%@", prc/100.0,unitStr];
            NSMutableAttributedString *prcStr = [[NSMutableAttributedString alloc]initWithString:tempStr];
            [prcStr addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(3, tempStr.length-3)];
            [prcLabel setAttributedText:prcStr];
        }else{
            NSString *tempStr = [NSString stringWithFormat:@"售价：---"];
            NSMutableAttributedString *prcStr = [[NSMutableAttributedString alloc]initWithString:tempStr];
            [prcStr addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(3, tempStr.length-3)];
            [prcLabel setAttributedText:prcStr];
        }
    }
    
    [bgScrollView addSubview:prcLabel];
    
    //预订金额
    NSInteger prc1 = [[self.infoDict objectForKey:@"prepay"] integerValue];
    if (prc1 > 0) {
        //必须定金预订
        UILabel *prcmposLabel = [[UILabel alloc] initWithFrame:CGRectMake((SCREEN_WIDTH-30)/2 + 15, topPos + 5, (SCREEN_WIDTH-30)/2, 35)];
        prcmposLabel.backgroundColor = [UIColor clearColor];
        prcmposLabel.font = [UIFont systemFontOfSize:15];
        prcmposLabel.textAlignment = NSTextAlignmentRight;
        NSString *tempStr1 = [NSString stringWithFormat:@"预付款：¥%.2f", prc1/100.0];
        NSMutableAttributedString *prcStr1 = [[NSMutableAttributedString alloc]initWithString:tempStr1];
        [prcStr1 addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(4, tempStr1.length-4)];
        [prcmposLabel setAttributedText:prcStr1];
        [bgScrollView addSubview:prcmposLabel];
        
    }
    
    NSString *prc = [self.infoDict objectForKey:@"goodsmarketprice"];
    if (prc.integerValue != 0) {
        
        //市场价格，1.3.1需求新增
        UILabel *oldprcLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, prcLabel.frame.origin.y + prcLabel.frame.size.height + 2, (SCREEN_WIDTH-30)/2, 18)];
        oldprcLabel.backgroundColor = [UIColor clearColor];
        oldprcLabel.font = [UIFont systemFontOfSize:15];
        oldprcLabel.textColor = [UIColor lightGrayColor];
        [bgScrollView addSubview:oldprcLabel];
        
        //市场价格
        if([[self.infoDict objectForKey:@"pircestatus"] isEqualToString:@"1"]){
            //区间价格
            NSString *oldPrice = [NSString stringWithFormat:@"售价：¥%.2f",prc.doubleValue/100.0];
            NSUInteger length = [oldPrice length];
            
            NSMutableAttributedString *attri = [[NSMutableAttributedString alloc] initWithString:oldPrice];
            [attri addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(4, length-4)];
            [attri addAttribute:NSStrikethroughColorAttributeName value:[UIColor lightGrayColor] range:NSMakeRange(4, length-4)];
            [attri addAttribute:NSForegroundColorAttributeName value:[UIColor clearColor] range:NSMakeRange(0, 3)];
            [oldprcLabel setAttributedText:attri];
            
        }else if ([[self.infoDict objectForKey:@"pircestatus"] isEqualToString:@"2"]){
            //发布价格
            NSString *oldPrice = [NSString stringWithFormat:@"售价：¥%.2f", prc.doubleValue/100.0f];
            NSUInteger length = [oldPrice length];
            
            NSMutableAttributedString *attri = [[NSMutableAttributedString alloc] initWithString:oldPrice];
            [attri addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(4, length-4)];
            [attri addAttribute:NSStrikethroughColorAttributeName value:[UIColor lightGrayColor] range:NSMakeRange(4, length-4)];
            [attri addAttribute:NSForegroundColorAttributeName value:[UIColor clearColor] range:NSMakeRange(0, 3)];
            
            [oldprcLabel setAttributedText:attri];
            
        }else if ([[self.infoDict objectForKey:@"pircestatus"] isEqualToString:@"3"]){
            //定制服务
            //定制服务单位？没确定所以先不添加
            NSString *unitStr = [[self.infoDict objectForKey:@"unit"] isEqualToString:@"1"]?@"人":@"间";//1:人 2:间
            
            NSString *oldPrice = [NSString stringWithFormat:@"售价：¥%.2f/%@", prc.doubleValue/100.0f,unitStr];
            NSUInteger length = [oldPrice length];
            
            NSMutableAttributedString *attri = [[NSMutableAttributedString alloc] initWithString:oldPrice];
            [attri addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(4, length-4)];
            [attri addAttribute:NSStrikethroughColorAttributeName value:[UIColor lightGrayColor] range:NSMakeRange(4, length-4)];
            [attri addAttribute:NSForegroundColorAttributeName value:[UIColor clearColor] range:NSMakeRange(0, 3)];
            
            [oldprcLabel setAttributedText:attri];
        }
        oldprcLabel.adjustsFontSizeToFitWidth = YES;
        topPos += 65;

    }else{
        topPos += 45;

    }
    
    //分割线
    LineView *line3 = [[LineView alloc]initWithFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 0.5)];
    line3.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
    [bgScrollView addSubview:line3];
    topPos += 1;
    
    //数量
    UIView *numBoardView = [[UIView alloc] initWithFrame:CGRectMake(0, topPos, SCREEN_WIDTH - 10, 55)];
    [bgScrollView addSubview:numBoardView];
    
    UILabel *numTitle = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, 50, 35)];
    numTitle.text = @"数量：";
    numTitle.font = [UIFont systemFontOfSize:15];
    numTitle.textColor = [UIColor blackColor];
    [numBoardView addSubview:numTitle];
    
    UIButton *btnLess = [[UIButton alloc] initWithFrame:CGRectMake(60, 8, 44, 39)];
    [btnLess setBackgroundImage:[UIImage imageNamed:@"a_min.png"] forState:UIControlStateNormal];
    [numBoardView addSubview:btnLess];
    [btnLess addTarget:self action:@selector(numLessAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIImageView *numBgView = [[UIImageView alloc] initWithFrame:CGRectMake(106, 12.5, 60, 30)];
    numBgView.image = [UIImage imageNamed:@"num_bg.png"];
    [numBoardView addSubview:numBgView];
    
    UILabel *numLabel = [[UILabel alloc] initWithFrame:numBgView.bounds];
    numLabel.tag = 222;//获取后用于更改数量
    numLabel.text = @"1";
    numLabel.textAlignment = NSTextAlignmentCenter;
    numLabel.textColor = [UIColor blackColor];
    if ([[self.infoDict objectForKey:@"storenum"] intValue] == 0 || [[self.infoDict objectForKey:@"status"] intValue] != 2) {
        numLabel.textColor = [UIColor lightGrayColor];
    }
    [numBgView addSubview:numLabel];
    UIButton *btnMore = [[UIButton alloc] initWithFrame:CGRectMake(168, 8, 44, 39)];
    [btnMore setBackgroundImage:[UIImage imageNamed:@"a_plus.png"] forState:UIControlStateNormal];
    [btnMore addTarget:self action:@selector(numMoreAction) forControlEvents:UIControlEventTouchUpInside];
    [numBoardView addSubview:btnMore];
    
    //库存
    UILabel *storeLabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 105, 10, 90, 35)];
    storeLabel.font = [UIFont systemFontOfSize:15];
    storeLabel.backgroundColor = [UIColor clearColor];
    storeLabel.textAlignment = NSTextAlignmentRight;
    storeLabel.text = [NSString stringWithFormat:@"库存：%@",[self.infoDict objectForKey:@"storenum"]];
    storeLabel.textColor = [UIColor blackColor];
    [numBoardView addSubview:storeLabel];

    topPos += 55;
    
    //分割线
    UIImageView *line5 = [[UIImageView alloc]initWithFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 5)];
    line5.image = [UIImage imageNamed:@"goods_gap.png"];
    [bgScrollView addSubview:line5];
    topPos += 5;
    
    ZLog(@"%@",self.merDic);
    //店铺信息
    UIView *shopDetailView = [[UIView alloc]initWithFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 110)];
    shopDetailView.backgroundColor = [UIColor clearColor];
    [bgScrollView addSubview:shopDetailView];
    
    //店铺头像
    UIImageView *shopIcon = [[UIImageView alloc]initWithFrame:CGRectMake(15, 12, 37, 37)];
    [shopDetailView addSubview:shopIcon];
    NSString *urlStr = [self.merDic objectForKey:@"listpic"];
    [shopIcon XK_setImageWithURL:[NSURL URLWithString:urlStr] placeholderImage:[UIImage imageNamed:@"mpos_icon.png"]];
    
    //店铺名称
    UILabel *lbShopName = [[UILabel alloc]initWithFrame:CGRectMake(55, 12, SCREEN_WIDTH - 70, 20)];
    lbShopName.text = [NSString stringWithFormat:@"%@",[self.merDic objectForKey:@"shopname"]];
    lbShopName.textAlignment = 0;
    lbShopName.font = [UIFont systemFontOfSize:15];
    [shopDetailView addSubview:lbShopName];
    //店铺描述
    UILabel *lbShopDetail = [[UILabel alloc]initWithFrame:CGRectMake(55, 32, SCREEN_WIDTH - 70, 20)];
    NSString *descStr1 = [self.merDic objectForKey:@"address"];
    if (descStr1.length > 0) {
        lbShopDetail.text = [NSString stringWithFormat:@"%@",[self.merDic objectForKey:@"address"]];
        
    }else{
        lbShopDetail.text = [NSString stringWithFormat:@""];
    }
    lbShopDetail.textAlignment = 0;
    lbShopDetail.textColor = [UIColor colorWithHexString:@"#b0b0b0"];
    lbShopDetail.font = [UIFont systemFontOfSize:13];
    [shopDetailView addSubview:lbShopDetail];

    UIButton *shopContactBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    shopContactBtn.frame = CGRectMake(15, 55, 137, 30);
    [shopContactBtn setImage:[UIImage imageNamed:@"goods_contact.png"] forState:UIControlStateNormal];
    [shopContactBtn addTarget:self action:@selector(doContact:) forControlEvents:UIControlEventTouchUpInside];
    [shopDetailView addSubview:shopContactBtn];
    
    UIButton *shopInfoBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    shopInfoBtn.frame = CGRectMake(SCREEN_WIDTH - 15 - 137, 55, 137, 30);
    [shopInfoBtn setImage:[UIImage imageNamed:@"goods_home.png"] forState:UIControlStateNormal];
    [shopInfoBtn addTarget:self action:@selector(doShopHome:) forControlEvents:UIControlEventTouchUpInside];
    [shopDetailView addSubview:shopInfoBtn];

    topPos += 110;
    
    [bgScrollView setContentSize:CGSizeMake(SCREEN_WIDTH, topPos)];

    //购买按钮
    //购买按钮，隐藏价格不让预订
    if ([[self.infoDict objectForKey:@"isprice"] intValue] == 1) {
        
        UIView *boardBottomView = [[UIView alloc] initWithFrame:CGRectMake(0, bgScrollView.frame.origin.y + bgScrollView.frame.size.height, SCREEN_WIDTH, 50)];
        boardBottomView.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:boardBottomView];
        
        UIButton *btnCar = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH/2, 50)];
        [btnCar setBackgroundColor:[UIColor colorWithHexString:@"#636363"]];
        [btnCar addTarget:self action:@selector(shoppingcarAction) forControlEvents:UIControlEventTouchUpInside];
        [boardBottomView addSubview:btnCar];
        
        UIImageView *carIcon = [[UIImageView alloc]initWithFrame:CGRectMake(25, 10, 27, 27)];
        carIcon.image = [UIImage imageNamed:@"shopping.png"];
        [btnCar addSubview:carIcon];
        UILabel *carLabel = [[UILabel alloc]initWithFrame:CGRectMake(60, 10, SCREEN_WIDTH/2 - 70, 30)];
        carLabel.backgroundColor = [UIColor clearColor];
        carLabel.text = @"加入购物车";
        carLabel.textAlignment = 0;
        carLabel.textColor = [UIColor whiteColor];
        carLabel.font = [UIFont systemFontOfSize:17];
        [btnCar addSubview:carLabel];
        
        UIButton *btnBuy = [[UIButton alloc] initWithFrame:CGRectMake(SCREEN_WIDTH/2, 0, SCREEN_WIDTH/2, 50)];
        [btnBuy setBackgroundColor:[UIColor colorWithHexString:@"#ff2371"]];
        [btnBuy setTitle:@"立即预订" forState:UIControlStateNormal];
        [btnBuy setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btnBuy.titleLabel.font = [UIFont systemFontOfSize:17];
        [btnBuy addTarget:self action:@selector(buyAction) forControlEvents:UIControlEventTouchUpInside];
        [boardBottomView addSubview:btnBuy];
    }else{
        
        [bgScrollView setFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        
    }
    
}

- (void)doContact:(UIButton *)sender{
    //登陆判断
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    
    //由于数据格式不统一，此处统一shopid命名
    NSMutableDictionary * dicNew = [[NSMutableDictionary alloc] initWithDictionary:self.merDic];
    [dicNew setObject:[self.merDic objectForKey:@"id"] forKey:@"shopid"];
    
    chatVC * ctrl = [[chatVC alloc] init];
    ctrl.dicChatInfo = dicNew;
    [self.navigationController pushViewController:ctrl animated:YES];

}

- (void)doShopHome:(UIButton *)sender{
    //进入店铺首页
    mposDetailViewController *detailV = [[mposDetailViewController alloc]init];
    detailV.merDic = self.merDic;
    [self.navigationController pushViewController:detailV animated:YES];
    
}

- (void)numLessAction{
    if(![[self.view viewWithTag:222] isKindOfClass:[UILabel class]])
        return;
    UILabel *numLabel = (UILabel*)[self.view viewWithTag:222];
    NSInteger num = [numLabel.text integerValue];
    if(num > 1)
        numLabel.text = [NSString stringWithFormat:@"%ld",num - 1];
}

- (void)numMoreAction{
        
    if(![[self.view viewWithTag:222] isKindOfClass:[UILabel class]])
        return;
    UILabel *numLabel = (UILabel*)[self.view viewWithTag:222];
    NSInteger num = [numLabel.text integerValue];
    //数量判断
    NSInteger storenum = [[self.infoDict objectForKey:@"storenum"] integerValue];
    
    if (num + 1 > storenum) {
        [self showAlert:nil withTitle:@"库存不足！" haveCancelButton:NO];
        return;
    }
    numLabel.text = [NSString stringWithFormat:@"%ld",num + 1];
}

- (void)shoppingcarAction{
    
    if (!MyAppDelegate.userInfo) {
        
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        
        return;
    }
    
    //友盟统计
    [MobClick event:@"G_CART_ADD"];

    if ([[self.infoDict objectForKey:@"storenum"] intValue] == 0 || [[self.infoDict objectForKey:@"status"] intValue] != 2) {
        [self showAlert:nil withTitle:@"商品已售完或已经下架" haveCancelButton:NO];
        return;
    }
    
    UILabel *numLabel = (UILabel*)[self.view viewWithTag:222];
    NSInteger num = [numLabel.text integerValue];
    
    NSString * usr = [MyAppDelegate.userInfo objectForKey:@"id"];
    NSString * tkn = [MyAppDelegate.userInfo objectForKey:@"logintoken"];
    NSString *shopid = [_infoDict objectForKey:@"shopid"];
    NSString *goodsid = [_infoDict objectForKey:@"id"];
    NSString *phone = [self.detailInfo objectForKey:@"contact"]?[self.detailInfo objectForKey:@"contact"]:@"";
    NSDictionary *contentDic = [[NSDictionary alloc]initWithObjectsAndKeys:usr,@"uid",goodsid,@"goodsid",phone,@"phone",shopid,@"shopid",[NSNumber numberWithInteger:num],@"goodsnum",tkn,@"logintoken",@"1",@"devicetype",KVERSION,@"version_name", nil];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"Signedorder",@"Mod",@"PShopping",@"Act",contentDic,@"Content", nil];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSArray* infoArray = [resultDic objectForKey:@"DetailInfo"];
            ZLog(@"%@",infoArray);
            [self showalertString:@"已成功添加购物车"];
            //刷新未读消息和购物车数量
            [MyAppDelegate getNoReadInfo];
            
        }else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
    }];
}

//商品预订
- (void)buyAction{
    
    //验证登陆
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        
        return;
    }
    
    //bug 428
    if ([[self.infoDict objectForKey:@"storenum"] intValue] == 0 || [[self.infoDict objectForKey:@"status"] intValue] != 2) {
        [self showAlert:nil withTitle:@"商品已售完或已经下架" haveCancelButton:NO];
        return;
    }
    
    //去掉配送方式选择
    [self gotoPayView];

}

- (void)gotoPayView{
    if(![[self.view viewWithTag:222] isKindOfClass:[UILabel class]])
        return;
    UILabel *numLabel = (UILabel*)[self.view viewWithTag:222];
    int num = [numLabel.text intValue];
    
    NSMutableDictionary *tempDic = [NSMutableDictionary dictionary];
    [tempDic setObject:[self.merDic objectForKey:@"shopname"] forKey:@"shopname"];
    [tempDic setObject:[self.merDic objectForKey:@"id"] forKey:@"shopid"];
    [tempDic setObject:[self.merDic objectForKey:@"address"] forKey:@"address"];
    [tempDic setObject:[self.merDic objectForKey:@"contact"] forKey:@"contact"];
    
    NSDictionary *tempDic1 = [NSDictionary dictionaryWithObjectsAndKeys:
                              [self.infoDict objectForKey:@"listpic"],@"listpic",
                              [self.infoDict objectForKey:@"goodsprice"],@"goodsprice",
                              [self.infoDict objectForKey:@"goodsname"],@"goodsname",
                              [NSNumber numberWithInt:num],@"goodsnum",
                              [self.infoDict objectForKey:@"id"],@"goodsid",
                              [self.infoDict objectForKey:@"prepay"],@"prepay",
                              [self.infoDict objectForKey:@"pircestatus"],@"pircestatus",
                              [self.infoDict objectForKey:@"initialprice"],@"initialprice",
                              [self.infoDict objectForKey:@"endprice"],@"endprice",
                              [self.infoDict objectForKey:@"unit"],@"unit",
                              nil];
    NSArray *tempArr1 = [NSArray arrayWithObject:tempDic1];
    [tempDic setObject:tempArr1 forKey:@"goodlist"];
    
    payConfirmViewController *payV = [[payConfirmViewController alloc]init];
    payV.isFromCart = NO;
    payV.infoDict = tempDic;
    [self.navigationController pushViewController:payV animated:YES];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_GOODSDETAIL_VIEW"];
    
    if (MyAppDelegate.shopCartNumber && MyAppDelegate.shopCartNumber.integerValue > 0) {
        [imageAlertCart setHidden:NO];
        [alertLabel setText:MyAppDelegate.shopCartNumber];
    }else{
        [imageAlertCart setHidden:YES];
    }
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self hideMoreView];
    
    //友盟统计
    [MobClick endLogPageView:@"G_GOODSDETAIL_VIEW"];
    
}

@end
