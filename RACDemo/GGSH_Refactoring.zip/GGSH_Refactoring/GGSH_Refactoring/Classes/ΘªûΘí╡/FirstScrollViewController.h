//
//  FirstScrollViewController.h
//  GGSH_Refactoring
//
//  Created by siqiyang on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//轮播图

#import <UIKit/UIKit.h>
@protocol FirstScrollViewControllerDelegate <NSObject>
//设置代理，轮播图的点击的响应
- (void)pushToShopWithShopId:(NSString *)shopid;

@end
@interface FirstScrollViewController : UIViewController

@property (retain, nonatomic) IBOutlet UIPageControl *pageControl;

@property (retain, nonatomic) IBOutlet UIScrollView *topScrollView;

@property (nonatomic,strong) NSMutableArray *arrNews;

@property (nonatomic,assign) id<FirstScrollViewControllerDelegate>delegate;

- (void)updateTopScrollView;

@end
