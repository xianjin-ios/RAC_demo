//
//  WebviewVC.m
//  cards
//
//  Created by STAR on 16-10-19.
//  Copyright (c) 2016年 STAR. All rights reserved.
//

#import "WebveiwVC.h"
#import "AppDelegate.h"
#import "LoginVC.h"

@interface WebveiwVC ()<loginDelegate>

@end

@implementation WebveiwVC
@synthesize webview=_webview;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.webview.backgroundColor = [UIColor clearColor];
    
    //获取生活服务网址
    [self getLifeUrl];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_LIFE_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_LIFE_VIEW"];
    
}

- (void)setTetle:(NSString *)title{
    self.title = title;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)loadurl: (NSString*)url{
    chromeBar = [[UIProgressView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.bounds.size.width, 6.0f)];
    [chromeBar setProgress:0.0f animated:YES];
    [self.view addSubview:chromeBar];
    self.webview.scalesPageToFit = YES;
    [self.webview setUserInteractionEnabled:YES];
    [self.webview setDelegate:self];
    [self.webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
    
}

-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    //huad，加入了js调取客户端方法
    NSString *urlstr = request.URL.absoluteString;
    NSRange range = [urlstr rangeOfString:@"ggshapp://"];
    if (range.length!=0) {
        //若过期
        [webView goBack];

        NSString *method = [urlstr substringFromIndex:(range.location+range.length)];
        SEL selctor = NSSelectorFromString(method);
        [self performSelector:selctor withObject:nil];
    }else{
        

    }
    return YES;
}

//重新登陆的方法
//ggshAPP://reLogin
- (void)reLogin{
    LoginVC *loginV = [[LoginVC alloc]init];
    loginV.delegate = self;
    UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
    [self presentViewController:navi6 animated:YES completion:nil];
}

-(void)finishLogin{
    //登陆成功
    
    //获取生活服务网址
    [self getLifeUrl];
    
}
-(void)cancelLogin{
    //取消登陆
}
-(void)failedLogin{
    //登陆失败
}

//获取生活服务网址
- (void)getLifeUrl{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"LifeService" forKey:@"Mod"];
    [dic setObject:@"home" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    if ([MyAppDelegate.userInfo objectForKey:@"phone"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"user_login_name"];
    }
    
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            //数据赋值
            self.url = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"url"];
        }else{
            self.url = @"";
        }
        
        //刷新界面
        [self loadurl:self.url];
    }];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
}

- (void)webView:(IMTWebView *)_webView didReceiveResourceNumber:(int)resourceNumber totalResources:(int)totalResources {
    //Set progress value
    [chromeBar setProgress:((float)resourceNumber) / ((float)totalResources) animated:YES];
    if (((float)resourceNumber) / ((float)totalResources) == 1) {
        [chromeBar setHidden:YES];
    }
    //Reset resource count after finished
    if (resourceNumber == totalResources) {
        _webView.resourceCount = 0;
        _webView.resourceCompletedCount = 0;
    }
}
@end
