//
//  CityVC.h
//  cards
//
//  Created by STAR on 16-10-21.
//  Copyright (c) 2012年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

//选择城市的代理
@protocol SelectCityDelegate <NSObject>

@optional
-(void)FinishSelect:(NSDictionary *)info;
-(void)CancelSelect;

@end

@interface CityVC : BaseViewController<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, retain) IBOutlet UITableView *iMyTableView;
@property (nonatomic, assign) id<SelectCityDelegate> delegate;

@end
