//
//  MposSearchProductViewController.h
//  GGSH
//
//  Created by siqiyang on 16/3/22.
//  Copyright © 2016年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface MposSearchProductViewController :BaseViewController
//{
//    UITextField *_lbSearch;
//
//}
@property (nonatomic,strong) UITextField *lbSearch;

@property (retain, nonatomic) IBOutlet UICollectionView *productCollectionView;

//店铺总的数据源
@property (nonatomic,strong) NSMutableArray * productDataArray;
//搜索结果的数据源
@property (nonatomic,strong) NSMutableArray *searchProductionArr;
//用于没有数据时的提示
@property (nonatomic,strong) UIView *noView;
//用于存储店铺的信息
@property (nonatomic,strong) NSMutableDictionary *shopInfo;


@end
