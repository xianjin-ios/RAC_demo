//
//  mposShopInfoVC.m
//  GGSH
//
//  Created by siqiyang on 15/11/5.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "mposShopInfoVC.h"

@interface mposShopInfoVC ()<UIScrollViewDelegate>
{
    IBOutlet UIScrollView *_scrollView;
    IBOutlet UIView *_shopnameView;
    IBOutlet UIView *_shopdescView;
    IBOutlet UIView *_shopimageView;
    IBOutlet UIView *_comnameView;
    IBOutlet UIView *_comaddressView;
    IBOutlet UIView *_comlicenseView;
    IBOutlet UIView *_alertView;
    
    
    
    IBOutlet UILabel *_shopName;
    
    IBOutlet UILabel *_shopDes;
    
    IBOutlet UIImageView *_shopImage1;
    
    IBOutlet UIImageView *_shopImage2;
    
    IBOutlet UIImageView *_shopImage3;
    
    IBOutlet UILabel *_compName;
    
    IBOutlet UILabel *_compAddress;
    
    IBOutlet UIImageView *_compImage;
    
    IBOutlet UILabel *_alertLabel;
    
    UIView *bgLicenseView;
    
    NSMutableArray *imageArr;
    
    UIPageControl * _pageController;
}

@end

@implementation mposShopInfoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"店铺资料";
    _compImage.contentMode = UIViewContentModeRedraw;
    [self adjustView];
    
    [self loadInfoView];
}

- (void)adjustView{
    
    for (int i = 31; i < 37; i ++) {
        UIView *line = [_scrollView viewWithTag:i];
        [line setBackgroundColor:[UIColor colorWithHexString:@"#dfdfdf"]];
        [line setFrame:CGRectMake(0, line.frame.origin.y, SCREEN_WIDTH, 0.5)];
    }
    
    [_alertLabel sizeToFit];
    
    [_scrollView setContentSize:CGSizeMake(SCREEN_WIDTH, _alertLabel.frame.origin.y + _alertLabel.frame.size.height + 20)];
}

- (void)loadInfoView{
    
    ZLog(@"%@",self.dicData);
    NSInteger topPos = 0;
    
    //店铺名称
    NSString *shopNameStr = [self.dicData objectForKey:@"shopname"];
    [_shopName setText:shopNameStr];
    [_shopnameView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 40)];
    topPos += 40;
    
    //店铺描述
    NSString *shopDesStr = [self.dicData objectForKey:@"shopdesc"];
    if (shopDesStr.length > 0) {
        UIFont *nameFont=[UIFont fontWithName:@"Helvetica" size:14];
        CGSize size = [NSString getHeight:shopDesStr withFont:nameFont andWidth:SCREEN_WIDTH - 78];
        [_shopDes setFrame:CGRectMake(70, 10, SCREEN_WIDTH - 78, size.height)];
        ZLog(@"%@ ,%f,%f",NSStringFromCGRect([UIScreen mainScreen].bounds),_shopDes.bounds.size.width,size.height);
        _shopDes.text = shopDesStr;
        [_shopDes sizeToFit];
        [_shopdescView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, size.height + 40)];
        topPos += _shopdescView.bounds.size.height;
    }else{
        [_shopDes setFrame:CGRectMake(70, 10, SCREEN_WIDTH - 78, 20)];
        [_shopdescView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 40)];
        topPos += 40;
    }
    imageArr = [[self.dicData objectForKey:@"shopdescpic"] mutableCopy];
    for (int i = 0; i < imageArr.count; i ++) {
        NSString *imageUrlStr = [imageArr objectAtIndex:i];
        switch (i) {
            case 0:{
                [_shopImage1 XK_setImageWithURL:[NSURL URLWithString:imageUrlStr] placeholderImage:[UIImage imageNamed:GoodsSmallImage]];
                UITapGestureRecognizer *itap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doTapShopImage:)];
                itap.cancelsTouchesInView = NO;
                [_shopImage1 addGestureRecognizer:itap];
            }
                break;
            case 1:{
                [_shopImage2 XK_setImageWithURL:[NSURL URLWithString:imageUrlStr] placeholderImage:[UIImage imageNamed:GoodsSmallImage]];
                UITapGestureRecognizer *itap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doTapShopImage:)];
                itap.cancelsTouchesInView = NO;
                [_shopImage2 addGestureRecognizer:itap];
            }
                break;
            case 2:{
                [_shopImage3 XK_setImageWithURL:[NSURL URLWithString:imageUrlStr] placeholderImage:nil];
                UITapGestureRecognizer *itap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doTapShopImage:)];
                itap.cancelsTouchesInView = NO;
                [_shopImage3 addGestureRecognizer:itap];
            }
                break;
                
            default:
                break;
        }
    }
    [_shopimageView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 140)];
    topPos += 140;
    
    //公司名称
    NSString *compNameStr = [self.dicData objectForKey:@"enterprisename"];
    [_compName setText:compNameStr];
    [_comnameView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 40)];
    topPos += 40;
    
    //公司地址
    NSString *compAddressStr = [self.dicData objectForKey:@"address"];
    [_compAddress setText:compAddressStr];
    [_comaddressView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 40)];
    topPos += 40;
    
    NSString *compUrlStr = [self.dicData objectForKey:@"licensepic"];
    [_compImage XK_setImageWithURL:[NSURL URLWithString:compUrlStr] placeholderImage:[UIImage imageNamed:GoodsBagImage]];
    UITapGestureRecognizer *itap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doTapImage)];
    itap.cancelsTouchesInView = NO;
    [_compImage addGestureRecognizer:itap];
    [_comlicenseView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 260)];
    topPos += 260;
    
    [_alertView setFrame:CGRectMake(0, topPos, SCREEN_WIDTH, 120)];
    topPos += 120;
    
    [_scrollView setContentSize:CGSizeMake(SCREEN_WIDTH, topPos + 20)];
    
}

- (void)doTapShopImage:(UIGestureRecognizer *)sender{
//    NSLog(@"%d",sender.view.tag);
    NSInteger tag = sender.view.tag - 2001;
    UIScrollView *sv = (UIScrollView *)[MyAppDelegate.window viewWithTag:301];
    if (!sv) {
        sv = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        sv.delegate = self;
        sv.tag = 301;
        sv.backgroundColor = [UIColor blackColor];
        sv.showsVerticalScrollIndicator = NO;
        sv.showsHorizontalScrollIndicator = NO;
        sv.pagingEnabled = YES;
        sv.contentSize = CGSizeMake(SCREEN_WIDTH*imageArr.count, SCREEN_HEIGHT);
        [MyAppDelegate.window addSubview:sv];
    }

    for (int i = 0; i < [imageArr count]; i ++) {
        
        NSString *imageUrlStr = [imageArr objectAtIndex:i];
        
        //创建图片控件
        UIImageView * imgView = [[UIImageView alloc] init];
        imgView.frame = CGRectMake(i * sv.frame.size.width, 0, sv.frame.size.width, sv.frame.size.height);
        imgView.backgroundColor = [UIColor clearColor];
        imgView.userInteractionEnabled = YES;
        [sv addSubview:imgView];
        
        UIImageView * imgnameView = [[UIImageView alloc] init];
        imgnameView.frame = CGRectMake(0, 0, imgView.frame.size.width, sv.frame.size.height);
        imgnameView.backgroundColor = [UIColor clearColor];
        imgnameView.image = [UIImage imageNamed:@"scrollview_bg.png"];
        imgnameView.userInteractionEnabled = YES;
        [imgView addSubview:imgnameView];
        
        NSURL *url = [NSURL URLWithString:imageUrlStr];
        [imgnameView XK_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"scrollview_bg.png"]];
        
        UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hidePicView)];
        tapGr.cancelsTouchesInView = NO;
        [imgnameView addGestureRecognizer:tapGr];
        
    }

    _pageController = [[UIPageControl alloc]initWithFrame:CGRectMake((SCREEN_WIDTH - 66)/2, SCREEN_HEIGHT - 50, 66, 16)];
    _pageController.tag = 302;
    [MyAppDelegate.window addSubview:_pageController];
    _pageController.backgroundColor = [UIColor blackColor];
    _pageController.numberOfPages = imageArr.count;
    _pageController.layer.cornerRadius = 8;

    [sv setContentOffset:CGPointMake(SCREEN_WIDTH*tag, 0)];
    _pageController.currentPage = tag;

}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (scrollView.tag == 301) {
        if(!decelerate)
        {
            [self _updatePageIndex:scrollView];
        }
    }
    
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (scrollView.tag == 301) {
        [self _updatePageIndex:scrollView];

    }
}

-(void)_updatePageIndex:(UIScrollView*)scrollView
{
    int page = (int)scrollView.contentOffset.x / (int)scrollView.frame.size.width;
    
    _pageController.currentPage = page;
    
}

- (void)doTapImage{
    //v1.2.3 点击营业执照显示完整大图片
    //v.1.3.0  按手机屏幕适配
    CGSize size = _compImage.image.size;
    //图片的宽高比例
    CGFloat scale = size.height/size.width;
    
    CGRect rec = [UIScreen mainScreen].bounds;
    bgLicenseView = [[UIView alloc] initWithFrame:rec];
    bgLicenseView.backgroundColor = [UIColor blackColor];
    UIImageView *imgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, (SCREEN_HEIGHT - SCREEN_WIDTH * scale) *0.5, SCREEN_WIDTH, SCREEN_WIDTH * scale)];
    NSLog(@"%f, %@,%@",scale,NSStringFromCGRect(imgV.frame),NSStringFromCGRect(rec));
    
    
    [bgLicenseView addSubview:imgV];
    UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hidePicView)];
    tapGr.cancelsTouchesInView = NO;
    [bgLicenseView addGestureRecognizer:tapGr];
    imgV.image = _compImage.image;
    imgV.contentMode = UIViewContentModeRedraw;
    [MyAppDelegate.window addSubview:bgLicenseView];
    return;
}

- (void)hidePicView{
    [bgLicenseView removeFromSuperview];
    bgLicenseView = nil;
    
    UIScrollView *sv = (UIScrollView *)[MyAppDelegate.window viewWithTag:301];
    if (sv) {
        [sv removeFromSuperview];
        sv = nil;
        
        [_pageController removeFromSuperview];
        _pageController = nil;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
