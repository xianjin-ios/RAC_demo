//
//  mposDetailViewController.h
//  GGSH
//
//  Created by heyddo on 15/3/13.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface mposDetailViewController : BaseViewController<UICollectionViewDataSource,UICollectionViewDelegate,BMKMapViewDelegate>
{
    
    IBOutlet UICollectionView *iCollectionView;
    
    IBOutlet UIImageView *gotoDetailImage;
    
    IBOutlet UIButton *attentBtn;
}
@property (nonatomic,assign) BOOL isFromMail;
@property (nonatomic,assign) BOOL isFromMpos;
@property (nonatomic,assign) BOOL isFromggCoupon;//从逛逛优惠券来的

@property (nonatomic,retain) NSMutableDictionary *merDic;
@property (nonatomic,retain) NSString *shopId;

@property (retain, nonatomic) IBOutlet UIView *topView;
@property (retain, nonatomic) IBOutlet UIImageView *merchantIcon;
@property (retain, nonatomic) IBOutlet UILabel *shopName;
@property (retain, nonatomic) IBOutlet UILabel *addressLabel;

- (IBAction)daohang:(id)sender;
- (IBAction)attenShop:(id)sender;

@end
