//
//  orderResultViewController.h
//  GGSH
//
//  Created by siqiyang on 15/9/21.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface orderResultViewController : BaseViewController{
    
}

@property (nonatomic,retain) NSString *orderNum;

@end
