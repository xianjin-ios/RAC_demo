//
//  BaseViewController.h
//  GGSH
//
//  Created by siqiyang on 16/10/21.
//  Copyright (c) 2015年 yl. All rights reserved.
//

#import "BaseViewController.h"

@interface lookGoodsViewController : BaseViewController<UICollectionViewDataSource,UICollectionViewDelegate,UITableViewDataSource,UITableViewDelegate>
{
    
    IBOutlet UILabel *lbCity;
    IBOutlet UIImageView *sortSellImage;
    IBOutlet UIImageView *sortPriceImage;
    
    IBOutlet UIButton *btnCity;
    
}
@property (nonatomic,retain) UITableView *typeTableView;
@property (nonatomic,retain) UITableView *typeDetailTableView;

@property (nonatomic,retain) NSDictionary *localtionNearByDic;//商圈数据
@property (nonatomic,retain) NSMutableArray *typeArray;//商圈列表
@property (nonatomic,retain) NSMutableArray *typeDetailArray;//商圈详情

- (IBAction)btnCity:(id)sender;
- (IBAction)sortSell:(id)sender;
- (IBAction)sortPrice:(id)sender;

@end
