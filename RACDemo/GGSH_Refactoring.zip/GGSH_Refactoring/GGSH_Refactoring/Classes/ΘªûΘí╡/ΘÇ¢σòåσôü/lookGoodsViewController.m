//
//  lookGoodsViewController.m
//  GGSH
//
//  Created by yl on 16/10/21.
//  Copyright (c) 2015年 yl. All rights reserved.
//

#import "lookGoodsViewController.h"
#import "lookGoodsCell.h"
#import "LoginVC.h"
#import "MyMessageVC.h"
#import "proDetailViewController.h"
#import "SearchViewController.h"

@interface lookGoodsViewController ()<MJRefreshBaseViewDelegate>
{
    
    UIView *baseView;
    UIImage *_cellImage;
    UIImage *_type_cell;
    UIImage *_type_select;
    UIImage *_type_line;

    NSInteger selectRow;

    NSString *pcode;
    
    UIView *noView;
    
    IBOutlet UICollectionView *iCollectionView;
    
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    
    int sortsell;//(1按销量倒序排2按销量正序排)
    int sortprice;//(1按价格倒序排2按价格正序排)
    int pageIndex;
    
    
    UIImageView *imageAlert;
    
    NSMutableArray *dataArray;

}
@end

@implementation lookGoodsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"逛商品";
    
//    [iCollectionView setFrame:CGRectMake(0, 45, 320, SCREEN_HEIGHT - 64 - 45)];
    [self cancelTapHideKeyBoard:YES];
    //添加导航栏右边按钮
    UIButton *searchButton = [UIButton buttonWithType:UIButtonTypeCustom];
    searchButton.frame = CGRectMake(0.0, 0.0, 16, 16);
    [searchButton addTarget:self action:@selector(gotoSearchView) forControlEvents:UIControlEventTouchUpInside];
    [searchButton setBackgroundImage:[UIImage imageNamed:@"nav_search.png"] forState:UIControlStateNormal];
    searchButton.titleLabel.font = [UIFont systemFontOfSize:13];
    UIBarButtonItem *rightBarButtonItem1 = [[UIBarButtonItem alloc] initWithCustomView:searchButton];
    rightBarButtonItem1.style = UIBarButtonItemStylePlain;
    
    UIButton *editButton = [UIButton buttonWithType:UIButtonTypeCustom];
    editButton.frame = CGRectMake(0.0, 0.0, 16, 16);
    [editButton addTarget:self action:@selector(gotoMessage) forControlEvents:UIControlEventTouchUpInside];
    [editButton setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    editButton.titleLabel.font = [UIFont systemFontOfSize:13];
    UIBarButtonItem *rightBarButtonItem2 = [[UIBarButtonItem alloc] initWithCustomView:editButton];
    rightBarButtonItem2.style = UIBarButtonItemStylePlain;
    //判断是否要添加红点提示
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(10, -4, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [rightBarButtonItem2.customView addSubview:imageAlert];
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }

    self.navigationItem.rightBarButtonItems = @[rightBarButtonItem2, rightBarButtonItem1];

    _header = [MJRefreshHeaderView header];
    _header.scrollView = iCollectionView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = iCollectionView;
    _footer.delegate = self;

    //创建一个底层半透明 view,作为条件选择的 tableview 载体
    baseView = [[UIView alloc]init];
    [baseView setFrame:CGRectMake(0, 45, self.view.frame.size.width, 0)];
    baseView.backgroundColor = [UIColor blackColor];
    baseView.alpha = 0.6;
    [self.view addSubview:baseView];

    self.typeTableView = [[UITableView alloc]init];
    self.typeTableView.delegate = self;
    self.typeTableView.dataSource = self;
    self.typeTableView.backgroundColor = [UIColor colorAndAlphaWithHexString:@"#f6f6f6"];
    self.typeTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width/3, 0)];
    [self.view addSubview:self.typeTableView];
    
    self.typeDetailTableView = [[UITableView alloc]init];
    self.typeDetailTableView.delegate = self;
    self.typeDetailTableView.dataSource = self;
    self.typeDetailTableView.backgroundColor = [UIColor clearColor];
    self.typeDetailTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.typeDetailTableView setFrame:CGRectMake(self.view.frame.size.width/3, 45, self.view.frame.size.width/3*2, 0)];
    [self.view addSubview:self.typeDetailTableView];
    
    //初始化数据
    self.localtionNearByDic = [NSMutableDictionary dictionaryWithCapacity:2];
    self.typeArray = [NSMutableArray arrayWithCapacity:2];
    self.typeDetailArray = [NSMutableArray arrayWithCapacity:2];

    _cellImage = [UIImage imageNamed:@"mpos_cell.png"];
    _type_cell = [UIImage imageNamed:@"around_topcellselect.png"];
    _type_select = [UIImage imageNamed:@"around_topcellBg.png"];
    _type_line = [UIImage imageNamed:@"around_topcellLine.png"];

    sortprice = 0;
    sortsell = 0;
    pageIndex = 1;
    
    dataArray = [NSMutableArray array];
    lbCity.text = MyAppDelegate.curcityname?MyAppDelegate.curcityname:@"地区";
    
    //解决商品没有占满屏幕无法下拉的问题
    iCollectionView.alwaysBounceVertical = YES;

    //注册cell
    UINib *nib = [UINib nibWithNibName:@"lookGoodsCell" bundle:[NSBundle mainBundle]];
    [iCollectionView registerNib:nib forCellWithReuseIdentifier:@"lookCell"];
    
    [self refreshList];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refreshList) name:kGotLocation object:nil];

    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
}

- (void)refreshList{
    [self getPcode];
    [self getList];

}

- (void)refreshNavBtn{
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
}

//跳转搜索界面
- (void)gotoSearchView{
    SearchViewController *controller = [[SearchViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
    
}

//跳转到消息列表
-(void)gotoMessage{
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];
    
}

- (void)getPcode
{
    if ([MyAppDelegate.localDic objectForKey:MyAppDelegate.curcityname]) {
        pcode = [MyAppDelegate.localDic objectForKey:MyAppDelegate.curcityname];
    }else{
        pcode = @"10";
    }
    ZLog(@"curcityname==%@",MyAppDelegate.curcityname);
    ZLog(@"pcodeStr == %@",pcode);
    
    [self getLocalDic];
}

- (void)getLocalDic
{
    NSString *path = [[NSBundle mainBundle]  pathForResource:@"ProvinceAndCities" ofType:@"geojson"];
    NSData *jdata = [[NSData alloc] initWithContentsOfFile:path ];
    NSError* error;
    NSDictionary* Adata = [NSJSONSerialization JSONObjectWithData:jdata options:kNilOptions error:&error];
    self.localtionNearByDic = Adata;
    
    [self setPcodeData];
}

- (void)setPcodeData{
    
    if (self.typeArray.count != 0) {
        [self.typeArray removeAllObjects];
        [self.typeDetailArray removeAllObjects];
    }
    ZLog(@"%@",self.localtionNearByDic);
    
    if ([[self.localtionNearByDic objectForKey:@"DetailInfo"] isKindOfClass:[NSArray class]]) {
        for (int i = 0; i < [[self.localtionNearByDic objectForKey:@"DetailInfo"] count]; i++) {
            NSString *typeName = [NSString stringWithFormat:@"%@",[[[self.localtionNearByDic objectForKey:@"DetailInfo"] objectAtIndex:i] objectForKey:@"regionname"]];
            [self.typeArray addObject:typeName];
        }
    }
    
    self.typeDetailArray = [NSMutableArray arrayWithArray:[[[self.localtionNearByDic objectForKey:@"DetailInfo"] objectAtIndex:selectRow] objectForKey:@"city"]];
    
    [self.typeTableView reloadData];
    [self.typeDetailTableView reloadData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_GOODS_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_GOODS_VIEW"];
    
}

#pragma mark - network
- (void)getList{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"GoodsSel" forKey:@"Mod"];
    [dic setObject:@"homeGoodsList" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:pcode forKey:@"pcode"];
    
    //筛选条件
    if (sortprice != 0) {
        [dicContent setObject:[NSNumber numberWithInt:sortprice] forKey:@"sortprice"];
    }else{
        [dicContent setObject:@"" forKey:@"sortprice"];
    }
    if (sortsell != 0) {
        [dicContent setObject:[NSNumber numberWithInt:sortsell] forKey:@"sortsell"];
    }else{
        [dicContent setObject:@"" forKey:@"sortsell"];
    }
    
    [dicContent setObject:[NSNumber numberWithInt:pageIndex] forKey:@"pageindex"];
    [dicContent setObject:[NSNumber numberWithInt:10] forKey:@"pagesize"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            if(1 == pageIndex){
                dataArray = [[resultDic objectForKey:@"DetailInfo"]mutableCopy];
            }
            else{
                //上拉增加新数据
                [dataArray addObjectsFromArray:[resultDic objectForKey:@"DetailInfo"]];
            }
        }
        else{
            dataArray = [resultDic objectForKey:@"DetailInfo"];
        }
        [iCollectionView reloadData];
        
        if (dataArray.count == 0) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [iCollectionView addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
        
    }];
}

#pragma mark - 刷新的代理方法进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(0 == [MyAppDelegate reachBility]){
        [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        return;
    }
    
    if(refreshView == _header) {// 下拉刷新
        pageIndex = 1;
        [self getList];
    }else if (refreshView == _footer){//上拉加载更多
        if(dataArray.count%10 == 0){
            pageIndex += 1;
            [self getList];
        }
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    return;
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section;
{
    return dataArray.count;
}

//边框
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    NSDictionary *dic = [dataArray objectAtIndexedSubscript:indexPath.row];
    lookGoodsCell *cell = [cv dequeueReusableCellWithReuseIdentifier:@"lookCell" forIndexPath:indexPath];
    
    cell.dicCell = dic;
    
    [cell awakeFromNib];
    
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    //商品详情
    proDetailViewController *proV = [[proDetailViewController alloc]init];
    proV.detailInfo = [dataArray objectAtIndex:indexPath.row];
    proV.proId = [[dataArray objectAtIndex:indexPath.row] objectForKey:@"id"];
    [self.navigationController pushViewController:proV animated:YES];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSInteger row = 0;
    if (tableView == self.typeTableView) {
        if (self.typeArray.count != 0) {
            row = self.typeArray.count;
        }else
            row = 0;
    }else if (tableView == self.typeDetailTableView) {
        if (self.typeDetailArray.count != 0) {
            row = self.typeDetailArray.count;
        }else
            row = 0;
    }else
        row = 0;
    
    return row;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (tableView == self.typeTableView){
        static NSString *identifier = @"typeCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
        }
        //防止cell重叠
        while ([cell.contentView.subviews lastObject] ) {
            [(UIView *)[cell.contentView.subviews lastObject] removeFromSuperview];
        }
        
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIImageView *typebgImg= [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.typeTableView.frame.size.width, 45)];
        typebgImg.image = _type_cell;
        typebgImg.tag = indexPath.row+100;
        [cell.contentView addSubview:typebgImg];
        
        UILabel *titlelabel = [[UILabel alloc]init];
        titlelabel.frame = CGRectMake(5, 10, self.typeTableView.frame.size.width, 20);
        titlelabel.backgroundColor = [UIColor clearColor];
        titlelabel.font = [UIFont systemFontOfSize:13];
        titlelabel.textAlignment = 0;
        titlelabel.textColor = [UIColor colorAndAlphaWithHexString:@"#595767"];
        [cell.contentView addSubview:titlelabel];
        
        if (self.typeArray.count != 0) {
            
            if (indexPath.row == selectRow) {
                typebgImg.image = _type_select;
            }
            
            titlelabel.text = [NSString stringWithFormat:@"  %@",[self.typeArray objectAtIndex:indexPath.row]];
        }
        
        return cell;
    }else if (tableView == self.typeDetailTableView){
        static NSString *identifier = @"typeDetailCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
        }
        //防止cell重叠
        while ([cell.contentView.subviews lastObject] ) {
            [(UIView *)[cell.contentView.subviews lastObject] removeFromSuperview];
        }
        
        cell.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIImageView *bgImg= [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.typeDetailTableView.frame.size.width, 44)];
        bgImg.image = _type_select;
        [cell.contentView addSubview:bgImg];
        
        UIImageView *cellLine= [[UIImageView alloc]initWithFrame:CGRectMake(15, 44, self.typeDetailTableView.frame.size.width - 15, 1)];
        cellLine.image = _type_line;
        [cell.contentView addSubview:cellLine];
        
        UILabel *titlelabel = [[UILabel alloc]init];
        titlelabel.frame = CGRectMake(5, 10, self.typeDetailTableView.frame.size.width, 20);
        titlelabel.backgroundColor = [UIColor clearColor];
        titlelabel.font = [UIFont systemFontOfSize:13];
        titlelabel.textAlignment = 0;
        titlelabel.textColor = [UIColor colorAndAlphaWithHexString:@"#595767"];
        [bgImg addSubview:titlelabel];
        
        if (self.typeDetailArray.count != 0) {
            
            titlelabel.text = [NSString stringWithFormat:@"  %@",[[self.typeDetailArray objectAtIndex:indexPath.row] objectForKey:@"name"]];
            if ([[[self.typeDetailArray objectAtIndex:indexPath.row] objectForKey:@"name"] isEqualToString:lbCity.text]) {
                titlelabel.textColor = [UIColor colorWithHexString:@"#064ea8"];
            }
            
        }
        
        return cell;
    }else
        return nil;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.typeTableView){
        
        for (int i = 0; i< self.typeArray.count; i++) {
            if (i == indexPath.row) {
                UIImageView *cellBg = (UIImageView *)[self.view viewWithTag:indexPath.row+100];
                cellBg.image = [UIImage imageNamed:@"around_topcellBg.png"];
            }else{
                UIImageView *cellBg = (UIImageView *)[self.view viewWithTag:i+100];
                cellBg.image = [UIImage imageNamed:@"around_topcellselect.png"];
            }
            
        }
        
        selectRow = indexPath.row;
        if (self.typeDetailArray.count != 0) {
            [self.typeDetailArray removeAllObjects];
        }
        self.typeDetailArray = [NSMutableArray arrayWithArray:[[[self.localtionNearByDic objectForKey:@"DetailInfo"] objectAtIndex:indexPath.row] objectForKey:@"city"]];
        
        ZLog(@"%@",self.localtionNearByDic);
        ZLog(@"%@",self.typeDetailArray);
        
        [self.typeDetailTableView reloadData];
            
    }else if (tableView == self.typeDetailTableView){
        
        pcode  = [NSString stringWithFormat:@"%@",[[self.typeDetailArray objectAtIndex:indexPath.row] objectForKey:@"pcode"]] ;
        
        [lbCity setText:[[self.typeDetailArray objectAtIndex:indexPath.row] objectForKey:@"name"]];
        
        [self btnCity:btnCity];
        
        pageIndex = 1;
        
        //条件筛选
        [self getList];
    }
}

#pragma mark - buttonTarget
- (IBAction)btnCity:(id)sender {
    btnCity.selected = !btnCity.selected;
    
    if (btnCity.selected == YES) {
                
        [self setPcodeData];
        
        [baseView setFrame:CGRectMake(0,  45, self.view.frame.size.width, self.view.frame.size.height-45)];
        
        [UIView beginAnimations:nil context:nil];
        [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width/3, self.view.frame.size.height-200)];
        [self.typeDetailTableView setFrame:CGRectMake(self.view.frame.size.width/3, 45, self.view.frame.size.width/3*2, self.view.frame.size.height-200)];
        [UIView commitAnimations];
        
    }else{
                
        [baseView setFrame:CGRectMake(0, 45, self.view.frame.size.width, 0)];
        
        [UIView beginAnimations:nil context:nil];
        [self.typeTableView setFrame:CGRectMake(0, 45, self.view.frame.size.width/3, 0)];
        [self.typeDetailTableView setFrame:CGRectMake(self.view.frame.size.width/3, 45, self.view.frame.size.width/3*2, 0)];
        
        [UIView commitAnimations];
    }
}

- (IBAction)sortSell:(id)sender {
    sortSellImage.highlighted = !sortSellImage.highlighted;
    if (sortSellImage.highlighted == YES) {
        sortsell = 1;
    }else{
        sortsell = 2;
    }
    
    sortprice = 0;
    
    [self getList];
}

- (IBAction)sortPrice:(id)sender {
    sortPriceImage.highlighted = !sortPriceImage.highlighted;
    if (sortPriceImage.highlighted == YES) {
        sortprice = 1;
    }else{
        sortprice = 2;
    }
    
    sortsell = 0;
    
    [self getList];

}
@end
