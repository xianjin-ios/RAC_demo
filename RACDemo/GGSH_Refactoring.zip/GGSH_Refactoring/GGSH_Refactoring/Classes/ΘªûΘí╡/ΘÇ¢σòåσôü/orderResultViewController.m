//
//  orderResultViewController.m
//  GGSH
//
//  Created by siqiyang on 15/9/21.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "orderResultViewController.h"
#import "LineView.h"
#import "myOrderVC.h"
#import "mposDetailViewController.h"

@interface orderResultViewController ()
{
    IBOutlet UIScrollView *_scrollView;
    
    IBOutlet UIView *_topView;
    
    IBOutlet UILabel *_lbResult;
    
    NSDictionary *backDic;
    
}
@property (nonatomic,assign) int type;//送货方式

@end

@implementation orderResultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"预订结果";
    
    LineView *downLine = [[LineView alloc]initWithFrame:CGRectMake(0, _topView.frame.size.height+_topView.frame.origin.y, SCREEN_WIDTH, 0.5)];
    downLine.backgroundColor = [UIColor colorWithHexString:@"#b0b0b0"];
    [_scrollView addSubview:downLine];

    
    UIButton *btn1 = (UIButton *)[_scrollView viewWithTag:101];
    if (btn1 != nil) {
        [btn1 removeFromSuperview];
    }
    btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn1 setFrame:CGRectMake(15, 300, 120, 40)];
    [btn1 setBackgroundColor:[UIColor colorWithHexString:@"#ff0085"]];
    [btn1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn1 setTitle:@"查看我的订单" forState:UIControlStateNormal];
    [btn1.titleLabel setFont:[UIFont systemFontOfSize:15]];
    [btn1 setTag:101];
    [btn1 addTarget:self action:@selector(checkOrder) forControlEvents:UIControlEventTouchUpInside];
    [_scrollView addSubview:btn1];
    
    UIButton *btn2 = (UIButton *)[_scrollView viewWithTag:102];
    if (btn2 != nil) {
        [btn2 removeFromSuperview];
    }
    btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn2 setFrame:CGRectMake(SCREEN_WIDTH - 15 - 120, 300, 120, 40)];
    [btn2 setBackgroundColor:[UIColor colorWithHexString:@"#ff0085"]];
    [btn2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn2 setTitle:@"进入店铺首页" forState:UIControlStateNormal];
    [btn2.titleLabel setFont:[UIFont systemFontOfSize:15]];
    [btn2 setTag:102];
    [btn2 addTarget:self action:@selector(goToHome) forControlEvents:UIControlEventTouchUpInside];
    [_scrollView addSubview:btn2];
    
    //获取订单详情
    [self getOrderData];
}

#pragma mark - network
-(void)getOrderData{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"userOrder" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:self.orderNum forKey:@"num"];
    
    [dicContent setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
            [self hideHUD];
        ZLog(@"resonseString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            //加载详情
            backDic = [resultDic objectForKey:@"DetailInfo"];
            [self loadDetailView:backDic];
            
        }
        else{
            [self showalertString:[resultDic objectForKey:@"Message"]];
        }
        

        
    }];
   



    
}

- (void)loadDetailView:(NSDictionary *)dic{
    
    self.type = [[[dic objectForKey:@"payInfo"] objectForKey:@"transport"] intValue];
    
    if (self.type == 1) {
        _lbResult.text = @"请尽快到店取货，";
    }else if (self.type == 2){
        _lbResult.text = @"请耐心等待商家送货上门，";
    }
    
    //布局
    //起点
    int topPos = _topView.frame.origin.y + _topView.frame.size.height;
    
    topPos += 10;
    //订单信息
    //订单编号
    UILabel *lbOrderNum = [[UILabel alloc]initWithFrame:CGRectMake(15, topPos, SCREEN_WIDTH - 30, 20)];
    lbOrderNum.backgroundColor = [UIColor clearColor];
    lbOrderNum.font = [UIFont systemFontOfSize:13];
    lbOrderNum.textAlignment = NSTextAlignmentLeft;
    lbOrderNum.textColor = [UIColor blackColor];
    lbOrderNum.text = [NSString stringWithFormat:@"订单编号：%@",[[dic objectForKey:@"payInfo"] objectForKey:@"num"]];
    [_scrollView addSubview:lbOrderNum];
    topPos += 25;
    
    //订购人或收货人
    UILabel *lbAcceptName = [[UILabel alloc]initWithFrame:CGRectMake(15, topPos , SCREEN_WIDTH - 30, 20)];
    lbAcceptName.backgroundColor = [UIColor clearColor];
    lbAcceptName.font = [UIFont systemFontOfSize:13];
    lbAcceptName.textAlignment = NSTextAlignmentLeft;
    lbAcceptName.textColor = [UIColor blackColor];
    if (self.type == 1) {
        lbAcceptName.text = [NSString stringWithFormat:@"订购人：%@",[[dic objectForKey:@"payInfo"] objectForKey:@"contact"]];

    }else if (self.type == 2){
        lbAcceptName.text = [NSString stringWithFormat:@"收货人：%@  %@",[[dic objectForKey:@"payInfo"] objectForKey:@"acceptname"],[[dic objectForKey:@"payInfo"] objectForKey:@"contact"]];

    }
    [_scrollView addSubview:lbAcceptName];
    topPos += 25;
    
    //收货地址或取货地址
    NSString *addressStr = [[dic objectForKey:@"payInfo"] objectForKey:@"address"];
    
    UILabel *lbAddressT = [[UILabel alloc]initWithFrame:CGRectMake(15, topPos, 65, 13)];
    lbAddressT.backgroundColor = [UIColor clearColor];
    lbAddressT.font = [UIFont systemFontOfSize:13];
    lbAddressT.textAlignment = NSTextAlignmentLeft;
    lbAddressT.textColor = [UIColor blackColor];
    lbAddressT.numberOfLines = 0;
    lbAddressT.lineBreakMode = NSLineBreakByCharWrapping;
    if (self.type == 1) {
        lbAddressT.text = [NSString stringWithFormat:@"取货地址："];
        
    }else if (self.type == 2){
        lbAddressT.text = [NSString stringWithFormat:@"收货地址："];
        
    }
    [_scrollView addSubview:lbAddressT];
    
    UILabel *lbAddress = [[UILabel alloc]initWithFrame:CGRectMake(80, topPos, SCREEN_WIDTH - 95, 1000)];
    lbAddress.backgroundColor = [UIColor clearColor];
    lbAddress.font = [UIFont systemFontOfSize:13];
    lbAddress.textAlignment = NSTextAlignmentLeft;
    lbAddress.textColor = [UIColor blackColor];
    lbAddress.numberOfLines = 0;
    lbAddress.lineBreakMode = NSLineBreakByWordWrapping;
    lbAddress.text = [NSString stringWithFormat:@"%@",addressStr];
    [_scrollView addSubview:lbAddress];
    
    [lbAddress sizeToFit];
    
    topPos += lbAddress.frame.size.height + 5;
    
    //订单二维码
    UIImageView *bcodeImage = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH/2 - 60, topPos, 120, 120)];
    NSString *bcodeUrl = [[dic objectForKey:@"payInfo"] objectForKey:@"code"];

    [bcodeImage XK_setImageWithURL:[NSURL URLWithString:bcodeUrl] placeholderImage:nil];
    [_scrollView addSubview:bcodeImage];
    topPos += 125;
    
    //提示语
    UILabel *lbAlert = [[UILabel alloc]initWithFrame:CGRectMake(15, topPos, SCREEN_WIDTH - 30, 40)];
    lbAlert.backgroundColor = [UIColor clearColor];
    lbAlert.font = [UIFont systemFontOfSize:13];
    lbAlert.textAlignment = NSTextAlignmentCenter;
    lbAlert.textColor = [UIColor colorWithHexString:@"#7d7d7d"];
    lbAlert.numberOfLines = 2;
    lbAlert.lineBreakMode = NSLineBreakByCharWrapping;
    lbAlert.text = @"请妥善保管图片，切勿泄漏，避免因图片泄漏造成的损失";
    [_scrollView addSubview:lbAlert];
    topPos += 40 + 20;
    
    //按钮
    UIButton *btn1 = (UIButton *)[_scrollView viewWithTag:101];
    if (btn1 != nil) {
        [btn1 removeFromSuperview];
    }
    btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn1 setFrame:CGRectMake(15, topPos, 120, 40)];
    [btn1 setBackgroundColor:[UIColor colorWithHexString:@"#ff0085"]];
    [btn1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn1 setTitle:@"查看我的订单" forState:UIControlStateNormal];
    [btn1.titleLabel setFont:[UIFont systemFontOfSize:15]];
    [btn1 setTag:101];
    [btn1 addTarget:self action:@selector(checkOrder) forControlEvents:UIControlEventTouchUpInside];
    [_scrollView addSubview:btn1];
    
    UIButton *btn2 = (UIButton *)[_scrollView viewWithTag:102];
    if (btn2 != nil) {
        [btn2 removeFromSuperview];
    }
    btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn2 setFrame:CGRectMake(SCREEN_WIDTH - 15 - 120, topPos, 120, 40)];
    [btn2 setBackgroundColor:[UIColor colorWithHexString:@"#ff0085"]];
    [btn2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn2 setTitle:@"进入店铺首页" forState:UIControlStateNormal];
    [btn2.titleLabel setFont:[UIFont systemFontOfSize:15]];
    [btn2 setTag:102];
    [btn2 addTarget:self action:@selector(goToHome) forControlEvents:UIControlEventTouchUpInside];
    [_scrollView addSubview:btn2];

    
    [_scrollView setContentSize:CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT + lbAddress.frame.size.height)];
    
}

//查看我的订单
- (void)checkOrder{
    myOrderVC *ctrl = [[myOrderVC alloc]init];
    ctrl.user_order_type = 2;
    [self.navigationController pushViewController:ctrl animated:YES];
}

//进入店铺首页
- (void)goToHome{
    mposDetailViewController *ctrl = [[mposDetailViewController alloc]init];
    ctrl.shopId = [[backDic objectForKey:@"payInfo"] objectForKey:@"shopid"];
    [self.navigationController pushViewController:ctrl animated:YES];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
