//
//  shopCartViewController.h
//  GGSH
//
//  Created by heyddo on 15/3/13.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface shopCartViewController : BaseViewController<UIAlertViewDelegate>
@property (retain, nonatomic) IBOutlet UIButton *selectAll;

- (void)setBuyPro : (NSDictionary *)arr;
- (IBAction)buyAction:(id)sender ;
- (void)delProductItem:(NSString *)deleteStr;
@end
