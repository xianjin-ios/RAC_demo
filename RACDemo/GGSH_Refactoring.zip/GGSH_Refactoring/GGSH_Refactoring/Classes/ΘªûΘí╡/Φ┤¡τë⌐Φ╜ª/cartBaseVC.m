//
//  cartBaseVC.m
//  GGSH
//
//  Created by 任春宁 on 15/7/3.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "cartBaseVC.h"
#import "mposDetailViewController.h"
#import "chatVC.h"
#import "shopCartViewController.h"


@interface cartBaseVC ()<UIAlertViewDelegate>
@property (retain, nonatomic) IBOutlet UIButton *selectAllBtn;
@property (weak, nonatomic) IBOutlet UIButton *goDetailBtn;

@property (nonatomic,assign) NSInteger index;//数据在数据源中的位置

@end

@implementation cartBaseVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.view.layer.borderWidth = ONEPIXL;
}


#pragma mark - uitableview

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *delDic = [[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:indexPath.row];
    NSString *delShpping = [NSString stringWithFormat:@"%@-%@", [delDic objectForKey:@"goodsid"], [delDic objectForKey:@"goodsnum"]];
    
    if([self.cartVc respondsToSelector:@selector(delProductItem:)]){
        [self.cartVc delProductItem : delShpping];
    }
}

- (IBAction)deleteProduct:(id)sender{
    
    //准备要删除的数据
    NSMutableArray *tempArray = [NSMutableArray array];
    for(NSDictionary *dic in [_dicOrderInfo objectForKey:@"goodlist"]){
        if([dic objectForKey:@"isSelected"] && [[dic objectForKey:@"isSelected"] isEqualToString:@"1"]){
            [tempArray addObject:[NSString stringWithFormat:@"%@-%@", [dic objectForKey:@"goodsid"], [dic objectForKey:@"goodsnum"]]];
        }
    }
    NSString *delStr = [tempArray componentsJoinedByString:@","];
    
    //若没选中，提示用户
    if(0 == delStr.length){
        [self showAlert:nil withTitle:@"请选择商品" haveCancelButton:NO];
        return;
    }
    
    UIAlertView *alertV = [[UIAlertView alloc]initWithTitle:@"提示" message:@"确认删除选中商品？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    alertV.tag = 111;
    [alertV show];
    
    
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 111) {
        if (buttonIndex == 1) {
            //准备要删除的数据
            NSMutableArray *tempArray = [NSMutableArray array];
            for(NSDictionary *dic in [_dicOrderInfo objectForKey:@"goodlist"]){
                if([dic objectForKey:@"isSelected"] && [[dic objectForKey:@"isSelected"] isEqualToString:@"1"]){
                    [tempArray addObject:[NSString stringWithFormat:@"%@-%@", [dic objectForKey:@"goodsid"], [dic objectForKey:@"goodsnum"]]];
                }
            }
            NSString *delStr = [tempArray componentsJoinedByString:@","];
            //删除数据
            if([self.cartVc respondsToSelector:@selector(delProductItem:)]){
                [self.cartVc delProductItem : delStr];
            }
        }
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
     NSArray * _arrGoods = [_dicOrderInfo objectForKey:@"goodlist"];
    
    return _arrGoods.count;
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 59;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    //翻页CELL
    static NSString *CellIdentifier = @"COMMONCELL";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        int left = 0;
        int top = 5;
        
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(left, 10, 40, 40);
        [btn setImage:[UIImage imageNamed:@"ProductOrder_unchecked_big.png"] forState:UIControlStateNormal];
        btn.tag = 2000;
        [btn setImage:[UIImage imageNamed:@"ProductOrder_checked_big.png"] forState:UIControlStateSelected];
        [cell.contentView addSubview:btn];
        [btn addTarget:self action:@selector(btnTouch:) forControlEvents:UIControlEventTouchUpInside];
        
        left += 9+25;
        
        //缩略图
        UIImageView * imgViewThumb = [[UIImageView alloc] init];
        imgViewThumb.tag = 11;
        imgViewThumb.layer.borderColor = [UIColor colorWithHexString:@"#dfdfdf"].CGColor;
        imgViewThumb.layer.borderWidth = 0.5f;
        
        imgViewThumb.frame = CGRectMake(left, top, 50, 50);
        imgViewThumb.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:imgViewThumb];
        
        left += 45 + 8 + 5;
        //产品名称
        UILabel * lbProductName = [[UILabel alloc] init];
        lbProductName.tag = 12;
        lbProductName.backgroundColor = [UIColor clearColor];
        lbProductName.font = [UIFont systemFontOfSize:13];
        lbProductName.frame = CGRectMake(left, top, 170, 16);
        lbProductName.numberOfLines = 0;
        lbProductName.lineBreakMode = NSLineBreakByCharWrapping;
        [cell.contentView addSubview:lbProductName];
        
        //价格
        UILabel * lbPrice = [[UILabel alloc] init];
        lbPrice.tag = 13;
        lbPrice.textColor = [UIColor redColor];
        lbPrice.backgroundColor = [UIColor clearColor];
        lbPrice.font = [UIFont systemFontOfSize:13];
        lbPrice.frame = CGRectMake(left, top + 18, 170, 16);
        lbPrice.lineBreakMode = NSLineBreakByCharWrapping;
        [cell.contentView addSubview:lbPrice];
        
        //预订金
        UILabel * lbPrePrice = [[UILabel alloc] init];
        lbPrePrice.tag = 15;
        lbPrePrice.textColor = [UIColor redColor];
        lbPrePrice.backgroundColor = [UIColor clearColor];
        lbPrePrice.font = [UIFont systemFontOfSize:13];
        lbPrePrice.frame = CGRectMake(left, top + 35, 170, 16);
        lbPrePrice.lineBreakMode = NSLineBreakByCharWrapping;
        [cell.contentView addSubview:lbPrePrice];
        
        //数量
        UILabel * lbNum = [[UILabel alloc] init];
        lbNum.tag = 14;
        lbNum.textAlignment = NSTextAlignmentCenter;
        lbNum.backgroundColor = [UIColor clearColor];
        lbNum.font = [UIFont systemFontOfSize:13];
        lbNum.textColor = [UIColor blackColor];
        lbNum.frame = CGRectMake(SCREEN_WIDTH - 80 + 24, top + 18, 32, 17);
        lbNum.lineBreakMode = NSLineBreakByCharWrapping;
        lbNum.layer.borderWidth = 0.5f;
        lbNum.layer.borderColor = [UIColor colorWithHexString:@"#dfdfdf"].CGColor;
        [cell.contentView addSubview:lbNum];
        
        UIButton *btnMin = [UIButton buttonWithType:UIButtonTypeCustom];
        [btnMin setFrame:CGRectMake(SCREEN_WIDTH - 80, top + 15, 23, 23)];
        [btnMin setBackgroundImage:[UIImage imageNamed:@"c_min.png"] forState:UIControlStateNormal];
        [btnMin setBackgroundColor:[UIColor clearColor]];
        [btnMin setTag:16];
        [btnMin addTarget:self action:@selector(btnMin:) forControlEvents:UIControlEventTouchUpInside];
        [cell.contentView addSubview:btnMin];
        
        UIButton *btnPlus = [UIButton buttonWithType:UIButtonTypeCustom];
        [btnPlus setFrame:CGRectMake(SCREEN_WIDTH - 80 + 25 + 32, top + 15, 23, 23)];
        [btnPlus setBackgroundImage:[UIImage imageNamed:@"c_plus.png"] forState:UIControlStateNormal];
        [btnPlus setTag:17];
        [btnPlus setBackgroundColor:[UIColor clearColor]];
        [btnPlus addTarget:self action:@selector(btnPlus:) forControlEvents:UIControlEventTouchUpInside];
        [cell.contentView addSubview:btnPlus];

        UILabel * lbStoreNum = [[UILabel alloc] init];
        lbStoreNum.tag = 18;
        lbStoreNum.textAlignment = NSTextAlignmentCenter;
        lbStoreNum.backgroundColor = [UIColor clearColor];
        lbStoreNum.font = [UIFont systemFontOfSize:11];
        lbStoreNum.textColor = [UIColor redColor];
        lbStoreNum.frame = CGRectMake(SCREEN_WIDTH - 80 + 5, top + 35, 70, 17);
        lbStoreNum.lineBreakMode = NSLineBreakByCharWrapping;
        [cell.contentView addSubview:lbStoreNum];

    }
    
    [cell.contentView setTag:indexPath.row+1000];
    
    NSArray * _arrGoods = [_dicOrderInfo objectForKey:@"goodlist"];
    NSDictionary * dicGoodInfo = [_arrGoods objectAtIndex:indexPath.row];

    
    //选中状态
    UIButton *btnSel = (UIButton *)[cell.contentView viewWithTag:2000];
    if([dicGoodInfo objectForKey:@"isSelected"] && [[dicGoodInfo objectForKey:@"isSelected"] isEqualToString:@"1"]){
        [btnSel setSelected:YES];
    }else{
        [btnSel setSelected:NO];
    }
    
    //加载图片
    NSString * strThumbUrl = [dicGoodInfo objectForKey:@"listpic"];
    
    UIImageView * imgViewThumb = (UIImageView*)[cell.contentView viewWithTag:11];
    [imgViewThumb XK_setImageWithURL:[NSURL URLWithString:strThumbUrl] placeholderImage:nil];
    
    //商品名称
    UILabel * lbGoodName = (UILabel *)[cell.contentView viewWithTag:12];
    lbGoodName.text = [dicGoodInfo objectForKey:@"goodsname"];
    
    //商品价格
    UILabel * lbPrice = (UILabel*)[cell.contentView viewWithTag:13];
    NSString * strPrice = [dicGoodInfo objectForKey:@"goodsprice"];
    float fPrice = [strPrice floatValue ] / 100;
    NSString *prc = [NSString stringWithFormat:@"售价：￥%.2f", fPrice];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:prc];
    [str addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0,3)];
    lbPrice.attributedText = str;
    
    //预订金
    UILabel *lbPrePrice = (UILabel*)[cell.contentView viewWithTag:15];
    double prePrice = [[dicGoodInfo objectForKey:@"prepay"] doubleValue];
    if(prePrice > 0){
        [lbPrePrice setHighlighted:NO];
        NSString *prc = [NSString stringWithFormat:@"预订金：￥%.2f", prePrice / 100.0f];
        NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:prc];
        [str addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0,4)];
        lbPrePrice.attributedText = str;
    }else{
        //没有预订金，则不显示该标签
        [lbPrePrice setHighlighted:YES];
    }
    
    //数量
    UILabel * lbNum = (UILabel *)[cell.contentView viewWithTag:14];
    lbNum.text = [NSString stringWithFormat:@"%@", [dicGoodInfo objectForKey:@"goodsnum"]];
    if ([[dicGoodInfo objectForKey:@"goodsstu"] intValue] != 2 || [[dicGoodInfo objectForKey:@"storenum"] intValue] == 0) {
        lbNum.textColor = [UIColor lightGrayColor];
    }
    
    //库存
    UILabel * lbStoreNum = (UILabel *)[cell.contentView viewWithTag:18];
    lbStoreNum.text = [NSString stringWithFormat:@"可售%@", [dicGoodInfo objectForKey:@"storenum"]];

    return cell;
}

//减一
- (void)btnMin:(UIButton *)sender{
    UIButton *btn = (UIButton *)sender;

    ZLog(@"%ld",(long)btn.superview.tag);

    NSInteger tag = btn.superview.tag - 1000;
    if ([[[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] objectForKey:@"goodsstu"] intValue] != 2) {
        [self showAlert:nil withTitle:@"商品已售完或已经下架" haveCancelButton:NO];
        return;
    }
    int goodsnum = [[[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] objectForKey:@"goodsnum"] intValue];
    if (goodsnum==1) {
        return;
    }
    goodsnum --;
    if (goodsnum < 0) {
        goodsnum = 0;
    }
    [[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] setObject:[NSString stringWithFormat:@"%d",goodsnum] forKey:@"goodsnum"];

    [self calPrc];
    [_tableView reloadData];
    NSString *goodsid = [[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] objectForKey:@"goodsid"];
    
  
    [self.delegate doChangeGoodsNum:goodsnum AndGoodsId:goodsid];
}

//加一
- (void)btnPlus:(UIButton *)sender{
    UIButton *btn = (UIButton *)sender;
    ZLog(@"%ld",(long)btn.superview.tag);

    NSInteger tag = btn.superview.tag - 1000;
    if ([[[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] objectForKey:@"goodsstu"] intValue] != 2) {
        [self showAlert:nil withTitle:@"商品已售完或已经下架" haveCancelButton:NO];
        return;
    }
    int goodsnum = [[[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] objectForKey:@"goodsnum"] intValue];
    goodsnum ++;
    //不能超过库存
    if (goodsnum > [[[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] objectForKey:@"storenum"] intValue]) {
        goodsnum --;
    }
    [[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] setObject:[NSString stringWithFormat:@"%d",goodsnum] forKey:@"goodsnum"];

    [self calPrc];
    [_tableView reloadData];

    NSString *goodsid = [[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] objectForKey:@"goodsid"];
    [self.delegate doChangeGoodsNum:goodsnum AndGoodsId:goodsid];

}

- (IBAction)btnTouch:(id)sender{
    UIButton *btn = (UIButton *)sender;
    [btn setSelected:!btn.isSelected];
    BOOL isSelect = btn.isSelected;
    long tag = btn.superview.tag - 1000;
    if(isSelect){
        [[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] setObject:@"1" forKey:@"isSelected"];
        //判断此时是否全选
        NSArray *arr = [_dicOrderInfo objectForKey:@"goodlist"];
        int selectNum = 0;
        for (NSDictionary *dic in arr) {
            if ([[dic objectForKey:@"isSelected"]isEqualToString:@"1"]) {
                selectNum ++;
            }
        }
        if (selectNum == arr.count) {
            _selectAllBtn.selected = YES;
        }
        // ======判断是否全选====
        
    }else{
        [[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:tag] setObject:@"0" forKey:@"isSelected"];
        //判断之前全选按钮是否选中
        _selectAllBtn.selected = NO;
    }
   
    [self dataChangedWithDic];
    [self calPrc];
}

#pragma mark - 选中全部商品
- (IBAction)selectAllBtn:(id)sender{
    UIButton *btn = (UIButton*)sender;
    [btn setSelected:!btn.isSelected];
    if(btn.isSelected){
        for(NSMutableDictionary *dic in [_dicOrderInfo objectForKey:@"goodlist"]){
            
            [dic setObject:@"1" forKey:@"isSelected"];
        }
    }else{
        for(NSMutableDictionary *dic in [_dicOrderInfo objectForKey:@"goodlist"]){
            [dic setObject:@"0" forKey:@"isSelected"];
        }
    }
   
    [self dataChangedWithDic];
    [self calPrc];
    [_tableView reloadData];
}

//计算单元内价格
- (void)calPrc{
    NSArray *proArray = [_dicOrderInfo objectForKey:@"goodlist"];
    int prc = 0;
    for(NSDictionary *dic in proArray){
        if([dic objectForKey:@"isSelected"] && [[dic objectForKey:@"isSelected"] isEqualToString:@"1"]){
            //判断是否可以购买
            if ([[dic objectForKey:@"goodsstu"] intValue] != 2) {
                continue;
            }
            prc += ((NSString*)[dic objectForKey:@"prepay"]).doubleValue * ((NSString*)[dic objectForKey:@"goodsnum"]).doubleValue;
        }
    }
    
    _lbFooter.text = [NSString stringWithFormat:@"￥%.2f", prc/100.0f];
    
}



//选择订单
-(void)clickState:(id)sender{
    
}
+(int)getHeight:(NSDictionary *) dicInfo{
    
    NSArray * _arrGoods = [dicInfo objectForKey:@"goodlist"];
    
    return _arrGoods.count * 59 + 35 + 37.5 + 7;
}


-(void)loadData:(NSDictionary *)dicInfo withIndex:(NSInteger)index{
    _index = index;
    //转换为可变元素，添加选中状态
    NSMutableArray *muArray = [NSMutableArray array];
    for(NSDictionary *dic in [dicInfo objectForKey:@"goodlist"]){
        
        [muArray addObject:[dic mutableCopy]];
    }
    _dicOrderInfo = [dicInfo mutableCopy];
    [_dicOrderInfo setObject:muArray forKey:@"goodlist"];
    
    //设置订单信息
    NSString * strShopName = [[[_dicOrderInfo objectForKey:@"goodlist"] objectAtIndex:0]objectForKey:@"shopname"];
    if (strShopName == nil) {
        NSDictionary * dicPayinfo = [_dicOrderInfo objectForKey:@"payInfo"];
        if (dicPayinfo != nil) {
            strShopName = [dicPayinfo objectForKey:@"shopname"];
        }
    }
    
   
    CGFloat width = SCREEN_WIDTH - 25 -35-20;
    
    CGRect rect = [strShopName boundingRectWithSize:CGSizeMake(width, _goDetailBtn.bounds.size.height) options:NSStringDrawingUsesFontLeading attributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:15],NSFontAttributeName, nil] context:nil];
    _imgViewNext.frame = CGRectMake(rect.size.width + 15, _imgViewNext.frame.origin.y, _imgViewNext.frame.size.width, _imgViewNext.frame.size.height);
    _lbTitle.frame = CGRectMake(_lbTitle.frame.origin.x, _lbTitle.frame.origin.y, rect.size.width, _lbTitle.frame.size.height);
     _lbTitle.text = strShopName;
    _imgViewNext.image = [UIImage imageNamed:@"my_next"];
    //商品金额合计
    NSDictionary * dicNum = [_dicOrderInfo objectForKey:@"num"];
    NSString * strPayMoney = [dicNum objectForKey:@"paymoney"];
    float fPayMoney = [strPayMoney floatValue] / 100;
    _lbFooter.text = [NSString stringWithFormat:@"￥%.2f", fPayMoney];
    [self calPrc];//计算总价格
    [_tableView reloadData];
    
}

//去店铺
-(IBAction)goShop:(id)sender{
    NSMutableDictionary *mudicShopInfo = [[NSMutableDictionary alloc] init];

    [mudicShopInfo setValue:[[[_dicOrderInfo objectForKey:@"goodlist"]objectAtIndex:0] objectForKey:@"shopid"] forKey:@"id"];
    mposDetailViewController *detailV = [[mposDetailViewController alloc]init];
    detailV.merDic = [mudicShopInfo mutableCopy];
    [self.navigationController pushViewController:detailV animated:YES];
    
}
//联系卖家
-(IBAction)chatToShopper:(id)sender{
    

    NSMutableDictionary * dicNewShopInfo = [[NSMutableDictionary alloc] init];
    
    NSDictionary * dicPayInfo = [_dicOrderInfo objectForKey:@"payInfo"];
    NSString * strShopName = [dicPayInfo objectForKey:@"shopname"];
    [dicNewShopInfo setObject:strShopName forKey:@"shopname"];
    
    NSArray * arrGoods = [_dicOrderInfo objectForKey:@"goodsDetail"];
    if (arrGoods.count > 0) {
        NSDictionary * dicGood = [arrGoods objectAtIndex:0];
        NSString * strShopID = [dicGood objectForKey:@"shopid"];
        [dicNewShopInfo setObject:strShopID forKey:@"shopid"];
    }
    
    //设置店铺名称和ID
    chatVC * ctrl = [[chatVC alloc] init];
    ctrl.dicChatInfo = dicNewShopInfo;
    [self.navigationController pushViewController:ctrl animated:YES];
}

-(void)hideChatButtton:(BOOL)flat{
    
    _btnChat.hidden = flat;
}

- (IBAction)buyPro:(id)sender{
    NSMutableArray *muArray = [NSMutableArray array];
    for(NSDictionary *dic in [_dicOrderInfo objectForKey:@"goodlist"]){
        if([dic objectForKey:@"isSelected"] && [[dic objectForKey:@"isSelected"] isEqualToString:@"1"]){
            [muArray addObject:dic];
        }
    }
    NSMutableDictionary *tempDic = [_dicOrderInfo mutableCopy];
    [tempDic setObject:muArray forKey:@"goodlist"];
    
    [_cartVc setBuyPro:tempDic];
    [_cartVc buyAction:nil];
}

//状态发生改变
- (void)dataChangedWithDic{
    NSMutableDictionary *changedDic = [[NSMutableDictionary alloc]init];
    [changedDic setObject:[NSNumber numberWithInteger:_index] forKey:@"index"];
    [changedDic setObject:_dicOrderInfo forKey:@"info"];
    //发起通知
    [[NSNotificationCenter defaultCenter]postNotificationName:@"changeSelect" object:changedDic];
    
}
@end
