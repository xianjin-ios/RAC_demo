//
//  shopCartViewController.m
//  GGSH
//
//  Created by heyddo on 15/3/13.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "shopCartViewController.h"
#import "payConfirmViewController.h"
#import "cartBaseVC.h"
#import "ProductOrderBaseCell.h"
#import "LoginVC.h"
#import "MyMessageVC.h"


@interface shopCartViewController ()<MJRefreshBaseViewDelegate,SHOPCART_DELEGATE,loginDelegate>
{
    IBOutlet UILabel *summerPriceLabel;
    
    //用户选中的商品
    NSMutableArray *buyArray;
    
    //当前处理为buyDic，放弃使用buyArry；
    NSDictionary *buyDic;
    
    NSMutableArray *sectionArr;
    
    int pageIndex;
    
    MJRefreshFooterView *_footer;
    
    //是否全选
    BOOL isSelectAll;
    
    //价格footer 存放价钱Label
    NSMutableArray *priceLabelArray;
    
    int curSectiontToBuy;
    
    int glbPreMoney;
    
    UIView *noView;
    
    UIImageView *imageAlert;
    
    IBOutlet UITableView *iTableView;
    
    NSMutableArray *dataArray;
}
@end

@implementation shopCartViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"购物车";
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = iTableView;
    _footer.delegate = self;
    
    pageIndex = 1;
    
    [self searchProduct];
    
    summerPriceLabel.text = @"0元";
    buyArray = [NSMutableArray arrayWithCapacity:5];
    sectionArr = [NSMutableArray arrayWithCapacity:2];

    priceLabelArray = [NSMutableArray arrayWithCapacity:2];
    
    [self addRightBar];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(searchProduct) name:@"refreshChartData" object:nil];
    
    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
}

- (void)refreshNavBtn{
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_CART_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_CART_VIEW"];
    
}

//添加右上角按钮
-(void)addRightBar{
    
    UIButton *editButton = [UIButton buttonWithType:UIButtonTypeCustom];
    editButton.frame = CGRectMake(0.0, 0.0, 16, 16);
    [editButton addTarget:self action:@selector(gotoMessage) forControlEvents:UIControlEventTouchUpInside];
    [editButton setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    editButton.titleLabel.font = [UIFont systemFontOfSize:13];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:editButton];
    rightBarButtonItem.style = UIBarButtonItemStylePlain;
    //判断是否要添加红点提示
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(10, -4, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [rightBarButtonItem.customView addSubview:imageAlert];
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
}

//跳转到消息列表
-(void)gotoMessage{
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];
    
}

#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if (refreshView == _footer){//上拉加载更多
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            [self showAlert:nil withTitle:@"无网络连接" haveCancelButton:NO];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        pageIndex += 1;
        
        //网络请求
        [self searchProduct];
        
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        
    }
}

//1s的假loading，取消正在加载就好
- (void)OneSecondElapse{
    [self hideHUD];
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_footer endRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)searchProduct{
    
    NSString *tocken;
    NSString *userid;
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        userid = [MyAppDelegate.userInfo objectForKey:@"id"];
        tocken = [MyAppDelegate.userInfo objectForKey:@"logintoken"];
    }
    
    NSString *phone = [MyAppDelegate.userInfo objectForKey:@"phone"];
    
    NSDictionary *contentDic = [NSDictionary dictionaryWithObjectsAndKeys:userid,@"uid",tocken,@"logintoken",phone,@"user_login_name",[NSNumber numberWithInteger:pageIndex],@"pageindex",@"20",@"pagesize",@"1",@"devicetype",KVERSION,@"version_name", nil];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"Signedorder",@"Mod",@"Shoppingsel",@"Act",contentDic,@"Content", nil];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSMutableArray* infoArray = [resultDic objectForKey:@"DetailInfo"];
            NSMutableArray *goodsArray = [[NSMutableArray alloc]init];//存放商品
            
            /*    ++++++++++++++++添加状态++++++++++++    */
            if (infoArray.count>0) {
                [infoArray enumerateObjectsUsingBlock:^(NSMutableDictionary * obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    NSArray *arr = [obj objectForKey:@"goodlist"];
                    NSMutableArray *goodlist = [[NSMutableArray alloc]init];
                    NSMutableDictionary *good = [[NSMutableDictionary alloc]init];
                    for (NSMutableDictionary *goodInfo in arr) {
                        NSMutableDictionary *dic = [[NSMutableDictionary alloc]initWithDictionary:goodInfo];
                        [dic setObject:[NSString stringWithFormat:@"0"] forKey:@"isSelected"];
                        [goodlist addObject:dic];
                    }
                    if (goodlist.count>0) {
                        [good setObject:goodlist forKey:@"goodlist"];
                        [goodsArray addObject:good];
                    }
                }];
            }
            dataArray = [goodsArray mutableCopy];
        }
        else if( [[resultDic objectForKey:@"Code"] isEqualToString:@"9998"]){
            dataArray = nil;
        }
        [iTableView reloadData];
        
        if (dataArray.count == 0) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [iTableView addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
    }];
}

//改变购物车数量
- (void)changeCardNum:(int)goodsnum AndGoodsId:(NSString *)goodsid{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Shopping" forKey:@"Mod"];
    [dic setObject:@"shoppingChange" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
    }
    
    [dicContent setObject:goodsid forKey:@"goodsid"];
    [dicContent setObject:[NSNumber numberWithInt:goodsnum] forKey:@"goodsnum"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];

    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            NSDictionary *tempGoodsDic = [resultDic objectForKey:@"DetailInfo"];
            
            //改变服务器获取回来的数据，数量、价格、预付
            for(NSMutableDictionary *arrdic in dataArray){
                NSMutableArray *arrdata = [arrdic objectForKey:@"goodlist"];
                for(NSMutableDictionary *dicEve in arrdata){
                    if ([[dicEve objectForKey:@"goodsid"] isEqualToString:goodsid]) {
                        [dicEve setObject:tempGoodsDic[@"goodsnum"] forKey:@"goodsnum"];
                        [dicEve setObject:tempGoodsDic[@"paymoney"] forKey:@"paymoney"];
                        [dicEve setObject:tempGoodsDic[@"prepay"] forKey:@"prepay"];
                    }
                }
            }
        }else if ([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
            //库存不足刷新列表
            pageIndex = 1;
            [self searchProduct];
            
            return;
        }else{
            [self showAlert:nil withTitle:@"系统繁忙，请稍候再试" haveCancelButton:NO];
        }
        
        //刷新界面
        [iTableView reloadData];
    }];
}

#pragma mark - tableview
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *dic = [dataArray objectAtIndex:indexPath.row];
    return [cartBaseVC getHeight:dic] ;
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"selectCELL";
    
    ProductOrderBaseCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[ProductOrderBaseCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        //添加自定义View
        cartBaseVC * ctrl = [[cartBaseVC alloc] init];
        ctrl.view.autoresizingMask = UIViewAutoresizingNone;
        ctrl.view.frame = CGRectMake(0, 10, SCREEN_WIDTH, cell.frame.size.height - 10);
        [cell.contentView addSubview:ctrl.view];
        ctrl.delegate = self;
        cell.ctrl = ctrl;
        
        ctrl.navigationController = self.navigationController;
        
    }
    
    NSDictionary * dicOrderInfo = [dataArray objectAtIndex:indexPath.row];
    cartBaseVC * bb = (cartBaseVC*)cell.ctrl;
    bb.cartVc = self;
    int height = [cartBaseVC getHeight:dicOrderInfo];
    bb.view.frame = CGRectMake(0, 10, SCREEN_WIDTH, height - 10);
    /**
     *  注册通知，监控是否选中
     *
     */
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(isSelectStateChanged:) name:@"changeSelect" object:nil];

    [bb loadData:dicOrderInfo withIndex:indexPath.row];
    
    return cell;
    
}

#pragma mark - doact
-(void)doChangeGoodsNum:(int)goodsnum AndGoodsId:(NSString *)goodsid{
    ZLog(@"goodsnum : %d  ===== goodsid : %@",goodsnum,goodsid);
    [self changeCardNum:goodsnum AndGoodsId:goodsid];
}

- (void)calTotleMoney{
    int totleMoney = 0;
    
    //预付钱数
    int preMoney = 0;
    for(int i = 0; i < buyArray.count; i++){
        NSDictionary *dict = [buyArray objectAtIndex:i];
        int perPrc = [[dict objectForKey:@"goodsprice"] intValue];
        int num = [[dict objectForKey:@"goodsnum"] intValue];
        totleMoney += perPrc * num;
        
        //预付
        NSString *preMoneyStr = [dict objectForKey:@"prepay"];
        preMoney += preMoneyStr.intValue * num;
    }
    
    //标记全部钱数
    glbPreMoney = preMoney;
    
    UIView *prcTolView = (UILabel*)[priceLabelArray objectAtIndex:curSectiontToBuy];
    if(prcTolView){
        
        UILabel *label = (UILabel*)[prcTolView viewWithTag:302];
        ZLog(@"%@",label.text);
        [label setValue:@"wolao" forKey:@"text"];
        ZLog(@"%@",label.text);
        [iTableView reloadSections:[[NSIndexSet alloc]initWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
//        label.text = [NSString stringWithFormat:@"%.2f元",glbPreMoney/100.0f];
//        label.textColor = [UIColor redColor];
    }
    
    summerPriceLabel.text = [NSString stringWithFormat:@"%.2f元",totleMoney/100.0f];
}

#pragma mark - 选择一个店铺的所有商品 & 选择意见商品
//选中后订单内所有商品都选中
- (IBAction)touchheadAction:(id)sender{
    UIButton *btn = (UIButton*)sender;
    int section = (int)btn.tag;
    
    //清除全选状态
    isSelectAll = NO;
    [self.selectAll setSelected:NO];
    
    curSectiontToBuy = ((NSString*)[btn titleForState:UIControlStateDisabled]).intValue;

    ZLog(@"%d==%d",section,btn.selected);
    
    //若又重复，删除重复
    NSArray *arr = [[dataArray objectAtIndex:section] objectForKey:@"goodlist"];
    NSDictionary *object1;
    NSDictionary *object2;
    //待删除arr
    NSMutableArray *tempArr = [NSMutableArray array];
    for (object1 in arr) {
        for (object2 in buyArray) {
            if (object1 == object2) {
                [tempArr addObject:object1];
            }
        }
    }
    [buyArray removeObjectsInArray:tempArr];

    if(btn.selected == NO){
        btn.selected = YES;
        //将选中的section加入选中队列
        [sectionArr addObject:[NSNumber numberWithInt:section]];
        
        [buyArray addObjectsFromArray:arr];//重新添加
        
    }else{
        btn.selected = NO;
        
        [sectionArr removeObject:[NSNumber numberWithInt:section]];
        
    }
    
//    ZLog(@"%@==%d",buyArray,buyArray.count);

    [iTableView reloadData];
    [self calTotleMoney];
}

//选中或去选中当前item
- (IBAction)selectItemAct:(id)sender{
    UIButton *btn = (UIButton*)sender;
    
    //清除全选状态
    isSelectAll = NO;
    [self.selectAll setSelected:NO];
    
    int section = [[btn titleForState:UIControlStateDisabled] intValue];
    int indexRow = [[btn titleForState:UIControlStateReserved] intValue];
    curSectiontToBuy = section;
    
    NSDictionary *tempDic = [[[dataArray objectAtIndex:section] objectForKey:@"goodlist"] objectAtIndex:indexRow];

    UIImageView *checkImageV = (UIImageView *)[btn.superview viewWithTag:300];
    if(btn.isSelected){
        [btn setSelected:NO];
        checkImageV.image = [UIImage imageNamed:@"ProductOrder_unchecked.png"];
        //删除商品
        NSMutableArray *tempArr = [NSMutableArray array];
        for (NSDictionary *moveDic in buyArray) {
            if ([tempDic isEqual:moveDic]) {
                [tempArr addObject:tempDic];
            }
        }
        [buyArray removeObjectsInArray:tempArr];
        
    }else{
        [btn setSelected:YES];
        checkImageV.image = [UIImage imageNamed:@"ProductOrder_checked.png"];
        
        if (buyArray.count > 0) {
            BOOL haveItem = NO;
            for (NSDictionary *moveDic in buyArray) {
                if ([tempDic isEqual:moveDic]) {
                    haveItem = YES;
                }
            }
            if (haveItem == NO) {
                [buyArray addObject:tempDic];
            }
        }else
            [buyArray addObject:tempDic];
        
    }
    ZLog(@"%@==%ld",buyArray,buyArray.count);
    
    //判断当前section是否全选
    NSArray *arr = [[dataArray objectAtIndex:section] objectForKey:@"goodlist"];
    NSDictionary *object1;
    NSDictionary *object2;
    int num = 0;
    for (object1 in arr) {
        for (object2 in buyArray) {
            if (object1 == object2) {
                num += 1;
            }
        }
    }
    
    if (num == arr.count) {
        [sectionArr addObject:[NSNumber numberWithInt:section]];
    }else{
        NSMutableArray *tempArr = [NSMutableArray array];
        for (id object in sectionArr) {
            if ([NSNumber numberWithInt:section] == object) {
                [tempArr addObject:[NSNumber numberWithInt:section]];
            }
        }
        [sectionArr removeObjectsInArray:tempArr];
    }
    
    ZLog(@"%@",dataArray);
    //删除不在列的订单 curSectiontToBuy
    for (int i = 0; i < dataArray.count; i++) {
        NSArray *arrdata = [[dataArray objectAtIndex:i] objectForKey:@"goodlist"];
        for(int j = 0; j < arrdata.count; j++){
            NSDictionary *dicEve = [arrdata objectAtIndex:j];
            for(int k = 0; k < buyArray.count; k++){
                NSDictionary *ibuyDic = [buyArray objectAtIndex:k];
                if([ibuyDic isEqual:dicEve]){
                    if(curSectiontToBuy != i){
                        [buyArray removeObject:ibuyDic];
                        break;
                    }
                }
            }
        }
    }

    //刷新数据
    [iTableView reloadData];
    [self calTotleMoney];
}


//删除购物车中商品
- (void)delProductItem:(NSString *)deleteStr{
    
    NSString *tocken;
    NSString *userid;
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        userid = [MyAppDelegate.userInfo objectForKey:@"id"];
        tocken = [MyAppDelegate.userInfo objectForKey:@"logintoken"];
    }
        
    NSString *jsonString = [NSString stringWithFormat:@"{\"Mod\":\"Signedorder\",\"Act\":\"Shoppingdel\",\"Content\":{\"uid\":\"%@\",\"goods\":\"%@\",\"logintoken\":\"%@\",\"devicetype\":\"1\",\"version_name\":\"%@\"}}",userid, deleteStr, tocken, KVERSION];
    ZLog(@"json str is:%@",jsonString);
    
    
    NSDictionary *contentDic = [NSDictionary dictionaryWithObjectsAndKeys:userid,@"uid",deleteStr,@"goods",tocken,@"logintoken",KVERSION,@"version_name", nil];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"Signedorder",@"Mod",@"Shoppingdel",@"Act",contentDic,@"Content", nil];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            [self searchProduct];
            
            //刷新未读消息和购物车数量
            [MyAppDelegate getNoReadInfo];
            
        }else
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        
    }];
}

//设置要购买的商品，然后购买
- (void)setBuyPro : (NSDictionary *)arr{
    buyDic = arr;
}

- (IBAction)buyAction:(id)sender {
    ZLog(@"%@",buyDic);
    if ([[buyDic objectForKey:@"goodlist"]count] == 0) {
        [self showAlert:nil withTitle:@"没有选择商品！" haveCancelButton:NO];
        return;
    }
    
    //增加商品数量判断
    for (NSDictionary *dic in [buyDic objectForKey:@"goodlist"]) {
        if ([[dic objectForKey:@"goodsnum"] intValue] == 0) {
            [self showAlert:nil withTitle:@"所选商品不能为0" haveCancelButton:NO];
            return;
        }
        if ([[dic objectForKey:@"storenum"] intValue] == 0 || [[dic objectForKey:@"goodsstu"] intValue] != 2) {
            [self showAlert:nil withTitle:@"商品已售完或已经下架" haveCancelButton:NO];
            return;
        }
        NSString *storenum = [dic objectForKey:@"storenum"];
        NSString *goodsnum = [dic objectForKey:@"goodsnum"];
        if ([storenum intValue] < [goodsnum intValue]) {
            [self showAlert:nil withTitle:@"购买的商品库存不足，请调整" haveCancelButton:NO];
            return;
        }
    }
    
    payConfirmViewController *payV = [[payConfirmViewController alloc]init];
    payV.infoDict = buyDic;
    payV.isFromCart = YES;
    [self.navigationController pushViewController:payV animated:YES];
    return;

}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 111) {
        [self.navigationController popToRootViewControllerAnimated:YES];

    }
}
#pragma mark - cell上的选中状态发生变化时
- (void)isSelectStateChanged:(NSNotification *)notify{
    NSDictionary *dic = notify.object;
    
    NSNumber *indexNum = [dic objectForKey:@"index"];
    NSUInteger integer = indexNum.integerValue;
    NSDictionary *proDic = [dic objectForKey:@"info"];
    //替换数据源中的对象
    [dataArray replaceObjectAtIndex:integer withObject:proDic];
    
    
}

@end
