//
//  cartBaseVC.h
//  GGSH
//  购物车店铺商品
//  Created by 耿彦利 on 15/7/7.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@class shopCartViewController;

@protocol SHOPCART_DELEGATE <NSObject>

- (void)doChangeGoodsNum:(int)goodsnum AndGoodsId:(NSString *)goodsid;

@end
@interface cartBaseVC : BaseViewController<UITableViewDataSource, UITableViewDelegate>{
    
    
    IBOutlet UITableView * _tableView;
    
    IBOutlet UIButton * _rightButton;
    
    IBOutlet UILabel * _lbTitle;
    
    IBOutlet UILabel * _lbFooter;
    
    IBOutlet UILabel * _lbState;
    
    //右侧尖头
    IBOutlet UIImageView * _imgViewNext;
    
    //订单信息
    NSMutableDictionary * _dicOrderInfo;
    
    //联系卖家
    IBOutlet UIButton * _btnChat;
    
}

@property (nonatomic, assign) id<SHOPCART_DELEGATE> delegate;
@property (nonatomic, assign) shopCartViewController *cartVc;
@property (nonatomic, strong) UINavigationController * navigationController;

//获取高度
+(int)getHeight:(NSDictionary *) dicInfo;

-(void)loadData:(NSDictionary *)dicInfo withIndex:(NSInteger)index;

-(void)hideChatButtton:(BOOL)flat;

@end





