//
//  mposMerchantViewController.h
//  GGSH
//
//  Created by heyddo on 15/3/13.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface mposMerchantViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>
{
    
    IBOutlet UIScrollView *_scrollview;
    
    UIButton *pcodeBtn;
    UIButton *typeBtn;
    UIButton *distanceBtn;

    UILabel *pcodeBtnLabel;
    UILabel *typeBtnLabel;
    UILabel *distanceBtnLabel;
    
    UIView *downLineIn;

}

@property (nonatomic,retain) UITableView *typeTableView;
@property (nonatomic,retain) UITableView *typeDetailTableView;

@property (nonatomic,retain) NSDictionary *localtionNearByDic;//商圈数据
@property (nonatomic,retain) NSMutableArray *typeArray;//商圈列表
@property (nonatomic,retain) NSMutableArray *typeDetailArray;//商圈详情


- (IBAction)pcodeBtn:(id)sender;
- (IBAction)typeBtn:(id)sender;
- (IBAction)distanceBtn:(id)sender;


@end
