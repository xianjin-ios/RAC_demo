//
//  proTopVC.h
//  GGSH
//
//  Created by siqiyang on 15/9/21.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface proTopVC : UIViewController<UIScrollViewDelegate>
{
    IBOutlet UIPageControl *_pageController;
    
    IBOutlet UIScrollView *_scrollView;
    
    
}

@property (nonatomic ,retain) UIImageView *shareImage;

@property (nonatomic, strong) UINavigationController * navigationController;

@property (nonatomic, strong) NSMutableArray * arrImages;

- (void)loadInfoView;

@end
