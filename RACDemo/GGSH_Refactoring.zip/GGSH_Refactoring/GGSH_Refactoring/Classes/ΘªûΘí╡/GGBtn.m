//
//  GGBtn.m
//  GGSH_Refactoring
//
//  Created by siqiyang on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "GGBtn.h"
#import "UIView+Extension.h"
@implementation GGBtn

- (void)layoutSubviews{
    if (_ggButtonType == FirstInMiddleType) {//首页里面中间的按钮
        // 106 ,55 image  , title 21,detail 21
        self.imageView.M_y = 11;
        self.imageView.M_width = 55;
        self.imageView.M_width = 55;
        self.imageView.M_centerX = self.M_width *0.5;
        
        //title
        self.titleLabel.M_x = 0;
        self.titleLabel.M_y = self.imageView.M_bottom;
        self.titleLabel.M_height = 21;
        self.titleLabel.M_width = self.M_width;
        self.titleLabel.font = [UIFont systemFontOfSize:13];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
    }
    
}

@end
