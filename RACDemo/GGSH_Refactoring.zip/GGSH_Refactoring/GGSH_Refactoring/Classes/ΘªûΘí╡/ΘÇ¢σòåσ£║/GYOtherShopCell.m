//
//  GYOtherShopCell.m
//  cards
//
//  Created by STAR on 13-1-11.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import "GYOtherShopCell.h"

@implementation GYOtherShopCell
@synthesize dataSource, nameLabel, addressLabel, phoneLabel, distanceLabel;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UIImageView *background = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 60)];
        background.image = [UIImage imageNamed:@"bgCell.png"];
        [self addSubview:background];
        
        nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 5, 259, 20)];
        [self addSubview: nameLabel];
        nameLabel.font = [UIFont systemFontOfSize:15];
        nameLabel.backgroundColor = [UIColor clearColor];
        
        addressLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 20, 260, 20)];
        addressLabel.font = [UIFont systemFontOfSize:13];
        addressLabel.backgroundColor = [UIColor clearColor];
        [self addSubview: addressLabel];
        
        phoneLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 34, 240, 20)];
        phoneLabel.font = [UIFont systemFontOfSize:13];
        phoneLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:phoneLabel];
        
        distanceLabel = [[UILabel alloc]initWithFrame:CGRectMake(270, 20, 50, 20)];
        distanceLabel.backgroundColor = [UIColor clearColor];
        distanceLabel.font = [UIFont systemFontOfSize:12];
        [self addSubview:distanceLabel];
    }
    return self;
}

-(void)setDataSource:(NSDictionary *)value{
    if ([value isEqualToDictionary:dataSource]) {
		return;
	}
	dataSource = value;
	[self setNeedsLayout];
}

-(void)layoutSubviews
{
    ZLog(@"%@",dataSource);
    nameLabel.text = [dataSource objectForKey:@"ShopName"];
    addressLabel.text = [dataSource objectForKey:@"Address"];
    phoneLabel.text = [NSString stringWithFormat:@"电话：%@",[dataSource objectForKey:@"Phone"]];
    NSString *distance = [dataSource objectForKey:@"Distance"];
    if(distance.length > 3)
        distance = [NSString stringWithFormat:@"%@.%@km",[distance substringToIndex:(distance.length - 3)],[distance substringWithRange:NSMakeRange(distance.length - 3,1)]];
    else
        distance = [NSString stringWithFormat:@"%@m",distance];
    distanceLabel.text = distance;
    
}
@end
