//
//  ShopCell.h
//  hongdian
//
//  Created by STAR on 16-10-19.
//  Copyright (c) 2016年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ShopCell : UITableViewCell{
    UIImageView *image;
    UILabel *name;
    UILabel *infoTitle;
    UILabel *dislabel;
    UIImageView *iconImageView;
    UIImageView *iconImageView2;
    UIImageView *iconImageView3;
    NSDictionary *dataSource;
}
@property(nonatomic,retain) UIImageView *image;
@property(nonatomic ,retain) UILabel *name;
@property(nonatomic, retain) UILabel *infoTitle;
@property(nonatomic, retain)  UILabel *dislabel;
@property(nonatomic, retain)NSDictionary *dataSource;


-(void)setDataSource:(NSDictionary *)value;
@end
