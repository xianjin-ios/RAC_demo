//
//  GYSelfShopHeaderCell.m
//  guangguang
//
//  Created by starnet on 13-4-23.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import "GYSelfShopHeaderCell.h"

@implementation GYSelfShopHeaderCell

@synthesize commentIconImg,commentNumber,shoppingCommentBtn,delegate;
@synthesize count;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UIImageView *navTitleImg = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 35)];
        navTitleImg.image = [UIImage imageNamed:@"shopCommentTitle.png"];//
        [self addSubview: navTitleImg];
        
        self.commentNumber = [[UIButton alloc]initWithFrame:CGRectMake(260, 10, 45, 17)];

        [self.commentNumber setBackgroundImage:[UIImage imageNamed:@"commentCount.png"] forState:UIControlStateNormal];
        self.commentNumber.titleLabel.font = [UIFont systemFontOfSize:10];
        [navTitleImg addSubview:commentNumber];
        
        
        self.shoppingCommentBtn = [[UIButton alloc]initWithFrame:CGRectMake(10, 45, 300, 36)];
        [self.shoppingCommentBtn setBackgroundImage:[UIImage imageNamed:@"commenting.png"] forState:UIControlStateNormal];
        [self.shoppingCommentBtn addTarget:self action:@selector(commentting:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:shoppingCommentBtn];

        
        CGRect lineRect = CGRectMake(0, 90-1, 320, 1);
        [self addPartingLine:lineRect];
    }
    return self;
}

- (void)addPartingLine:(CGRect)rect
{
    UIImageView *lineImg = [[UIImageView alloc]initWithFrame:rect];
    [lineImg setImage:[UIImage imageNamed:@"line.png"]];
    [self.contentView addSubview:lineImg];
}

-(void)setDataSource:(NSInteger)value
{
    self.count = value;
   [self.commentNumber setTitle:[NSString stringWithFormat:@"%ldd",self.count] forState:UIControlStateNormal];
    self.commentNumber.titleLabel.textColor = [UIColor colorWithHexString:@"#846347"];
}
- (void)commentting:(id)sender
{
    if([self.delegate respondsToSelector:@selector(clickUserWillComment)])
    {
        [delegate clickUserWillComment];
    }
}

@end
