//
//  GYSelfShopCommentFooterCell.m
//  guangguang
//
//  Created by starnet on 13-4-23.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import "GYSelfShopCommentFooterCell.h"

@implementation GYSelfShopCommentFooterCell
@synthesize shoppingMoreBtn,delegate;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UIButton *moreShoppingComment = [[UIButton alloc]initWithFrame:CGRectMake(10, 0, 300, 35)];
        [moreShoppingComment setTitle:@"查看更多逛逛用户评论 >" forState:UIControlStateNormal];
        moreShoppingComment.titleLabel.font = [UIFont systemFontOfSize:12];
        [moreShoppingComment setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [moreShoppingComment addTarget:self action:@selector(onClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:moreShoppingComment];
    }
    return self;
}

- (void)onClick:(id)sender
{
    if([self.delegate respondsToSelector:@selector(checkMoreShopCommentContent)])
    {
        [delegate checkMoreShopCommentContent];
    }
}

@end
