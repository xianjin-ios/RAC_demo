//
//  GYShopDetailCellDelegate.h
//  guangguang
//
//  Created by starnet on 13-4-23.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol GYShopDetailCellDelegate <NSObject>

@optional
- (void)clickUserWillComment;
- (void)checkMoreShopCommentContent;
- (void)clickLoadMore;
@end
