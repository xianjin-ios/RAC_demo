//
//  floorInfoVC.m
//  GGSH
//  商场楼层
//  Created by 任春宁 on 15/7/7.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "floorInfoVC.h"
//#import "MerchantDetailViewController.h"
//#import "BrandOfFloorVC.h"

@interface floorInfoVC ()

@end

@implementation floorInfoVC

//初始化
-(id)initWithShopID:(NSString *)strShopId{
    
    self = [super init];
    if (self) {
        _strShopId = strShopId;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    _collectionView.backgroundColor = [UIColor clearColor];
    
    [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"CollectionCell"];

    [self getFloorInfo];

}


-(void)getFloorInfo{
    //组合参数
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setObject:[NSNumber numberWithInt:1] forKey:@"DeviceID"];
    [dic setObject:_strShopId forKey:@"ShopID"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kShopBrandFloor withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        NSDictionary *resultDic = [results objectForKey:@"Result"];
        ZLog(@"message is:%@",[resultDic objectForKey:@"Message"]);
        if([[resultDic objectForKey:@"Status"] isEqualToString:@"Success"]){
            
            _arrFloor = [resultDic objectForKey:@"FloorListInfo"];
            
            [_collectionView reloadData];
            
            if (self.delegate != nil && [self.delegate respondsToSelector:@selector(loadDataSuccess:)]) {
                [self.delegate loadDataSuccess:_arrFloor];
            }
            
        }
    }];
}


- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section;
{
    return _arrFloor.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    
    static NSString * CellIdentifier = @"CollectionCell";
    UICollectionViewCell * cell = [cv dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    
    cell.contentView.backgroundColor = [UIColor colorWithHexString:@"#F4F4F4"];
    
    NSDictionary * dicInfo = [_arrFloor objectAtIndex:indexPath.row];
    
    //楼层名称
    UILabel * lbFloorName = (UILabel*)[cell.contentView viewWithTag:110];
    if (lbFloorName == nil) {
        lbFloorName = [[UILabel alloc] init];
        lbFloorName.tag = 110;
        lbFloorName.frame = CGRectMake(0, 15, 92, 20);
        [cell.contentView addSubview:lbFloorName];
        lbFloorName.font = [UIFont systemFontOfSize:17];
        lbFloorName.textAlignment = NSTextAlignmentCenter;
    }
    
    lbFloorName.text = [dicInfo objectForKey:@"FloorName"];
    
    
    //品牌数量
    UILabel * lbBrandNum = (UILabel*)[cell.contentView viewWithTag:111];
    if (lbBrandNum == nil) {
        lbBrandNum = [[UILabel alloc] init];
        lbBrandNum.frame = CGRectMake(0, 45, 92, 20);
        lbBrandNum.textColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:lbBrandNum];
        lbBrandNum.font = [UIFont systemFontOfSize:13];
        lbBrandNum.textAlignment = NSTextAlignmentCenter;
    }
    
    NSArray * arrBrands = [dicInfo objectForKey:@"BrandList"];
    lbBrandNum.text = [NSString stringWithFormat:@"(%ld个品牌)", (unsigned long)arrBrands.count];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary * dicFloor = [_arrFloor objectAtIndex:indexPath.row];
    NSArray * arrBrand = [dicFloor objectForKey:@"BrandList"];

//    BrandOfFloorVC *brandVC = [[BrandOfFloorVC alloc] initWithBrandList:arrBrand];
//    brandVC.title = [NSString stringWithFormat:@"%@(%ld个品牌)",[dicFloor objectForKey:@"FloorName"],(unsigned long)arrBrand.count];
//    brandVC.isFromMail = self.isFromMail;
//    brandVC.isFromMpos = self.isFromMpos;
//    [self.navigationController pushViewController:brandVC animated:YES];
}


-(int)getHeight{
    
    
    if (_arrFloor != nil) {
        return (int)( _arrFloor.count / 3 + 1 ) * 85;
    }
    
    return _collectionView.contentSize.height;
    
}

@end
