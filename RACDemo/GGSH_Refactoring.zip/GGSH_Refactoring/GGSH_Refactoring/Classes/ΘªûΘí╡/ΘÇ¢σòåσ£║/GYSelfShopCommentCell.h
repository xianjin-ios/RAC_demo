//
//  GYSelfShopCommentCell.h
//  guangguang
//
//  Created by starnet on 13-4-22.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GYShopDetailCellDelegate.h"
#define Content_Color RGBCOLOR(0x74, 0x74, 0x74)
#define Name_Color RGBCOLOR(0x84,0x63,0x47)

@interface GYSelfShopCommentCell : UITableViewCell

@property (nonatomic, retain) UIImageView *commentImage;
@property (nonatomic, retain) UILabel *commentName;
@property (nonatomic, retain) UILabel *commentTime;
@property (nonatomic, retain) UILabel *commentContent;
@property (nonatomic, retain) UIImageView *lineImg;
@property(nonatomic, retain)  NSDictionary *dataSource;
@property (nonatomic, assign) id<GYShopDetailCellDelegate>delegate;
@property (nonatomic, retain) UIImageView *expandImage;

-(void)setDataSource:(NSDictionary *)value;
-(void)changeSelectCellHight;
@end
