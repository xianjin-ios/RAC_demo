//
//  GYShopInfoBigCell.h
//  逛逛
//
//  Created by STAR on 13-2-27.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface GYShopInfoBigCell : UITableViewCell
@property(nonatomic,retain) IBOutlet UIImageView *image;
@property(nonatomic ,retain) IBOutlet UILabel *name;
@property(nonatomic, retain) IBOutlet UILabel *timeLabel;
@property(nonatomic, retain)NSDictionary *dataSource;
@property(nonatomic, assign) BOOL haveEndTime;//YES:有结束时间。NO：没有结束时间。
@end
