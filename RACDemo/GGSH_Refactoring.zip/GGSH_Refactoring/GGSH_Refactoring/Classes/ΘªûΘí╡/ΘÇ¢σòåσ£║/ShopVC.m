//
//  ShopVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/18.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "ShopVC.h"
#import "ShopCell.h"
#import "WebveiwVC.h"
#import "ShopDetailVC.h"

@interface ShopVC ()<UITableViewDataSource, UITableViewDelegate,MJRefreshBaseViewDelegate>{
    //新闻轮播数据
    NSArray * _arrNews;
    
    //需要刷新数据的通知
    BOOL needUpdateData;
    
    IBOutlet UITableView *_iMyTableView;
    NSMutableArray *dataArray;
    
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    
    UIImageView *imageAlert;
    
    int icurpage;
    
    //轮播图
    UIScrollView *csView;
    UIPageControl * pageCtrl;
    
    //限制3分钟内的重复刷新
    NSDate *date;
    
    //当前位置
    UIView *curLocationView;
    UILabel *curLocationLabel;
}

@end

@implementation ShopVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self cancelTapHideKeyBoard:YES];

    self.title = @"逛商场";
    icurpage = 1;
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    
    //注册城市切换通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cityChanged:) name:@"NOTI_CITY_CHANGED" object:nil];
    
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _iMyTableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _iMyTableView;
    _footer.delegate = self;
    
    //创建轮播图scrollview
    csView = [[UIScrollView alloc] initWithFrame:CGRectMake(0.0,0.0,SCREEN_WIDTH,150.0)];
    csView.delegate = self;
    csView.showsHorizontalScrollIndicator = NO;
    csView.backgroundColor = [UIColor clearColor];
    csView.tag = 2300;
    
    
    pageCtrl = [[UIPageControl alloc] init];
    pageCtrl.frame = CGRectMake(200, 130, 80, 20);
    pageCtrl.backgroundColor = [UIColor blackColor];
    pageCtrl.currentPage = 0;
    pageCtrl.layer.cornerRadius = 10;
    
    //获取轮播图
    [self getNews:csView];
    //获取商户列表
    [self getshopList];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_MALL_VIEW"];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_MALL_VIEW"];
    
    //显示当前位置
    if(MyAppDelegate.curPosition){
        if(!curLocationView){
            curLocationLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 20)];
            curLocationLabel.backgroundColor = [UIColor clearColor];
            curLocationLabel.font = [UIFont systemFontOfSize:13];
            curLocationLabel.textAlignment = NSTextAlignmentCenter;
            
            CGRect viewLocation = CGRectMake(0, self.view.frame.size.height - 110, SCREEN_WIDTH, 20);

            curLocationView = [[UIView alloc] initWithFrame:viewLocation];
            curLocationView.backgroundColor = [UIColor lightGrayColor];
            curLocationView.alpha = 0.8;
            
            [curLocationView addSubview:curLocationLabel];
            [self.view addSubview:curLocationView];
            [self performSelector:@selector(handleLabelTimer) withObject:nil afterDelay:5];
        }
        curLocationLabel.text = [NSString stringWithFormat:@"您的当前位置是:%@", MyAppDelegate.curPosition];
    }
}

//定位的图标处来后5s自动消失，
- (void)handleLabelTimer{
    CGContextRef context = UIGraphicsGetCurrentContext();
    [UIView beginAnimations:nil context:context];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.5];
    [curLocationView setAlpha:0.0f];
    curLocationView.frame = CGRectMake(0, curLocationView.frame.origin.y+30, 320, 30);
    [UIView commitAnimations];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//城市改变
- (void)cityChanged:(NSNotification *)notification {
    needUpdateData = YES;
}

//获取轮播信息
-(void)getNews:(UIScrollView*)scrollView{
    
    UIScrollView * sv = scrollView;
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [xkNetwork xk_requstWithDic:item withUrl:kShopNewsList withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        NSDictionary* dicResults = [results objectForKey:@"Result"];
        
        if ([[dicResults objectForKey:@"Status"] isEqualToString:@"Success"]) {
            
            //获取数据成功
            _arrNews = [dicResults objectForKey:@"ListInfo"];
            
            //初始化数据
            if (sv == nil) {
                return;
            }
            sv.contentSize = CGSizeMake(sv.frame.size.width* _arrNews.count, sv.frame.size.height);
            sv.pagingEnabled = YES;
            
            pageCtrl.numberOfPages = _arrNews.count;

            
            for (int i = 0; i < _arrNews.count; i ++) {
                
                NSDictionary * dicNews = [_arrNews objectAtIndex:i];

                //创建图片控件
                UIImageView * imgView = [[UIImageView alloc] init];
                imgView.frame = CGRectMake(i * sv.frame.size.width, 0, sv.frame.size.width, sv.frame.size.height);
                imgView.backgroundColor = [UIColor clearColor];
                [sv addSubview:imgView];
                
                UIButton *btnImageDetail = [UIButton buttonWithType:UIButtonTypeCustom];
                btnImageDetail.tag = 2000 + i;
                btnImageDetail.frame = CGRectMake(i * sv.frame.size.width, 0, sv.frame.size.width, sv.frame.size.height);
                btnImageDetail.backgroundColor = [UIColor clearColor];
                [btnImageDetail addTarget:self action:@selector(clickNews:) forControlEvents:UIControlEventTouchUpInside];
                [sv addSubview:btnImageDetail];
                
                //加载图片
                NSURL *url = [NSURL URLWithString:[dicNews objectForKey:@"Pic" ]];
                [imgView XK_setImageWithURL:url placeholderImage:nil];
            }
        }
    }];
}

//滑动图片时，更新pageControl
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    int page = (int)scrollView.contentOffset.x / (int)scrollView.frame.size.width;
    pageCtrl.currentPage = page;
}


#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    if(refreshView == _header) {// 下拉刷新
        //先判断网络是否可用
        if(0 == [MyAppDelegate reachBility]){
            UIImageView *alertView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 150, 320, 20)];
            alertView.image = [UIImage imageNamed:@"netNoConnect.png"];
            [self.view addSubview:alertView];
            alertView.tag = 103;
            [self endHeaderAndFooterLoading];
            return;
        }
        
        //3分钟内不能重复发起网络请求，只是界面上闪动下正在加载，就1s。
        if(date){
            NSDate *tLater = [date dateByAddingTimeInterval:kGlbRefreshTimeOut];
            if(NSOrderedDescending == [tLater compare:[NSDate date]]){
                [self performSelector:@selector(endHeaderAndFooterLoading) withObject:nil afterDelay:2];
                return;
            }
        }
        
        icurpage = 1;
        if(0 == MyAppDelegate.ilatitude){//提示用户正在定位
            UIImageView *alertView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 150, 320, 20)];
            alertView.image = [UIImage imageNamed:@"noLocationInfo.png"];
            [self.view addSubview:alertView];
            alertView.tag = 104;
            [self performSelector:@selector(removeAlertViewNoLocation) withObject:nil afterDelay:2];
        }else{
            [self performSelector:@selector(getshopList) withObject:nil afterDelay:1];
        }
        [self performSelector:@selector(endHeaderAndFooterLoading) withObject:nil afterDelay:1];
    }else if(refreshView == _footer){
        icurpage++;
        if(0 == MyAppDelegate.ilatitude){//提示用户正在定位
            UIImageView *alertView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 150, 320, 20)];
            alertView.image = [UIImage imageNamed:@"noLocationInfo.png"];
            [self.view addSubview:alertView];
            alertView.tag = 104;
            [self performSelector:@selector(removeAlertViewNoLocation) withObject:nil afterDelay:2];
        }else{
            [self performSelector:@selector(getshopList) withObject:nil afterDelay:0.1];
        }
        [self performSelector:@selector(endHeaderAndFooterLoading) withObject:nil afterDelay:1];
    }
}

- (void)removeAlertViewNoLocation{
    UIView *alert = [self.view viewWithTag:104];
    if(alert)
        [alert removeFromSuperview];
}

//
- (void)endHeaderAndFooterLoading{
    [_header endRefreshing];
    [_footer endRefreshing];
}

//点击轮播图
-(void)clickNews:(id)sender{
    
    UIButton * btn = (UIButton *)sender;
    NSInteger index = btn.tag - 2000;
    NSDictionary * dic = [_arrNews objectAtIndex:index];
    NSString * strUrl = [dic objectForKey:@"Url"];
    
    if (!strUrl || strUrl.length <= 0) {
        return;
    }
    
    WebveiwVC * ctrl = [[WebveiwVC alloc] init];
    ctrl.url = strUrl;
    ctrl.title = @"详情";
    [self.navigationController pushViewController:ctrl animated:YES];
    
}

//获取商场列表
- (void)getshopList{
    [self showHUD];
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"DeviceID"];
    
    //获取区域
    
    NSString * cityID = [USERDEFAULT objectForKey:@"CityID"];
    
    
    //设置区域
    if(cityID.length > 0){
        [item setObject:cityID forKey:@"RegionID"];
    }else{
        [item setObject:@"D0101" forKey:@"RegionID"];
    }
    //佳艳7.4更改需求，要显示全部
    [item setObject:[NSNumber numberWithInt:-1] forKey:@"Distance"];
    
#if TARGET_IPHONE_SIMULATOR
    [item setObject:[NSNumber numberWithDouble:39.934427] forKey:@"Latitude"];
    [item setObject:[NSNumber numberWithDouble:116.422824] forKey:@"Longitude"];
#else
    [item setObject:[NSNumber numberWithDouble:MyAppDelegate.ilatitude] forKey:@"Latitude"];
    [item setObject:[NSNumber numberWithDouble:MyAppDelegate.ilongitude] forKey:@"Longitude"];
#endif
    
    [item setObject:@"1" forKey:@"ShopType"];
    [item setObject:[NSNumber numberWithInt:icurpage] forKey:@"PageIndex"];
    [item setObject:[NSNumber numberWithInt:20] forKey:@"PageSize"];
    
    [xkNetwork xk_requstWithDic:item withUrl:kGuangguang withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        if(1 == icurpage){
            date = [NSDate date];//保存本次获取数据的时间,且只在第一页时候保存保存这个数据。
            [dataArray removeAllObjects];
        }
        if(nil == dataArray){
            dataArray = [NSMutableArray array];
        }
        [dataArray addObjectsFromArray:[[results objectForKey:@"Result"] objectForKey:@"ListInfo"]];
        [_iMyTableView reloadData];
    }];
}

#pragma mark tableview begin
- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(0 == indexPath.row){
        static NSString *CellIdentifier = @"topCell";
        UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            [cell.contentView addSubview:csView];
            [cell.contentView addSubview:pageCtrl];
        }
        return cell;
    }else{
        static NSString *CellIdentifier = @"ShopCell";
        ShopCell *cell = (ShopCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[ShopCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        cell.dataSource = [dataArray objectAtIndex:indexPath.row - 1];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
}

//指定每个分区中有多少行，默认为1
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return dataArray.count + 1;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(0 == indexPath.row)
        return 150;
    else
        return 60;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.row == 0)
        return;
    ShopDetailVC *idetailView = [[ShopDetailVC alloc] init];
    idetailView.shopID = [[dataArray objectAtIndex:indexPath.row - 1]objectForKey:@"ShopID"];
    idetailView.isFromMail = YES;
    [self.navigationController pushViewController:idetailView animated:YES];
}

@end
