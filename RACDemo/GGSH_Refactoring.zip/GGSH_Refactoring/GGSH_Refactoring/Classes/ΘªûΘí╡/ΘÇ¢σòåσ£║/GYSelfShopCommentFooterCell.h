//
//  GYSelfShopCommentFooterCell.h
//  guangguang
//
//  Created by starnet on 13-4-23.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GYShopDetailCellDelegate.h"

@interface GYSelfShopCommentFooterCell : UITableViewCell

@property (nonatomic ,retain)UIButton *shoppingMoreBtn;
@property (nonatomic, assign) id<GYShopDetailCellDelegate>delegate;
@end
