//
//  floorInfoVC.h
//  GGSH
//  商场楼层
//  Created by 任春宁 on 15/7/7.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

//加载数据成功代理
@protocol FLOOOR_DELEGATE <NSObject>

//加载数据成功
-(void)loadDataSuccess:(NSArray *)info;

@end

@interface floorInfoVC : BaseViewController<UICollectionViewDataSource, UICollectionViewDelegate>{
    
    
    IBOutlet UICollectionView * _collectionView;
    
    NSArray * _arrFloor;
    
    //保存商场ID
    NSString * _strShopId;
    
    
}

@property (nonatomic,assign) BOOL isFromMpos;
@property (nonatomic,assign) BOOL isFromMail;

@property ( nonatomic, strong ) UINavigationController * navigationController;

@property( nonatomic, strong) id< FLOOOR_DELEGATE > delegate;


-(id)initWithShopID:(NSString *)strShopId;

-(void)getFloorInfo;

//获取高度
-(int)getHeight;

@end



