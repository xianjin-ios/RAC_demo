//
//  GYShopInfoBigCell.m
//  逛逛
//
//  Created by STAR on 13-2-27.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import "GYShopInfoBigCell.h"

@implementation GYShopInfoBigCell
@synthesize image,dataSource,name,timeLabel;
@synthesize haveEndTime;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        // Initialization code
        image = [[UIImageView alloc]initWithFrame:CGRectMake(5, 5, 310, 115)];
        //????
//        image.isShopInfoBigCell = YES;
        image.image = [UIImage imageNamed:@"bgPlaceHolder.png"];
        [self.contentView addSubview: image];
        
        UIImageView *backgroundimage = [[UIImageView alloc]initWithFrame:CGRectMake(5, 120, 310, 60)];
        backgroundimage.image = [UIImage imageNamed:@"shopdetailbackgroun.png"];
        [self.contentView addSubview:backgroundimage];
        
        name = [[UILabel alloc]initWithFrame:CGRectMake(14, 125,300, 20)];
        [self.contentView addSubview:name];
        
        timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(14, 148,300, 20)];
        timeLabel.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:timeLabel];
    }
    return self;
}

//- (void)setSelected:(BOOL)selected animated:(BOOL)animated
//{
//    [super setSelected:selected animated:animated];
//
//    // Configure the view for the selected state
//}
-(void)setDataSource:(NSDictionary *)value
{
    if ([value isEqualToDictionary:dataSource]) {
		return;
	}

	dataSource = value;
	[self setNeedsLayout];
}

-(void)layoutSubviews
{
    ZLog(@"%@",dataSource);
    if([dataSource objectForKey:@"InfoTitle"])
        name.text=[dataSource objectForKey:@"InfoTitle"];
    if(haveEndTime){
        timeLabel.text = [NSString stringWithFormat:@"活动时间：%@ 至 %@",[dataSource objectForKey:@"BeginTime"],[dataSource objectForKey:@"EndTime"]];
    }else{
        timeLabel.text = [NSString stringWithFormat:@"开始时间：%@",[dataSource objectForKey:@"BeginTime"]];
    }
    
    NSString *imagePath = nil;
    if(((NSString *)[dataSource valueForKey:@"PictureUrl"]).length > 0){
    imagePath = [NSString stringWithFormat:@"%@%@%@",[[dataSource valueForKey:@"PictureUrl"] substringToIndex:(((NSString *)[dataSource valueForKey:@"PictureUrl"]).length - 4)],@"_cover1",[[dataSource valueForKey:@"PictureUrl"] substringFromIndex:(((NSString *)[dataSource valueForKey:@"PictureUrl"]).length - 4)]];
    }
    
    [image XK_setImageWithURL:[NSURL URLWithString:imagePath] placeholderImage:nil];
}
@end
