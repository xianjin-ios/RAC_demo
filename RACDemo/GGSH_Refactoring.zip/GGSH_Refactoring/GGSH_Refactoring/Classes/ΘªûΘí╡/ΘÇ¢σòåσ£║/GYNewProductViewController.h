//
//  GYNewProductViewController.h
//  GGSH_Refactoring
//
//  Created by siqiyang on 16/12/8.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface GYNewProductViewController : BaseViewController

@end
