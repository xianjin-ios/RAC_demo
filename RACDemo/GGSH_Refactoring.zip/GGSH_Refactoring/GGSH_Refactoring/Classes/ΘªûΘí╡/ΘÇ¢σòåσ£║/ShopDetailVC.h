//
//  ShopDetailVC.h
//  cards
//
//  Created by STAR on 16-10-19.
//  Copyright (c) 2016年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "XLCycleScrollView.h"
//#import "MerchantDetailViewController.h"
//zhang jun
#import "GYShopDetailCellDelegate.h"
#import "floorInfoVC.h"
#import "BaseViewController.h"
#import "loginVC.h"

@interface ShopDetailVC : BaseViewController<UITableViewDataSource, UITableViewDelegate, GYShopDetailCellDelegate, loginDelegate/*,refreshNewProduct*/, FLOOOR_DELEGATE>{
    BOOL refresh;//yes 刷新
    BOOL isShowBigbeen;//yes：需要显示bigbeen；no：不需要显示bigbeen；
    UIView *bigbeen;//无数据提醒图；
    
    NSMutableArray *trueimageArray;
    NSString *shopID;
    NSString *shopType;
    NSString *iLatitude;
    NSString *iLongitude;
    
    //
    NSString *logoPic;
    
    IBOutlet UILabel *topLabel;
    
    IBOutlet UILabel *topLabel2;//top2上的label
    IBOutlet UILabel *topLabel3;//top3上的label
    IBOutlet UILabel *favnum;


    IBOutlet UITableViewCell *topcell;
    IBOutlet UITableViewCell *topcell2;
    IBOutlet UITableViewCell *arrayinfo1;
    IBOutlet UITableViewCell *arrayinfo2;
    IBOutlet UITableViewCell *arrayinfo3;
    IBOutlet UITableViewCell *arrayinfo4;
    IBOutlet UITableViewCell *cardInfo;
    
    IBOutlet UITableViewCell *introCell;
    IBOutlet UITextView *introTextView;

    
    IBOutlet UILabel *weiboLabel;
    IBOutlet UILabel *netLabel;
    IBOutlet UILabel *addressLabel;
    IBOutlet UILabel *phoneLabel;
    
    UIButton *attentionbtn;
    //当前选取的是优惠信息，商场卡信息，商场信息，商场品牌
    int curtype;
    
    UIView *subview;
    
    //YES:显示页面的时候push评论的页面；NO：不做处理
    BOOL pushPublishFlag;

    //当前新品优惠的页数，默认是1.
    int curPage;
    
    
    //大众点评的DianpingShopID
    NSNumber *dianpingShopID;
    
    //官，惠，折 icon
    UIImageView *iconImageView;
    UIImageView *iconImageView2;
    UIImageView *iconImageView3;
}

@property (nonatomic,assign) BOOL isFromMpos;
@property (nonatomic,assign) BOOL isFromMail;
@property (nonatomic,assign) BOOL isFromMyAttention;//是否来自我的关注
@property (nonatomic, retain) NSString * shopID;

@property (nonatomic, retain) NSDictionary *shopInfo;//保存了商场的详情，目的：收藏；
@property (nonatomic, retain) IBOutlet UITableView *iMyTableView;
@property (nonatomic, retain) NSMutableArray *dataArray;

@property (nonatomic, retain) NSArray *headPicArray;
//商户信息列表
@property (nonatomic, retain) NSString *lasttime;
@property (nonatomic, retain) NSArray *shopCardArray;
@property (nonatomic, retain) NSMutableArray *shopListInfoArray;//新品优惠


@property (nonatomic, retain) UILabel *topLabel;
@property (nonatomic, retain) UILabel *topLabel2;
@property (nonatomic, retain) UILabel *topLabel3;
@property (nonatomic, retain) UILabel *favnum;

//@property (nonatomic, retain) ASIFormDataRequest *netcardrequest;
//@property (nonatomic, retain) ASIFormDataRequest *netOtherrequest;
@property (nonatomic, retain) NSArray *shopOtherArray;
//@property (nonatomic, retain) ASIFormDataRequest *collectrequest;

@property (nonatomic, retain) IBOutlet UIButton *topbtn0;
@property (nonatomic, retain) IBOutlet UIButton *topbtn1;
@property (nonatomic, retain) IBOutlet UIButton *topbtn2;
@property (nonatomic, retain) IBOutlet UIButton *topbtn3;
@property (nonatomic, retain) IBOutlet UIButton *top2btn1;
@property (nonatomic, retain) IBOutlet UIButton *top2btn2;
@property (nonatomic, retain) IBOutlet UIButton *top2btn3;

@property (nonatomic, retain) UITableViewCell *topcell;
@property (nonatomic, retain) UITableViewCell *topcell2;
@property (nonatomic, retain) IBOutlet UITextView *brandintrocelltext;

@property (nonatomic, retain) UITableViewCell *arrayinfo1;
@property (nonatomic, retain) UITableViewCell *arrayinfo2;
@property (nonatomic, retain) UITableViewCell *arrayinfo3;
@property (nonatomic, retain) UITableViewCell *arrayinfo4;

@property (nonatomic, retain) UITableViewCell *introCell;
@property (nonatomic, retain) UITextView *introTextView;
@property (nonatomic, retain) NSString *Intro;


@property (nonatomic, retain) UILabel *weiboLabel;
@property (nonatomic, retain) UILabel *netLabel;
@property (nonatomic, retain) UILabel *addressLabel;
@property (nonatomic, retain) UILabel *phoneLabel;
//- (void)getDetailInfo:(NSString*)ShopID;
- (IBAction)attention:(id)sender;
- (IBAction)showMap:(id)sender;
- (IBAction)showWeibo:(id)sender;
- (IBAction)gotoweb:(id)sender;
- (IBAction)telephone:(id)sender;
- (void)showPublishView;

//zhang jun
@property (nonatomic, retain) NSString *refreshtime;
@property (nonatomic, retain) NSArray *shopCommentInfoArray;//商户评论信息
@property (nonatomic, assign) NSInteger shopCommentCount;
@property (nonatomic, retain) NSMutableDictionary *dicClicked;

//大众点评的评论
@property (nonatomic, retain) NSArray *dianPingArray;

@property (nonatomic, assign) int intNumTest;
@end
