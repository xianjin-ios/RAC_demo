//
//  ShopVC.h
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/18.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface ShopVC : BaseViewController

@end
