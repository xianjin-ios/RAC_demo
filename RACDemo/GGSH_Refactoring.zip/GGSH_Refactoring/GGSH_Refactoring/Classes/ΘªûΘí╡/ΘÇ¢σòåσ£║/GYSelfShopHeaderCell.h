//
//  GYSelfShopHeaderCell.h
//  guangguang
//
//  Created by starnet on 13-4-23.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GYShopDetailCellDelegate.h"
#define Content_Colors RGBCOLOR(0x84,0x63,0x47)
@interface GYSelfShopHeaderCell : UITableViewCell

@property (nonatomic, retain) UIImageView *commentIconImg;
@property (nonatomic, retain) UIButton *commentNumber;
@property (nonatomic, retain) UIButton *shoppingCommentBtn;
@property (nonatomic, retain) id<GYShopDetailCellDelegate>delegate;
@property (nonatomic, assign) NSInteger count;
-(void)setDataSource:(NSInteger)value;
@end
