//
//  GYOtherShopCell.h
//  cards
//
//  Created by STAR on 13-1-11.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GYOtherShopCell : UITableViewCell{
    NSDictionary *dataSource;
}
@property(nonatomic ,retain) IBOutlet UILabel *nameLabel;
@property(nonatomic, retain) IBOutlet UILabel *addressLabel;
@property(nonatomic, retain) IBOutlet UILabel *phoneLabel;
@property(nonatomic, retain) IBOutlet UILabel *distanceLabel;
@property(nonatomic, retain)NSDictionary *dataSource;

-(void)setDataSource:(NSDictionary *)value;
@end
