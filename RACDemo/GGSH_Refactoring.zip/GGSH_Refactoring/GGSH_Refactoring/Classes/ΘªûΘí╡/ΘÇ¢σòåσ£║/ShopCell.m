//
//  ShopCell.m
//  hongdian
//
//  Created by STAR on 16-10-19.
//  Copyright (c) 2016年 STAR. All rights reserved.
//

#import "ShopCell.h"
#import "QuartzCore/QuartzCore.h"

@implementation ShopCell
@synthesize name,infoTitle,dislabel;
@synthesize image;
@synthesize imageView;
@synthesize dataSource;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        UIImageView *backimage = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bgCell.png"]];
        backimage.frame = CGRectMake(0, 0, 320, 60);
        [self addSubview:backimage];

        name = [[UILabel alloc]initWithFrame:CGRectMake(65, 6, 220, 28)];
        name.backgroundColor = [UIColor clearColor];
        name.font = [UIFont systemFontOfSize:15];
        [self addSubview:name];
        
        //三个小图标
        iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake(300, 6, 16, 17)];
        [self addSubview:iconImageView];
        
        iconImageView2 = [[UIImageView alloc] initWithFrame:CGRectMake(300, 6, 16, 17)];
        [self addSubview:iconImageView2];
        
        iconImageView3 = [[UIImageView alloc] initWithFrame:CGRectMake(300, 6, 16, 17)];
        [self addSubview:iconImageView3];
        
        infoTitle = [[UILabel alloc]initWithFrame:CGRectMake(65, 35, 187, 21)];
        infoTitle.backgroundColor = [UIColor clearColor];
        infoTitle.font = [UIFont systemFontOfSize:12];
        [self addSubview:infoTitle];
        
        dislabel = [[UILabel alloc]initWithFrame:CGRectMake(238, 35, 62, 21)];
        dislabel.backgroundColor = [UIColor clearColor];
        dislabel.font = [UIFont systemFontOfSize:11];
        dislabel.textAlignment = NSTextAlignmentRight;
        [self addSubview:dislabel];
        dislabel.hidden = YES;
        UIImageView *pointerview = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"arrow.png"]];
        pointerview.frame = CGRectMake(292, 28, 7, 14);
        [self addSubview:pointerview];
        
        //分割线
        UIView *sepLineView = [[UIView alloc]initWithFrame:CGRectMake(0, 60 - ONEPIXL, SCREEN_WIDTH, ONEPIXL)];
        sepLineView.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:sepLineView];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated{
    [super setSelected:selected animated:animated];
}

-(void)setDataSource:(NSDictionary *)value
{
    if ([value isEqualToDictionary:dataSource]) {
		return;
	}

	dataSource = value;
    
    if(image){
        [image removeFromSuperview];
    }
    image = [[UIImageView alloc]initWithFrame:CGRectMake(12.5, 8, 45, 45)];
    image.image = [UIImage imageNamed:@"bgPhoto.png"];
    [self addSubview:image];
    NSString *imagePath = [dataSource valueForKey:@"Logo"];
    if (imagePath != nil && (NSNull *)imagePath != [NSNull null] && ![imagePath isEqualToString:@""]){
        NSURL *url = [NSURL URLWithString:imagePath];
        image.image = nil;
        [image XK_setImageWithURL:url placeholderImage:nil];
        image.layer.cornerRadius = 6;
    }
    
	[self setNeedsLayout];
}

-(void)layoutSubviews
{
    
    name.text=[dataSource objectForKey:@"ShopName"];
    
    //加载一张小图标。
    if([[dataSource objectForKey:@"Icon1"] isEqualToString:@"True"]){
        CGSize dateStringSize = [NSString getHeight:name.text withFont:name.font andWidth:310];
        int lensize = dateStringSize.width > 177 ? 177:dateStringSize.width;
        ZLog(@"%@--%d", name.text,lensize);
        iconImageView.frame = CGRectMake(lensize+80, 12, 16, 17);
        iconImageView.image = [UIImage imageNamed:@"guan_icon.png"];
    }else{
        iconImageView.image = nil;
    }
    if([[dataSource objectForKey:@"Icon2"] isEqualToString:@"True"]){
        CGSize dateStringSize = [NSString getHeight:name.text withFont:name.font andWidth:310];
        int lensize = dateStringSize.width > 177 ? 177:dateStringSize.width;
        iconImageView2.frame = CGRectMake(lensize+80 + 20, 12, 16, 17);
        iconImageView2.image = [UIImage imageNamed:@"hui_icon.png"];
    }else{
        iconImageView2.image = nil;
    }
    if([[dataSource objectForKey:@"Icon3"] isEqualToString:@"True"]){
        CGSize dateStringSize = [NSString getHeight:name.text withFont:name.font andWidth:310];
        int lensize = dateStringSize.width > 177 ? 177:dateStringSize.width;
        iconImageView3.frame = CGRectMake(lensize+80 + 40, 12, 16, 17);
        iconImageView3.image = [UIImage imageNamed:@"zhe_icon.png"];
    }else{
        iconImageView3.image = nil;
    }
    
    
    infoTitle.text = [dataSource objectForKey:@"Address"];
    NSString *distance = [dataSource objectForKey:@"Distance"];
    if(distance.length > 3)
        distance = [NSString stringWithFormat:@"%@.%@km",[distance substringToIndex:(distance.length - 3)],[distance substringWithRange:NSMakeRange(distance.length - 3,1)]];
    else
        distance = [NSString stringWithFormat:@"%@m",distance];
    dislabel.text = distance;
    
}

@end
