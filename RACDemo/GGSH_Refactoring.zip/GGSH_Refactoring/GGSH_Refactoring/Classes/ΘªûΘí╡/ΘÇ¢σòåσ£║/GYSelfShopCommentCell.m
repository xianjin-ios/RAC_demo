//
//  GYSelfShopCommentCell.m
//  guangguang
//
//  Created by starnet on 13-4-22.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import "GYSelfShopCommentCell.h"
//#import "EGOImageView.h"
//#import "EGOCache.h"
@implementation GYSelfShopCommentCell

@synthesize commentImage,commentName,commentTime,commentContent,dataSource,delegate,lineImg,expandImage;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self addContentView];
        CGRect nextLineRect = CGRectMake(0, 123, 320, 1);
        [self addPartingLine:nextLineRect];
    }
    return self;
}

- (void)addPartingLine:(CGRect)rect
{
    self.lineImg = [[UIImageView alloc]initWithFrame:rect];
    [lineImg setImage:[UIImage imageNamed:@"line.png"]];
    [self addSubview:lineImg];
}

-(void)changeSelectCellHight
{
   // ZLog(@"CommentContent:%@",[dataSource objectForKey:@"CommentContent"]);
    NSString *string = [dataSource objectForKey:@"CommentContent"];
    CGSize size = [NSString getHeight:string withFont:[UIFont systemFontOfSize:12] andWidth:280];
    [self.commentContent setFrame:CGRectMake(10, 55, 300, size.height)];
    CGRect selectRect = CGRectMake(0, 123+size.height-30, 320, 1);
    [self.lineImg setFrame:selectRect];
    CGRect selectBtnRect = CGRectMake(230, 90+size.height-30, 71, 21);
    [self.expandImage setFrame:selectBtnRect];
    [expandImage setImage:[UIImage imageNamed:@"clickRetract.png"]];
}

- (void)addContentView
{
    //ZLog(@"%@",dataSource);
    self.commentImage = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 38, 38)];
    [self addSubview:commentImage];
    
    self.commentName = [[UILabel alloc]initWithFrame:CGRectMake(53, 15, 150, 15)];
    [self.commentName setFont:[UIFont systemFontOfSize:12]];
    self.commentName.textColor = [UIColor colorWithHexString:@"#846347"];
    [self.commentName setBackgroundColor:[UIColor clearColor]];
    [self addSubview:commentName];
    
    self.commentTime = [[UILabel alloc]initWithFrame:CGRectMake(53, 28, 150, 30)];
    [self.commentTime setFont:[UIFont systemFontOfSize:10]];
    self.commentTime.textColor = [UIColor colorWithHexString:@"#747474"];
    [self.commentTime setBackgroundColor:[UIColor clearColor]];
    [self addSubview:commentTime];
    
    self.commentContent = [[UILabel alloc]initWithFrame:CGRectMake(10, 55, 300, 30)];
    [self.commentContent setFont:[UIFont systemFontOfSize:12]];
    self.commentContent.numberOfLines = 0;
    self.commentContent.textColor =  [UIColor colorWithHexString:@"#747474"];
    self.commentContent.lineBreakMode = NSLineBreakByCharWrapping;
    [self.commentContent setBackgroundColor:[UIColor clearColor]];
    [self addSubview:commentContent];
    
    self.expandImage = [[UIImageView alloc]initWithFrame:CGRectMake(230, 90, 71, 21)];
    [self.expandImage setImage:[UIImage imageNamed:@"clickExpand.png"]];
    [self addSubview:expandImage];
}

-(void)setDataSource:(NSDictionary *)value
{
    if ([value isEqualToDictionary:dataSource]) {
		return;
	}
	dataSource = value;
	[self setShopData];
}

- (void)setShopData{
    if([dataSource objectForKey:@"UserAvatars"])
    {
        NSString *imagePath = nil;
        if(((NSString *)[dataSource valueForKey:@"UserAvatars"]).length > 0){
            imagePath = [NSString stringWithFormat:@"%@",[dataSource valueForKey:@"UserAvatars"]];
        }
        //ZLog(@"imagePath:%@",imagePath);
        NSURL *url = [NSURL URLWithString:imagePath];
        [self.commentImage XK_setImageWithURL:url placeholderImage:nil];
    }else{
        [self.commentImage setImage:[UIImage imageNamed:@"commentIcon.png"]];
    }
    
    if([dataSource objectForKey:@"NickName"])
    {
        [self.commentName setText:[dataSource objectForKey:@"NickName"]];
    }
    
    [self.commentTime setText:[dataSource objectForKey:@"CreateTime"]];
    
    [self.commentContent setText:[dataSource objectForKey:@"CommentContent"]];
    CGSize contentSize = [self getStringLength:[dataSource objectForKey:@"CommentContent"]];
    //ZLog(@"contentSize.height:%f",contentSize.height);
    if(contentSize.height <= 35)
    {
        [self.expandImage setImage:[UIImage imageNamed:@"grayClick.png"]];
    }
}

- (CGSize)getStringLength:(NSString *)string
{
    CGSize size = [NSString getHeight:string withFont:[UIFont systemFontOfSize:12] andWidth:280];
    return size;
}

@end
