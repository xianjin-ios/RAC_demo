//
//  ShopDetailVC.m
//  cards
//
//  Created by STAR on 16-10-19.
//  Copyright (c) 2016年 STAR. All rights reserved.
//

#import "ShopDetailVC.h"
//#import "GYShopInfoCell.h"
//#import "GYMapViewController.h"
//#import "GYShopMerchantViewController.h"
#import "WebveiwVC.h"
#import "GYOtherShopCell.h"
#import "AppDelegate.h"
#import "floorInfoVC.h"
#import "GYShopInfoBigCell.h"
//#import "GYNewProductViewController.h"
#import "GYShopCell.h"
//#import "AttentionShop.h"
//#import "GYAlbumViewController.h"
#import "CommonCrypto/CommonDigest.h"
//#import "GYSubmitPruduct.h"
#import "GYSelfShopCommentCell.h"
#import "GYSelfShopHeaderCell.h"
#import "GYSelfShopCommentFooterCell.h"
//#import "GYPublishViewController.h"
//#import "GYShopCommentListViewController.h"
#import "LoginVC.h"
//#import "CardViewController.h"
#import "MyMessageVC.h"
//#import "mposDetailViewController.h"
#import "GYNewProductViewController.h"
#import "GYShopInfoDetailViewController.h"
@interface ShopDetailVC ()<MJRefreshBaseViewDelegate,loginDelegate>{
    //商场品牌
    NSArray *merchantArray;
    
    //楼层信息
    floorInfoVC * _floorVC;
    
    //商场品牌下边的分类
    UIButton *typeBtn1;
    UIButton *typeBtn2;
    UIButton *typeBtn3;
    UIButton *typeBtn4;
    
    MJRefreshFooterView *_footer;
    
    UIImageView *imageAlert;
}

@end

@implementation ShopDetailVC
@synthesize iMyTableView, dataArray;
@synthesize topcell, topcell2;
@synthesize weiboLabel, netLabel, addressLabel, phoneLabel;
@synthesize arrayinfo1, arrayinfo2, arrayinfo3, arrayinfo4;
@synthesize Intro , introCell, introTextView;
@synthesize topbtn0,topbtn1,topbtn2,topbtn3;
@synthesize topLabel,favnum;
@synthesize shopListInfoArray, shopCardArray, lasttime;
@synthesize shopOtherArray;
@synthesize brandintrocelltext;//品牌简介。
@synthesize topLabel2, topLabel3;//第2个top的店名。
@synthesize top2btn1, top2btn2, top2btn3;
@synthesize headPicArray;
@synthesize shopInfo;
//zhang jun
@synthesize refreshtime,shopCommentInfoArray,shopCommentCount,dicClicked;
@synthesize dianPingArray;
@synthesize shopID;

- (void) setRefresh{
    refresh = YES;
}

#pragma mark 网络
-(void)getShopInfoList{
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"DeviceID"];
    if(nil != [[NSUserDefaults standardUserDefaults] objectForKey:@"CityID"]){
        [item setObject:[[NSUserDefaults standardUserDefaults] objectForKey:@"CityID"] forKey:@"RegionID"];
    }else{
        [item setObject:@"D0101" forKey:@"RegionID"];
    }
    
    [item setObject:@"1|2" forKey:@"InfoType"];
    
    [item setObject:[NSNumber numberWithInt:shopID.intValue] forKey:@"ShopID"];
    [item setObject:[NSNumber numberWithInt:curPage] forKey:@"PageIndex"];
    [item setObject:[NSNumber numberWithInt:30] forKey:@"PageSize"];
    if( nil == self.lasttime ){
        NSString *datestr;
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setTimeZone:[NSTimeZone systemTimeZone]];
        [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
        datestr = [formatter stringFromDate:[NSDate date]];
        [item setObject:datestr forKey:@"RefreshTime"];
        [item setObject:datestr forKey:@"RefreshTime"];
    }else{
        [item setObject:self.lasttime forKey:@"RefreshTime"];
    }
    
    [xkNetwork xk_requstWithDic:item withUrl:kShopInfoList withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];

        ZLog(@"---%@",[results objectForKey:@"Result"]);
        self.lasttime = [[[results objectForKey:@"Result"] objectForKey:@"DetailInfo"]objectForKey:@"RefreshTime"];
        
        NSArray *tempArr = [[results objectForKey:@"Result"] objectForKey:@"ListInfo"];
        
        if (curPage == 1) {
            [self.shopListInfoArray removeAllObjects];
        }
        
        if (tempArr.count == 0) {
            refresh = NO;
            
            curPage --;
            if (curPage < 0) {
                curPage = 1;
            }
        }else{
            if (curPage == 1) {
                self.shopListInfoArray = [tempArr mutableCopy];
            }else{
                [self.shopListInfoArray addObjectsFromArray:tempArr];
            }
        }
        
        isShowBigbeen = YES;
        [self.iMyTableView reloadData];
    }];
}

-(void)getShopDetail{
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    
    [item setObject:shopID forKey:@"ShopID"];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"UserID"];
    }
    [item setObject:@"1" forKey:@"DeviceID"];
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    
    [xkNetwork xk_requstWithDic:item withUrl:kShopDetail withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];

        NSDictionary *dict1 = results;
        if([dict1 objectForKey:@"DetailInfo"] && ![[dict1 objectForKey:@"ErrorCode"] isEqualToString:@""]){
            return;
        }else{
            ZLog(@"result string is:%@",results);
            self.shopInfo = [[dict1 objectForKey:@"Result"]objectForKey:@"DetailInfo"];
            //图片数组，图片数量不确定，需要精确判断。
            self.topLabel.text = [self.shopInfo objectForKey:@"ShopName"];
            dianpingShopID = [[self.shopInfo objectForKey:@"DianpingShopID"] copy];
            
            shopType = [[self.shopInfo objectForKey:@"ShopType"] copy];
            if([shopType isEqualToString:@"2"]){
                self.title = @"商户详情";
            }else{
                [self performSelector:@selector(setTitleWithTimeElaps:) withObject:@"商场详情" afterDelay:0.3];
            }
            
            //是否关注
            NSString *IsAttented = [self.shopInfo objectForKey:@"IsAttented"];
            if ([IsAttented isEqualToString:@"1"]) {
                [attentionbtn setSelected:YES];
            }else{
                [attentionbtn setSelected:NO];
            }
            
            //三个小图标
            if([[self.shopInfo objectForKey:@"Icon1"] isEqualToString:@"True"]){
                iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake(100, 6, 16, 17)];
                [self.introCell addSubview:iconImageView];
                iconImageView.image = [UIImage imageNamed:@"guan_icon.png"];
            }
            
            if([[self.shopInfo objectForKey:@"Icon2"] isEqualToString:@"True"]){
                iconImageView2 = [[UIImageView alloc] initWithFrame:CGRectMake(120, 6, 16, 17)];
                [self.introCell addSubview:iconImageView2];
                iconImageView2.image = [UIImage imageNamed:@"hui_icon.png"];
            }
            
            if([[self.shopInfo objectForKey:@"Icon3"] isEqualToString:@"True"]){
                iconImageView3 = [[UIImageView alloc] initWithFrame:CGRectMake(140, 6, 16, 17)];
                [self.introCell addSubview:iconImageView3];
                iconImageView3.image = [UIImage imageNamed:@"zhe_icon.png"];
            }
            
            if([[self.shopInfo objectForKey:@"AttentionCount"] isKindOfClass:[NSNumber class]]){
                self.favnum.text = [[[[dict1 objectForKey:@"Result"] objectForKey:@"DetailInfo"] objectForKey:@"AttentionCount"] stringValue];
            }else if([[self.shopInfo objectForKey:@"AttentionCount"] isKindOfClass:[NSString class]]){
                self.favnum.text = [self.shopInfo objectForKey:@"AttentionCount"];
            }
            self.topLabel2.text = [self.shopInfo objectForKey:@"ShopName"];
            
            self.topLabel3.text = [self.shopInfo objectForKey:@"BrandSimpleName"];
            self.headPicArray = [self.shopInfo objectForKey:@"PictureList"];
            logoPic = [[self.shopInfo objectForKey:@"Logo"] copy];
            
            if(self.headPicArray.count > 0){
                NSString *tempStr = [self.headPicArray objectAtIndex:0];
                UIImageView *shoplogo = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 132)];
                [shoplogo XK_setImageWithURL:[NSURL URLWithString:tempStr] placeholderImage:nil];
                
                [topcell addSubview:shoplogo];
                
                //上传照片的提示
                UIView *myexView = [[UIView alloc]init];
                myexView.bounds = CGRectMake(0, 0, 132, 24);
                myexView.center = CGPointMake(160, 112);
                myexView.layer.cornerRadius = 4;
                myexView.backgroundColor = [UIColor colorWithRed:138/255.0f green:109/255.0f blue:79/255.0f alpha:0.75];
                [topcell addSubview:myexView];
                myexView.hidden = YES;
                UILabel *textLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 132, 24)];
                textLabel.textColor = [UIColor whiteColor];
                textLabel.backgroundColor = [UIColor clearColor];
                textLabel.font = [UIFont boldSystemFontOfSize:14];
                textLabel.textAlignment = NSTextAlignmentCenter;
                textLabel.text = @"进入相册上传照片";
                [myexView addSubview:textLabel];
            }
            if([[self.shopInfo objectForKey:@"Weibo"] isEqualToString:@""]){
                weiboLabel.text = @"微博：暂时没有微博";
            }else{
                weiboLabel.text = [NSString stringWithFormat:@"微博:%@",[[[dict1  objectForKey:@"Result"] objectForKey:@"DetailInfo"] objectForKey:@"Weibo"]];
                ZLog(@"%@",dict1 );
            }
            if([[self.shopInfo objectForKey:@"WebSiteUrl"] isEqualToString:@""])
                netLabel.text = @"暂时没有网站哦";
            else
                netLabel.text = [NSString stringWithFormat:@"官网：%@",[self.shopInfo objectForKey:@"WebSiteUrl"]];
            addressLabel.text = [[[dict1 objectForKey:@"Result"] objectForKey:@"DetailInfo"] objectForKey:@"Address"];
            phoneLabel.text = [NSString stringWithFormat:@"电话：%@",[self.shopInfo objectForKey:@"Phone"]];
            self.Intro = [self.shopInfo objectForKey:@"Intro"];
            
            iLatitude = [[self.shopInfo objectForKey:@"Latitude"] copy];
            iLongitude = [[self.shopInfo objectForKey:@"Longitude"] copy];
            isShowBigbeen = YES;
            [iMyTableView reloadData];
        }
    }];
}

- (void)removeAlertView{
    UIView *alert = [self.view viewWithTag:103];
    if(alert)
        [alert removeFromSuperview];
    
    bigbeen.hidden = NO;
}

- (void)getDetailInfo:(NSString*)ShopID{
    ZLog(@"%@",ShopID);
    if(nil == ShopID){
        return;
    }
    shopID = [ShopID copy];
    
    //先判断网络是否可用
    if(0 == [MyAppDelegate reachBility]){
        
        UIImageView *alertView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 150, 320, 20)];
        alertView.image = [UIImage imageNamed:@"netNoConnect.png"];
        [self.view addSubview:alertView];
        alertView.tag = 103;
        [self performSelector:@selector(removeAlertView) withObject:nil afterDelay:1];
        return;
    }
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];

    [item setObject:shopID forKey:@"ShopID"];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"UserID"];
    }
    [item setObject:@"1" forKey:@"DeviceID"];
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    
    //一次调用2个接口 如下－－－－
    NSMutableDictionary *item2 = [[NSMutableDictionary alloc] init];
    [item2 setObject:[NSNumber numberWithInt:1] forKey:@"DeviceID"];
    if(nil != [[NSUserDefaults standardUserDefaults] objectForKey:@"CityID"]){
        [item2 setObject:[USERDEFAULT objectForKey:@"CityID"] forKey:@"RegionID"];
    }else{
        [item2 setObject:@"D0101" forKey:@"RegionID"];
    }
    
    [item2 setObject:@"1|2" forKey:@"InfoType"];
    [item2 setObject:[NSNumber numberWithInt:shopID.intValue] forKey:@"ShopID"];
    [item2 setObject:[NSNumber numberWithInt:curPage] forKey:@"PageIndex"];
    [item2 setObject:[NSNumber numberWithInt:30] forKey:@"PageSize"];
    [item2 setObject:@"1" forKey:@"devicetype"];
    [item2 setObject:KVERSION forKey:@"version_name"];
    if( nil == self.lasttime ){
        NSString *datestr;
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setTimeZone:[NSTimeZone systemTimeZone]];
        [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
        datestr = [formatter stringFromDate:[NSDate date]];
        [item2 setObject:datestr forKey:@"RefreshTime"];
        [item2 setObject:datestr forKey:@"RefreshTime"];
    }else{
        [item2 setObject:self.lasttime forKey:@"RefreshTime"];
    }

    

    NSDictionary *dicA = [NSDictionary dictionaryWithObjectsAndKeys:@"shopInterface",@"Mod",@"getShopDetail",@"Act",item,@"Content", nil];
    NSDictionary *dicB = [NSDictionary dictionaryWithObjectsAndKeys:@"informationInterface",@"Mod",@"getInfoListByShop",@"Act",item,@"Content", nil];
    
    [xkNetwork xk_requstWithDic:dicA withUrl:kManyInterfaceWithOnetime withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        NSDictionary *dict1 = [[(NSArray*)results objectAtIndex:0]objectForKey:@"Content"];
        if([dict1 objectForKey:@"DetailInfo"] && ![[dict1 objectForKey:@"ErrorCode"] isEqualToString:@""]){
            return;
        }else{
            ZLog(@"result string is:%@",results);
            self.shopInfo = [[dict1 objectForKey:@"Result"]objectForKey:@"DetailInfo"];
            //图片数组，图片数量不确定，需要精确判断。
            self.topLabel.text = [self.shopInfo objectForKey:@"ShopName"];
            dianpingShopID = [[self.shopInfo objectForKey:@"DianpingShopID"] copy];
            
            shopType = [[self.shopInfo objectForKey:@"ShopType"] copy];
            if([shopType isEqualToString:@"2"]){
                self.title = @"商户详情";
            }else{
                [self performSelector:@selector(setTitleWithTimeElaps:) withObject:@"商场详情" afterDelay:0.3];
            }
            
            //是否关注
            NSString *IsAttented = [self.shopInfo objectForKey:@"IsAttented"];
            if ([IsAttented isEqualToString:@"1"]) {
                [attentionbtn setSelected:YES];
            }else{
                [attentionbtn setSelected:NO];
            }
            
            //三个小图标
            if([[self.shopInfo objectForKey:@"Icon1"] isEqualToString:@"True"]){
                iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake(100, 6, 16, 17)];
                [self.introCell addSubview:iconImageView];
                iconImageView.image = [UIImage imageNamed:@"guan_icon.png"];
            }
            
            if([[self.shopInfo objectForKey:@"Icon2"] isEqualToString:@"True"]){
                iconImageView2 = [[UIImageView alloc] initWithFrame:CGRectMake(120, 6, 16, 17)];
                [self.introCell addSubview:iconImageView2];
                iconImageView2.image = [UIImage imageNamed:@"hui_icon.png"];
            }
            
            if([[self.shopInfo objectForKey:@"Icon3"] isEqualToString:@"True"]){
                iconImageView3 = [[UIImageView alloc] initWithFrame:CGRectMake(140, 6, 16, 17)];
                [self.introCell addSubview:iconImageView3];
                iconImageView3.image = [UIImage imageNamed:@"zhe_icon.png"];
            }
            
            if([[self.shopInfo objectForKey:@"AttentionCount"] isKindOfClass:[NSNumber class]]){
                self.favnum.text = [[self.shopInfo objectForKey:@"AttentionCount"] stringValue];
            }else if([[self.shopInfo objectForKey:@"AttentionCount"] isKindOfClass:[NSString class]]){
                self.favnum.text = [self.shopInfo objectForKey:@"AttentionCount"];
            }
            self.topLabel2.text = [self.shopInfo objectForKey:@"ShopName"];
            
            self.topLabel3.text = [self.shopInfo objectForKey:@"BrandSimpleName"];
            self.headPicArray = [self.shopInfo objectForKey:@"PictureList"];
            logoPic = [[self.shopInfo objectForKey:@"Logo"] copy];
            
            if(self.headPicArray.count > 0){
                NSString *tempStr = [self.headPicArray objectAtIndex:0];
                UIImageView *shoplogo = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 132)];
                [shoplogo XK_setImageWithURL:[NSURL URLWithString:tempStr] placeholderImage:nil ];
                
                [topcell addSubview:shoplogo];
                
                
                //上传照片的提示
                UIView *myexView = [[UIView alloc]init];
                myexView.bounds = CGRectMake(0, 0, 132, 24);
                myexView.center = CGPointMake(160, 112);
                myexView.layer.cornerRadius = 4;
                myexView.backgroundColor = [UIColor colorWithRed:138/255.0f green:109/255.0f blue:79/255.0f alpha:0.75];
                [topcell addSubview:myexView];
                myexView.hidden = YES;
                UILabel *textLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 132, 24)];
                textLabel.textColor = [UIColor whiteColor];
                textLabel.backgroundColor = [UIColor clearColor];
                textLabel.font = [UIFont boldSystemFontOfSize:14];
                textLabel.textAlignment = NSTextAlignmentCenter;
                textLabel.text = @"进入相册上传照片";
                [myexView addSubview:textLabel];
            }
            if([[self.shopInfo objectForKey:@"Weibo"] isEqualToString:@""]){
                weiboLabel.text = @"微博：暂时没有微博";
            }else{
                weiboLabel.text = [NSString stringWithFormat:@"微博:%@",[self.shopInfo objectForKey:@"Weibo"]];
                ZLog(@"%@",dict1 );
            }
            if([[self.shopInfo objectForKey:@"WebSiteUrl"] isEqualToString:@""])
                netLabel.text = @"暂时没有网站哦";
            else
                netLabel.text = [NSString stringWithFormat:@"官网：%@",[self.shopInfo objectForKey:@"WebSiteUrl"]];
            addressLabel.text = [self.shopInfo objectForKey:@"Address"];
            phoneLabel.text = [NSString stringWithFormat:@"电话：%@",[self.shopInfo objectForKey:@"Phone"]];
            self.Intro = [self.shopInfo objectForKey:@"Intro"];
            
            iLatitude = [self.shopInfo objectForKey:@"Latitude"];
            iLongitude = [self.shopInfo objectForKey:@"Longitude"];
            isShowBigbeen = YES;
            [iMyTableView reloadData];
        }
    }];
    
    [xkNetwork xk_requstWithDic:dicB withUrl:kManyInterfaceWithOnetime withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        NSDictionary *dict2 = [[(NSArray*)results objectAtIndex:0]objectForKey:@"Content"];
        self.lasttime = [[[dict2 objectForKey:@"Result"] objectForKey:@"DetailInfo"]objectForKey:@"RefreshTime"];
        if(self.shopListInfoArray != nil && self.shopListInfoArray.count > 0 && !refresh){
            [self.shopListInfoArray addObjectsFromArray:[[dict2 objectForKey:@"Result"] objectForKey:@"ListInfo"]];
        }else{
            refresh = NO;
            self.shopListInfoArray = [[dict2  objectForKey:@"Result"] objectForKey:@"ListInfo"];
        }
    }];
}

#pragma network end
- (IBAction)attention:(id)sender{
    
    if([attentionbtn isSelected]){
        //当前选中状态，不做处理。
        [self showAlert:nil withTitle:@"已经关注" haveCancelButton:NO];
        return;
    }
    //友盟统计
    [MobClick event:@"G_MALL_ATTENTION"];

    
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:shopID forKey:@"ShopID"];
    if(MyAppDelegate.userInfo){
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"UserID"];
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"LoginToken"];
    }
    
    [xkNetwork xk_requstWithDic:item withUrl:kAddAttention withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        NSString *resultstr = @"";
        if([[[results objectForKey:@"Result"] objectForKey:@"Status"] isEqualToString:@"Failure"]){
            resultstr = @"已经关注";
        }else if ([[[results objectForKey:@"Result"] objectForKey:@"Status"] isEqualToString:@"Success"]){
            resultstr = @"关注成功";
    
            //发送通知刷新关注页面
            [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshAttention" object:nil];
            
        }else{
            resultstr = [[results objectForKey:@"Result"] objectForKey:@"Message"];
        }
        [attentionbtn setSelected:YES];

        [self showalertString:resultstr];
    }];
}

//在视图动画结束前收到设置标题，会有混乱现象，这个是推迟0.3s设置。
- (void)setTitleWithTimeElaps : (NSString *)newTitle{
    self.title = @"商场详情";
}

#pragma mark - 刷新的代理方法进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    if (refreshView == _footer){//上拉加载更多
        
        if (curtype == 0) {
            curPage ++;
            [self getShopInfoList];
        }
        
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    return;
}

- (void)endHeaderFooterLoading{
    [_footer endRefreshing];
}


- (IBAction)showMap:(id)sender{
    return;//不跳了
}

- (IBAction)showWeibo:(id)sender{
    return;//不跳了
}
-(IBAction)gotoweb:(id)sender{
    return;//不跳了
}

- (IBAction)telephone:(id)sender{
    return;//不跳了
}


#pragma mark - tableview begin
- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(0 == indexPath.row){
        return topcell;
    }
    
    if(0 == curtype){
        //加载更多
        if( (self.shopListInfoArray.count == (curPage - 1) * 30) && (indexPath.row == self.shopListInfoArray.count + 1) && curPage != 1){
            UITableViewCell *cell = [[UITableViewCell alloc]initWithFrame:CGRectMake(0, 0, 320, 40)];
            UIImageView *getMoreView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 40)];
            getMoreView.image = [UIImage imageNamed:@"getMore.png"];
            [cell addSubview:getMoreView];
            return cell;
        }
        
        static NSString *CellIdentifier = @"GYShopInfoBigCell";
        GYShopInfoBigCell *cell = (GYShopInfoBigCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        if (cell == nil) {
            cell = [[GYShopInfoBigCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        
        cell.dataSource = [self.shopListInfoArray objectAtIndex:indexPath.row - 1];
        if(1 == [[cell.dataSource objectForKey:@"InfoType"] intValue]){
            cell.haveEndTime = YES;
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }else if (1 == curtype){
        //zhang jun
        if(1 == indexPath.row){
            static NSString *CellIdentifier = @"GYSelfHeaderShopCommentCell";
            GYSelfShopHeaderCell *cell = (GYSelfShopHeaderCell*)[iMyTableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if(cell == nil){
                cell = [[GYSelfShopHeaderCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            cell.backgroundColor = [UIColor clearColor];
            [cell setDataSource:self.shopCommentCount];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.delegate = self;
            return cell;
        }else if ([self.shopCommentInfoArray count]+2 == indexPath.row){
            static NSString *CellIdentifier = @"GYSelfShopCommentFooterCell";
            GYSelfShopCommentFooterCell *cell = nil;
            if(cell == nil){
                cell = [[GYSelfShopCommentFooterCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            cell.backgroundColor = [UIColor clearColor];
            cell.delegate = self;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }else if([self.shopCommentInfoArray count]+2 > indexPath.row){
            static NSString *CellIdentifier = @"GYSelfShopCommentCell";
            GYSelfShopCommentCell *cell = nil;
            if(cell == nil){
                cell = [[GYSelfShopCommentCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            cell.backgroundColor = [UIColor clearColor];
            cell.dataSource = [self.shopCommentInfoArray objectAtIndex:indexPath.row - 1];
            [cell setDataSource:cell.dataSource];
            //cell.commentTime.text = self.refreshtime;
            NSString *string = cell.commentContent.text;
            CGSize size = [NSString getHeight:string withFont:[UIFont systemFontOfSize:12] andWidth:280];
            float sumFloat = 110 + size.height;
            NSString *floats = [NSString stringWithFormat:@"%f",sumFloat];
            if ([[self.dicClicked objectForKey:indexPath] isEqualToString: floats])
            {
                [cell changeSelectCellHight];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }else if([self.shopCommentInfoArray count]+3 == indexPath.row){
            //大众点评 head
            UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
            if (cell == nil) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"UITableViewCell"];
            }
            cell.backgroundColor = [UIColor clearColor];
            cell.frame = CGRectMake(0.0, 0.0, 320.0, 35.5f);
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            UIImageView *dianPingImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"dianPingCommentTitle.png"]];
            dianPingImgView.frame = cell.frame;
            [cell addSubview:dianPingImgView];
            return cell;
        }else if([self.shopCommentInfoArray count]+3 < indexPath.row){
            //大众点评
            UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
            if (cell == nil) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"UITableViewCell"];
            }
            cell.backgroundColor = [UIColor clearColor];
            cell.frame = CGRectMake(0.0, 0.0, 320.0, 125.0f);
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            //用户名
            UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(10.0f, 10.0f, 300.0f, 20.0f)];
            nameLabel.text = [[self.dianPingArray objectAtIndex:(indexPath.row - self.shopCommentInfoArray.count - 4)] objectForKey:@"user_nickname"];
            [cell addSubview:nameLabel];
            nameLabel.font = [UIFont systemFontOfSize:13];
            nameLabel.backgroundColor = [UIColor clearColor];
            
            //评星
            UIImageView *imgview = [[UIImageView alloc]initWithFrame:CGRectMake(10, 33, 84, 16)];
            [imgview XK_setImageWithURL:[NSURL URLWithString:[[self.dianPingArray objectAtIndex:(indexPath.row - self.shopCommentInfoArray.count - 4)] objectForKey:@"rating_s_img_url"]] placeholderImage:nil];
            [cell addSubview:imgview];
            
            //几星
            UILabel *starLabel = [[UILabel alloc]initWithFrame:CGRectMake(99.0f, 33.0f, 30.0f, 17.0f)];
            starLabel.text = ((NSNumber*)[[self.dianPingArray objectAtIndex:(indexPath.row - self.shopCommentInfoArray.count - 4)] objectForKey:@"review_rating"]).stringValue;
            starLabel.font = [UIFont systemFontOfSize:13];
            starLabel.backgroundColor = [UIColor clearColor];
            starLabel.textColor = [UIColor lightGrayColor];
            [cell addSubview:starLabel];
            
            //评论内容
            UILabel *contenLabel = [[UILabel alloc]initWithFrame:CGRectMake(10.0f, 43.0f, 300.0f, 60.0f)];
            contenLabel.numberOfLines = 3;
            contenLabel.text = [[self.dianPingArray objectAtIndex:(indexPath.row - self.shopCommentInfoArray.count - 4)] objectForKey:@"text_excerpt"];
            [cell addSubview:contenLabel];
            contenLabel.font = [UIFont systemFontOfSize:13];
            contenLabel.backgroundColor = [UIColor clearColor];
            
            //时间
            UILabel *timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, cell.frame.size.height-20, 320, 16)];
            timeLabel.text = [NSString stringWithFormat:@"%@  来自大众点评",[[self.dianPingArray objectAtIndex:(indexPath.row - self.shopCommentInfoArray.count - 4)] objectForKey:@"created_time"]];
            [cell addSubview:timeLabel];
            timeLabel.font = [UIFont systemFontOfSize:12];
            timeLabel.textColor = [UIColor lightGrayColor];
            timeLabel.backgroundColor = [UIColor clearColor];
            
            //分割线
            UIImageView *lineImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"line.png"]];
            lineImageView.frame = CGRectMake(0, cell.frame.size.height-1, 320, 1);
            [cell addSubview:lineImageView];
            
            return cell;
        }
    }else if (2 == curtype){
        if(1 == indexPath.row){
            return arrayinfo2;
        }
        if (2 == indexPath.row) {
            return arrayinfo1;
        }
        if(3 == indexPath.row){
            return arrayinfo3;
        }
        if(4 == indexPath.row){
            return arrayinfo4;
        }
        if(indexPath.row == self.shopOtherArray.count + 6 - 1){
            [self.introTextView setFrame:CGRectMake(15, 40, SCREEN_WIDTH - 30, introCell.frame.size.height - 40)];
            return introCell;
        }
        
        static NSString *CellIdentifier = @"GYOtherShopCell";
        GYOtherShopCell *cell = (GYOtherShopCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:CellIdentifier
                                                                     owner:nil
                                                                   options:nil];
            cell = [topLevelObjects objectAtIndex:0];
        }
        cell.backgroundColor = [UIColor clearColor];
        cell.dataSource = [self.shopOtherArray objectAtIndex:indexPath.row - 4];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
        
    }else if (5 == curtype){
        return [self tableView:(UITableView *)tableView cellForRowAtIndexPathMerchant:(NSIndexPath *)indexPath];
    }
    
    //楼层信息
    else if (4 == curtype){
        
        static NSString *CellIdentifier = @"FloorCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
        }
        
        //嵌入楼层信息
        if (_floorVC == nil) {
            _floorVC = [[floorInfoVC alloc ] initWithShopID:self.shopID];
            _floorVC.delegate = self;
            _floorVC.navigationController = self.navigationController;
            _floorVC.isFromMpos = self.isFromMpos;
            if (self.isFromMpos) {
                //这里防止从逛云商进的商城详情，调回列表页
                _floorVC.isFromMail = YES;
                
            }else{
                //这里从逛商城进的商城详情，调回列表页
                _floorVC.isFromMail = self.isFromMail;
                
            }
            _floorVC.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, 300);
            [cell.contentView addSubview:_floorVC.view];
            
        }

        return cell;
         
    }

    ZLog(@"返回错误cell item");
    return nil;
}

//指定每个分区中有多少行，默认为1
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(0 == curtype ){
        ZLog(@"---%@",self.shopListInfoArray);
        if(isShowBigbeen){
            if(0 == self.shopListInfoArray.count )
                bigbeen.hidden = NO;
            else
                bigbeen.hidden = YES;
        }
        if(curPage > 1){
            if((curPage - 1) * 30 == self.shopListInfoArray.count){
                return self.shopListInfoArray.count + 2;
            }
        }
        return self.shopListInfoArray.count + 1;
    }else if(1 == curtype){
        //zhang jun
        if(0 == self.shopCommentInfoArray.count)
            bigbeen.hidden = NO;
        else
            bigbeen.hidden = YES;
        bigbeen.hidden = YES;
        if(self.dianPingArray.count != 0){
            //比以前增加了3条评论和一条列表头
            return self.shopCommentInfoArray.count + 4 + self.dianPingArray.count;
        }
        return  [self.shopCommentInfoArray count] + 3;
    } else if (2 == curtype){
        bigbeen.hidden = YES;
        return self.shopOtherArray.count + 6;
    }
    else if(4 == curtype){
        return 1 + 1;
    }else if(5 == curtype){
        bigbeen.hidden = YES;
        return 2 + merchantArray.count;
    }
    
    return 0;

}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(0 == indexPath.row)
        return 189;

    if(0 == curtype){
        
        if( (self.shopListInfoArray.count == (curPage - 1) * 30) && (indexPath.row == self.shopListInfoArray.count + 1) && curPage != 1){
            return 40;
        }
        return 184;
    }else if (1 == curtype){
        //zhang jun
        if(indexPath.row == 1){
            //网友评论
            return 90;
        }else if(indexPath.row == self.shopCommentInfoArray.count+2){
            //点击获取更多
            return 43;
        }else if(indexPath.row == self.shopCommentInfoArray.count+3){
            //大众点评的head
            return 35.5f;
        }else if(indexPath.row  < self.shopCommentInfoArray.count+2){
            ZLog(@"dicClicked:%@",self.dicClicked);
            if([[self.dicClicked objectForKey:indexPath]floatValue] >= 35)
            {
                return [[self.dicClicked objectForKey:indexPath] floatValue];
            }else
                return 125;
        }else{
            //大众点评的评论，高度确定。
            return 125;
        }
    }else if(2 == curtype){
        if(indexPath.row < 5)
            return 40;
        else if(self.shopOtherArray.count + 6 - 1 == indexPath.row){
            
            UIFont *dateFont = [UIFont fontWithName:@"Helvetica" size:13];
            
            CGSize dateStringSize = [NSString getHeight:self.Intro withFont:dateFont andWidth:290];
            self.introTextView.frame = CGRectMake(15, 40, 290, dateStringSize.height+ 10);
            self.introTextView.text = self.Intro;
            return dateStringSize.height+110;
        }else if(5 == indexPath.row){
            return 100;
        }else{
            return 60;
        }
        
    }else if (5 == curtype){
        return 53;
    }
    //楼层
    else if ( 4 == curtype){
        
        if (_floorVC != nil) {
            return [_floorVC getHeight];
        }
        
        return 200;
        
    }
    
    
    return 189;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    [tableView deselectRowAtIndexPath:indexPath animated:YES];
//    UIViewController *control = [[UIViewController alloc]init];
//    control.view.backgroundColor = [UIColor redColor];
//    [self.navigationController pushViewController:control animated:YES];
//    return;
    if(indexPath.row == 0){
        return;//相册禁止进入
    }

    if(0 == curtype){
        if( (self.shopListInfoArray.count == (curPage - 1) * 30) && (indexPath.row == self.shopListInfoArray.count + 1) && curPage != 1){
            [self getShopInfoList];
            return;
        }
        
        NSString *infoType = [[self.shopListInfoArray objectAtIndex:indexPath.row - 1] objectForKey:@"InfoType"];
        ZLog(@"infoType is:%@",infoType);
        if([@"2" isEqualToString:infoType]){
            //新品信息
            GYNewProductViewController *contro = [[GYNewProductViewController alloc]init];
            [self.navigationController pushViewController:contro animated:YES];
//            [contro request:[[[self.shopListInfoArray objectAtIndex:indexPath.row - 1]objectForKey:@"InfoID"] intValue]];
            return;
        }else{
            //优惠信息
            GYShopInfoDetailViewController *contro = [[GYShopInfoDetailViewController alloc]init];
            [self.navigationController pushViewController:contro animated:YES];
//            [contro request:[[[self.shopListInfoArray objectAtIndex:indexPath.row - 1]objectForKey:@"InfoID"] intValue]];
            return;
        }
    }else if(1 == curtype){
        //zhang jun
        if([self.shopCommentInfoArray count]+3 == indexPath.row){
            //大众点评 head
            return;
        }else if([self.shopCommentInfoArray count]+3 < indexPath.row){
            NSString *urlStr = [[self.dianPingArray objectAtIndex:(indexPath.row - self.shopCommentInfoArray.count - 4)] objectForKey:@"review_url"];
        
            if(urlStr.length > 0 ){
                WebveiwVC *webView = [[WebveiwVC alloc]init];
                [webView setTetle:@"大众点评"];
                [webView loadurl:urlStr];
                [self.navigationController pushViewController:webView animated:YES];
            }
            return;
        }
        if(1 != indexPath.row  && [self.shopCommentInfoArray count]+2 != indexPath.row){
            GYSelfShopCommentCell *targetCell = (GYSelfShopCommentCell *)[tableView cellForRowAtIndexPath:indexPath];
            NSInteger same = [indexPath compare:[self.dicClicked objectForKey:@"indexPath"]];
            NSString *string = targetCell.commentContent.text;
            CGSize size = [NSString getHeight:string withFont:[UIFont systemFontOfSize:12] andWidth:280];
            float sumFloat = 110 + size.height;
            NSString *floats = [NSString stringWithFormat:@"%f",sumFloat];
            if (size.height >= 35 && same!= 0){
                [self.dicClicked setObject:floats forKey:indexPath];
                [self.dicClicked setObject:indexPath forKey:@"indexPath"];
            }
            else{
                [self.dicClicked removeObjectForKey:indexPath];
                [self.dicClicked removeObjectForKey:@"indexPath"];
            }
            [iMyTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        }
    }else if(2 == curtype){
        if(indexPath.row > 5 && indexPath.row < 10){
//            GYShopMerchantViewController *controller = [[GYShopMerchantViewController alloc]init];
//            [self.navigationController pushViewController:controller animated:YES];
        }
    }else if(5 == curtype){
        if(indexPath.row == 1){
            //点了“购物类”、娱乐类等背景。
            return;
        }
        NSDictionary *infodic = [merchantArray objectAtIndex:(indexPath.row - 2)];

        //若有商户id则可以跳转
        if ([[infodic objectForKey:@"YunposShopID"] intValue] != 0) {
//            mposDetailViewController *detailV = [[mposDetailViewController alloc]init];
//            detailV.shopId = [infodic objectForKey:@"YunposShopID"];
//            detailV.isFromMpos = self.isFromMpos;
//            if (self.isFromMpos) {
//                //这里防止从逛云商进的商城详情，调回列表页
//                detailV.isFromMail = YES;
//
//            }else{
//                //这里从逛商城进的商城详情，调回列表页
//                detailV.isFromMail = self.isFromMail;
//
//            }
//
//            [self.navigationController pushViewController:detailV animated:YES];

        }
    }
}

#pragma mark 滚动
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(iMyTableView.contentOffset.y > 132)
        subview.frame = CGRectMake(subview.frame.origin.x, iMyTableView.contentOffset.y , subview.frame.size.width, subview.frame.size.height);
    else
        subview.frame = CGRectMake(0, 132, 320, 56.5);
    
}
#pragma table end


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

    }
    return self;
}

- (void)addNewInfo{
//    GYSubmitPruduct *controller = [[GYSubmitPruduct alloc]init];
//    controller.refreshDataDelegate = self;
//    controller.shopId = [shopID intValue];
//    [self.navigationController pushViewController:controller animated:YES];
//    [controller release];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_MALLDETAIL_VIEW"];

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_MALLDETAIL_VIEW"];
    
    ZLog(@"viewwillapper");
    if (1 == curtype){
        [self typebtn1Click:nil];
    }
    if(refresh){
        curPage = 1;
        [self getShopInfoList];
    }
    if (_isFromMyAttention) {//从我的关注而来
        [attentionbtn setSelected:YES];
    }
    //这里加个字段，特权用户只能上传到自己的店里
    BOOL showDianXiaoEr = NO;
    ZLog(@"%@",[MyAppDelegate.userInfo objectForKey:@"shopids"]);
    if(MyAppDelegate.userInfo){
        if(shopID && [[MyAppDelegate.userInfo objectForKey:@"shopids"] isKindOfClass:[NSString class]] && [[MyAppDelegate.userInfo objectForKey:@"shopids"] rangeOfString:shopID].location != NSNotFound){
            showDianXiaoEr = YES;
        }
    }
 
//    if(showDianXiaoEr && [MyAppDelegate.userInfo objectForKey:@"usertype"] && ([[MyAppDelegate.userInfo objectForKey:@"usertype"] intValue] == 2) ){
//        //上传新图片
//        UIButton *refreshButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        refreshButton.frame = CGRectMake(0.0, 0.0, 50, 26);
//        [refreshButton setBackgroundImage:[UIImage imageNamed:@"a-z.png"] forState:UIControlStateNormal];
//        [refreshButton setBackgroundImage:[UIImage imageNamed:@"a-z.png"] forState:UIControlStateSelected];
//        [refreshButton addTarget:self action:@selector(addNewInfo) forControlEvents:UIControlEventTouchUpInside];
//        refreshButton.titleLabel.font = [UIFont systemFontOfSize:14];
//        [refreshButton setTitle:@"店小二" forState:UIControlStateNormal];
//        refreshButton.titleLabel.font = [UIFont systemFontOfSize:12];
//        refreshButton.titleLabel.textColor = [UIColor whiteColor];
//        refreshButton.hidden = YES;
//        UIBarButtonItem *refreshBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:refreshButton];
//        refreshBarButtonItem.style = UIBarButtonItemStylePlain;
//        self.navigationItem.rightBarButtonItem = refreshBarButtonItem;
//        [refreshBarButtonItem release];
//    }
}

-(void)backAction{
    if (self.isFromMail) {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    [self cancelTapHideKeyBoard:YES];
    curPage = 1;
    [iMyTableView setDelegate:self];
    [iMyTableView setDataSource:self];
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = self.iMyTableView;
    _footer.delegate = self;
    
    [topbtn0 setSelected:YES];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgImage.png"]];
    
    subview = [[UIView alloc]initWithFrame:CGRectMake(0, 132, 320, 56.5)];
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 25)];
    image.image = [UIImage imageNamed:@"blackbackground.png"];
    topLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 3, 240, 20)];
    topLabel.backgroundColor = [UIColor clearColor];
    topLabel.textColor = [UIColor whiteColor];
    UIImageView *image2 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 25,320, 32)];
    
    image2.image = [UIImage imageNamed:@"merchant_type_bg.png"];

    attentionbtn = [[UIButton alloc]initWithFrame:CGRectMake(240, 0, 70, 24)];
    [attentionbtn setBackgroundImage:[UIImage imageNamed:@"market_attent.png"] forState:UIControlStateNormal];
    [attentionbtn setBackgroundImage:[UIImage imageNamed:@"market_attented.png"] forState:UIControlStateSelected];
    [attentionbtn addTarget:self action:@selector(attention:) forControlEvents:UIControlEventTouchUpInside];
    attentionbtn.titleLabel.font = [UIFont systemFontOfSize:13];
    [attentionbtn setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
    [subview addSubview:image];
    [subview addSubview:topLabel];

    [subview addSubview:image2];

    [subview addSubview:attentionbtn];
    
    topbtn0 = [[UIButton alloc]initWithFrame:CGRectMake(0, 25, 80, 31.5)];
    [topbtn0 setTitle:@"新品优惠" forState:UIControlStateNormal];
    topbtn0.titleLabel.font = [UIFont systemFontOfSize:16];
    [topbtn0 addTarget:self action:@selector(typebtn0Click:) forControlEvents:UIControlEventTouchUpInside];
    [topbtn0 setBackgroundImage:[UIImage imageNamed:@"merchant_btn_sel.png"] forState:UIControlStateSelected];
    [subview addSubview:topbtn0];
    topbtn1 = [[UIButton alloc]initWithFrame:CGRectMake(80, 25, 80, 31.5)];
    [topbtn1 setTitle:@"商场资料" forState:UIControlStateNormal];
    topbtn1.titleLabel.font = [UIFont systemFontOfSize:16];
    [topbtn1 addTarget:self action:@selector(typebtn1Click:) forControlEvents:UIControlEventTouchUpInside];
    [topbtn1 setBackgroundImage:[UIImage imageNamed:@"merchant_btn_sel.png"] forState:UIControlStateSelected];
    [subview addSubview:topbtn1];
    topbtn2 = [[UIButton alloc]initWithFrame:CGRectMake(160, 25, 80, 31.5)];
    [topbtn2 setTitle:@"商场品牌" forState:UIControlStateNormal];
    topbtn2.titleLabel.font = [UIFont systemFontOfSize:16];
    [topbtn2 addTarget:self action:@selector(typebtn2Click:) forControlEvents:UIControlEventTouchUpInside];
    [topbtn2 setBackgroundImage:[UIImage imageNamed:@"merchant_btn_sel.png"] forState:UIControlStateSelected];
    [subview addSubview:topbtn2];
    topbtn3 = [[UIButton alloc]initWithFrame:CGRectMake(240, 25, 80, 31.5)];
    [topbtn3 setTitle:@"商场楼层" forState:UIControlStateNormal];
    topbtn3.titleLabel.font = [UIFont systemFontOfSize:16];
    [topbtn3 addTarget:self action:@selector(typebtn3Click:) forControlEvents:UIControlEventTouchUpInside];
    [topbtn3 setBackgroundImage:[UIImage imageNamed:@"merchant_btn_sel.png"] forState:UIControlStateSelected];
    [subview addSubview:topbtn3];
    [self.iMyTableView addSubview:subview];
    
    
    //无数据提示
    bigbeen = [[UIView alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 97 - 80)/2, 300, 97 + 80, 101 + 40)];
    [bigbeen setBackgroundColor:[UIColor clearColor]];

    UIImageView *noImage= [[UIImageView alloc]initWithFrame:CGRectMake(40, 0, 97, 101)];
    noImage.image = [UIImage imageNamed:@"bgNoPoint.png"];
    [bigbeen addSubview:noImage];
    
    UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 105, 97+80, 15)];
    labela.backgroundColor = [UIColor clearColor];
    labela.text = @"抱歉，此品牌还未添加优惠哦";
    labela.font = [UIFont systemFontOfSize:12];
    labela.textColor = [UIColor lightGrayColor];
    labela.textAlignment = NSTextAlignmentCenter;
    [bigbeen addSubview:labela];
    UILabel *labelb = [[UILabel alloc]initWithFrame:CGRectMake(0, 120, 97+80, 15)];
    labelb.backgroundColor = [UIColor clearColor];
    labelb.text = @"先去别的地方逛逛吧～";
    labelb.font = [UIFont systemFontOfSize:12];
    labelb.textColor = [UIColor lightGrayColor];
    labelb.textAlignment = NSTextAlignmentCenter;
    [bigbeen addSubview:labelb];
    [iMyTableView addSubview:bigbeen];
    
    self.dicClicked = [[NSMutableDictionary alloc]init];
    
    if (self.shopID != nil) {
        [self getShopInfoList];
    }

    [self addRightBar];
    
    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
}

- (void)refreshNavBtn{
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
}

//添加右上角按钮
-(void)addRightBar{
    UIButton *editButton0 = [UIButton buttonWithType:UIButtonTypeCustom];
    editButton0.frame = CGRectMake(0.0, 0.0, 16, 16);
    [editButton0 addTarget:self action:@selector(gotoHome) forControlEvents:UIControlEventTouchUpInside];
    [editButton0 setBackgroundImage:[UIImage imageNamed:@"home_s.png"] forState:UIControlStateNormal];
    editButton0.titleLabel.font = [UIFont systemFontOfSize:13];
    UIBarButtonItem *rightBarButtonItem0 = [[UIBarButtonItem alloc] initWithCustomView:editButton0];
    rightBarButtonItem0.style = UIBarButtonItemStylePlain;
    
    UIButton *editButton = [UIButton buttonWithType:UIButtonTypeCustom];
    editButton.frame = CGRectMake(0.0, 0.0, 16, 16);
    [editButton addTarget:self action:@selector(gotoMessage) forControlEvents:UIControlEventTouchUpInside];
    [editButton setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    editButton.titleLabel.font = [UIFont systemFontOfSize:13];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:editButton];
    rightBarButtonItem.style = UIBarButtonItemStylePlain;
    //判断是否要添加红点提示
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(10, -4, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [rightBarButtonItem.customView addSubview:imageAlert];
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }

    self.navigationItem.rightBarButtonItems = @[rightBarButtonItem, rightBarButtonItem0];
}

- (void)gotoHome{
    [self.navigationController popToRootViewControllerAnimated:NO];
//    [MyAppDelegate.mainTab setSelectedIndex:0];
//    [MyAppDelegate.mainTab.selectImage setFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
}

//跳转到消息列表
-(void)gotoMessage{
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];
    
}

//top1
-(void)typebtnSelected{
    [topbtn0 setSelected:NO];
    [topbtn1 setSelected:NO];
    [topbtn2 setSelected:NO];
    [topbtn3 setSelected:NO];
}

//新品优惠
- (IBAction)typebtn0Click:(id)sender{

    curtype = 0;
    [self typebtnSelected];
    [topbtn0 setSelected:YES];
    
    [self getShopInfoList];
}
//商城资料
- (IBAction)typebtn1Click:(id)sender{
    //友盟统计
    [MobClick event:@"G_MALL_DETAIL"];

    curtype = 2;
    [self typebtnSelected];
    [topbtn1 setSelected:YES];
    
    [self getShopDetail];
//    [iMyTableView reloadData];
}

//商城品牌
- (IBAction)typebtn2Click:(id)sender{
    //友盟统计
    [MobClick event:@"G_MALL_BRAND"];

    curtype = 5;
    [self typebtnSelected];
    [topbtn2 setSelected:YES];
    [self requestBrandList:shopID.intValue withTag:1];
}

//商场楼层
- (IBAction)typebtn3Click:(id)sender{
    //友盟统计
    [MobClick event:@"G_MALL_FLOOR"];

    curtype = 4;
    [self typebtnSelected];
    [topbtn3 setSelected:YES];
    [iMyTableView reloadData];
}

#pragma mark -
#pragma mark 点评
//zhang jun
-(void)getShopCommentInfoList{
    //先判断网络是否可用
    if(0 == [MyAppDelegate reachBility]){
        UIImageView *alertView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 150, 320, 20)];
        alertView.image = [UIImage imageNamed:@"netNoConnect.png"];
        [self.view addSubview:alertView];
        alertView.tag = 103;
        [self performSelector:@selector(removeAlertView) withObject:nil afterDelay:1];
        return;
    }
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"DeviceID"];
    [item setObject:[NSNumber numberWithInt:shopID.intValue] forKey:@"ShopID"];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"PageIndex"];
    [item setObject:[NSNumber numberWithInt:4] forKey:@"PageSize"];
    if( nil == self.refreshtime ){
        NSString *datestr;
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setTimeZone:[NSTimeZone systemTimeZone]];
        [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
        datestr = [formatter stringFromDate:[NSDate date]];
        [item setObject:datestr forKey:@"RefreshTime"];
        [item setObject:datestr forKey:@"RefreshTime"];
    }else{
        [item setObject:self.refreshtime forKey:@"RefreshTime"];
    }
    
    [xkNetwork xk_requstWithDic:item withUrl:kShopCommentList withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        NSDictionary *detail = [[results objectForKey:@"Result"] objectForKey:@"DetailInfo"];
        self.shopCommentCount = [[detail objectForKey:@"DataCount"]intValue];
        self.refreshtime = [detail objectForKey:@"RefreshTime"];
        self.shopCommentInfoArray = [[results objectForKey:@"Result"] objectForKey:@"ListInfo"];
        [self.iMyTableView reloadData];
    }];
}

//大众点评
- (void)getDazhongComment{
    ZLog(@"dianping id is :%@",dianpingShopID);

    //SHA-1 加密  platform2
    NSString *signVal = [NSString stringWithFormat:@"%@business_id%dformatjsonplatform2%@", kDazhongAppKey, dianpingShopID.intValue, kDazhongSecret];
    const char *cstr = [signVal cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:signVal.length];
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    CC_SHA1(data.bytes, (uint32_t)data.length, digest);
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++){
        [output appendFormat:@"%02x", digest[i]];
    }
    NSString *upperOutput = [output uppercaseString];

    NSString *requestStr = [NSString stringWithFormat:@"%@appkey=%@&sign=%@&business_id=%d&format=json&platform=2", kDazhongCommentUrl, kDazhongAppKey, upperOutput, dianpingShopID.intValue];
    NSURL *url = [NSURL URLWithString:requestStr];
    ZLog(@"url:%@",url);
    
    [xkNetwork xk_requstWithDic:[NSDictionary dictionary] withUrl:requestStr withRequestMethod:@"GET" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        self.dianPingArray = [results objectForKey:@"reviews"];
        [self.iMyTableView reloadData];
    }];
}

- (void)clickUserWillComment
{
    if(MyAppDelegate.userInfo){
        [self pushPublishView];
    }else{
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"您还没有登录,请登录" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        alertView.tag = 106;
        [alertView show];
    }
}
- (void)checkMoreShopCommentContent
{
//    GYShopCommentListViewController *publishVC = [[GYShopCommentListViewController alloc]init];
//    publishVC.shopId = shopID;
//    [self.navigationController pushViewController:publishVC animated:YES];
}

#pragma mark alertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if ([alertView tag] == 103) {    
        if (buttonIndex == 0) {
            NSString *num = [[NSString alloc] initWithFormat:@"tel://%@",[phoneLabel.text substringFromIndex:3]];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:num]];
        }
    }else if(106 == alertView.tag){
        //评论登录
        if(1 == buttonIndex){
            LoginVC *controller = [[LoginVC alloc]init];
            controller.delegate = self;
            [self presentViewController:controller animated:YES completion:nil];
            controller.delegate = self;
        }
    }
}

- (void)showPublishView{
    pushPublishFlag = YES;
}
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
   
    if(pushPublishFlag){
        pushPublishFlag = NO;
        [self performSelector:@selector(pushPublishView) withObject:nil afterDelay:0.1];
    }
}

- (void)pushPublishView{
//    GYPublishViewController *publishVC = [[GYPublishViewController alloc]init];
//    publishVC.shopId = shopID;
//    ZLog(@"%@",shopID);
//    [self.navigationController pushViewController:publishVC animated:NO];
}

- (void)finishLogin{
    if (self.shopID != nil) {
        [self getDetailInfo:self.shopID];
    }
    
    [self attention:nil];
}

-(void)loadDataSuccess:(NSArray *)info{
    
    [iMyTableView reloadData];
    
}


#pragma mark - 商场品牌 
- (void)requestBrandList:(int)shopId withTag:(int)tag{
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"DeviceID"];
    [item setObject:[NSNumber numberWithInt:shopId] forKey:@"ShopID"];
    
    //1：购物 2:娱乐 3:生活 4:美食  15.10.29:这个字段不传，从服务器返回数据中ShopType加以区分数据类型
//    [item setObject:[NSString stringWithFormat:@"%d",tag] forKey:@"BrandTag"];
    
#if TARGET_IPHONE_SIMULATOR
    [item setObject:[NSNumber numberWithDouble:39.934427] forKey:@"Latitude"];
    [item setObject:[NSNumber numberWithDouble:116.422824] forKey:@"Longitude"];
#else
    [item setObject:[NSNumber numberWithDouble:MyAppDelegate.ilatitude] forKey:@"Latitude"];
    [item setObject:[NSNumber numberWithDouble:MyAppDelegate.ilongitude] forKey:@"Longitude"];
#endif
    [item setObject:[NSNumber numberWithInt:1] forKey:@"PageIndex"];
    [item setObject:[NSNumber numberWithInt:2000] forKey:@"PageSize"];
    
    [xkNetwork xk_requstWithDic:item withUrl:kShopMerchant withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *results = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        if([[[results objectForKey:@"Result"] objectForKey:@"ErrorCode"] isEqualToString:@""]){
            NSArray *tempArray = [[results objectForKey:@"Result"] objectForKey:@"ListInfo"];
            NSMutableArray *subArray = [[NSMutableArray alloc]init];
            for(NSDictionary *dic in tempArray){
                if([[dic objectForKey:@"ShopType"] isEqualToString:[NSString stringWithFormat:@"%d",tag]]){
                    [subArray addObject:dic];
                }
            }
            merchantArray = subArray;
            
            [iMyTableView reloadData];
        }
    }];
}

//获取4个分类的button之一
- (UIButton *)geiTypeButton : (NSString*) title{
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, (SCREEN_WIDTH - 50)/4, 30)];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitle:title forState:UIControlStateSelected];
    [btn setTitleColor:[UIColor colorWithRed:216/255.0f green:23/255.0f blue:124/255.0f alpha:1] forState:UIControlStateSelected];
    [btn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"merchant_type_btn.png"] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"merchant_type_btn_sel.png"] forState:UIControlStateSelected];
    [btn addTarget:self action:@selector(merchantTypeSelect:) forControlEvents:UIControlEventTouchUpInside];
    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    return btn;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPathMerchant:(NSIndexPath *)indexPath{
    if(1 == indexPath.row){
        //品牌分类
        static NSString *Identifier = @"typCELL";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identifier];
        if (cell == nil){
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];

            typeBtn1 = [self geiTypeButton:@"购物类"];
            typeBtn1.frame = CGRectMake(10, 10, (SCREEN_WIDTH - 50)/4, 30);
            [typeBtn1 setSelected:YES];
            typeBtn1.tag = 1;
            CGFloat btnW = (SCREEN_WIDTH - 50)/4.0;
            
            typeBtn2 = [self geiTypeButton:@"娱乐类"];
            typeBtn2.frame = CGRectMake(20 + btnW, 10, btnW, 30);
            typeBtn2.tag = 2;
            
            typeBtn3 = [self geiTypeButton:@"生活类"];
            typeBtn3.frame = CGRectMake(30 + 2*btnW, 10, btnW, 30);
            typeBtn3.tag = 3;
            
            typeBtn4 = [self geiTypeButton:@"美食类"];
            typeBtn4.frame = CGRectMake(40 + 3*btnW, 10, btnW, 30);
            typeBtn4.tag = 4;
            
            [cell.contentView addSubview:typeBtn1];
            [cell.contentView addSubview:typeBtn2];
            [cell.contentView addSubview:typeBtn3];
            [cell.contentView addSubview:typeBtn4];
            
        }
        return cell;
    }
    
    static NSString *CellIdentifier = @"merCELL";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
        //line view
        UIView *lineV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, ONEPIXL)];
        lineV.backgroundColor = [UIColor colorWithHexString:@"#dfdfdf"];
        [cell.contentView addSubview:lineV];
        
        //图片
        UIImageView *imgV = [[UIImageView alloc] initWithFrame:CGRectMake(10, 3, 48, 48)];
        imgV.tag = 1001;
        [cell.contentView addSubview:imgV];
        
        //标题
        UILabel *lbTitle = [[UILabel alloc] initWithFrame:CGRectMake(68, 20, SCREEN_WIDTH - 68 - 60, 16)];
        lbTitle.tag = 1002;
        lbTitle.font = [UIFont systemFontOfSize:14];
        lbTitle.textColor = [UIColor darkGrayColor];
        [cell.contentView addSubview: lbTitle];
        
        //建行mpos图标
        UIImageView *ismposIcon = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 100 + 65, 17, 15, 15)];
        ismposIcon.tag = 1004;
        ismposIcon.hidden = YES;
        ismposIcon.image = [UIImage imageNamed:@"yunmpos_icon.png"];
        [cell.contentView addSubview:ismposIcon];
        
        //楼层
        UILabel *lbFloor = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 60, 20, 60, 16)];
        lbFloor.font = [UIFont systemFontOfSize:14];
        lbFloor.tag = 1003;
        lbFloor.textColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:lbFloor];
        
        UIImageView *nextImg = [[UIImageView alloc]init];
        nextImg.frame = CGRectMake(SCREEN_WIDTH - 20, 22, 9, 13);
        nextImg.image = [UIImage imageNamed:@"app_next.png"];
        nextImg.tag = 1005;
        nextImg.hidden = YES;
        [cell.contentView addSubview:nextImg];
    }
    
    NSDictionary *infodic = [merchantArray objectAtIndex:(indexPath.row - 2)];
    NSString *imgPath = [infodic objectForKey:@"Logo"];
    UIImageView *imgV = (UIImageView*)[cell viewWithTag:1001];
    [imgV XK_setImageWithURL:[NSURL URLWithString:imgPath] placeholderImage:nil];
    
    UILabel *lbTitle = (UILabel *)[cell viewWithTag:1002];
    lbTitle.text = [infodic objectForKey:@"ShopName"];
    
    //商城的云POS商户
    UIImageView *ismposIcon = (UIImageView *)[cell.contentView viewWithTag:1004];
    UIImageView *nextImg = (UIImageView *)[cell.contentView viewWithTag:1005];

    int ismpos = [[infodic objectForKey:@"YunposShopID"] intValue];
    if (ismpos != 0) {
        //加字数判断
        if (lbTitle.text.length > 13) {
            [lbTitle setFrame:CGRectMake(65, 20, SCREEN_WIDTH - 100, 16)];
            [ismposIcon setFrame:CGRectMake(SCREEN_WIDTH - 100 + 65, 20, 15, 15)];
        }else{
            [lbTitle setFrame:CGRectMake(65, 20, lbTitle.text.length * 15, 16)];
            [ismposIcon setFrame:CGRectMake(lbTitle.frame.size.width + lbTitle.frame.origin.x, 20, 15, 15)];
            
        }
        nextImg.hidden = NO;
        ismposIcon.hidden = NO;
    }else{
        [lbTitle setFrame:CGRectMake(65, 20, SCREEN_WIDTH - 100, 16)];
        [ismposIcon setFrame:CGRectMake(SCREEN_WIDTH - 100 + 65, 20, 15, 15)];
        ismposIcon.hidden = YES;
        nextImg.hidden = YES;
    }
    
    UILabel *lbFloor = (UILabel *)[cell viewWithTag:1003];
    NSString *floorStr = [infodic objectForKey:@"Floor"];
    if(floorStr.length > 0){
        [lbFloor setHidden:NO];
        lbFloor.text = floorStr;
    }else{
        [lbFloor setHidden:YES];
    }
    
    return cell;
}

- (IBAction)merchantTypeSelect:(id)sender{
    [typeBtn1 setSelected:NO];
    [typeBtn2 setSelected:NO];
    [typeBtn3 setSelected:NO];
    [typeBtn4 setSelected:NO];
    [sender setSelected:YES];
    [self requestBrandList:(int)shopID.intValue withTag:(int)((UIButton*)sender).tag];
}
@end


