//
//  lookGoodsCell.m
//  GGSH
//
//  Created by siqiyang on 15/7/1.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "lookGoodsCell.h"

@implementation lookGoodsCell

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self)
    {
        self.label.text = @"";
        [self.image setImage:[UIImage imageNamed:@"goodsListDefaultImage.png"]];
        self.lbPrc.text = @"";
        self.lbNum.text = @"";
        self.lbOldPrc.text = @"";
        
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    ZLog(@"%@",self.dicCell);
    
    NSString *goodsname = [self.dicCell objectForKey:@"goodsname"];
    CGSize size = [NSString getHeight:goodsname withFont:[UIFont systemFontOfSize:13] andWidth:1300];
    self.label.text = goodsname;
    //一行的时候中间显示
    if (size.width > 130) {
        [self.label sizeToFit];
    }
    self.label.textColor = [UIColor colorWithHexString:@"#000000"];
    
    NSString *dicPath = [self.dicCell objectForKey:@"listpic"];
    [self.image XK_setImageWithURL:[NSURL URLWithString:dicPath] placeholderImage:nil];
//    self.image.noBorderFlag = YES;
    
    //价格
    if([[self.dicCell objectForKey:@"pircestatus"] isEqualToString:@"1"]){
        //区间价格
        int begprc = ((NSString*)[self.dicCell objectForKey:@"initialprice"]).doubleValue;
        int endprc = ((NSString*)[self.dicCell objectForKey:@"endprice"]).doubleValue;
        self.lbPrc.text = [NSString stringWithFormat:@"¥%.2f-%.2f", begprc/100.0 ,endprc/100.0];
        self.lbPrc.adjustsFontSizeToFitWidth = YES;
    }else if ([[self.dicCell objectForKey:@"pircestatus"] isEqualToString:@"2"]){
        //发布价格
        NSString *prc = [self.dicCell objectForKey:@"goodsprice"];
        self.lbPrc.text = [NSString stringWithFormat:@"￥%.2f", prc.doubleValue/100.0f];
        
    }else if ([[self.dicCell objectForKey:@"pircestatus"] isEqualToString:@"3"]){
        //定制服务
        //定制服务单位？没确定所以先不添加
        NSString *unitStr = [[self.dicCell objectForKey:@"unit"] isEqualToString:@"1"]?@"人":@"间";//1:人 2:间
        
        NSString *prc = [self.dicCell objectForKey:@"goodsprice"];
        self.lbPrc.text = [NSString stringWithFormat:@"￥%.2f/%@", prc.doubleValue/100.0f,unitStr];
        
    }
    self.lbPrc.adjustsFontSizeToFitWidth = YES;
    
    //市场价格
    if([[self.dicCell objectForKey:@"pircestatus"] isEqualToString:@"1"]){
        //区间价格
        NSString *prc = [self.dicCell objectForKey:@"goodsmarketprice"];
//        if (prc.integerValue == 0) {
//            [self.lbOldPrc setHidden:YES];
//        }else{
//            [self.lbOldPrc setHidden:NO];
//        }
        NSString *oldPrice = [NSString stringWithFormat:@"¥%.2f",prc.doubleValue/100.0];
        NSUInteger length = [oldPrice length];
        
        NSMutableAttributedString *attri = [[NSMutableAttributedString alloc] initWithString:oldPrice];
        [attri addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(1, length-1)];
        [attri addAttribute:NSStrikethroughColorAttributeName value:[UIColor lightGrayColor] range:NSMakeRange(1, length-1)];
        [self.lbOldPrc setAttributedText:attri];
        
    }else if ([[self.dicCell objectForKey:@"pircestatus"] isEqualToString:@"2"]){
        //发布价格
        NSString *prc = [self.dicCell objectForKey:@"goodsmarketprice"];
//        if (prc.integerValue == 0) {
//            [self.lbOldPrc setHidden:YES];
//        }else{
//            [self.lbOldPrc setHidden:NO];
//        }
        NSString *oldPrice = [NSString stringWithFormat:@"￥%.2f", prc.doubleValue/100.0f];
        NSUInteger length = [oldPrice length];
        
        NSMutableAttributedString *attri = [[NSMutableAttributedString alloc] initWithString:oldPrice];
        [attri addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(1, length-1)];
        [attri addAttribute:NSStrikethroughColorAttributeName value:[UIColor lightGrayColor] range:NSMakeRange(1, length-1)];
        [self.lbOldPrc setAttributedText:attri];
        
    }else if ([[self.dicCell objectForKey:@"pircestatus"] isEqualToString:@"3"]){
        //定制服务
        //定制服务单位？没确定所以先不添加
        NSString *unitStr = [[self.dicCell objectForKey:@"unit"] isEqualToString:@"1"]?@"人":@"间";//1:人 2:间
        
        NSString *prc = [self.dicCell objectForKey:@"goodsmarketprice"];
//        if (prc.integerValue == 0) {
//            [self.lbOldPrc setHidden:YES];
//        }else{
//            [self.lbOldPrc setHidden:NO];
//        }
        NSString *oldPrice = [NSString stringWithFormat:@"￥%.2f/%@", prc.doubleValue/100.0f,unitStr];
        NSUInteger length = [oldPrice length];
        
        NSMutableAttributedString *attri = [[NSMutableAttributedString alloc] initWithString:oldPrice];
        [attri addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(1, length-1)];
        [attri addAttribute:NSStrikethroughColorAttributeName value:[UIColor lightGrayColor] range:NSMakeRange(1, length-1)];
        [self.lbOldPrc setAttributedText:attri];
    }
    self.lbOldPrc.adjustsFontSizeToFitWidth = YES;
   

    //销售数量
    NSString *numStr = [self.dicCell objectForKey:@"sellnum"];
    self.lbNum.text = [NSString stringWithFormat:@"已售%@笔", numStr];
}
@end
