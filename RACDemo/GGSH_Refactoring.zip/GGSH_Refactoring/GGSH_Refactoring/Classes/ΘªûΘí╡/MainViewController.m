//
//  MainViewController.m
//  GGSH_Refactoring
//
//  Created by huadong on 16/9/14.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "MainViewController.h"
#import "UIView+Extension.h"
#import "MJRefresh.h"
#import "SearchViewController.h"
#import "mposDetailViewController.h"
#import "MyMessageVC.h"
#import "ShopVC.h"
#import "MyOrderVC.h"
#import "LoginVC.h"
#import "CouponTypeVC.h"
#import "AddWantBuyVC.h"
#import "mySignViewController.h"
#import "lookGoodsViewController.h"
#import "mposMerchantViewController.h"

#import "NewsCtrl.h"

#import "shopCartViewController.h"
#import "MyOrderVC.h"


#define TopHeight 125+64
@interface MainViewController ()<UITableViewDelegate,UITableViewDataSource,MJRefreshBaseViewDelegate,UISearchBarDelegate,loginDelegate,NewsSelectDelegate>
{
   
    MJRefreshHeaderView *_header;
    NewsCtrl *_newsContrl;//轮播
    //购物车
    UIImageView *imageAlertCart;
    UILabel *alertLabel;
    //未读消息
    UIImageView *imageAlert;
    //未读优惠券
    UIImageView *imageAlertCoupon;
    
}
@property (nonatomic,assign) NSInteger selectBtnTag;//记录点击按钮的tag值（需要登录的按钮）
@property (nonatomic,strong) NSMutableArray *newsArray;//存储轮播数据
@property (weak, nonatomic) IBOutlet UITableView *mainTable;
@property (nonatomic,strong) NSMutableDictionary *btnsDic;//存储中间按钮上的数据
@property (nonatomic,strong) NSMutableArray *attentionArr;//存储热门关注的店铺
@property (nonatomic, retain) NSDate *date;

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_mainTable setFrame:CGRectMake(0, -64, _mainTable.frame.size.width, _mainTable.frame.size.height + 64)];
    _mainTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    _mainTable.tableFooterView = [[UIView alloc]init];
    
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _mainTable;
    _header.frame = CGRectMake(0, 10, _mainTable.frame.size.width, 64);
    _header.delegate = self;
    _attentionArr = [[NSMutableArray alloc]init];
    [self getTopScrollData];
    self.newsArray = [[NSMutableArray alloc]init];
    //初始化中间按钮上的数据
    [self initWithBtnsDic];
    [self getAttentionData];
    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
}
- (void)refreshNavBtn{
    if (MyAppDelegate.shopCartNumber.integerValue > 0) {
        [imageAlertCart setHidden:NO];
        [alertLabel setText:MyAppDelegate.shopCartNumber];
        
    }else{
        [imageAlertCart setHidden:YES];
    }
    
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
    
    //在我的卡券上添加红点
    if (MyAppDelegate.isHaveNoReadConpon) {
        [imageAlertCoupon setHidden:NO];
    }else{
        [imageAlertCoupon setHidden:YES];
    }
}
/**
 获取轮播信息
 */
- (void)getTopScrollData{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Members" forKey:@"Mod"];
    [dic setObject:@"carousel" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    [dicContent setObject:@"3" forKey:@"type"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    [xkNetwork xk_requstWithDic:dic withUrl: kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        //        转换为NSString
        NSString *jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];

        ZLog(@"jsonString = %@",jsonString);
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
    
            //获取数据成功
            NSArray * arrNews = [resultDic objectForKey:@"DetailInfo"];
            [_newsArray addObjectsFromArray: arrNews];
            [_mainTable reloadData];
        }
    }];

    
    
}
- (void)initWithBtnsDic{
    NSArray *images = @[@"cloudshow_06",@"cloudshow_05",@"cloudshow_04",@"cloudshow_03",@"cloudshow_02",@"cloudshow_01"];
    NSArray *titles = @[@"逛云商",@"逛商品",@"交易提示单",@"我的订单",@"我的卡券",@"我要买"];
    NSArray *detailTs = @[@"好店云集，享便捷",@"千种商品，任意购",@"刷卡消费全记录",@"查看全部的商品订单",@"领卡券，享实惠",@"逛不到，我帮你"];
    _btnsDic = [NSMutableDictionary dictionaryWithObjectsAndKeys:images,@"images",titles,@"titles",detailTs,@"detailTitles", nil];
    
//    [_mainTable reloadData];
}

- (void)createTopNavi{
    //左边-购物车
    UIButton *trolleyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [trolleyBtn setFrame:CGRectMake(5, 8, 28, 30)];
    UIImageView *trolleyIcon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 28, 30)];
    trolleyIcon.image = [UIImage imageNamed:@"nav_left.png"];
    [trolleyBtn setBackgroundImage:trolleyIcon.image forState:UIControlStateNormal];
    [trolleyBtn addTarget:self action:@selector(doTrolley:) forControlEvents:UIControlEventTouchUpInside];
    trolleyBtn.tag = 101;
    [self.navigationController.navigationBar addSubview: trolleyBtn];
    
    imageAlertCart = [[UIImageView alloc]initWithFrame:CGRectMake(14, -2, 18, 13)];
    [imageAlertCart setImage:[UIImage imageNamed:@"imageAlertCart.png"]];
    [imageAlertCart setBackgroundColor:[UIColor whiteColor]];
    imageAlertCart.layer.cornerRadius = 6;
    imageAlertCart.layer.borderWidth = 0.5f;
    imageAlertCart.layer.borderColor = [UIColor redColor].CGColor;
    [trolleyBtn addSubview:imageAlertCart];
    
    alertLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 18, 13)];
    [alertLabel setTextAlignment:NSTextAlignmentCenter];
    [alertLabel setFont:[UIFont systemFontOfSize:8]];
    [alertLabel setTextColor:[UIColor redColor]];
    [imageAlertCart addSubview:alertLabel];
    [imageAlertCart setHidden:YES];
    
    //右边-message
    
    UIButton *editButton = [UIButton buttonWithType:UIButtonTypeCustom];
    editButton.frame = CGRectMake(SCREEN_WIDTH - 35, 8, 28, 30);
    [editButton addTarget:self action:@selector(doTrolley:) forControlEvents:UIControlEventTouchUpInside];
    [editButton setBackgroundImage:[UIImage imageNamed:@"nav_right.png"] forState:UIControlStateNormal];
    editButton.titleLabel.font = [UIFont systemFontOfSize:13];
    editButton.tag = 102;
    [self.navigationController.navigationBar addSubview: editButton];
    
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(16, -1, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [editButton addSubview:imageAlert];
    [imageAlert setHidden:YES];
    
    //search
    UIView *bgview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - 96, 28)];
    bgview.backgroundColor = [UIColor clearColor];
    bgview.center = CGPointMake(SCREEN_WIDTH/2 - 50, 44/2);
    int space = 5;
    UIImageView *imgSearBg = [[UIImageView alloc] initWithFrame:CGRectMake(-10+space, 0, SCREEN_WIDTH - 86, 28)];
    imgSearBg.image = [UIImage imageNamed:@"search_mid.png"];
    [bgview addSubview:imgSearBg];
    
    UIImageView *imgSear = [[UIImageView alloc] initWithFrame:CGRectMake(space, 8, 11, 11)];
    imgSear.image = [UIImage imageNamed:@"search_red.png"];
    [bgview addSubview:imgSear];
    
    UILabel *searLabel = [[UILabel alloc] initWithFrame:CGRectMake(15+space, 4, SCREEN_WIDTH - 105, 20)];
    searLabel.textColor = [UIColor lightGrayColor];
    searLabel.text = @"输入商家名称、商品名称或商场名称";
    searLabel.font = [UIFont systemFontOfSize:12];
    [bgview addSubview:searLabel];
    
    //跳转
    UIButton *jumpBtn = [[UIButton alloc] initWithFrame:bgview.bounds];
    [jumpBtn addTarget:self action:@selector(jumpToSearchAction) forControlEvents:UIControlEventTouchUpInside];
    [bgview addSubview:jumpBtn];
    
    self.navigationItem.titleView = bgview;
    if (MyAppDelegate.userInfo) {
        [self refreshNavBtn];
    }
}
- (void)jumpToSearchAction{
    SearchViewController *vc = [[SearchViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
}
#pragma mark - 购物车
- (void)doTrolley:(id)sender
{
    UIButton *btn = (UIButton *)sender;
    switch (btn.tag) {
        case 101:{//购物车
            if (!MyAppDelegate.userInfo) {
                self.selectBtnTag = 101;
                [self login];
                return;
            }
            shopCartViewController *vc = [[shopCartViewController alloc]init];
            [self.navigationController pushViewController:vc  animated:YES];
            break;
        }
        case 102:{//消息
            if (!MyAppDelegate.userInfo) {
                self.selectBtnTag = 102;
                [self login];
                return;
            }
            MyMessageVC *vc = [[MyMessageVC alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
            break;
        }
        default:
            break;
    }
    
}
#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(refreshView == _header) {// 下拉刷新
       
        
        //3秒内不能重复发起网络请求，只是界面上闪动下正在加载，就1s。
        if(self.date){
            NSDate *tenMiniteLater = [self.date dateByAddingTimeInterval:3];
            NSDate *currentDate = [NSDate date];
            if(NSOrderedDescending == [tenMiniteLater compare:currentDate]){
                ZLog(@"ascending");
                self.date = [NSDate date];
                [self performSelector:@selector(OneSecondElapse) withObject:nil afterDelay:1];
                [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
                return;
            }
            
            //网络请求
            //刷新首页数据
            [self getAttentionData];

        }else{
            self.date = [NSDate date];
            //网络请求
            //刷新首页数据
            [self getAttentionData];

            
        }
        
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
}

//1s的假loading，取消正在加载就好
- (void)OneSecondElapse{
    [self hideHUD];
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
}


- (void)getAttentionData{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Showhome" forKey:@"Mod"];
    [dic setObject:@"index" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    if ([MyAppDelegate.userInfo objectForKey:@"phone"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"phone"];
    }else{
        [dicContent setObject:@"" forKey:@"phone"];
    }
    
    [dicContent setObject:[NSNumber numberWithDouble:MyAppDelegate.ilongitude] forKey:@"longitude"];
    [dicContent setObject:[NSNumber numberWithDouble:MyAppDelegate.ilatitude] forKey:@"latitude"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        NSLog(@"responseSting = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        if ([[responseDict objectForKey:@"Code"]isEqualToString:@"0000"]) {
            if (_attentionArr.count) {
                [_attentionArr removeAllObjects];
            }
            [_attentionArr addObjectsFromArray:[responseDict objectForKey:@"DetailInfo"]];
            [_mainTable reloadData];
        }
        
    }];
}

#pragma mark -- UITableViewDatasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row ==0) {
        static NSString *cellId = @"cell0";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]init];
            
            cell.selectionStyle = UITableViewCellSeparatorStyleNone;
            _newsContrl = [[NewsCtrl alloc]initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, 125)];
            _newsContrl.delegate = self;
            _newsContrl.urlString = @"img";
            [cell.contentView addSubview:_newsContrl.view];
            if (_newsArray.count) {
                  [_newsContrl setNewsArray:_newsArray];
            }
          
        }
        return cell;
    }
    else if (indexPath.row == 1) {
        static NSString *cellId = @"cell1";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]init];
            cell.selectionStyle = UITableViewCellSeparatorStyleNone;
            cell.backgroundColor = [UIColor whiteColor];
            CGFloat width = SCREEN_WIDTH/3;
            NSArray *images = [_btnsDic objectForKey:@"images"];
            NSArray *titles = [_btnsDic objectForKey:@"titles"];
            NSArray *details = [_btnsDic objectForKey:@"detailTitles"];
            for (int i = 0; i < images.count; i++) {
                UIButton *btn = [self createViewWithFrame:CGRectMake(i%3 *width , i/3 *width, width, width) withbtnImage:[UIImage imageNamed:[images objectAtIndex:i]] withtitle:titles[i] withDetailTitle:details[i] withBtnType:1];
                [btn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:btn];
                btn.tag = 1000+i;
            }
        }
        return cell;
    }
    else if (indexPath.row == 2) {
        static NSString *cellId = @"cell2";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]init];
            cell.contentView.backgroundColor = [UIColor colorWithHexString:@"#F4F5F6"];
            cell.selected = NO;
          //320:73
            UIButton *btn = [self createViewWithFrame:CGRectMake(0 , 5, SCREEN_WIDTH, SCREEN_WIDTH *73/320) withbtnImage:[UIImage imageNamed:@"cloudshow_07" ]withtitle:@"逛商场" withDetailTitle:@"品鉴时尚潮流" withBtnType:2];
            [btn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:btn];
            btn.tag = 50;

        }
     
        return cell;
    }
    else if (indexPath.row == 3) {
        static NSString *cellId = @"cell3";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
        if (cell == nil) {
            cell = [[UITableViewCell alloc]init];
            cell.contentView.backgroundColor = [UIColor colorWithHexString:@"#F4F5F6"];
            cell.selected = NO;
            CGFloat width = (SCREEN_WIDTH - 32)/3.0;
            CGFloat height = width + 20;
            CGFloat toHeight=0;
            if (_attentionArr.count/3 >0) {
                toHeight = (_attentionArr.count/3 +1)*height;
            }
            else{
                if (_attentionArr.count) {
                    toHeight = height;
                }
                else
                toHeight =(_attentionArr.count/3)*height;
            }
            UIView *attentionView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 37.5 +toHeight)];
            NSLog(@"%f",attentionView.bounds.size.height);
            attentionView.backgroundColor = [UIColor whiteColor];
            [cell.contentView addSubview:attentionView];
            UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(15, 0, SCREEN_WIDTH - 30, 37.5)];
            label.text = @"热门关注";
            label.backgroundColor = [UIColor clearColor];
            label.font = [UIFont systemFontOfSize:15];
            label.textColor = [UIColor redColor];
            [attentionView addSubview:label];
            
            for (int i = 0; i <_attentionArr.count; i++) {
                NSDictionary *dict = [_attentionArr objectAtIndex:i];
                
                UIButton *attBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                attBtn.frame = CGRectMake(8 + (i%3)*(width +8), 37.5+ i/3 *height, width, height);
              
                //image
                UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, attBtn.M_width, attBtn.M_width)];
                imageView.layer.masksToBounds = YES;
                imageView.layer.borderWidth = 0.5;
                imageView.layer.borderColor = [[UIColor colorWithHexString:@"#F4F5F6"]CGColor];
                [imageView XK_setImageWithURL:[dict objectForKey:@"listpic"] placeholderImage:[UIImage imageNamed:@"goodsDefaultImage"]];
                [attBtn addSubview:imageView];
                //title
                UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, imageView.M_bottom, attBtn.M_width, height- imageView.M_height)];
                titleLabel.font = [UIFont systemFontOfSize:12];
                titleLabel.textColor = [UIColor colorWithHexString:@"#B0B0B0"];
                titleLabel.textAlignment = NSTextAlignmentCenter;
                titleLabel.text = [dict objectForKey:@"shopname"];
                [attBtn addSubview:titleLabel];
                [attBtn addTarget:self action:@selector(hotAttentionBtnClick:) forControlEvents:UIControlEventTouchUpInside];
                [attentionView addSubview:attBtn];
                attBtn.tag = 60 + i;
            }

        }
               return cell;
    }
    return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        return TopHeight;
    }
    else if (indexPath.row == 1){
        return SCREEN_WIDTH/3 *2;
    }
    else if (indexPath.row == 2)
        return SCREEN_WIDTH *73/320 +10;
    else if (indexPath.row == 3){

        CGFloat width = (SCREEN_WIDTH - 32)/3.0;
        CGFloat height = width + 20;
        CGFloat toHeight=0;
        if (_attentionArr.count/3 >0) {
            toHeight = (_attentionArr.count/3 +1)*height;
        }
        else{
            if (_attentionArr.count) {
                toHeight = height;
            }
            else
                toHeight =(_attentionArr.count/3)*height;
        }
        return toHeight + 37.5;
    }
    else
    return 100;
    
}
#pragma mark - 封装创建按钮的方法
//type = 1- 逛云商等6个，2-逛商场

/**
 创建按钮

 @param frame       按钮的frame
 @param image       按钮上的图片,
 @param title       标题
 @param detailTitle 副标题
 @param type        type = 1- 逛云商等6个，2-逛商场
 */
- (UIButton *)createViewWithFrame:(CGRect)frame withbtnImage:(UIImage *)image withtitle:(NSString *)title withDetailTitle:(NSString *)detailTitle withBtnType:(int)type{// 106 ,55 image  , title 21,detail 21
    UIButton *superButton = [UIButton buttonWithType:UIButtonTypeCustom];
    superButton.backgroundColor = [UIColor whiteColor];
    superButton.frame = frame;
    //image
    /*
     self.imageView.M_y = 11;
     self.imageView.M_width = 55;
     self.imageView.M_width = 55;
     self.imageView.M_centerX = self.M_width *0.5;
     
     //title
     self.titleLabel.M_x = 0;
     self.titleLabel.M_y = self.imageView.M_bottom;
     self.titleLabel.M_height = 21;
     self.titleLabel.M_width = self.M_width;
     self.titleLabel.font = [UIFont systemFontOfSize:13];
     self.titleLabel.textAlignment = NSTextAlignmentCenter;
     */
    UIImageView *imageView = [[UIImageView alloc]init];
    UILabel *titleLabel = [[UILabel alloc]init];
    UILabel *detailTitleLabel = [[UILabel alloc]init];
    if (type == 1) {//逛云商等6个
        imageView.frame = CGRectMake(0, 11, 55, 55);
        imageView.M_centerX = superButton.M_width *0.5;
        //title
        titleLabel.frame = CGRectMake(0, imageView.M_bottom, superButton.M_width, 21);
        titleLabel.font = [UIFont systemFontOfSize:13];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.textColor = [UIColor colorWithHexString:@"#4a4a4a"];
      
        //detailTitle
        detailTitleLabel.frame = CGRectMake(0, titleLabel.M_bottom - 3, superButton.M_width, 21);
        detailTitleLabel.font = [UIFont systemFontOfSize:10];
        detailTitleLabel.textAlignment = NSTextAlignmentCenter;
        detailTitleLabel.textColor = [UIColor colorWithHexString:@"#999999"];

    }
    else if (type == 2){
        imageView.frame = superButton.bounds;
        //title
        titleLabel.frame = CGRectMake(27, 17, 109, 21);
        titleLabel.font = [UIFont systemFontOfSize:18];
        titleLabel.textColor = [UIColor colorWithHexString:@"#F32833"];
        //detail
        detailTitleLabel.frame = CGRectMake(27, titleLabel.M_bottom, titleLabel.M_width, 21);
        detailTitleLabel.font = [UIFont systemFontOfSize:12];
        detailTitleLabel.textColor = [UIColor colorWithHexString:@"#B0B0B0"];
    }
    imageView.image = image;
    [superButton addSubview:imageView];
    titleLabel.text = title;
    [superButton addSubview:titleLabel];
    detailTitleLabel.text = detailTitle;
    [superButton addSubview:detailTitleLabel];
    
    return superButton;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView == _mainTable) {
        //仿京东＝＝！
        if (scrollView.contentOffset.y > 0) {
            [self setNavBarAlpha:0.5];
            
        }else{
            [self setNavBarAlpha:1];
        }
    }
}
- (void)setNavBarAlpha:(float)alpha{
    
       [(UIView *)[self.navigationController.navigationBar.subviews objectAtIndex:0]setAlpha:alpha];
}
#pragma mark - 按钮的点击事件（逛云商。。。逛商场）
- (void)buttonClick:(id)sender{
    UIButton *btn = (UIButton *)sender;
    switch (btn.tag) {
#warning 交易提示单、我的订单、我的卡券、我要买 都需要判断是否登录
        case 1000:{//逛云商
            mposMerchantViewController *vc = [[mposMerchantViewController alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 1001:{//逛商品
            lookGoodsViewController *vc = [[lookGoodsViewController alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 1002:{//交易提示单
            if (!MyAppDelegate.userInfo) {
                self.selectBtnTag = 1002;
                [self login];
                return;
            }
            mySignViewController *vc = [[mySignViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            break;
        }
        case 1003:{//我的订单
            if (!MyAppDelegate.userInfo) {
                self.selectBtnTag = 1003;
                [self login];
                return;
            }
            myOrderVC *vc = [[myOrderVC alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            break;
        }
        case 1004:{//我的卡券
            if (!MyAppDelegate.userInfo) {
                self.selectBtnTag = 1004;
                [self login];
                return;
            }
            CouponTypeVC *vc = [[CouponTypeVC alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            break;
        }
        case 1005:{//我要买
            if (!MyAppDelegate.userInfo) {
                self.selectBtnTag = 1005;
                [self login];
                return;
            }
            AddWantBuyVC *vc = [[AddWantBuyVC alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
            break;
        }
        case 50:{//逛商场
            ShopVC *shopCtrl = [[ShopVC alloc] init];
            [self.navigationController pushViewController:shopCtrl animated:YES];
            break;
        }
        default:
            break;
    }
    

}
#pragma mark - 热门关注的按钮点击
- (void)hotAttentionBtnClick:(id)sender{
    UIButton *btn = (UIButton *)sender;
    NSDictionary *dict = [_attentionArr objectAtIndex:btn.tag - 60];
    mposDetailViewController *detailV = [[mposDetailViewController alloc]init];
    detailV.merDic =[dict mutableCopy];
//    detailV.isFromMpos = YES;
    [self.navigationController pushViewController:detailV animated:YES];
    
}
#pragma mark - FirstScrollViewControllerDelegate-轮播图的跳转
- (void)newsSelect:(NSInteger)index{
    NSDictionary *shopDic = [_newsArray objectAtIndex:index];
    mposDetailViewController *vc = [[mposDetailViewController alloc]init];
    vc.shopId = [shopDic objectForKey:@"shopid"];
    [self.navigationController pushViewController:vc animated:YES];
    
}
- (void)pushToShopWithShopId:(NSString *)shopid{
    mposDetailViewController *vc = [[mposDetailViewController alloc]init];
    vc.shopId = shopid;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self createTopNavi];
//    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
}
- (void)viewWillDisappear:(BOOL)animated{
    
    UIButton *troBtn = (UIButton *)[self.navigationController.navigationBar viewWithTag:101];
    if (troBtn ) {
        [troBtn removeFromSuperview];
        troBtn = nil;
    }
    UIButton *mesBtn =(UIButton *)[self.navigationController.navigationBar viewWithTag:102];
    if (mesBtn) {
        [mesBtn removeFromSuperview];
        mesBtn = nil;
    }
    [self setNavBarAlpha:1];
    [super viewWillDisappear:animated];
    
}

#pragma mark- 跳转到登录
- (void)login{
    LoginVC *loginV = [[LoginVC alloc]init];
    loginV.delegate = self;
    UINavigationController *navc = [[UINavigationController alloc]initWithRootViewController:loginV];
    [self presentViewController:navc animated:YES completion:nil];
}

#pragma mark - 登录完成的回调
- (void)finishLogin{
    switch (self.selectBtnTag) {
        case 101:{//购物车
           
            shopCartViewController *vc = [[shopCartViewController alloc]init];
            [self.navigationController pushViewController:vc  animated:NO];
            break;
        }
        case 102:{//消息
            MyMessageVC *vc = [[MyMessageVC alloc] init];
            [self.navigationController pushViewController:vc animated:NO];
            break;
        }
        case 1002:{//交易提示单
           
            mySignViewController *vc = [[mySignViewController alloc]init];
            [self.navigationController pushViewController:vc animated:NO];
            break;
        }
        case 1003:{//我的订单
      
            myOrderVC *vc = [[myOrderVC alloc]init];
            [self.navigationController pushViewController:vc animated:NO];
            break;
        }
        case 1004:{//我的卡券
         
            CouponTypeVC *vc = [[CouponTypeVC alloc]init];
            [self.navigationController pushViewController:vc animated:NO];
            break;
        }
        case 1005:{//我要买
            
            AddWantBuyVC *vc = [[AddWantBuyVC alloc]init];
            [self.navigationController pushViewController:vc animated:NO];
            break;
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
