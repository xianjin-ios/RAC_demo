//
//  MyAttentionViewController.m
//  GGSH_Refactoring
//
//  Created by huadong on 16/9/14.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "MyAttentionViewController.h"
#import "LoginVC.h"
#import "MyMessageVC.h"
//#import "GYShopDetailViewController.h"
#import "ShopDetailVC.h"
#import "mposDetailViewController.h"

@interface MyAttentionViewController ()<MJRefreshBaseViewDelegate,UITableViewDelegate,UITableViewDataSource,loginDelegate>
{
    UIView *noView;
    
    MJRefreshHeaderView *_header;
    
    UIImageView *imageAlert;
}
@property (nonatomic, retain) NSDate *date;
@property (nonatomic, assign) BOOL isRequestShop;
@property (nonatomic, assign) BOOL isRequestBrand;
@property (nonatomic,strong) NSMutableArray *dataArray;

@end

@implementation MyAttentionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的关注";
    
    [self createRightNav];
    [self cancelTapHideKeyBoard:YES];
    _dataArray = [[NSMutableArray alloc]init];
    mutableFetchResults = [[NSMutableArray alloc]init];
 
    _header = [MJRefreshHeaderView header];
    _header.scrollView = self.iAttenTableView;
    _header.delegate = self;
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refreshMyAttention) name:@"refreshAttention" object:nil];
    //退出登陆刷新关注列表
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refreshMyAttention) name:kRefreshAttentData object:nil];
    //添加未读通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNavBtn) name:@"HaveNoRead" object:nil];
    if(MyAppDelegate.userInfo){
        
           [self getShopList:nil];
        
    }
    else{
            [self performSelector:@selector(showLogin) withObject:nil afterDelay:0.1];
        
    }
}

- (void)showLogin{
    LoginVC *loginV = [[LoginVC alloc]init];
    loginV.delegate = self;
    UINavigationController * navi = [[UINavigationController alloc] initWithRootViewController:loginV];
    [self presentViewController:navi animated:YES completion:nil];
}

//登录成功
- (void)finishLogin{
    [self getShopList:nil];
}

//登录失败
- (void)cancelLogin{
    [MyAppDelegate setTabSelect:0];
}

- (void)createRightNav{
    UIButton *messageButton = [UIButton buttonWithType:UIButtonTypeCustom];
    messageButton.frame = CGRectMake(0, 0, 16, 16);
    [messageButton addTarget:self action:@selector(gotoMessage) forControlEvents:UIControlEventTouchUpInside];
    [messageButton setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    messageButton.titleLabel.font = [UIFont systemFontOfSize:13];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:messageButton];
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
    //判断是否要添加红点提示
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(10, -4, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [rightBarButtonItem.customView addSubview:imageAlert];
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }

   
}
//消息按钮的点击
- (void)gotoMessage{
    MyMessageVC *newC = [[MyMessageVC alloc]init];
    [self.navigationController pushViewController:newC animated:YES];
}

- (void)refreshNavBtn{
    if (MyAppDelegate.isHaveNoReadMessage) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
    }
}

#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
//    [self showHUD];
    if(refreshView == _header) {// 下拉刷新
        //先判断网络是否可用
        if(0 == [MyAppDelegate whetherHaveNet]){
            [self showalertString:@"无网络连接"];
            [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
            return;
        }
        
        //5秒内不能重复发起网络请求，只是界面上闪动下正在加载，就1s。
        if(self.date){
            NSDate *tenMiniteLater = [self.date dateByAddingTimeInterval:5];
            NSDate *currentDate = [NSDate date];
            if(NSOrderedDescending == [tenMiniteLater compare:currentDate]){
                ZLog(@"ascending");
                self.date = [NSDate date];
                [self performSelector:@selector(OneSecondElapse) withObject:nil afterDelay:1];
                [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
                return;
            }
            
            //网络请求
            if ([attenshopbtn isSelected]) {
                [self getMyAtten];
            }else{
                [self getAttentionList];
            }
            
        }else{
            self.date = [NSDate date];
            //网络请求
            if ([attenshopbtn isSelected]) {
                [self getMyAtten];
            }else{
                [self getAttentionList];
            }
        }
        
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    }
}

//1s的假loading，取消正在加载就好
- (void)OneSecondElapse{
    [self hideHUD];
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
}

//刷新我的关注
- (void)refreshMyAttention{
    [self getAttentionList];
    [self getMyAtten];
}
#pragma mark - network
- (void)getMyAtten{
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    
    if (MyAppDelegate.userInfo) {
        NSString * usr = [MyAppDelegate.userInfo objectForKey:@"id"];
        [item setObject:usr forKey:@"UserID"];
        
    }else{
        [item setObject:@"" forKey:@"UserID"];
        
    }
    
       [self showHUD];
    [xkNetwork xk_requstWithDic:item withUrl:kMyAttentionShop withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
         [self hideHUD];
        ZLog(@"responseString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        self.isRequestShop = YES;
        if (mutableFetchResults.count != 0) {
            [mutableFetchResults removeAllObjects];
        }
        if (noView) {
            [noView removeFromSuperview];
            noView = nil;
        }
        mutableFetchResults = [[[resultDic objectForKey:@"Result"]objectForKey:@"ListInfo"] mutableCopy];
     
        if (mutableFetchResults.count == 0) {
            //无数据提示
            [self showNODataView];
        }else{

            [self hideNODataView];
        }
           [self.iAttenTableView reloadData];

    }];

    
}
- (void)showNODataView{
    //无数据提示
    if (!noView) {
        noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
        noView.backgroundColor = [UIColor clearColor];
        noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 55);
        UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
        bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
        UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
        labela.backgroundColor = [UIColor clearColor];
        labela.text = @"暂无内容";
        labela.textAlignment = 1;
        labela.font = [UIFont systemFontOfSize:15];
        labela.textColor = [UIColor lightGrayColor];
        [bigbeen addSubview:labela];
        [noView addSubview:bigbeen];
        [self.iAttenTableView addSubview:noView];
    }

}
- (void)hideNODataView{
    if (noView) {
        [noView removeFromSuperview];
        noView = nil;
    }
}
//获取关注商户列表
-(void)getAttentionList{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Show" forKey:@"Mod"];
    [dic setObject:@"Attentlist" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if (MyAppDelegate.userInfo) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
        
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
//    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        ZLog(@"responseString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        ZLog(@"%@",resultDic);
        if (self.dataArray.count != 0) {
            [self.dataArray removeAllObjects];
        }
        if (noView) {
            [noView removeFromSuperview];
            noView = nil;
        }
        if ([[resultDic objectForKey:@"DetailInfo"] isKindOfClass:[NSArray class]]) {
            NSMutableArray *tempArr = [resultDic objectForKey:@"DetailInfo"];
            self.dataArray = [tempArr mutableCopy];
            
        }
        
        [self.iAttenTableView reloadData];
        
        if (self.dataArray.count == 0) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 55);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [self.iAttenTableView addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
        
   }];
    
    

        
 
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //友盟统计
    [MobClick beginLogPageView:@"G_MYATTENTION_VIEW"];
    
//    //隐藏返回按钮
//    [super hideBackButton:YES];
//    
//    if(MyAppDelegate.userInfo){
//        [self getShopList:nil];
//    }else{
//        [self performSelector:@selector(showLogin) withObject:nil afterDelay:0.1];
//    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_MYATTENTION_VIEW"];
    
}
#pragma mark - buttonTarget
- (IBAction)getShopList:(id)sender {
    [attenShop setSelected:YES];
    [attenshopbtn setSelected:NO];
    
    [UIView beginAnimations:nil context:nil];
    [downLine setFrame:CGRectMake(attenShop.frame.origin.x, attenShop.frame.origin.y + attenShop.frame.size.height, attenShop.frame.size.width, 2)];
    [UIView commitAnimations];
    
    if (noView) {
        [noView removeFromSuperview];
        noView = nil;
    }
    
    if (self.dataArray.count != 0) {
        [_iAttenTableView reloadData];
    }else{
        [self getAttentionList];
        
    }
}

-(IBAction)shopbtnclick:(id)sender{
    [attenShop setSelected:NO];
    [attenshopbtn setSelected:YES];
    
    [UIView beginAnimations:nil context:nil];
    [downLine setFrame:CGRectMake(attenshopbtn.frame.origin.x, attenshopbtn.frame.origin.y + attenshopbtn.frame.size.height, attenshopbtn.frame.size.width, 2)];
    [UIView commitAnimations];
    
    if (noView) {
        [noView removeFromSuperview];
        noView = nil;
    }
    
    if (mutableFetchResults.count != 0) {
        [_iAttenTableView reloadData];
    }else{
        [self getMyAtten];
    }
    
}

#pragma -mark tableview begin
- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"attenTableViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
        cell.backgroundColor = [UIColor clearColor];
        
        UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(10, 5, 45, 45)];
        image.tag = 101;
        image.image = [UIImage imageNamed:@"mpos_icon.png"];
        [cell.contentView addSubview:image];
        
        
        UILabel *name = [[UILabel alloc]initWithFrame:CGRectMake(65, 5, SCREEN_WIDTH - 100, 25)];
        name.backgroundColor = [UIColor clearColor];
        name.font = [UIFont systemFontOfSize:15];
        name.textColor = [UIColor blackColor];
        name.tag = 102;
        [cell.contentView addSubview:name];
        
        
        UILabel *infoTitle = [[UILabel alloc]initWithFrame:CGRectMake(65, 30, SCREEN_WIDTH - 100, 20)];
        infoTitle.backgroundColor = [UIColor clearColor];
        infoTitle.font = [UIFont systemFontOfSize:12];
        infoTitle.tag = 103;
        infoTitle.textColor = [UIColor colorWithHexString:@"#636363"];
        [cell.contentView addSubview:infoTitle];
        
        
        UIImageView *pointerview = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"arrow.png"]];
        pointerview.frame = CGRectMake(SCREEN_WIDTH - 30, 20, 7, 14);
        [cell.contentView addSubview:pointerview];
        
        
        UIView *downLine1 = [[UIView alloc]initWithFrame:CGRectMake(0, 54.5, SCREEN_WIDTH, 0.5)];
        downLine1.backgroundColor = [UIColor colorWithHexString:@"#DFDFDF"];
        [cell.contentView addSubview:downLine1];
        
    }
    
    UIImageView *image = (UIImageView *)[cell.contentView viewWithTag:101];
    UILabel *name = (UILabel *)[cell.contentView viewWithTag:102];
    UILabel *infoTitle = (UILabel *)[cell.contentView viewWithTag:103];
    
    if([attenshopbtn isSelected]){
        name.frame = CGRectMake(65, 5, SCREEN_WIDTH - 100, 25);
        
        name.text = [[mutableFetchResults objectAtIndex:indexPath.row] objectForKey:@"ShopName"];
        
        infoTitle.text = [[mutableFetchResults objectAtIndex:indexPath.row] objectForKey:@"address"];
        
        NSString *imagePath = [[mutableFetchResults objectAtIndex:indexPath.row] objectForKey:@"Logo"];
        NSURL *url = [NSURL URLWithString:imagePath];
        if (imagePath.length > 0) {
            [image XK_setImageWithURL:url placeholderImage:nil];
            
        }else{
            image.image = [UIImage imageNamed:@"mpos_icon.png"];
        }
        
    }else if ([attenShop isSelected]){
        name.frame = CGRectMake(65, 5, SCREEN_WIDTH - 100, 25);
        
        name.text = [NSString stringWithFormat:@"%@",[[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"shopname"]];
        
        infoTitle.text = [NSString stringWithFormat:@"%@",[[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"address"]];
        
        NSString *imagePath = [NSString stringWithFormat:@"%@",[[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"listpic"]];
        NSURL *url = [NSURL URLWithString:imagePath];
        
        if (imagePath.length > 0) {
            [image XK_setImageWithURL:url placeholderImage:nil];
        }else{
            image.image = [UIImage imageNamed:@"mpos_icon.png"];
        }
    }
    return cell;
    
}


//指定有多少个分区(Section)，默认为1
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

//指定每个分区中有多少行，默认为1
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if ([attenShop isSelected]) {
        return self.dataArray.count;
    }else{
        if(mutableFetchResults){
            return [mutableFetchResults count];
        }
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 55;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if([attenshopbtn isSelected]){
//        if(2 == [[[mutableFetchResults objectAtIndex:indexPath.row] shoptype] intValue]){
//                    MerchantDetailViewController *controller = [[MerchantDetailViewController alloc]init];
//                controller.shopID = [[mutableFetchResults objectAtIndex:indexPath.row] objectForKey:@"ShopID"];
//                    [self.navigationController pushViewController:controller animated:YES];
//            
//                }else{
//        GYShopDetailViewController *idetailView = [[GYShopDetailViewController alloc] init];
//        idetailView.shopID = [[mutableFetchResults objectAtIndex:indexPath.row] objectForKey:@"ShopID"];
//        [self.navigationController pushViewController:idetailView animated:YES];
        ShopDetailVC *idetailView = [[ShopDetailVC alloc] init];
        idetailView.shopID = [[mutableFetchResults objectAtIndex:indexPath.row] objectForKey:@"ShopID"];
        idetailView.isFromMail = YES;
        idetailView.isFromMyAttention = YES;
        [self.navigationController pushViewController:idetailView animated:YES];

//        }
    }else if ([attenShop isSelected]){
        mposDetailViewController *detailV = [[mposDetailViewController alloc]init];
        detailV.merDic = [self.dataArray objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:detailV animated:YES];
        
    }
    
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tv editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView
commitEditingStyle:(UITableViewCellEditingStyle)editingStyle  forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if ([attenShop isSelected]){
        //取消关注云商
        [self unFollowShop : indexPath.row];
        return;
    }
    
    //    NSError *error;
    //    NSManagedObject *eventToDelete = [mutableFetchResults objectAtIndex:indexPath.row];
    NSString *delInfoId;
    if([attenshopbtn isSelected]){
        delInfoId = [[[mutableFetchResults objectAtIndex:indexPath.row] objectForKey:@"ShopID"] copy];
    }
    
    //    [[MyAppDelegate delegatemanagedObjectContext] deleteObject:eventToDelete];
    //    if (![[MyAppDelegate delegatemanagedObjectContext] save:&error]) {
    //        ZLog(@"Error Saving: %@",[error description]);
    //    }
    //    [self loadLocalData];
    

        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"UserID"];
        [item setObject:delInfoId forKey:@"ShopID"];
        [self showHUD];
    
        [xkNetwork xk_requstWithDic:item withUrl:kMyAttentionShopDel withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
            [self hideHUD];
            ZLog(@"reposeString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
            NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            
            ZLog(@"%@",resultDic);
            if ([[[resultDic objectForKey:@"Result"] objectForKey:@"Status"] isEqualToString:@"Success"]) {
                [self showalertString:@"取消成功！"];
                //网络请求
                if ([attenshopbtn isSelected]) {
                    [self getMyAtten];
                }else{
                    [self getAttentionList];
                }
            }else if ([[[resultDic objectForKey:@"Result"] objectForKey:@"Status"] isEqualToString:@"Success"]){
                [self showalertString:@"取消关注失败"];
            }
            
                [self.iAttenTableView reloadData];
            
            
        }];
        
//        if([attenshopbtn isSelected]){
//            [item setObject:delInfoId forKey:@"ShopID"];
//            SBJsonWriter *json = [[SBJsonWriter alloc] init];
//            NSString *jsonString = [json stringWithObject:item];
//            ZLog(@"del attention: %@",jsonString);
//            
//            NSURL *url = [NSURL URLWithString:kMyAttentionShopDel];
//            __block ASIFormDataRequest *request= [ASIFormDataRequest requestWithURL:url];
//            [request setRequestMethod:@"POST"];
//            [request setPostValue:jsonString forKey:@"JsonString"];
//            [MyAppDelegate checkNetStatus];
//            
//            [self showHUD];
//            
//            __block ASIFormDataRequest *_blorequest = request;
//            [request setCompletionBlock:^{
//                
//                [self hideHUD];
//                __block NSString *responseString = [_blorequest responseString];
//                NSData *responseData = [responseString dataUsingEncoding:NSUTF8StringEncoding];
//                
//                NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingAllowFragments error:nil];
//                
//                ZLog(@"%@",resultDic);
//                if ([[[resultDic objectForKey:@"Result"] objectForKey:@"Status"] isEqualToString:@"Success"]) {
//                    [MyAppDelegate showAlert:@"取消成功！"];
//                    //网络请求
//                    if ([attenshopbtn isSelected]) {
//                        [self getMyAtten];
//                    }else{
//                        [self getAttentionList];
//                    }
//                }else if ([[[resultDic objectForKey:@"Result"] objectForKey:@"Status"] isEqualToString:@"Success"]){
//                    [MyAppDelegate showAlert:@"取消关注失败"];
//                }
//                
//                
//            }];
//            [request setFailedBlock:^{
//                [self hideHUD];
//                
//            }];
//            [request startAsynchronous];
//            
//            [json release];
//        }
//        else{//
//            NSURL *url = [NSURL URLWithString:kMyAttentionBrandDel];
//            [item setObject:delInfoId forKey:@"BrandID"];
//            SBJsonWriter *json = [[SBJsonWriter alloc] init];
//            NSString *jsonString = [json stringWithObject:item];
//            ZLog(@"del attention: %@",jsonString);
//            
//            __block ASIFormDataRequest *request= [ASIFormDataRequest requestWithURL:url];
//            [request setRequestMethod:@"POST"];
//            [request setPostValue:jsonString forKey:@"JsonString"];
//            [MyAppDelegate checkNetStatus];
//            
//            [self showHUD];
//            
//            __block ASIFormDataRequest *_blorequest = request;
//            [request setCompletionBlock:^{
//                
//                [self hideHUD];
//                __block NSString *responseString = [_blorequest responseString];
//                NSData *responseData = [responseString dataUsingEncoding:NSUTF8StringEncoding];
//                
//                NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingAllowFragments error:nil];
//                
//                ZLog(@"%@",resultDic);
//                
//            }];
//            [request setFailedBlock:^{
//                [self hideHUD];
//                
//            }];
//            [request startAsynchronous];
//        }
//        [item release];
//    }

    
//        }
    
}
//取消关注云店铺
- (void)unFollowShop : (NSInteger) index{
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Show" forKey:@"Mod"];
    [dic setObject:@"cancelAttend" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:[NSString stringWithFormat:@"%@",[[self.dataArray objectAtIndex:index] objectForKey:@"id"]] forKey:@"shopid"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
//    //转换为NSString
//    NSData* result = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
//    NSString *jsonString = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
//    
//    ZLog(@"jsonString = %@",jsonString);
    [self showHUD];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        ZLog(@"responseString = %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);

        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        ZLog(@"%@",resultDic);
        
        if ([resultDic isKindOfClass:[NSDictionary class]]) {
            int code = [[resultDic objectForKey:@"Code"] intValue];
            if (code == 0000) {
                [self showalertString:@"取消成功！"];
                //网络请求
                if ([attenshopbtn isSelected]) {
                    [self getMyAtten];
                }else{
                    [self getAttentionList];
                }
            }else{
                [self showalertString:[resultDic objectForKey:@"Message"]];
            }
        }

        
    }];
  
}


@end
