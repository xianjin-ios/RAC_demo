//
//  MyAttentionViewController.h
//  GGSH_Refactoring
//
//  Created by huadong on 16/9/14.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface MyAttentionViewController : BaseViewController
{
    IBOutlet UIButton *attenShop;//云商
    IBOutlet UIButton *attenshopbtn;//商场
    
    IBOutlet UIView *downLine;
    
    //我的关注
    NSMutableArray *mutableFetchResults;
}
@property (nonatomic, retain) IBOutlet UITableView *iAttenTableView;


@end
