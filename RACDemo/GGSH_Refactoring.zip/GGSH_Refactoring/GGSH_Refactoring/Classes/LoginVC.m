//
//  LoginVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/13.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "LoginVC.h"
#import "SSKeychain.h"
#import "ForgotPassVC.h"
#import "RegisterVC.h"
#import <xkNetwork/xkNetwork.h>

@interface LoginVC (){
    IBOutlet UITextField *_tfUserName;
    IBOutlet UITextField *_tfKey;
    
    __weak IBOutlet UIScrollView *_scrV;
    
}

@end

@implementation LoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    if ([USERDEFAULT objectForKey:@"userName"]) {
        _tfUserName.text = [USERDEFAULT objectForKey:@"userName"];
    }
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES];
}

- (IBAction)doLogin:(id)sender{
    if (_tfUserName.text.length == 0){
        _tfUserName.placeholder = @"  手机号";
        [self showAlert:nil withTitle:@"用户名不能为空" haveCancelButton:NO];
        _tfKey.text = @"";
        _tfKey.placeholder = @"  密码";
    }else if (_tfKey.text.length == 0) {
        _tfKey.placeholder = @"  密码";
        [self showAlert:nil withTitle:@"密码不能为空" haveCancelButton:NO];
    }else{
        //保存用户名便于下次免输入
        [USERDEFAULT setObject:_tfUserName.text forKey:@"userName"];
        
        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
        //通过keyChain取用户名和密码
        [item setObject:[USERDEFAULT objectForKey:@"userName"] forKey:@"user_login_name"];
        [item setObject:_tfKey.text forKey:@"user_pass"];
        [item setObject:[NSNumber numberWithInteger:5] forKey:@"user_type"];
        [item setObject:[NSNumber numberWithInteger:1] forKey:@"devicetype"];
        [item setObject:KVERSION forKey:@"version_name"];
        if ([MyAppDelegate getDeviceToken]) {
            [item setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
        }else{
            [item setObject:@"" forKey:@"devicetoken"];
        }
        NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
        NSString *currentVersion = [infoDic objectForKey:@"CFBundleShortVersionString"];
        [item setObject:currentVersion forKey:@"version"];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"Members",@"Mod",@"Login",@"Act",item,@"Content", nil];
        
        [xkNetwork xk_requstWithDic:dic withUrl:KHTTPSURL withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
            if (data == nil || error != nil) {
                NSLog(@"kong");
                
                
                return;
            }
            NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
            
            NSLog(@"str : %@",tempStr);
            
            NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            
            int code = [[resultDic  objectForKey:@"Code"] intValue];
            if (code == 0000) {
                [SSKeychain setPassword:[USERDEFAULT objectForKey:@"userName"] forService:keyChainAccessGroup account:keyChainUser];
                [SSKeychain setPassword:_tfKey.text forService:keyChainAccessGroup account:keyChainLoginToken];
                
                MyAppDelegate.userInfo = [resultDic objectForKey:@"DetailInfo"];
            
                //保存用户名便于下次免输入
                [USERDEFAULT setObject:_tfUserName.text forKey:@"userName"];
                
                //设备收集
                [self InfoCollect];
              [MyAppDelegate getNoReadInfo];//获取未读信息
                [self.navigationController dismissViewControllerAnimated:NO completion:nil];
                if([self.delegate respondsToSelector:@selector(finishLogin)]) {
                    
                    [self.delegate finishLogin];
                }
                return;
                
            }else if (code == 5001){
                [self showAlert:nil withTitle:@"用户账号重复" haveCancelButton:NO];
            }else if (code == 5002){
                [self showAlert:nil withTitle:@"用户账号或密码不能为空" haveCancelButton:NO];
            }else if (code == 5003){
                [self showAlert:nil withTitle:@"登录失败!" haveCancelButton:NO];
            }else if (code == 5004){
                [self showAlert:nil withTitle:@"登录已过期" haveCancelButton:NO];
            }else if (code == 5005){
                [self showAlert:nil withTitle:@"设备类型错误！" haveCancelButton:NO];
            }else if (code == 5006){
                [self showAlert:nil withTitle:@"账号不存在！" haveCancelButton:NO];
            }else if (code == 5007){
                [self showAlert:nil withTitle:@"账号或者密码错误！" haveCancelButton:NO];
            }else if (code == 9999){
                [self showAlert:nil withTitle:@"获取数据失败或者操作失败！" haveCancelButton:NO];
            }
            if([self.delegate respondsToSelector:@selector(failedLogin)]) {
                
                [self.delegate failedLogin];
            }
            
        }];
    }
}

//收集手机信息
- (void)InfoCollect{
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    
    NSString *token = MyAppDelegate.devTokenStr;
    if (token.length > 0) {
        [item setObject:[token substringWithRange:NSMakeRange(1, token.length-2)] forKey:@"devicetoken"];
    }
    [item setObject:@"xkdx" forKey:@"platform"];
    
    //之前的日期版本被version_name取代
    [item setObject:KVERSION forKey:@"version"];
    [item setObject:KVERSION forKey:@"version_name"];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        
    }
    [item setObject:@"1" forKey:@"devicetype"];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"System",@"Mod",@"InfoCollect",@"Act",item,@"Content", nil];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        ZLog(@"InfoCollect : %@",resultDic);
        
    }];
}

- (IBAction)forgotPass:(id)sender{
    ForgotPassVC *vc = [[ForgotPassVC alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)toRegister:(id)sender{
    RegisterVC *vc = [[RegisterVC alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 取消登录
- (IBAction)reback:(id)sender{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    if([self.delegate respondsToSelector:@selector(cancelLogin)]) {
        [self.delegate cancelLogin];
    }
}

@end
