//
//  RegisterVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/19.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "RegisterVC.h"
#import "AgreementVC.h"

@interface RegisterVC (){
    IBOutlet UITextField *_tfPhoneNum;  /**<  手机号 */
    IBOutlet UITextField *_tfCheckCode;  /**<  验证码 */
    IBOutlet UITextField *_tfKey;  /**<  密码 */
    
    
    IBOutlet UIButton *_btnCode;  /**< 获取验证码 */
    IBOutlet UIButton *_btnReadAgreement; /**< 阅读协议按钮 */
}

@end

@implementation RegisterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (IBAction)goBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)getCheckCode:(id)sender{
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Members" forKey:@"Mod"];
    [dic setObject:@"getCode" forKey:@"Act"];
    
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    [dicContent setObject:@"51" forKey:@"type"];
    [dicContent setObject:_tfPhoneNum.text forKey:@"phone"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        int code = [[resultDic  objectForKey:@"Code"] intValue];
        if (code == 0000) {
            
        }
    }];
}

- (IBAction)btnAgreement:(id)sender{
    UIButton *btn = (UIButton *)sender;
    btn.selected = !btn.isSelected;
}

- (IBAction)readAgreement:(id)sender{
    AgreementVC *vc = [[AgreementVC alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)doRegister:(id)sender{
    if(!_btnReadAgreement.isSelected){
        [self showAlert:nil withTitle:@"请同意《服务协议》" haveCancelButton:NO];
        return;
    }
    
    if(_tfPhoneNum.text.length < 11 || _tfCheckCode.text.length < 1 ||
       _tfKey.text.length < 6){
        [self showAlert:nil withTitle:@"信息不完整" haveCancelButton:NO];
        return;
    }
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:_tfPhoneNum.text forKey:@"user_login_name"];
    [item setObject:@"" forKey:@"user_realname"];
    [item setObject:_tfKey.text forKey:@"user_pass"];
    [item setObject:[MyAppDelegate getDeviceToken] forKey:@"devicetoken"];
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    [item setObject:@"5" forKey:@"user_type"];
    [item setObject:_tfCheckCode.text forKey:@"code"];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"Members",@"Mod",@"register_v1",@"Act",item,@"Content", nil];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            
            
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        int code = [[resultDic  objectForKey:@"Code"] intValue];
        if (code == 0000) {
            [self showAlert:nil withTitle:@"注册成功！" haveCancelButton:NO];
        }else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
    }];
}

@end
