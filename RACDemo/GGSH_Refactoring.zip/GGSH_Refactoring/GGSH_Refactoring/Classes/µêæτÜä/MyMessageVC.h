//
//  MyMessageVC.h
//  GGSH_Refactoring
//  消息的现实顺序：第一项：系统消息
//               第二项：抢券通知
//               第＊项：用户消息
//  Created by STAR on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface MyMessageVC : BaseViewController

@end
