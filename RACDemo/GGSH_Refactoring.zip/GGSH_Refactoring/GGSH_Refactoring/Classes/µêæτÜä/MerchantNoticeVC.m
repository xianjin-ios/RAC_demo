//
//  MerchantNoticeVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/10.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "MerchantNoticeVC.h"
#import "MessageDetailVC.h"

@interface MerchantNoticeVC ()<UITableViewDelegate,UITableViewDataSource>{
    __weak IBOutlet UITableView *_iTableView;
    
    
    NSArray *_dataArray;
    
    UIView *noView;
}

@end

@implementation MerchantNoticeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"店铺通知";
    [self cancelTapHideKeyBoard:YES];
    // Do any additional setup after loading the view from its nib.
    [self getMessageNetData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 获取系统消息
- (void)getMessageNetData{
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    //
    [item setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
    [item setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    [item setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"phone"];
    [item setObject:[NSNumber numberWithInteger:2] forKey:@"type"];// 1： 拉取最新的一条店铺通知和未读的店铺通知数 2： 拉取列表
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"Release",@"Mod",@"Message_v1",@"Act",item,@"Content", nil];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        int code = [[resultDic objectForKey:@"Code"] intValue];
        if (code == 0000) {
            
            _dataArray = [NSMutableArray arrayWithArray:[resultDic objectForKey:@"DetailInfo"]];
            
        }
        [_iTableView reloadData];
        
        if (_dataArray.count == 0) {
            //无数据提示
            if (!noView) {
                noView = [[UIView alloc]initWithFrame:CGRectMake(55, 20, 97, 121)];
                noView.backgroundColor = [UIColor clearColor];
                noView.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 22);
                UIImageView *bigbeen = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
                bigbeen.image = [UIImage imageNamed:@"bgNoPoint.png"];
                UILabel *labela = [[UILabel alloc]initWithFrame:CGRectMake(0, 101, 97, 20)];
                labela.backgroundColor = [UIColor clearColor];
                labela.text = @"暂无内容";
                labela.textAlignment = 1;
                labela.font = [UIFont systemFontOfSize:15];
                labela.textColor = [UIColor lightGrayColor];
                [bigbeen addSubview:labela];
                [noView addSubview:bigbeen];
                [_iTableView addSubview:noView];
            }
        }else{
            if (noView) {
                [noView removeFromSuperview];
                noView = nil;
            }
        }
    }];
}


#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 66;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dicMessage = [_dataArray objectAtIndex:indexPath.row];
    
    //翻页CELL
    static NSString *CellIdentifier = @"COMMONCELL";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        //图标
        UIImageView *merchantIcon = [[UIImageView alloc]initWithFrame:CGRectMake(8, 16, 34, 34)];
        merchantIcon.tag = 101;
        merchantIcon.image = [UIImage imageNamed:@"_0001_system.png"];
        [cell.contentView addSubview:merchantIcon];
        
        NSString *imgUrl = [dicMessage objectForKey:@"listpic"];
        [merchantIcon XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:nil];
        
        //提示标识
        UIImageView *imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(38, 12, 9, 9)];
        [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
        [imageAlert setTag:1011];
        [cell.contentView addSubview:imageAlert];
        
        if ([dicMessage objectForKey:@"isread"] && [[dicMessage objectForKey:@"isread"] integerValue] != 1) {
            [imageAlert setHidden:NO];
        }else{
            [imageAlert setHidden:YES];
            
        }
        
        //标题
        UILabel * lbTitle = [[UILabel alloc] init];
        lbTitle.tag = 12;
        lbTitle.backgroundColor = [UIColor clearColor];
        lbTitle.font = [UIFont systemFontOfSize:15];
        lbTitle.textColor = [UIColor blackColor];
        [cell.contentView addSubview:lbTitle];
        lbTitle.frame = CGRectMake(50, 10, _iTableView.frame.size.width - 180, 20 );
        lbTitle.text = [dicMessage objectForKey:@"shopname"];
        
        //时间
        UILabel * lbTime = [[UILabel alloc] init];
        lbTime.tag = 13;
        lbTime.textAlignment = NSTextAlignmentRight;
        lbTime.backgroundColor = [UIColor clearColor];
        lbTime.font = [UIFont systemFontOfSize:13];
        lbTime.textColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:lbTime];
        lbTime.frame = CGRectMake(self.view.frame.size.width - 120, 10, 100, 15 );
        NSString * strTime = [dicMessage objectForKey:@"time" ];
        if (strTime == nil) {
            lbTime.text = @"";
        }
        else{
            
            lbTime.text = strTime;
            
        }
        //摘要
        UILabel * lbContent = [[UILabel alloc] init];
        lbContent.tag = 14;
        lbContent.backgroundColor = [UIColor clearColor];
        lbContent.font = [UIFont systemFontOfSize:13];
        lbContent.textColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:lbContent];
        lbContent.frame = CGRectMake(50, 36, _iTableView.frame.size.width - 60, 20 );
        lbContent.text = [dicMessage objectForKey:@"tite"];
        
        UIView *downLine = [[UIView alloc]initWithFrame:CGRectMake(0, 65.5, _iTableView.frame.size.width, 0.5)];
        downLine.backgroundColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:downLine];
        
    }
    
    //商店图标
    UIImageView *merchantIcon = (UIImageView *)[cell.contentView viewWithTag:101];
    NSString *imgUrl = [dicMessage objectForKey:@"listpic"];
    if (imgUrl.length > 0) {
        [merchantIcon XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:nil];
    }else{
        merchantIcon.image = [UIImage imageNamed:@"_0001_system.png"];
    }
    
    UIImageView *imageAlert = (UIImageView *)[cell.contentView viewWithTag:1011];
    if ([dicMessage objectForKey:@"isread"] && [[dicMessage objectForKey:@"isread"] integerValue] != 1) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
        
    }
    
    //标题
    UILabel * lbTitle = (UILabel*)[cell.contentView viewWithTag:12];
    lbTitle.text = [dicMessage objectForKey:@"shopname"];
    
    //时间
    UILabel * lbTime = (UILabel*)[cell.contentView viewWithTag:13];
    NSString * strTime = [dicMessage objectForKey:@"time" ];
    if (strTime == nil) {
        lbTime.text = @"";
    }
    else{
        
        lbTime.text = strTime;
        
    }
    
    UILabel *lbContent = (UILabel *)[cell.contentView viewWithTag:14];
    lbContent.text = [dicMessage objectForKey:@"tite"];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    MessageDetailVC *vc = [[MessageDetailVC alloc]init];
    vc.shopid = [[_dataArray objectAtIndex:indexPath.row] objectForKey:@"id"];
    [self.navigationController pushViewController:vc animated:YES];
}
@end
