//
//  MerchantNoticeVC.h
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/10.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface MerchantNoticeVC : BaseViewController

@end
