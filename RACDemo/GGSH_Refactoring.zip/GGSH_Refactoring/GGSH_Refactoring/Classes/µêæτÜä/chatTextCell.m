//
//  chatTextCell.m
//  CcbCloudPay
//  聊天界面，处理文本内容的UITableViewCell
//  Created by 任春宁 on 15/5/7.
//  Copyright (c) 2015年 xkdx. All rights reserved.
//

#import "chatTextCell.h"

//字体大小
#define LBNAME_FONTSIZE 14

#define TEXT_WIDTH ([[UIScreen mainScreen] bounds].size.width * 3 / 5)
#define SC_WIDTH ([[UIScreen mainScreen] bounds].size.width)

@implementation chatTextCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];


}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        UIImageView * userHeadImage = [[UIImageView alloc] init];
        userHeadImage.tag = 10;
        userHeadImage.frame = CGRectMake(0, 0, 40, 40);
        userHeadImage.backgroundColor = [UIColor clearColor];
        userHeadImage.clipsToBounds = YES;
        [self.contentView addSubview:userHeadImage];
        
        UIImageView * imgViewBG = [[UIImageView alloc] init];
        imgViewBG.tag = 11;
        imgViewBG.frame = CGRectMake(0, 0, 100, 20);
        imgViewBG.backgroundColor = [UIColor clearColor];
        imgViewBG.clipsToBounds = YES;
        [self.contentView addSubview:imgViewBG];
        
        UILabel * lbContent = [[UILabel alloc] init];
        lbContent.tag = 12;
        lbContent.frame = CGRectMake(0, 0, 100, 1000);
        lbContent.backgroundColor = [UIColor clearColor];
        lbContent.font = [UIFont systemFontOfSize:LBNAME_FONTSIZE];
        lbContent.textColor = [UIColor whiteColor];
        lbContent.lineBreakMode = NSLineBreakByCharWrapping;
        lbContent.numberOfLines = 0;
        [self.contentView addSubview:lbContent];
        
        UIImageView * imgContent = [[UIImageView alloc] init];
        imgContent.tag = 13;
        imgContent.frame = CGRectMake(0, 0, 100, 20);
        imgContent.backgroundColor = [UIColor clearColor];
        imgContent.clipsToBounds = YES;
        imgContent.userInteractionEnabled = YES;
        [self.contentView addSubview:imgContent];
        
    }
    return self;
    
}

//初始化数据
-(void)initData:(NSDictionary * )dicMsg{
    
    _dicMsg = dicMsg;
    //我发的信息显示在右边
    ZLog(@"%@",dicMsg);
    NSString * strAdmID = [_dicMsg objectForKey:@"admid"];
    ZLog(@"%@",strAdmID);
    if (![strAdmID isEqualToString:@"0"]) {//admid为0说明是用户发给商户的，在商户版中应该显示在左边
        
        [self initLeftData:_dicMsg];
    }
    else{
        
        [self initRightData:_dicMsg];
    }
    
}

-(void)initRightData:(NSDictionary *)dicMsg{
    
    NSString * type = [[_dicMsg objectForKey:@"type"]description];//消息类型（1为图片，0为文本）
    
    UIImageView * imgViewBG = (UIImageView *)[self.contentView viewWithTag:11];
    //右边
    UIEdgeInsets insets = UIEdgeInsetsMake(30, 13, 6, 20);
    UIImage *image = [UIImage imageNamed:@"face_chat1.png"];
    image = [image resizableImageWithCapInsets:insets];
    
    UILabel * lbContent = (UILabel *)[self.contentView viewWithTag:12];
    UIImageView * imgContent = (UIImageView *)[self.contentView viewWithTag:13];
    UIImageView * userHeadImage = (UIImageView *)[self.contentView viewWithTag:10];
    
    NSString *myHeadImgUrl = [self.userheadDic objectForKey:@"user_pic_assetid"];
    [userHeadImage XK_setImageWithURL:[NSURL URLWithString:myHeadImgUrl] placeholderImage:[UIImage imageNamed:@"my_head.png"]];
    userHeadImage.frame = CGRectMake( SC_WIDTH - 50, 10, 40, 40);

    if ([type isEqualToString:@"1"]) {
        //图片
        [lbContent setHidden:YES];
        [imgContent setHidden:NO];
        [imgViewBG setHidden:YES];

        NSString *imgUrl = [dicMsg objectForKey:@"pic"];
        imgContent.frame = CGRectMake( SC_WIDTH - 10 - SCREEN_WIDTH/3 - 50, 10, SCREEN_WIDTH/3, SCREEN_HEIGHT/3);
        
        if ([dicMsg objectForKey:@"defaultpic"]) {
            [imgContent setImage:[dicMsg objectForKey:@"defaultpic"]];
        }else{
            [userHeadImage XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:[UIImage imageNamed:@"my_head.png"]];
        }
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doSelectPic:)];
        [imgContent addGestureRecognizer:tap];

        CAShapeLayer *_maskLayer = [CAShapeLayer layer];
        _maskLayer.fillColor = [UIColor blackColor].CGColor;
        _maskLayer.strokeColor = [UIColor clearColor].CGColor;
        _maskLayer.frame = CGRectMake(0, 0, SCREEN_WIDTH/3, SCREEN_HEIGHT/3);
        _maskLayer.contentsCenter = CGRectMake(0.5, 0.8, 0.1, 0.1);
        _maskLayer.contentsScale = [UIScreen mainScreen].scale;                 //非常关键设置自动拉伸的效果且不变形
        _maskLayer.contents = (id)[UIImage imageNamed:@"face_chat1.png"].CGImage;
        
        imgContent.layer.mask = _maskLayer;
        imgContent.layer.frame = imgContent.frame;

    }else{
        [lbContent setHidden:NO];
        [imgContent setHidden:YES];
        [imgViewBG setHidden:NO];

        //文本
        lbContent.textColor = [UIColor blackColor];
        lbContent.textAlignment = NSTextAlignmentLeft;
        lbContent.frame = CGRectMake( SC_WIDTH - 30 - TEXT_WIDTH - 50, 20, TEXT_WIDTH, 1000);
        lbContent.text = [_dicMsg objectForKey:@"content"];
        [lbContent sizeToFit];
        lbContent.frame = CGRectMake( SC_WIDTH - 25 - lbContent.frame.size.width - 50, 20, lbContent.frame.size.width, lbContent.frame.size.height);
        
        imgViewBG.frame = CGRectMake(SC_WIDTH - 30 - lbContent.frame.size.width - 50, 10, lbContent.frame.size.width + 20, lbContent.frame.size.height + 20);
        imgViewBG.image = image;

    }

}

-(void)initLeftData:(NSDictionary *)dicMsg{
    
    NSString * type = [[_dicMsg objectForKey:@"type"]description];//消息类型（1为图片，0为文本）
    UIImageView * imgViewBG = (UIImageView *)[self.contentView viewWithTag:11];
    //左边
    UIEdgeInsets insets = UIEdgeInsetsMake(30, 20, 6, 12);
    UIImage *image = [UIImage imageNamed:@"face_chat3.png"];
    image = [image resizableImageWithCapInsets:insets];
    
    UILabel * lbContent = (UILabel *)[self.contentView viewWithTag:12];
    UIImageView * imgContent = (UIImageView *)[self.contentView viewWithTag:13];
    UIImageView * userHeadImage = (UIImageView *)[self.contentView viewWithTag:10];

    NSString *shopHeadImgUrl = [self.userheadDic objectForKey:@"listpic"];
    [userHeadImage XK_setImageWithURL:[NSURL URLWithString:shopHeadImgUrl] placeholderImage:[UIImage imageNamed:@"store.png"]];
    userHeadImage.frame = CGRectMake( 10, 10, 40, 40);
    
    if ([type isEqualToString:@"1"]) {
        //图片
        [lbContent setHidden:YES];
        [imgContent setHidden:NO];
        [imgViewBG setHidden:YES];

        NSString *imgUrl = [dicMsg objectForKey:@"pic"];
        imgContent.frame = CGRectMake( 10 + 50, 10, SCREEN_WIDTH/3, SCREEN_HEIGHT/3);
        if ([dicMsg objectForKey:@"defaultpic"]) {
            [imgContent setImage:[dicMsg objectForKey:@"defaultpic"]];
        }else{
            [userHeadImage XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:[UIImage imageNamed:@"store.png"]];
        }
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doSelectPic:)];
        [imgContent addGestureRecognizer:tap];
        
        CAShapeLayer *_maskLayer = [CAShapeLayer layer];
        _maskLayer.fillColor = [UIColor blackColor].CGColor;
        _maskLayer.strokeColor = [UIColor clearColor].CGColor;
        _maskLayer.frame = CGRectMake(0, 0, SCREEN_WIDTH/3, SCREEN_HEIGHT/3);
        _maskLayer.contentsCenter = CGRectMake(0.5, 0.8, 0.1, 0.1);
        _maskLayer.contentsScale = [UIScreen mainScreen].scale;                 //非常关键设置自动拉伸的效果且不变形
        _maskLayer.contents = (id)[UIImage imageNamed:@"face_chat3.png"].CGImage;
        
        imgContent.layer.mask = _maskLayer;
        imgContent.layer.frame = imgContent.frame;
        
    }else{
        [lbContent setHidden:NO];
        [imgContent setHidden:YES];
        [imgViewBG setHidden:NO];

        //文本
        lbContent.textAlignment = NSTextAlignmentLeft;
        lbContent.textColor = [UIColor blackColor];
        lbContent.frame = CGRectMake(30 + 50, 20, [[UIScreen mainScreen] bounds].size.width * 3 / 5, 1000);
        lbContent.text = [_dicMsg objectForKey:@"content"];
        [lbContent sizeToFit];
        
        imgViewBG.frame = CGRectMake(10 + 50, 10, lbContent.frame.size.width + 30, lbContent.frame.size.height + 20);
        imgViewBG.image = image;

    }
    
    
}
- (void)doSelectPic:(UITapGestureRecognizer *)sender{
    ZLog(@"111");
    
    if ([self.delegate respondsToSelector:@selector(selectpic:)]) {
        [self.delegate selectpic:_dicMsg];
    }
}
//返回CELL高度
+(int)getHeight:(NSDictionary * )dicMsg{
    
    NSString * type = [[dicMsg objectForKey:@"type"]description];//消息类型（1为图片，0为文本）

    if ([type isEqualToString:@"1"]) {
        
        return SCREEN_HEIGHT/3;
    }
    
    NSString * strContent = [dicMsg objectForKey:@"content"];
    
    int maxContentWidth = [[UIScreen mainScreen] bounds].size.width * 3 / 5;
    
    CGSize sizeToFit = [NSString getHeight:strContent withFont:[UIFont systemFontOfSize:LBNAME_FONTSIZE] andWidth:maxContentWidth - 16];
    
    return sizeToFit.height + 20;
    
}


@end
