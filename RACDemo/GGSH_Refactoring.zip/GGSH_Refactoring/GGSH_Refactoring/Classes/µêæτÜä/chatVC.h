//
//  chatVC.h
//  CcbCloudPay
//  聊天界面
//  Created by 任春宁 on 15/5/7.
//  Copyright (c) 2015年 xkdx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MJRefresh.h"
#import "MessageInputBoardVC.h"
#import "BaseViewController.h"

@interface chatVC : BaseViewController<UITableViewDataSource, UITableViewDelegate, MJRefreshBaseViewDelegate,MessageInputBoardVCDelegate, UIScrollViewDelegate>{
    
    IBOutlet UITableView * _tableView;
    
    //聊天数据
    NSMutableArray * _arrMessages;
    
    //聊天数据框
    MessageInputBoardVC * _msgInputBoardCtrl;
    
    
    MJRefreshHeaderView *_header;
    
}

//聊天的用户信息
@property ( nonatomic, strong) NSDictionary * dicChatInfo;

@end
