//
//  AgreementVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/20.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "AgreementVC.h"

@interface AgreementVC ()<UIWebViewDelegate>{
    UIWebView *userWebView;
    
    UIActivityIndicatorView *activityIndicator;
}

@end

@implementation AgreementVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"协议";
    
    self.navigationController.navigationBarHidden = NO;
    // Do any additional setup after loading the view from its nib.
    userWebView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    userWebView.tag = 11;
    userWebView.opaque = NO;
    [self.view addSubview:userWebView];
    userWebView.backgroundColor = [UIColor clearColor];
    userWebView.delegate = self;
    userWebView.clipsToBounds = YES;
    
    NSString* strUrl = [NSString stringWithFormat:@"%@/index.php/Api/WapStaticShow/agreement?type=gg",kMposHeadUrl];
    
    [userWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:strUrl]]];
}

#pragma mark - webViewDelegate
- (void) webViewDidStartLoad:(UIWebView *)webView
{
    webView.frame = self.view.bounds;
    
    activityIndicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    [activityIndicator setCenter:self.view.center];
    [activityIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleWhite];
    [self.view addSubview:activityIndicator];
    [activityIndicator startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [activityIndicator stopAnimating];
    [activityIndicator removeFromSuperview];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
