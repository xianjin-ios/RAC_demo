//
//  SettingVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "SettingVC.h"
#import "ChangePasswordVC.h"
#import "FeedbackVC.h"
//#import "AboutUsVC.h"
#import "OcUseSwift-Swift.h"
#import "GGSH_Refactoring-Bridging-Header.h"
#import "UIAlertView+Block.h"


@interface SettingVC ()<UITableViewDelegate,UITableViewDataSource>{
    NSArray *_arrTitle;
    
    __weak IBOutlet UITableView *_iTableView;
    
    IBOutlet UIButton *_btnLogout;
}

@end

@implementation SettingVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"设置";
    
    _arrTitle = @[@"修改密码",@"关于我们",@"意见反馈"];
    
    [self cancelTapHideKeyBoard:YES];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [MyAppDelegate makeTabBarHidden:YES];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_SET_VIEW"];
    if (MyAppDelegate.userInfo) {
        [_btnLogout setHidden:NO];
        
    }else{
        [_btnLogout setHidden:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MyAppDelegate makeTabBarHidden:NO];
    
//    self.backButton.hidden = YES;
    
    //友盟统计
    [MobClick endLogPageView:@"G_SET_VIEW"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 43;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //翻页CELL
    static NSString *CellIdentifier = @"COMMONCELL";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        //标题
        UILabel *lbTitle = [[UILabel alloc]initWithFrame:CGRectMake(10, 12, SCREEN_WIDTH/3*2 - 15, 20)];
        lbTitle.tag = 201;
        lbTitle.textColor = [UIColor blackColor];
        lbTitle.font = [UIFont systemFontOfSize:15];
        lbTitle.backgroundColor = [UIColor clearColor];
        lbTitle.textAlignment = 0;
        [cell.contentView addSubview:lbTitle];

        //导航箭头
        UIImageView *navImg = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 33, 9, 25, 25)];
        navImg.image = [UIImage imageNamed:@"my_next.png"];
        [cell.contentView addSubview:navImg];
        
        //分割线
        UIView *downLine = [[UIView alloc]initWithFrame:CGRectMake(0, 43-ONEPIXL, SCREEN_WIDTH, ONEPIXL)];
        downLine.backgroundColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:downLine];
    }
    
    UILabel *lbTitle = (UILabel *)[cell.contentView viewWithTag:201];
    lbTitle.text = [_arrTitle objectAtIndex:indexPath.row];

    return cell;
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(0 == indexPath.row){
        ChangePasswordVC *vc = [[ChangePasswordVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }else if(1 == indexPath.row){
        AboutVC *vc = [[AboutVC alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
//        self.navigationController pushViewController:vc animated:<#(BOOL)#>
//        [self.navigationController pushViewController:vc animated:YES];
//        AboutUsVC *vc = [[AboutUsVC alloc] init];
//        [self.navigationController pushViewController:vc animated:YES];
    }else if(2 == indexPath.row){
        FeedbackVC *vc = [[FeedbackVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
}


- (IBAction)tuichu:(id)sender {
    
    //友盟统计
    [MobClick event:@"G_EXIT"];
    
    UIAlertView *alertV = [[UIAlertView alloc]initWithTitle:@"提示" message:@"是否退出？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alertV alertViewWithBlock:^(NSInteger btnIndex) {
        if(1 == btnIndex){
            //百度push解绑设备
            [MyAppDelegate logoutBPush];
            
            MyAppDelegate.userInfo = nil;
            
            [SSKeychain deletePasswordForService:keyChainAccessGroup account:keyChainLoginToken];
            [SSKeychain deletePasswordForService:keyChainAccessGroup account:keyChainUser];
            
            [_btnLogout setHidden:YES];
            
            //刷新未读提示
            [MyAppDelegate getNoReadInfo];
            
            //发送退出登陆通知
            [[NSNotificationCenter defaultCenter] postNotificationName:@"NOTI_LOGOUT" object:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:kRefreshAttentData object:nil];
            
            [self showAlert:nil withTitle:@"成功退出" haveCancelButton:NO];
            
            [self.navigationController popToRootViewControllerAnimated:YES];
            
        }
    }];
}

//返回首页
- (IBAction)gotoFirstView:(id)sender {
    
    [MyAppDelegate.mainTabVC setSelectedIndex:0];
    [MyAppDelegate.mainTabVC.selectImage setFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, 49)];
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}

@end
