//
//  chatTextCell.h
//  CcbCloudPay
//  聊天界面，处理文本内容的UITableViewCell
//  Created by 任春宁 on 15/5/7.
//  Copyright (c) 2015年 xkdx. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SELECTPIC_DELEGATE <NSObject>

- (void)selectpic:(NSDictionary * )dicMsg;

@end
@interface chatTextCell : UITableViewCell{
    
    NSDictionary * _dicMsg;
}
@property (nonatomic,assign)id<SELECTPIC_DELEGATE> delegate;
@property (nonatomic,retain)NSMutableDictionary *userheadDic;

-(void)initData:(NSDictionary * )dicMsg;

//获取cell高度
+(int)getHeight:(NSDictionary * )dicMsg;

@end
