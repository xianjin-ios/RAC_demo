//
//  SFeedBackVC.swift
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/14.
//  Copyright © 2016年 huadong. All rights reserved.
//

import UIKit




class SFeedBackVC: BaseViewController {

    @IBOutlet weak var _tvSuggest: UITextView!
    @IBOutlet weak var _tfContact: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "意见反馈";

        //样式
        _tvSuggest.layer.borderWidth = ONEPIXL;
        _tvSuggest.layer.borderColor = UIColor.lightGray.cgColor;
        _tvSuggest.layer.cornerRadius = 5;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

//    weak var doFeedback: UIButton!{
//        if(_tvSuggest.text.characters.count > 200 || 0 == _tvSuggest.text.characters.count){
//            let alertController = UIAlertController(title: nil,
//                                                    message: "输入不能为空，或多于200字！", preferredStyle: .alert)
//            let okAction = UIAlertAction(title: "好的", style: .default, handler: {
//                action in
//                print("点击了确定")
//                })
//            alertController.addAction(okAction)
//            self.present(alertController, animated: true, completion: nil)
//            return nil
//        }
//        
//        // submit
//        let item = NSMutableDictionary.init()
//        if (_tvSuggest.text.characters.count > 0){
//            item["Content"] = _tvSuggest.text;
//        }
//        if((_tfContact.text?.characters.count)!  > 0){
//            item["Title"] = _tfContact.text;
//        }
////        xkNetwork .xk_requst(withDic: item, withUrl: kAdvice, withRequestMethod: "POST", isHTTPS: NO, andMultiPartFile: nil, andGetData: ^(id data, NSError *error){
////            
////            }
////
//    }


}
