//
//  MessageDetailVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/10.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "MessageDetailVC.h"

@interface MessageDetailVC (){
    

    __weak IBOutlet UITextView *_tfDetail;
    __weak IBOutlet UIImageView *_imgInfo;
    __weak IBOutlet UILabel *_lbTime;
    __weak IBOutlet UILabel *_lbTitle;
}

@end

@implementation MessageDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"店铺消息";
    // Do any additional setup after loading the view from its nib.
    
    _imgInfo.image = [UIImage imageNamed:@"goucai_bg.png"];
    //获取详情
    [self getDetail];
}

- (void)getDetail{
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    //
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [item setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [item setObject:@"" forKey:@"uid"];
        [item setObject:@"" forKey:@"logintoken"];
        
    }
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    [item setObject:[NSString stringWithFormat:@"%@",self.shopid] forKey:@"id"];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"Shop",@"Mod",@"MsgeDetail",@"Act",item,@"Content", nil];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        NSDictionary *dic = [resultDic objectForKey:@"DetailInfo"];
        
        _lbTitle.text = [dic objectForKey:@"tite"];
        _lbTime.text = [dic objectForKey:@"time"];
        _tfDetail.text = [dic objectForKey:@"content"];
        
        [_imgInfo XK_setImageWithURL:[NSURL URLWithString:[dic objectForKey:@"pic"]] placeholderImage:[UIImage imageNamed:@"goucai_bg.png"]];        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
