//
//  SwiftHeader.swift
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/14.
//  Copyright © 2016年 huadong. All rights reserved.
//

import Foundation

//关于显示的宏定义
let ONEPIXL = 1/UIScreen.main.scale
let SCREEN_HEIGHT = UIScreen.main.bounds.height
let SCREEN_WIDTH = UIScreen.main.bounds.width

//意见反馈 --feedback
//let kAdvice; "http://gginter.guangguang.net.cn:8182/otherInterface/advice.php"
