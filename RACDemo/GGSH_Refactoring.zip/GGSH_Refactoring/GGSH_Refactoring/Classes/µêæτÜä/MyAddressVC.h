//
//  MyAddressVC.h
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@protocol SETADDRESS_DELEGATE <NSObject>
- (void)selectAddress:(NSInteger)selectIndex;
@end


@interface MyAddressVC : BaseViewController

@property (nonatomic,assign) id<SETADDRESS_DELEGATE> delegate;

@property (nonatomic,assign) BOOL isFromMy;

@property (nonatomic,assign) NSString *addressId;

- (IBAction)addPerAddress:(id)sender;


@end
