//
//  AgreementVC.h
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/20.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface AgreementVC : BaseViewController

@end
