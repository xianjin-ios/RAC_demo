//
//  MyOrderVC.h
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface MyOrderVC : BaseViewController

@property (retain, nonatomic) NSString * TradeStatus;
@property (assign, nonatomic) NSInteger user_order_type;//1代付预付款2待收货/自取3已完成

@property (nonatomic,assign) BOOL isPaying;

@end
