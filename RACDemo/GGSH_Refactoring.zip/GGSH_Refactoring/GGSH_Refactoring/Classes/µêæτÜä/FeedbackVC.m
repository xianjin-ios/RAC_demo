//
//  FeedbackVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/8.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "FeedbackVC.h"

@interface FeedbackVC (){
    __weak IBOutlet UITextView *_tvSuggest;
    __weak IBOutlet UITextField *_tfContact;
}

@end

@implementation FeedbackVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"意见反馈";
    
    //样式
    _tvSuggest.layer.borderWidth = ONEPIXL;
    _tvSuggest.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _tvSuggest.layer.cornerRadius = 5;
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [MyAppDelegate makeTabBarHidden:YES];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MyAppDelegate makeTabBarHidden:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doFeedback:(id)sender{
    if([_tvSuggest.text length] > 200 || 0 == [_tvSuggest.text length]){
        [self showAlert:nil withTitle:@"输入不能为空，或多于200字！" haveCancelButton:NO];
        return;
    }
    // submit
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    
    if ([_tvSuggest.text length]>0) {
        [item setObject:_tvSuggest.text forKey:@"Content"];
    }
    if ([_tfContact.text length]>0) {
        [item setObject:_tfContact.text forKey:@"Title"];
    }
    
    [xkNetwork xk_requstWithDic:item withUrl:kAdvice withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        NSString *message = [[resultDic  objectForKey:@"Result"] objectForKey:@"Message"];
        [self showAlert:nil withTitle:message haveCancelButton:NO];
        
    }];
}

@end
