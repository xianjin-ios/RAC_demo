//
//  ForgotPassVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/19.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "ForgotPassVC.h"

@interface ForgotPassVC (){
    //注册获取验证码90秒等待
    int wait90Sec;
    
    
    IBOutlet UITextField *_tfPhoneNum;
    IBOutlet UITextField *_tfPass1;
    IBOutlet UITextField *_tfPass2;
    IBOutlet UITextField *_tfCheckCode;
    IBOutlet UIButton *_btnCheckCode;
}

@end

@implementation ForgotPassVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"忘记密码";
    self.navigationController.navigationBarHidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)getCheckCode:(id)sender{
    //结束计时
    wait90Sec = 90;
    [self startCount];
    
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Members" forKey:@"Mod"];
    [dic setObject:@"getCode" forKey:@"Act"];
    
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    [dicContent setObject:@"52" forKey:@"type"];
    [dicContent setObject:_tfPhoneNum.text forKey:@"phone"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        int code = [[resultDic  objectForKey:@"Code"] intValue];
        if (code == 0000) {
            
        }
    }];
}

- (IBAction)changePassword:(id)sender{
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Members" forKey:@"Mod"];
    [dic setObject:@"forgetPass_v1" forKey:@"Act"];
    
    NSMutableDictionary * contentDic = [[NSMutableDictionary alloc] init];
    [contentDic setObject:_tfPhoneNum.text forKey:@"user_login_name"];//手机号码
    [contentDic setObject:_tfPass1.text forKey:@"user_pass"];//新密码
    [contentDic setObject:_tfPass2.text forKey:@"repasswd"];//确认密码
    [contentDic setObject:_tfCheckCode.text forKey:@"code"];//验证码
    [contentDic setObject:@"5" forKey:@"user_type"];
    [contentDic setObject:@"1" forKey:@"devicetype"];
    [contentDic setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:contentDic forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            
            
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        int code = [[resultDic  objectForKey:@"Code"] intValue];
        if (code == 0000) {
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
    }];
}

//开始90S计时
- (void)startCount{
    wait90Sec--;
    if (wait90Sec < 0) {
        wait90Sec = 0;
    }
    NSString *titleStr = [NSString stringWithFormat:@"%ds后重新获取", wait90Sec];
    [_btnCheckCode setTitle:titleStr forState:UIControlStateNormal];
    
    if(wait90Sec <= 0){
        [_btnCheckCode setTitle:@"重新获取验证码" forState:UIControlStateNormal];
    }else{
        [self performSelector:@selector(startCount) withObject:nil afterDelay:1];
    }
}

@end
