//
//  qiangquanVC.m
//  GGSH
//
//  Created by STAR on 15/12/23.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "qiangquanVC.h"
#import "MJRefresh.h"
#import "UITableView+Wave.h"
#import "LoginVC.h"
#import "CoreBluetooth/CoreBluetooth.h"

@interface qiangquanVC ()<UITableViewDataSource,UITableViewDelegate,MJRefreshBaseViewDelegate,CBCentralManagerDelegate,loginDelegate>{
    
    NSMutableArray *_dataArray;
    
    __weak IBOutlet UITableView *_iTableView;
    
    NSString *uuidStr;
    NSString *majorStr;
    NSString *minorStr;
    
    CBCentralManager *cBManager;
    
    NSArray *couponArray;
    
    MJRefreshHeaderView *_header;
    
    //从抢券进入，最初显示的是一个简介页面，下拉后刷去优惠券
    BOOL isShowIntro;
    
    //没有优惠券提示，下拉该页面刷新数据
    BOOL isNoCouponData;

    
    NSString *shopid;
}

@end

@implementation qiangquanVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title = @"抢券";
    
    cBManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _iTableView;
    _header.delegate = self;
    
    if (self.is_notification) {
        //从通知过来
        [self performSelector:@selector(getListFromServer) withObject:nil afterDelay:0.1];
    }else{
        //正常进入

        isShowIntro = YES;
        [_iTableView reloadData];

    }
   
}

- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    NSString *message = @"";
    switch (central.state) {
            
        case CBCentralManagerStateUnknown:
            message = @"初始化中，请稍后……";
            break;
        case CBCentralManagerStateResetting:
            message = @"设备不支持状态，过会请重试……";
            break;
        case CBCentralManagerStateUnsupported:
            message = @"设备未授权状态，过会请重试……";
            break;
        case CBCentralManagerStateUnauthorized:
            message = @"设备未授权状态，过会请重试……";
            break;
        case CBCentralManagerStatePoweredOff:
            //关闭了蓝牙，清空beacon数据
            [MyAppDelegate cleanBeaconInfoArray];
            message = @"尚未打开蓝牙，请在设置中打开……";
            break;
        case CBCentralManagerStatePoweredOn:
            message = @"蓝牙已经成功开启，稍后……";
            break;
        default:
            break;
    }
    
}

- (void)showDefaultView{
    
    UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 142, 142)];
    [self.view addSubview:imageV];
    imageV.image = [UIImage imageNamed:@"qiangquan_logo.png"];
    imageV.center = CGPointMake(SCREEN_WIDTH/2, 150);
    
    UILabel *lbText1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 260, SCREEN_WIDTH, 20)];
    lbText1.textColor = [UIColor darkGrayColor];
    lbText1.textAlignment = NSTextAlignmentCenter;
    lbText1.text = @"如果身处逛逛平台实体店附近，";
    [self.view addSubview:lbText1];
    
    UILabel *lbText2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 280, SCREEN_WIDTH, 20)];
    lbText2.textColor = [UIColor darkGrayColor];
    lbText2.textAlignment = NSTextAlignmentCenter;
    lbText2.text = @"打开手机蓝牙，下拉刷新本页面，";
    [self.view addSubview:lbText2];
    
    UILabel *lbText3 = [[UILabel alloc] initWithFrame:CGRectMake(0, 300, SCREEN_WIDTH, 20)];
    lbText3.textColor = [UIColor darkGrayColor];
    lbText3.textAlignment = NSTextAlignmentCenter;
    lbText3.text = @"有机会参与抢券哦！！";
    [self.view addSubview:lbText3];
}

- (qiangquanVC*)initWithUUID : (NSString*)uuid Major : (NSString*) major minor : (NSString*)minor{
    uuidStr = [uuid copy];
    majorStr = [major copy];
    minorStr = [minor copy];
    self.is_notification = YES;
    return [super init];
}

//获取全局的uuid给当前vc
- (void)setUUidInfo{
    NSDictionary *dic = [MyAppDelegate getCurBeacon];
    if(dic){
        uuidStr = [[dic objectForKey:@"uuid"] copy];
        majorStr = [[dic objectForKey:@"major"] copy];
        minorStr = [[dic objectForKey:@"minor"] copy];
    }else {
        uuidStr = nil;
        majorStr = nil;
        minorStr = nil;
    }
}

#pragma mark - 网络请求 获取优惠券
- (void)getListFromServer{
    
    if(!uuidStr || !majorStr || !minorStr){
        //如果数据为空，提示优惠券飞走了
        isNoCouponData = YES;
        [_iTableView reloadData];
        return;
    }
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Beacon" forKey:@"Mod"];
    [dic setObject:@"activityShow" forKey:@"Act"];


    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    [dicContent setObject:uuidStr forKey:@"uuid"];
    [dicContent setObject:majorStr forKey:@"major"];
    [dicContent setObject:minorStr forKey:@"minor"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];

    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if(_dataArray){
            [_dataArray removeAllObjects];
        }
        
        if([resultDic objectForKey:@"DetailInfo"] && [[resultDic objectForKey:@"DetailInfo"] isKindOfClass:[NSDictionary class]]){
            _dataArray = [[[resultDic objectForKey:@"DetailInfo"] objectForKey:@"couponInfo"] mutableCopy];
            
            shopid = [[[[resultDic objectForKey:@"DetailInfo"] objectForKey:@"shopInfo"] objectForKey:@"id"] copy];
        }
        
        
        if(0 == _dataArray.count){
            isNoCouponData = YES;
            [_iTableView reloadData];
        }else{
            isNoCouponData = NO;
            [_iTableView reloadData];
            [_iTableView reloadDataAnimateWithWave:LeftToRightWaveAnimation];
        }
    }];
    
    
}

//领取优惠券
- (void)receiveCouponWithCouponId:(NSString *)couponid{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Coupon" forKey:@"Mod"];
    [dic setObject:@"receiveCoupon" forKey:@"Act"];
    
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
    }
    [dicContent setObject:couponid forKey:@"couponid"];
    [dicContent setObject:shopid forKey:@"shopid"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            //领取成功
            [self showAlert:nil withTitle:@"领取成功" haveCancelButton:NO];
            //刷新未读提示
            [MyAppDelegate getNoReadInfo];
            
            //修改本地数据库并刷新列表
            NSMutableArray *tempArr = [_dataArray mutableCopy];
            for (int i = 0; i < tempArr.count; i ++) {
                NSMutableDictionary *dic = [[_dataArray objectAtIndex:i] mutableCopy];
                if ([[dic objectForKey:@"id"] isEqualToString:couponid]) {
                    //修改成已领取
                    [dic setValue:@"1" forKey:@"cansave"];
                    [_dataArray replaceObjectAtIndex:i withObject:dic];
                }
            }
            
            [_iTableView reloadData];
        }else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
    }];
}

#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(refreshView == _header) {// 下拉刷新
        
        //下拉刷新，不再显示初始页面
        isShowIntro = NO;
        
        //下拉后删除旧数据
        [MyAppDelegate removeOldBeaconData];
        
        //触发搜索信号,通知的情况下不触发
        if (!self.is_notification) {
            
            isNoCouponData = YES;
            //重获beacon信息
            [self setUUidInfo];

        }

        [self getListFromServer];

        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
        
    }
}


- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
}

#pragma mark - UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //没有优惠券，要现实一个提示用户刷新
    if(isNoCouponData)
        return 1;
    
    return _dataArray.count + 1;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(isShowIntro){
        //展示下啦刷新的图片和文字提醒
        return 200;
    }else if(isNoCouponData){
        return 200;
    }
    return 56;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //提示刷新页面
    if(isShowIntro){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IntroTop"];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"IntroTop"];
        }
        
        UIImageView *imageV = (UIImageView *)[cell.contentView viewWithTag:201];
        if (!imageV) {
            imageV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 142, 142)];
        }
        imageV.tag = 201;
        [cell.contentView addSubview:imageV];
        imageV.image = [UIImage imageNamed:@"qiangquan_logo.png"];
        imageV.center = CGPointMake(SCREEN_WIDTH/2, 150);
        
        UILabel *lbText1 = (UILabel *)[cell.contentView viewWithTag:202];
        if (!lbText1) {
            lbText1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 260, SCREEN_WIDTH, 20)];
        }
        lbText1.tag = 202;
        lbText1.textColor = [UIColor darkGrayColor];
        lbText1.textAlignment = NSTextAlignmentCenter;
        lbText1.text = @"如果身处逛逛平台实体店附近，";
        [cell.contentView addSubview:lbText1];
        
        UILabel *lbText2 = (UILabel *)[cell.contentView viewWithTag:203];
        if (!lbText2) {
            lbText2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 280, SCREEN_WIDTH, 20)];
        }
        lbText2.tag = 203;
        lbText2.textColor = [UIColor darkGrayColor];
        lbText2.textAlignment = NSTextAlignmentCenter;
        lbText2.text = @"打开手机蓝牙，下拉刷新本页面，";
        [cell.contentView addSubview:lbText2];
        
        UILabel *lbText3 = (UILabel *)[cell.contentView viewWithTag:204];
        if (!lbText3) {
            lbText3 = [[UILabel alloc] initWithFrame:CGRectMake(0, 300, SCREEN_WIDTH, 20)];
        }
        lbText3.tag = 204;
        lbText3.textColor = [UIColor darkGrayColor];
        lbText3.textAlignment = NSTextAlignmentCenter;
        lbText3.text = @"有机会参与抢券哦！！";
        [cell.contentView addSubview:lbText3];
        
        return cell;
    }else if(isNoCouponData){
        //没有券
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IntroSetTop"];
        if (cell == nil){
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"IntroSetTop"];
        }
        
        UIImageView *imageV = (UIImageView *)[cell.contentView viewWithTag:301];
        if (!imageV) {
            imageV = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 97, 101)];
        }
        imageV.tag = 301;
        imageV.image = [UIImage imageNamed:@"qiangquan.png"];
        [cell.contentView addSubview:imageV];
        imageV.center = CGPointMake(SCREEN_WIDTH/2, 150);
        
        UILabel *lbText = (UILabel *)[cell.contentView viewWithTag:302];
        if (!lbText) {
            lbText = [[UILabel alloc] initWithFrame:CGRectMake(0, 230, SCREEN_WIDTH, 20)];
        }
        lbText.tag = 302;
        [cell.contentView addSubview:lbText];
        lbText.textAlignment = NSTextAlignmentCenter;
        lbText.text = @"手慢了，优惠券已飞走";
        return cell;
    }else{
        //翻页CELL
        static NSString *CellIdentifier = @"CONPCELL";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.clipsToBounds = YES;
            
            //背景
            UIImageView *cellBg = [[UIImageView alloc]initWithFrame:CGRectMake(12, 10, SCREEN_WIDTH-24, 46)];
            cellBg.image = [UIImage imageNamed:@"red_bg.png"];
            cellBg.tag = 105;
            [cell.contentView addSubview:cellBg];
            
            //类别图 优惠券、折扣券等
            UIImageView *headImage = [[UIImageView alloc] initWithFrame:CGRectMake(15, 15, 34, 34)];
            headImage.tag = 101;
            [cell.contentView addSubview:headImage];
            
            //尾部的详情背景图
            UIImageView *titView = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 93, 10, 84, 46)];
            titView.tag = 1002;
            [cell.contentView addSubview:titView];
            
            //优惠券名称
            UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 15, SCREEN_WIDTH - 100 - 50, 20)];
            titleLabel.tag = 102;
            titleLabel.text = @"哈根达斯优惠券";
            titleLabel.numberOfLines = 0;
            titleLabel.textAlignment = NSTextAlignmentLeft;
            titleLabel.textColor = [UIColor darkGrayColor];
            titleLabel.font = [UIFont systemFontOfSize:12];
            [cell.contentView addSubview:titleLabel];
            
            //详情
            UILabel *detailLabel = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 90, 15, 75, 20)];
            detailLabel.tag = 103;
            detailLabel.textAlignment = 2;
            detailLabel.font = [UIFont systemFontOfSize:18];
            detailLabel.textColor = [UIColor whiteColor];
            [cell.contentView addSubview:detailLabel];
            
            UILabel *detailLabel1 = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 90, 40, 80, 16)];
            detailLabel1.tag = 106;
            detailLabel1.textAlignment = 1;
            detailLabel1.font = [UIFont systemFontOfSize:12];
            detailLabel1.textColor = [UIColor whiteColor];
            [cell.contentView addSubview:detailLabel1];
            
            //时间
            UILabel *timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 38, SCREEN_WIDTH-145, 20)];
            timeLabel.tag = 104;
            timeLabel.text = @"有效期：2015.01.15-2015.02.10";
            timeLabel.textAlignment = 0;
            timeLabel.textColor = [UIColor lightGrayColor];
            timeLabel.font = [UIFont systemFontOfSize:11];
            [cell.contentView addSubview:timeLabel];
            
            
            
            //最后一个提示语句
            UILabel *alertLabel = [[UILabel alloc]initWithFrame:CGRectMake(12, 10, SCREEN_WIDTH-24, 46)];
            alertLabel.tag = 107;
            alertLabel.textAlignment = 0;
            alertLabel.font = [UIFont systemFontOfSize:11];
            alertLabel.textColor = [UIColor colorWithHexString:@"#636363"];
            [cell.contentView addSubview:alertLabel];
            NSMutableAttributedString *tempArrStr = [[NSMutableAttributedString alloc]initWithString:@"温馨提示：抢到的优惠券在店铺优惠券中收藏"];
            [tempArrStr addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#fe5252"] range:NSMakeRange(tempArrStr.length - 8,5)];
            [alertLabel setAttributedText:tempArrStr];
            alertLabel.hidden = YES;
            
        }
        
        UIImageView *headImage = (UIImageView *)[cell.contentView viewWithTag:101];
        UILabel *titleLabel = (UILabel *)[cell.contentView viewWithTag:102];
        UILabel *detailLabel = (UILabel *)[cell.contentView viewWithTag:103];
        UILabel *timeLabel = (UILabel *)[cell.contentView viewWithTag:104];
        UIImageView *titImageV = (UIImageView *)[cell.contentView viewWithTag:1002];
        UIImageView *cellBg = (UIImageView *)[cell.contentView viewWithTag:105];
        UILabel *detailLabel1 = (UILabel *)[cell.contentView viewWithTag:106];
        UILabel *alertLabel = (UILabel *)[cell.contentView viewWithTag:107];
        
        NSDictionary *dic;
        if (_dataArray.count != indexPath.row) {
            dic = [_dataArray objectAtIndex:indexPath.row];
        }else{
            dic = nil;
        }
        
        if (dic) {
            [headImage setHidden:NO];
            [titleLabel setHidden:NO];
            [detailLabel setHidden:NO];
            [timeLabel setHidden:NO];
            [titImageV setHidden:NO];
            [cellBg setHidden:NO];
            [detailLabel1 setHidden:NO];
            [alertLabel setHidden:YES];
            
            if ([[dic objectForKey:@"coupontype"] isEqualToString:@"2"]) {
                //红包
                NSString *detailStr = [NSString stringWithFormat:@"￥%.1f",[[dic objectForKey:@"money"] doubleValue]/100];
                if(detailStr.length > 2){
                    //功能：去掉四舍五入
                    detailStr = [detailStr substringToIndex:(detailStr.length - 2)];
                }
                //背景
                titImageV.image = [UIImage imageNamed:@"red_001.png"];
                headImage.image = [UIImage imageNamed:@"red_02.png"];
                
                //优惠额度
                detailLabel.text = detailStr;
                
            }else if ([[dic objectForKey:@"coupontype"] isEqualToString:@"1"]){
                //折扣
                NSString *detailStr = [NSString stringWithFormat:@"%.1f折",[[dic objectForKey:@"discount"] doubleValue]*10];
                
                titImageV.image = [UIImage imageNamed:@"red_003.png"];
                headImage.image = [UIImage imageNamed:@"red_01.png"];
                //优惠额度
                detailLabel.text = detailStr;
            }
            
            //优惠券名称
            titleLabel.frame = CGRectMake(50, 15, SCREEN_WIDTH - 100 - 50, 20);
            titleLabel.text = [NSString stringWithFormat:@"%@",[dic objectForKey:@"couponname"]];
            [titleLabel sizeToFit];
            if(titleLabel.frame.size.height > 40){
                //最多显示2行
                titleLabel.frame = CGRectMake(50, 15, SCREEN_WIDTH - 100 - 50, 30);
            }
            
            NSString *startTime = [[[xkBase alloc]init] XKstampToDate:[dic objectForKey:@"starttime"] format:@"yy/MM/dd"];
            NSString *endtime = [[[xkBase alloc]init] XKstampToDate:[dic objectForKey:@"endtime"] format:@"yy/MM/dd"];
            timeLabel.text = [NSString stringWithFormat:@"有效期:%@-%@",startTime,endtime];
            
            
            //是否领取
            if ([[dic objectForKey:@"cansave"] integerValue] == 1) {
                [detailLabel1 setText:@"已领取"];
            }else{
                [detailLabel1 setText:@"立即领取"];
            }
            
        }else{
            [headImage setHidden:YES];
            [titleLabel setHidden:YES];
            [detailLabel setHidden:YES];
            [timeLabel setHidden:YES];
            [titImageV setHidden:YES];
            [cellBg setHidden:YES];
            [detailLabel1 setHidden:YES];
            if (_dataArray.count > 0) {
                [alertLabel setHidden:NO];
            }else{
                [alertLabel setHidden:YES];
            }
            
        }
        
        return cell;
    }
    
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == _dataArray.count) {
        return;
    }
    
    if (!MyAppDelegate.userInfo) {
        LoginVC *loginV = [[LoginVC alloc]init];
        loginV.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
        [self presentViewController:navi6 animated:YES completion:nil];
        return;
    }
    
    NSMutableDictionary *dic = [[_dataArray objectAtIndex:indexPath.row] mutableCopy];
    if([@"1" isEqualToString:[dic objectForKey:@"cansave"]]){
        return;
    }

    NSString *couponid = [[_dataArray objectAtIndex:indexPath.row] objectForKey:@"id"];
    
    //领取优惠券
    [self receiveCouponWithCouponId:couponid];
   
}

@end
