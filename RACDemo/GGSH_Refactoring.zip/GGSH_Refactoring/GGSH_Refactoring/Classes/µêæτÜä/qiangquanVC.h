//
//  qiangquanVC.h
//  GGSH
//
//  Created by STAR on 15/12/23.
//  Copyright © 2015年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface qiangquanVC : BaseViewController

@property (nonatomic,assign) BOOL is_notification;

- (qiangquanVC*)initWithUUID : (NSString*)uuid Major : (NSString*) major minor : (NSString*)minor;
@end
