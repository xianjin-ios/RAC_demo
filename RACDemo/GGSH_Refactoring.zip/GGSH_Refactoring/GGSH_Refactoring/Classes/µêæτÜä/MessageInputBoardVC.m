//
//  MessageInputBoardVC.m
//  naren
//  message 模块的输入框调用
//  Created by 任春宁 on 13-12-2.
//  Copyright (c) 2013年 Saluton. All rights reserved.
//

#import "MessageInputBoardVC.h"

typedef enum keyboardType {
    DEFAULT,
    EMOJI,    //emoji
    KEYBOARD,    //输入
    ADD,     //功能
}keyboardType;

@interface MessageInputBoardVC ()
{
    IBOutlet UIButton *clickChange;
    IBOutlet UIButton *clickSend;
    
    IBOutlet UIView *addView;
    IBOutlet UIView *emojiView;
    
    IBOutlet UIScrollView *emojiScrollView;
    NSArray *emojiArr;
    
    BOOL isAdjustingKeyboard;
    
}
@property (nonatomic) keyboardType keyboardtype;

@end

@implementation MessageInputBoardVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        _originYoffset = SCREEN_STATUS_HEIGHT + SCREEN_NAVBAR_HEIGHT;
        _keyboardtype = DEFAULT;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleKeyboardWillChange:) name:UIKeyboardWillChangeFrameNotification object:nil];

    _yBoard = 0;
    _rcKeyboard = CGRectMake(0, 0, 0, 0);
    
//    UIImageView * imgView = (UIImageView*)[self.view viewWithTag:12];
//    imgView.layer.borderWidth = 1;
//    imgView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    UITextView * textView = (UITextView*)[self.view viewWithTag:11];
    [textView setContentSize:CGSizeMake(textView.frame.size.width, textView.frame.size.height)];
    textView.autocorrectionType = UITextAutocorrectionTypeNo;
    textView.autocapitalizationType = UITextAutocapitalizationTypeNone;

    [self setEmojiView];
    
}

-(void)viewDidUnload{
    [[NSNotificationCenter defaultCenter] removeObserver:UIKeyboardWillChangeFrameNotification];
    [super viewDidUnload];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma UITextViewDelegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    [self hide];
    _keyboardtype = KEYBOARD;
    [clickChange setImage:[UIImage imageNamed:@"face_face.png"] forState:UIControlStateNormal];
    if (_tvInput.text.length > 0) {
        [clickSend setImage:[UIImage imageNamed:@"face_send1.png"] forState:UIControlStateNormal];
    }else{
        [clickSend setImage:[UIImage imageNamed:@"face_add.png"] forState:UIControlStateNormal];
    }
    
    if (_yBoard > 0) {
        
        CGRect selfFrame = self.view.frame;
        selfFrame.origin.y = SCREEN_HEIGHT - 50 - self.originYoffset;
        _yBoard = 0;
        [self.delegate moveView:self.view toRect:selfFrame duration:0.25 hide:YES];
        
    }
    
    CGRect r = self.view.frame;
    r.origin.y -= 216;
    _yBoard = 216;
    [self.delegate moveView:self.view toRect:r duration:0.25 hide:NO];
    
    BOOL isBeginEdit = YES;
    
	return isBeginEdit;
    
}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView
{
    return YES;
}

-(void)textViewDidChange:(UITextView *)textView{
    
    bool isChinese;//判断当前输入法是否是中文
    //if ([[[UITextInputMode currentInputMode] primaryLanguage] isEqualToString: @"en-US"]) {//iOS7.0之前使用
    
    ////iOS7.0之后使用
    if ([[[UIApplication sharedApplication]textInputMode].primaryLanguage isEqualToString: @"en-US"]) {
        isChinese = false;
    }else{
        isChinese = true;
    }
    
    //要求输入最多400位字符
    NSString *str = [[textView text] stringByReplacingOccurrencesOfString:@"?" withString:@""];
    if (isChinese) { //中文输入法下
        UITextRange *selectedRange = [textView markedTextRange];
        //获取高亮部分
        UITextPosition *position = [textView positionFromPosition:selectedRange.start offset:0];
        // 没有高亮选择的字，则对已输入的文字进行字数统计和限制
        if (!position) {
            NSLog(@"输入的是汉字");
            if ( str.length>=401) {
                NSString *strNew = [NSString stringWithString:str];
                [textView setText:[strNew substringToIndex:400]];
            }
        }else{
            NSLog(@"输入的英文还没有转化为汉字的状态");
        }
    }else{
        NSLog(@"str=%@; 本次长度=%lu",str,(unsigned long)[str length]);
        if ([str length]>=401) {
            NSString *strNew = [NSString stringWithString:str];
            [textView setText:[strNew substringToIndex:400]];
        }
    }
    
    [self adjustTextView:textView WithText:nil];
    
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)string{
    
    NSString *text = string;
    
    //点击键盘发送按钮,同步用户编辑信息到服务器
    if ([text isEqualToString:@"\n"])
    {
        @try {
            [self.delegate sendMessage:textView.text];
        }
        @catch (NSException *exception) {
            
        }
        return NO;
    }
    
    [self adjustTextView:textView WithText:text];
    
    return YES;
}

- (void)adjustTextView:(UITextView *)textView WithText:(NSString *)text{
    
    if (textView.text.length > 0) {
        [clickSend setImage:[UIImage imageNamed:@"face_send1.png"] forState:UIControlStateNormal];
    }else{
        [clickSend setImage:[UIImage imageNamed:@"face_add.png"] forState:UIControlStateNormal];
    }
    
    //rencn调整控件高度
    //获取当前的高度
    CGRect frame = textView.frame;
    if (textView.contentSize.height < 95 || [text isEqualToString:@""]) {
        //获取未来的高度
        NSInteger newSizeH; //UITextView的实际高度
        NSInteger altitudeH = 28;//高度差
        if ([[UIDevice currentDevice].systemVersion floatValue] >= 7.0) {//7.0以上我们需要自己计算高度
            float fPadding = 16.0; // 8.0px x 2
            
            CGSize size = [NSString getHeight:textView.text withFont:textView.font andWidth:textView.contentSize.width - fPadding];
            newSizeH = size.height + 16.0 - 4;
        }
        else {
            newSizeH = textView.contentSize.height - 4;
        }
        
        altitudeH -= newSizeH;
        
        CGSize desSz = CGSizeMake(textView.contentSize.width, newSizeH);
        
        UIImageView * imgView = (UIImageView*)[self.view viewWithTag:12];
        UIEdgeInsets insets = UIEdgeInsetsMake(15, 15, 15, 15);
        imgView.image = [imgView.image resizableImageWithCapInsets:insets resizingMode:UIImageResizingModeStretch];
        CGRect rcImagView = imgView.frame;
        
        UIView * vBtnBg = [self.view viewWithTag:33];
        CGRect rcBtnBg = vBtnBg.frame;
        
        //调整UITextView
        frame.size.height = desSz.height;
        textView.frame = frame;
        
        rcImagView.size.height = frame.size.height + 8;
        //设置按钮列表的位置
        rcBtnBg.origin.y = rcImagView.size.height + 8 + 2;
        
        //计算整个托盘需要移动的位置
        CGRect rcBoard = self.view.frame;
        rcBoard.origin.y = _rcKeyboard.origin.y - self.originYoffset - rcImagView.size.height - 8;
        
        if ([self.delegate respondsToSelector:@selector(moveView:toRect:duration:hide:)]) {
            [self.delegate moveView:self.view toRect:rcBoard duration:0.25 hide:NO];
        }
        
        //调整输入框背景图片高度
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.25];
        
        imgView.frame = rcImagView;
        
        //设置按钮列表的位置
        vBtnBg.frame = rcBtnBg;
        if (_keyboardtype == EMOJI) {
            [emojiView setFrame:CGRectMake(0, 50 - altitudeH, SCREEN_WIDTH, 150)];
        }

        [UIView commitAnimations];
        
        
    }
    
}

#pragma mark - emoji
- (NSString *)emojiStrTrans:(int)i{
    int sym = EMOJI_CODE_TO_SYMBOL(i);
    NSString *emoT = [[NSString alloc] initWithBytes:&sym length:sizeof(sym) encoding:NSUTF8StringEncoding];
    return emoT;
}

- (NSArray *)defaultEmoticons {
    NSMutableArray *tempArray = [NSMutableArray new];
    
    [tempArray addObject:[self emojiStrTrans:0x1f60a]];
    [tempArray addObject:[self emojiStrTrans:0x1f60c]];
    [tempArray addObject:[self emojiStrTrans:0x1f60f]];
    [tempArray addObject:[self emojiStrTrans:0x1f601]];
    [tempArray addObject:[self emojiStrTrans:0x1f604]];
    [tempArray addObject:[self emojiStrTrans:0x1f609]];
    [tempArray addObject:[self emojiStrTrans:0x1f612]];
    [tempArray addObject:[self emojiStrTrans:0x1f614]];
    [tempArray addObject:[self emojiStrTrans:0x1f616]];
    [tempArray addObject:[self emojiStrTrans:0x1f618]];
    [tempArray addObject:[self emojiStrTrans:0x1f621]];
    [tempArray addObject:[self emojiStrTrans:0x1f628]];
    [tempArray addObject:[self emojiStrTrans:0x1f630]];
    [tempArray addObject:[self emojiStrTrans:0x1f631]];
    [tempArray addObject:[self emojiStrTrans:0x1f633]];
    [tempArray addObject:[self emojiStrTrans:0x1f637]];
    [tempArray addObject:[self emojiStrTrans:0x1f603]];
    [tempArray addObject:[self emojiStrTrans:0x1f61e]];
    [tempArray addObject:[self emojiStrTrans:0x1f620]];
    [tempArray addObject:[self emojiStrTrans:0x1f61c]];
    [tempArray addObject:[self emojiStrTrans:0x1f60d]];
    [tempArray addObject:[self emojiStrTrans:0x1f613]];
    [tempArray addObject:[self emojiStrTrans:0x1f61d]];
    [tempArray addObject:[self emojiStrTrans:0x1f62d]];
    [tempArray addObject:[self emojiStrTrans:0x1f602]];
    [tempArray addObject:[self emojiStrTrans:0x1f622]];
    [tempArray addObject:[self emojiStrTrans:0x1f61a]];
    [tempArray addObject:[self emojiStrTrans:0x1f623]];
    [tempArray addObject:[self emojiStrTrans:0x1f632]];
    [tempArray addObject:[self emojiStrTrans:0x1f62a]];
    [tempArray addObject:[self emojiStrTrans:0x1f64f]];
    [tempArray addObject:[self emojiStrTrans:0x1f6ac]];
    [tempArray addObject:[self emojiStrTrans:0x1f691]];
    [tempArray addObject:[self emojiStrTrans:0x1f692]];
    [tempArray addObject:[self emojiStrTrans:0x1f693]];
    [tempArray addObject:[self emojiStrTrans:0x1f6b9]];
    [tempArray addObject:[self emojiStrTrans:0x1f6ba]];
    [tempArray addObject:[self emojiStrTrans:0x1f6bd]];
    [tempArray addObject:[self emojiStrTrans:0x1f6c0]];
    [tempArray addObject:[self emojiStrTrans:0x1f683]];
    [tempArray addObject:[self emojiStrTrans:0x1f684]];
    [tempArray addObject:[self emojiStrTrans:0x1f697]];
    [tempArray addObject:[self emojiStrTrans:0x1f6a4]];
    [tempArray addObject:[self emojiStrTrans:0x1f6b2]];
    [tempArray addObject:[self emojiStrTrans:0x1f6a7]];
    [tempArray addObject:[self emojiStrTrans:0x1f6a5]];
    [tempArray addObject:[self emojiStrTrans:0x1f680]];
    [tempArray addObject:[self emojiStrTrans:0x1f47f]];
    [tempArray addObject:[self emojiStrTrans:0x1f4aa]];
    [tempArray addObject:[self emojiStrTrans:0x1f44a]];
    [tempArray addObject:[self emojiStrTrans:0x1f44d]];
    [tempArray addObject:[self emojiStrTrans:0x1f44e]];
    [tempArray addObject:[self emojiStrTrans:0x1f44f]];
    [tempArray addObject:[self emojiStrTrans:0x1f446]];
    [tempArray addObject:[self emojiStrTrans:0x1f447]];
    [tempArray addObject:[self emojiStrTrans:0x1f448]];
    [tempArray addObject:[self emojiStrTrans:0x1f449]];
    [tempArray addObject:[self emojiStrTrans:0x1f44c]];
    [tempArray addObject:[self emojiStrTrans:0x1f40d]];
    [tempArray addObject:[self emojiStrTrans:0x1f42c]];
    [tempArray addObject:[self emojiStrTrans:0x1f42d]];
    [tempArray addObject:[self emojiStrTrans:0x1f427]];
    [tempArray addObject:[self emojiStrTrans:0x1f433]];
    [tempArray addObject:[self emojiStrTrans:0x1f457]];
    [tempArray addObject:[self emojiStrTrans:0x1f452]];
    [tempArray addObject:[self emojiStrTrans:0x1f455]];
    [tempArray addObject:[self emojiStrTrans:0x1f459]];
    
//    for (int i=0x1F600; i<=0x1F64F; i++) {
//        if (i < 0x1F641 || i > 0x1F644) {
//            int sym = EMOJI_CODE_TO_SYMBOL(i);
//            NSString *emoT = [[NSString alloc] initWithBytes:&sym length:sizeof(sym) encoding:NSUTF8StringEncoding];
//            [tempArray addObject:emoT];
//        }
//    }
    
    
    NSMutableArray *array = [NSMutableArray new];
    for (int i = 0; i < tempArray.count; i ++) {
        [array addObject:[tempArray objectAtIndex:i]];

        if (i > 1 && i%21 == 0) {
            [array insertObject:@"x" atIndex:i-1];
        }
        if (i == tempArray.count - 1) {
            [array addObject:@"x"];
        }
    }
    return array;
}

- (BOOL)stringContainsEmoji:(NSString *)string
{
    __block BOOL returnValue = NO;
    
    [string enumerateSubstringsInRange:NSMakeRange(0, [string length])
                               options:NSStringEnumerationByComposedCharacterSequences
                            usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop) {
                                const unichar hs = [substring characterAtIndex:0];
                                if (0xd800 <= hs && hs <= 0xdbff) {
                                    if (substring.length > 1) {
                                        const unichar ls = [substring characterAtIndex:1];
                                        const int uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;
                                        if (0x1d000 <= uc && uc <= 0x1f77f) {
                                            returnValue = YES;
                                        }
                                    }
                                } else if (substring.length > 1) {
                                    const unichar ls = [substring characterAtIndex:1];
                                    if (ls == 0x20e3) {
                                        returnValue = YES;
                                    }
                                } else {
                                    if (0x2100 <= hs && hs <= 0x27ff) {
                                        returnValue = YES;
                                    } else if (0x2B05 <= hs && hs <= 0x2b07) {
                                        returnValue = YES;
                                    } else if (0x2934 <= hs && hs <= 0x2935) {
                                        returnValue = YES;
                                    } else if (0x3297 <= hs && hs <= 0x3299) {
                                        returnValue = YES;
                                    } else if (hs == 0xa9 || hs == 0xae || hs == 0x303d || hs == 0x3030 || hs == 0x2b55 || hs == 0x2b1c || hs == 0x2b1b || hs == 0x2b50) {
                                        returnValue = YES;
                                    }
                                }
                            }];
    
    return returnValue;
}

- (void)setEmojiView{
    emojiArr = [self defaultEmoticons];
    [emojiScrollView setContentSize:CGSizeMake(SCREEN_WIDTH * 4, 150)];
    //将表情放到UIButton里
    int W = 40;
    int H = 40;
    int X;
    int Y;
    @try{
        
        for (int i = 0; i <emojiArr.count ; i ++) {
            
            //横排
            X = 5 + ((i-(i/21)*21)%7) * (W+5) + 320 * (i/21);
            Y = 10 + ((i-(i/21)*21)/7) * (H+5);
            
            //竖排
//            X = 5 + ((i-(i/21)*21)/3) * (W+5) + 320 * (i/21);
//            Y = 10 + (i%3) * (H+5);
            
            UIButton *biaoqing =[[UIButton alloc] init];
            biaoqing.backgroundColor = [UIColor clearColor];
            biaoqing.frame = CGRectMake(X, Y, W, H);
            [emojiScrollView addSubview:biaoqing];
            NSString *Str = emojiArr[i];
            [biaoqing setTitle:Str forState:UIControlStateNormal];
            if (emojiArr.count%21 != 0 && i == emojiArr.count - 1) {
                //最后一页的删除按钮
                biaoqing.frame = CGRectMake(277 + 320 * (i/21), 105, W, H);
                [biaoqing setImage:[UIImage imageNamed:@"face_delete"] forState:UIControlStateNormal];
            }
            if (i > 1 && (i+1)%21 == 0) {
                //其他页面的删除按钮
                [biaoqing setImage:[UIImage imageNamed:@"face_delete"] forState:UIControlStateNormal];
            }
            [biaoqing addTarget:self action:@selector(biaoqingClick:) forControlEvents:UIControlEventTouchUpInside];
            
        }
    }
    @catch(NSException *exception) {
        NSLog(@"exception:%@", exception);
    }
    
    
}
- (void) biaoqingClick:(UIButton *)biaoqing{
    NSString *emojiStr = biaoqing.titleLabel.text;
    NSLog(@"%@",emojiStr);
    UITextView * tx = (UITextView*)[self.view viewWithTag:11];

    if ([emojiStr isEqualToString:@"x"]) {
        emojiStr = @"";

    }
    
    @try{
        
        NSInteger location  = tx.selectedRange.location;
        NSString * textStr = tx.text;
        NSString *resultStr = [NSString stringWithFormat:@"%@%@%@",[textStr substringToIndex:location],emojiStr,[textStr substringFromIndex:location]];
        //手动设置删除功能
        if ([emojiStr isEqualToString:@""]) {
            
            if (resultStr.length > 1) {
                //字符串大于1位，取字符串最后两位判断是否是表情代码，若是则删除两位，否则删除一位
                NSString *tempStr = [resultStr substringWithRange:NSMakeRange(resultStr.length - 2, 2)];
                if ([self stringContainsEmoji:tempStr]) {
                    resultStr = [resultStr substringToIndex:resultStr.length - 2];
                }else{
                    resultStr = [resultStr substringToIndex:resultStr.length - 1];
                }
            }else{
                //字符串剩一位一定不是表情则删除一位
                resultStr = [resultStr substringToIndex:resultStr.length - 1];

            }
            
        }
        tx.text = resultStr;
        
        //调整输入框
        [self adjustTextView:tx WithText:@""];
        
    }
    @catch(NSException *exception) {
        NSLog(@"exception:%@", exception);
    }
    

}

#pragma mark -
#pragma mark Responding to keyboard events

- (void)keyboardDidShow:(NSNotification *)notification
{

}

/*
 //键盘有三个状态
 1 不显示
 2 英文
 3 中文
 //*/
- (void)handleKeyboardWillChange:(NSNotification *)notification
{
    NSDictionary* userInfo = [notification userInfo];
    
    CGRect beginRect = [[userInfo objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    CGRect endRect = [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    //缓存键盘状态
    _rcKeyboard = endRect;
    
    //隐藏
    if (beginRect.origin.y > 0 && endRect.origin.y == SCREEN_HEIGHT) {
        return;
    }
    
    UIImageView * imgView = (UIImageView*)[self.view viewWithTag:12];
    CGRect rcImageView = imgView.frame;
    
    UITextView * tView = (UITextView *)[self.view viewWithTag:11];
    CGRect rcTView = tView.frame;
    
    rcImageView.size.height = rcTView.size.height + 8;
    
    CGRect selfFrame = self.view.frame;
    selfFrame.origin.y = endRect.origin.y - rcImageView.size.height - 8 - self.originYoffset;
    
    _yBoard = endRect.origin.y - rcImageView.size.height - 8 - self.originYoffset;
    
    if ([self.delegate respondsToSelector:@selector(moveView:toRect:duration:hide:)]) {
        [self.delegate moveView:self.view toRect:selfFrame duration:0.25 hide:NO];
    }

}

//显示其他功能
- (void)showAddPic{
    _keyboardtype = ADD;
    [clickChange setImage:[UIImage imageNamed:@"face_face.png"] forState:UIControlStateNormal];
    [clickSend setImage:[UIImage imageNamed:@"face_x.png"] forState:UIControlStateNormal];

    [self hideKeyboard];
    
    //需要判断，如果已经上移
    if (_yBoard > 0) {
        CGRect selfFrame = self.view.frame;
        selfFrame.origin.y = SCREEN_HEIGHT - 50 - self.originYoffset;
        _yBoard = 0;
        
        [self.delegate moveView:self.view toRect:selfFrame duration:0.25 hide:YES];

    }
    
    CGRect r = self.view.frame;
    r.origin.y -= 140;
    _yBoard = 140;
    [self.delegate moveView:self.view toRect:r duration:0.25 hide:NO];

    [addView setHidden:NO];
}

//隐藏输入设置
-(void)hide{
    
    _keyboardtype = DEFAULT;
    
    [clickChange setImage:[UIImage imageNamed:@"face_face.png"] forState:UIControlStateNormal];
    [clickSend setImage:[UIImage imageNamed:@"face_add.png"] forState:UIControlStateNormal];

    [addView setHidden:YES];
    [self hideKeyboard];
    [self hideEmojiKeyboard];
    
    @try {
        
        CGRect selfFrame = self.view.frame;
        selfFrame.origin.y = SCREEN_HEIGHT - 50 - self.originYoffset;
        _yBoard = 0;
        
        [self.delegate moveView:self.view toRect:selfFrame duration:0.25 hide:YES];
    }
    @catch (NSException *exception) {
        
    }

    
}

//点击功能按钮
-(IBAction)clickMediaButton:(id)sender{
    UIButton * btn = (UIButton*)sender;
    @try {
        [self.delegate clickOnButton:(int)btn.tag - 20];
    }
    @catch (NSException *exception) {
        
    }
 
}

-(void)clearText{
    
    UIImageView * imgView = (UIImageView*)[self.view viewWithTag:12];
    
    UITextView * tx = (UITextView*)[self.view viewWithTag:11];
    
    if ([tx.text length] ==  0) {
        return;
    }
    tx.text = @"";
    
    CGRect rcImageView = imgView.frame;
    rcImageView.size.height = 36;
    
    CGRect rcTextView = tx.frame;
    rcTextView.size.height = 28;
    
    UIView * vBtnBg = [self.view viewWithTag:33];
    CGRect rcBtnBg = vBtnBg.frame;
    rcBtnBg.origin.y = rcImageView.size.height + 8 + 2;
    
    
    //计算整个托盘需要移动的位置
    CGRect rcBoard = self.view.frame;
    rcBoard.origin.y = _rcKeyboard.origin.y - self.originYoffset - rcImageView.size.height - 8;
    @try {
        [self.delegate moveView:self.view toRect:rcBoard duration:0.25 hide:NO];
    }
    @catch (NSException *exception) {
        
    }
    
    
    //调整输入框背景图片高度
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.25];
    
    imgView.frame = rcImageView;
    
    //设置按钮列表的位置
    vBtnBg.frame = rcBtnBg;
    tx.frame = rcTextView;
    
    [UIView commitAnimations];
    
    
}

//显示键盘
- (void)showKeyboard{
    _keyboardtype = KEYBOARD;
    [clickChange setImage:[UIImage imageNamed:@"face_face.png"] forState:UIControlStateNormal];
    if (_tvInput.text.length > 0) {
        [clickSend setImage:[UIImage imageNamed:@"face_send1.png"] forState:UIControlStateNormal];
    }else{
        [clickSend setImage:[UIImage imageNamed:@"face_add.png"] forState:UIControlStateNormal];
    }
    
    UITextView * tx = (UITextView*)[self.view viewWithTag:11];
    if (_yBoard > 0) {
        
        CGRect selfFrame = self.view.frame;
        selfFrame.origin.y = SCREEN_HEIGHT - 50 - self.originYoffset;
        _yBoard = 0;
        [self.delegate moveView:self.view toRect:selfFrame duration:0.25 hide:YES];

    }
    
    CGRect r = self.view.frame;
    r.origin.y -= 216;
    _yBoard = 216;
    [self.delegate moveView:self.view toRect:r duration:0.25 hide:NO];

    [tx becomeFirstResponder];
    
}

- (void)hideKeyboard{
    [addView setHidden:YES];

    UITextView * tx = (UITextView*)[self.view viewWithTag:11];
    if ([tx isFirstResponder]) {
        [tx resignFirstResponder];
        
    }
}

//显示emoji表情输入
- (void)showEmojiKeyboard{
    _keyboardtype = EMOJI;
    [clickChange setImage:[UIImage imageNamed:@"face_keyboard.png"] forState:UIControlStateNormal];
    if (_tvInput.text.length > 0) {
        [clickSend setImage:[UIImage imageNamed:@"face_send1.png"] forState:UIControlStateNormal];
    }else{
        [clickSend setImage:[UIImage imageNamed:@"face_add.png"] forState:UIControlStateNormal];
    }
    
    //需要判断，如果已经上移
    if (_yBoard > 0) {
        
        CGRect selfFrame = self.view.frame;
        selfFrame.origin.y = SCREEN_HEIGHT - 50 - self.originYoffset;
        _yBoard = 0;
        [self.delegate moveView:self.view toRect:selfFrame duration:0.25 hide:YES];
        
        [self hideKeyboard];
        
    }
   
    CGRect r = self.view.frame;
    r.origin.y -= 150;
    _yBoard = 150;
    [self.delegate moveView:self.view toRect:r duration:0.25 hide:NO];

    //
    ZLog(@"showEmoji");
    @try{
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.25];
        [emojiView setFrame:CGRectMake(0, 50, SCREEN_WIDTH, 150)];
        [UIView commitAnimations];
        
        //
        CGRect endRect = CGRectMake(0, SCREEN_HEIGHT - 150, SCREEN_WIDTH, 150);
        _rcKeyboard = endRect;

    }
    @catch(NSException *exception) {
        NSLog(@"exception:%@", exception);
    }
    
    
}
//隐藏emoji表情键盘
- (void)hideEmojiKeyboard{
    [clickChange setImage:[UIImage imageNamed:@"face_face.png"] forState:UIControlStateNormal];
    [addView setHidden:YES];

    //
    ZLog(@"hideEmoji");
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.25];
    [emojiView setFrame:CGRectMake(0, 50+150, SCREEN_WIDTH, 150)];
    [UIView commitAnimations];

}

-(void)selectEmoji:(NSString *)emojiStr{
    
    ZLog(@"%@",emojiStr);
    
}

- (IBAction)clickChange:(id)sender {
    
    switch (_keyboardtype) {
        case DEFAULT:
        {
            
            [self showEmojiKeyboard];
            
        }
            break;
        case EMOJI:
        {
            [self hideEmojiKeyboard];
            [self showKeyboard];
            
        }
            break;
        case KEYBOARD:
        {
            [self hideKeyboard];
            [self showEmojiKeyboard];
        }
            break;
        case ADD:
        {
            [self hide];
            [self showEmojiKeyboard];
        }
            break;
            
        default:
            break;
    }

}

-(IBAction)clickSend:(id)sender{
    
    if (_tvInput.text.length > 0) {
        if ([self.delegate respondsToSelector:@selector(sendMessage:) ]) {
            [self.delegate sendMessage:_tvInput.text];
        }
    }else{
        switch (_keyboardtype) {
            case DEFAULT:
            {
                
                [self showAddPic];

            }
                break;
            case EMOJI:
            {
                [self hideEmojiKeyboard];
                [self showAddPic];
            }
                break;
            case KEYBOARD:
            {
                [self showAddPic];
            }
                break;
            case ADD:
            {
                [self hide];
            }
                break;
                
            default:
                break;
        }
        
    }
    
}
@end
