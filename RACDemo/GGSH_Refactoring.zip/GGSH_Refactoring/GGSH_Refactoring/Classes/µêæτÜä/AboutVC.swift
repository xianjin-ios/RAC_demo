//
//  AboutVC.swift
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/13.
//  Copyright © 2016年 huadong. All rights reserved.
//

import UIKit

class AboutVC: BaseViewController {
    
    @IBOutlet weak var _tfVersion: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "关于我们";

        let infoDictionary = Bundle.main.infoDictionary
        let shortVersion: String? = infoDictionary! ["CFBundleShortVersionString"] as? String
        let buildVersion: String? = infoDictionary! ["CFBundleVersion"] as? String
        _tfVersion.text = "版本：" + shortVersion! + "." + buildVersion!
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        (UIApplication.shared.delegate as! AppDelegate).makeTabBarHidden(true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        (UIApplication.shared.delegate as! AppDelegate).makeTabBarHidden(false)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
