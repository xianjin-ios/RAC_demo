//
//  MessageInputBoardVC.h
//  naren
//
//  Created by 任春宁 on 13-12-2.
//  Copyright (c) 2013年 Saluton. All rights reserved.
//

#import <UIKit/UIKit.h>

#define SCREEN_STATUS_HEIGHT    20
#define SCREEN_NAVBAR_HEIGHT    44

#define SCREEN_VIEW_HEIGHT      (SCREEN_HEIGHT - SCREEN_STATUS_HEIGHT - SCREEN_NAVBAR_HEIGHT)

#define EMOJI_CODE_TO_SYMBOL(x) ((((0x808080F0 | (x & 0x3F000) >> 4) | (x & 0xFC0) << 10) | (x & 0x1C0000) << 18) | (x & 0x3F) << 24);


@protocol MessageInputBoardVCDelegate<NSObject>
-(void)moveView:(UIView*)view toRect:(CGRect)toRect duration:(float)duration hide:(BOOL)hide;
-(void)clickOnButton:(int)tag;
-(void)sendMessage:(NSString*)text;
@end

@interface MessageInputBoardVC : UIViewController<UITextViewDelegate>{
    
    int _yBoard;
    
    CGRect _rcKeyboard;
    
    //输入文本框
    IBOutlet UITextView * _tvInput;
    
}

@property (assign,nonatomic) NSInteger originYoffset; //坐标系原点Y偏移值
@property (assign,nonatomic) id<MessageInputBoardVCDelegate> delegate;


-(IBAction)clickMediaButton:(id)sender;

//发送按钮
-(IBAction)clickSend:(id)sender;

-(void)hide;

-(void)clearText;

- (BOOL)stringContainsEmoji:(NSString *)string;

@end
