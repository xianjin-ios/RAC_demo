//
//  MyOrderDetailVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/29.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "MyOrderDetailVC.h"

@interface MyOrderDetailVC ()<UITableViewDataSource,UITableViewDelegate>{
    __weak IBOutlet UITableView *_iTableView;
    
    NSArray *_dataArray;
}

@end

@implementation MyOrderDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"交易详情";
    
    _dataArray = @[@[@"付款金额",@""],@[@"店铺名称",@""],@[@"当前状态",@""],@[@"交易时间",@""],@[@"交易方式",@""],@[@"订单编号",@""]];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //翻页CELL
    static NSString *CellIdentifier = @"COMMONCELL";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        UILabel *lbTitle = [[UILabel alloc]initWithFrame:CGRectMake(10, 10, 100, 20)];
        lbTitle.tag = 201;
        lbTitle.textColor = [UIColor blackColor];
        lbTitle.font = [UIFont systemFontOfSize:15];
        lbTitle.backgroundColor = [UIColor clearColor];
        lbTitle.textAlignment = 0;
        [cell.contentView addSubview:lbTitle];
        CGFloat desX = lbTitle.frame.origin.x + lbTitle.frame.size.width + 5;
        UILabel *lbDescript = [[UILabel alloc]initWithFrame:CGRectMake(desX, 10, SCREEN_WIDTH - desX - 10, 20)];
        lbDescript.tag = 202;
        lbDescript.textColor = [UIColor blackColor];
        lbDescript.font = [UIFont systemFontOfSize:13];
        lbDescript.backgroundColor = [UIColor clearColor];
        lbDescript.textAlignment = NSTextAlignmentRight;
        [cell.contentView addSubview:lbDescript];

        UIView *downLine = [[UIView alloc]initWithFrame:CGRectMake(0, 40 - ONEPIXL, SCREEN_WIDTH, ONEPIXL)];
        downLine.backgroundColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:downLine];
    }
    
    UILabel *lbTitle = (UILabel *)[cell.contentView viewWithTag:201];
    UILabel *lbDescript = (UILabel *)[cell.contentView viewWithTag:202];
    
    lbTitle.text = [_dataArray[indexPath.row] objectAtIndex:0];
    
    if(0 == indexPath.row){
        NSString *moneyStr = [self.infoDic objectForKey:@"fee"];
        lbDescript.text = [NSString stringWithFormat:@"￥%.2f",[moneyStr doubleValue]/100];
        lbDescript.textColor = [UIColor redColor];
    }else if (1 == indexPath.row){
        lbDescript.text = [self.infoDic objectForKey:@"shopname"];
    }else if (2 == indexPath.row){
        int typeValue = [[self.infoDic objectForKey:@"paystatus"] intValue];
        if (typeValue == 1) {
            lbDescript.text = @"成功";
        }else if (typeValue == 2){
            lbDescript.text = @"失败";
        }
    }else if (3 == indexPath.row){
        NSString *timeStr = [self.infoDic objectForKey:@"ctime"];
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:[timeStr integerValue]];
        NSDateFormatter  *dateformatter = [[NSDateFormatter alloc] init];
        [dateformatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        [dateformatter setTimeZone:[NSTimeZone systemTimeZone]];
        NSString *  locationString = [dateformatter stringFromDate:date];
        lbDescript.text = locationString;
    }else if(4 == indexPath.row){
        int detailValue = [[self.infoDic objectForKey:@"payway"] intValue];
        switch (detailValue) {
            case 1:
                lbDescript.text = @"mpos支付";
                break;
            case 2:
                lbDescript.text = @"支付宝";
                break;
            case 3:
                lbDescript.text = @"银联";
                break;
            case 4:
                lbDescript.text = @"现金";
                break;
            default:
                lbDescript.text = @"微信支付";
                break;
        }
    }else if (5 == indexPath.row){
        
        lbDescript.text = [self.infoDic objectForKey:@"num"];
    }

    return cell;
}

@end
