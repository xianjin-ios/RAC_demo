//
//  chatTimeCell.h
//  CcbCloudPay
//
//  Created by 任春宁 on 15/5/8.
//  Copyright (c) 2015年 xkdx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface chatTimeCell : UITableViewCell{



    NSDictionary * _dicMsg;
}


-(void)initData:(NSDictionary * )dicMsg;

//获取cell高度
+(int)getHeight:(NSDictionary * )dicMsg;

@end
