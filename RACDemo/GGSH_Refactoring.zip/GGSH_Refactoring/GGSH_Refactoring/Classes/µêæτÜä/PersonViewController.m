//
//  PersonViewController.m
//  GGSH
//
//  Created by siqiyang on 15/9/9.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "PersonViewController.h"
#import "MyInfoVC.h"
@interface PersonViewController ()
{
    IBOutlet UIScrollView *_scrollView;
    
    IBOutlet UIImageView *_uHeadImage;
    IBOutlet UITextField *_uName;
    IBOutlet UILabel *_uSex;
    IBOutlet UIButton *_uBirthDay;
    IBOutlet UITextField *_uAddress;
    IBOutlet UITextField *_uZhiye;
    IBOutlet UITextField *_uMail;
    IBOutlet UITextField *_uContact;
    IBOutlet UITextField *_uWeixin;
    
    NSMutableDictionary *userDic;
}
@end

@implementation PersonViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"我的资料";
    
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0.0, 0.0, 40, 25);
    [rightBtn addTarget:self action:@selector(gotoChangeView) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setTitle:@"编辑" forState:UIControlStateNormal];
    [rightBtn.titleLabel setFont:[UIFont systemFontOfSize:15]];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    rightBarButtonItem.style = UIBarButtonItemStylePlain;
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
    
    //修改用户资料
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getPersonalInfo) name:@"ChangeUserInfo" object:nil];
    [self getPersonalInfo];
    
    _uHeadImage.layer.cornerRadius = _uHeadImage.frame.size.height*0.5;
    _uHeadImage.layer.masksToBounds = YES;
}

- (void)gotoChangeView{
    
    MyInfoVC *ctrl = [[MyInfoVC alloc]init];
    ctrl.userDic = userDic;
    [self.navigationController pushViewController:ctrl animated:YES];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_MYDETAIL_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_MYDETAIL_VIEW"];
    
}

#pragma mark - network
//获取个人资料
-(void)getPersonalInfo{
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Personal" forKey:@"Mod"];
    [dic setObject:@"PersonalInfo" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"id"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [self showHUD];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        [self hideHUD];
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            if ([[resultDic objectForKey:@"DetailInfo"] isKindOfClass:[NSDictionary class]]) {
                
                userDic = [[resultDic objectForKey:@"DetailInfo"] mutableCopy];
                
                //加载信息
                [self loadDetailView:userDic];
            }
        }else{
            [self showalertString:[resultDic objectForKey:@"Message"]];
        }
        
    }];
}

- (void)loadDetailView:(NSMutableDictionary *)dic{
    ZLog(@"%@",dic);
    
    NSString *urlStr = [dic objectForKey:@"head_pic"];
    [_uHeadImage XK_setImageWithURL:[NSURL URLWithString:urlStr] placeholderImage:nil];
    
    NSString *nameStr = [dic objectForKey:@"realname"];
    _uName.text = nameStr;
    
    int sexcode = [[dic objectForKey:@"sex"] intValue];
    switch (sexcode) {
        case 0:
            _uSex.text = @"保密";
            break;
        case 1:
            _uSex.text = @"男";
            break;
        case 2:
            _uSex.text = @"女";
            break;
            
        default:
            break;
    }
    
    NSString *birthStr = [dic objectForKey:@"birthday"];
    [_uBirthDay setTitle:birthStr forState:UIControlStateNormal];
    
    NSString *addressStr = [dic objectForKey:@"address"];
    _uAddress.text = addressStr;
    
    NSString *zhiyeStr = [dic objectForKey:@"occupation"];
    _uZhiye.text = zhiyeStr;
    
    NSString *mailStr = [dic objectForKey:@"email"];
    _uMail.text = mailStr;
    
    NSString *contactStr = [dic objectForKey:@"phone"];
    _uContact.text = contactStr;

    NSString *weixinStr = [dic objectForKey:@"wchat"];
    _uWeixin.text = weixinStr;
    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
