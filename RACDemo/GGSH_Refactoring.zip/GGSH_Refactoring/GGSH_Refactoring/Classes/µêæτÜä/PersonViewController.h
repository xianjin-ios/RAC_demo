//
//  PersonViewController.h
//  GGSH
//
//  Created by siqiyang on 15/9/9.
//  Copyright (c) 2015年 YHD. All rights reserved.
//

#import "BaseViewController.h"

@interface PersonViewController : BaseViewController

@end
