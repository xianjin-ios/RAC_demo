//
//  MyMessageVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "MyMessageVC.h"
#import "MerchantNoticeVC.h"
#import "GrabCouponVC.h"
#import "chatVC.h"


@interface MyMessageVC ()<UITableViewDelegate,UITableViewDataSource,MJRefreshBaseViewDelegate>{
    __weak IBOutlet UITableView *_iTableView;
    NSMutableArray *_dataArray;
    
    NSInteger pageIndex;
    
    //系统消息列表
    NSMutableArray * _arrSysMessagelist;
    
    //个人消息列表
    NSMutableArray * _arrMyMessagelist;
    
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    NSDate *date;
    
}

@end

@implementation MyMessageVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的消息";
    
    _dataArray = [NSMutableArray array];
    [self cancelTapHideKeyBoard:YES];
    
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _iTableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _iTableView;
    _footer.delegate = self;
    
    //注册通知刷新
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getMessageNetData) name:@"refreshMessageNetData" object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_MESSAGE_VIEW"];
    
    pageIndex = 1;
    [self getMessageNetData];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_MESSAGE_VIEW"];
    
}

#pragma mark - 刷新的代理方法---进入下拉刷新\上拉加载更多都有可能调用这个方法
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    if(refreshView == _header) {// 下拉刷新
        //5秒内不能重复发起网络请求，只是界面上闪动下正在加载，就1s。
        if(date){
            NSDate *tenMiniteLater = [date dateByAddingTimeInterval:5];
            NSDate *currentDate = [NSDate date];
            if(NSOrderedDescending == [tenMiniteLater compare:currentDate]){
                ZLog(@"ascending");
                date = [NSDate date];
                [self performSelector:@selector(OneSecondElapse) withObject:nil afterDelay:1];
                [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
                return;
            }
            
            pageIndex = 1;
            //网络请求
            [self getMessageNetData];
            
        }else{
            date = [NSDate date];
            pageIndex = 1;
            [self getMessageNetData];
        }
        
    }else if (refreshView == _footer){
        pageIndex ++;
        [self getMessageNetData];
    }
    
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
}

//1s的假loading，取消正在加载就好
- (void)OneSecondElapse{
    [self hideHUD];
}

- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

#pragma mark - 获取系统消息
- (void)getMessageNetData{
    if(!MyAppDelegate.userInfo)
        return;
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
    [item setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    [item setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"phone"];
    [item setObject:[NSNumber numberWithInteger:1] forKey:@"type"];// 1： 拉取最新的一条店铺通知和未读的店铺通知数 2： 拉取列表
    [item setObject:@"1" forKey:@"devicetype"];
    [item setObject:KVERSION forKey:@"version_name"];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"Release",@"Mod",@"Message_v1",@"Act",item,@"Content", nil];

    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if ([resultDic isKindOfClass:[NSDictionary class]]) {
            int code = [[resultDic objectForKey:@"Code"] intValue];
            if (code == 0000) {
                _arrSysMessagelist = [NSMutableArray arrayWithArray:[resultDic objectForKey:@"DetailInfo"]];
            }
            
            if (_dataArray.count == 0) {
                if (_arrSysMessagelist.count == 0) {
                    NSDictionary *tempDic = [NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil];
                    [_dataArray insertObject:tempDic atIndex:0];
                    
                }else{
                    NSDictionary *tempDic = [_arrSysMessagelist objectAtIndex:0];
                    [_dataArray insertObject:tempDic atIndex:0];
                }
                
                //列表第2项是抢券通知
                [_dataArray insertObject:[NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil] atIndex:1];
            }else{
                if (_arrSysMessagelist.count == 0) {
                    NSDictionary *tempDic = [NSDictionary dictionaryWithObjectsAndKeys:@"",@"", nil];
                    [_dataArray replaceObjectAtIndex:0 withObject:tempDic];
                    
                }else{
                    NSDictionary *tempDic = [_arrSysMessagelist objectAtIndex:0];
                    [_dataArray replaceObjectAtIndex:0 withObject:tempDic];
                }
            }
            [self getMyMessage];
        }
    }];
}

#pragma mark - 获取个人消息
- (void)getMyMessage{
    NSMutableDictionary *dicContent = [[NSMutableDictionary alloc] init];
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"News" forKey:@"Mod"];
    [dic setObject:@"listNew_v1" forKey:@"Act"];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:@"" forKey:@"shopid"];
    [dicContent setObject:[NSNumber numberWithInteger:pageIndex] forKey:@"pageindex"];
    [dicContent setObject:[NSNumber numberWithInteger:20] forKey:@"pagesize"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if (pageIndex == 1) {
            //清空在dataArray中的用户消息
            [_dataArray removeObjectsInArray:_arrMyMessagelist];
            
            //清除用户消息缓存
            [_arrMyMessagelist removeAllObjects];
            
        }
        int code = [[resultDic objectForKey:@"Code"] intValue];
        if (code == 0000) {
            _arrMyMessagelist = [[resultDic objectForKey:@"DetailInfo"]mutableCopy];
            [_dataArray addObjectsFromArray:_arrMyMessagelist];
        }else{
            pageIndex --;
            if (pageIndex < 1) {
                pageIndex = 1;
            }
        }
        
        [_iTableView reloadData];
        
    }];
}

#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 66;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dicMessage = [_dataArray objectAtIndex:indexPath.row];
    
    //翻页CELL
    if (indexPath.row == 0) {
        static NSString *CellIdentifier = @"TOPCELL";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.clipsToBounds = YES;
            
            //图标
            UIImageView *merchantIcon = [[UIImageView alloc]initWithFrame:CGRectMake(8, 16, 34, 34)];
            merchantIcon.tag = 101;
            merchantIcon.image = [UIImage imageNamed:@"_0001_system.png"];
            [cell.contentView addSubview:merchantIcon];
            
            //提示标识
            UIImageView *imageAlertCell = [[UIImageView alloc]initWithFrame:CGRectMake(32, 12, 16, 16)];
            [imageAlertCell setImage:[UIImage imageNamed:@"imageAlert_b.png"]];
            [imageAlertCell setTag:1011];
            [cell.contentView addSubview:imageAlertCell];
            UILabel *alertLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 16, 16)];
            [alertLabel setTextAlignment:NSTextAlignmentCenter];
            [alertLabel setFont:[UIFont systemFontOfSize:8]];
            [alertLabel setTextColor:[UIColor whiteColor]];
            [alertLabel setTag:1012];
            [imageAlertCell addSubview:alertLabel];
            [alertLabel setText:@"99+"];
            
            if ([dicMessage objectForKey:@"releasenum"] && [[dicMessage objectForKey:@"releasenum"] integerValue] > 0) {
                [imageAlertCell setHidden:NO];
                NSString *releasenum = [dicMessage objectForKey:@"releasenum"];
                if ([releasenum integerValue] > 99) {
                    releasenum = @"99+";
                }
                alertLabel.text = releasenum;
            }else{
                [imageAlertCell setHidden:YES];
                alertLabel.text = @"";
                
            }
            
            //标题
            UILabel * lbTitle = [[UILabel alloc] init];
            lbTitle.tag = 12;
            lbTitle.backgroundColor = [UIColor clearColor];
            lbTitle.font = [UIFont systemFontOfSize:15];
            lbTitle.textColor = [UIColor blackColor];
            [cell.contentView addSubview:lbTitle];
            lbTitle.frame = CGRectMake(50, 10, _iTableView.frame.size.width - 180, 20 );
            lbTitle.text = @"店铺通知";
            
            
            //时间
            UILabel * lbTime = [[UILabel alloc] init];
            lbTime.tag = 13;
            lbTime.textAlignment = NSTextAlignmentRight;
            lbTime.backgroundColor = [UIColor clearColor];
            lbTime.font = [UIFont systemFontOfSize:13];
            lbTime.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:lbTime];
            lbTime.frame = CGRectMake(self.view.frame.size.width - 120, 10, 100, 15 );
            NSString * strTime = [dicMessage objectForKey:@"time" ];
            if (strTime == nil) {
                lbTime.text = @"";
            }
            else{
                
                lbTime.text = strTime;
                
            }
            //摘要
            UILabel * lbContent = [[UILabel alloc] init];
            lbContent.tag = 14;
            lbContent.backgroundColor = [UIColor clearColor];
            lbContent.font = [UIFont systemFontOfSize:13];
            lbContent.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:lbContent];
            lbContent.frame = CGRectMake(50, 36, _iTableView.frame.size.width - 60, 20 );
            lbContent.text = @"";
            
            UIView *downLine = [[UIView alloc]initWithFrame:CGRectMake(0, 65.5, _iTableView.frame.size.width, 0.5)];
            downLine.backgroundColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:downLine];
            
        }
        
        //未读标识
        UIImageView *imageAlertCell = (UIImageView *)[cell.contentView viewWithTag:1011];
        //未读数量
        UILabel * alertLabel = (UILabel*)[cell.contentView viewWithTag:1012];
        if ([dicMessage objectForKey:@"releasenum"] && [[dicMessage objectForKey:@"releasenum"] integerValue] > 0) {
            [imageAlertCell setHidden:NO];
            NSString *releasenum = [dicMessage objectForKey:@"releasenum"];
            if ([releasenum integerValue] > 99) {
                releasenum = @"99+";
            }
            alertLabel.text = releasenum;
        }else{
            [imageAlertCell setHidden:YES];
            alertLabel.text = @"";
            
        }
        
        //时间
        UILabel * lbTime = (UILabel*)[cell.contentView viewWithTag:13];
        NSString * strTime = [dicMessage objectForKey:@"time" ];
        if (strTime == nil) {
            lbTime.text = @"";
        }else{
            lbTime.text = strTime;
        }
        
        UILabel *lbContent = (UILabel *)[cell.contentView viewWithTag:14];
        NSString *contentStr = [NSString stringWithFormat:@"【%@】%@",[dicMessage objectForKey:@"shopname"],[dicMessage objectForKey:@"tite"]];
        if (![dicMessage objectForKey:@"shopname"]) {
            contentStr = @"";
        }
        lbContent.text = contentStr;
        return  cell;
    }else if (1 == indexPath.row){
        //抢券通知
        static NSString *CellIdentifier = @"TOPCELL";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.clipsToBounds = YES;
            
            //图标
            UIImageView *merchantIcon = [[UIImageView alloc]initWithFrame:CGRectMake(8, 16, 34, 34)];
            merchantIcon.tag = 101;
            merchantIcon.image = [UIImage imageNamed:@"qiangquan_notice.png"];
            [cell.contentView addSubview:merchantIcon];
            
            //提示标识
            UIImageView *imageAlertCell = [[UIImageView alloc]initWithFrame:CGRectMake(35, 12, 9, 9)];
            [imageAlertCell setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
            [imageAlertCell setTag:1011];
            [cell.contentView addSubview:imageAlertCell];
            [imageAlertCell setHidden:YES];
            
            //标题
            UILabel * lbTitle = [[UILabel alloc] init];
            lbTitle.tag = 12;
            lbTitle.backgroundColor = [UIColor clearColor];
            lbTitle.font = [UIFont systemFontOfSize:15];
            lbTitle.textColor = [UIColor blackColor];
            [cell.contentView addSubview:lbTitle];
            lbTitle.frame = CGRectMake(50, 10, _iTableView.frame.size.width - 180, 20 );
            lbTitle.text = @"抢券通知";
            
            
            //时间
            UILabel * lbTime = [[UILabel alloc] init];
            lbTime.tag = 13;
            lbTime.textAlignment = NSTextAlignmentRight;
            lbTime.backgroundColor = [UIColor clearColor];
            lbTime.font = [UIFont systemFontOfSize:13];
            lbTime.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:lbTime];
            lbTime.frame = CGRectMake(self.view.frame.size.width - 120, 10, 100, 15 );
            
            //摘要
            UILabel * lbContent = [[UILabel alloc] init];
            lbContent.tag = 14;
            lbContent.backgroundColor = [UIColor clearColor];
            lbContent.font = [UIFont systemFontOfSize:13];
            lbContent.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:lbContent];
            lbContent.frame = CGRectMake(50, 36, _iTableView.frame.size.width - 60, 20 );
            lbContent.text = @"";
            
            UIView *downLine = [[UIView alloc]initWithFrame:CGRectMake(0, 65.5, _iTableView.frame.size.width, 0.5)];
            downLine.backgroundColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:downLine];
            
        }
        
        BOOL isShow = NO;
        BOOL isShowNoRead = NO;
        NSInteger index = 0;
        for (NSInteger i = MyAppDelegate.beaconsInfoArray.count-1; i >= 0; i --) {
            NSDictionary *dic = [MyAppDelegate.beaconsInfoArray objectAtIndex:i];
            if([[dic objectForKey:@"isnotification"] isEqualToString:@"1"]){
                isShow = YES;
                index = i;
            }
            if([[dic objectForKey:@"isread"] isEqualToString:@"0"]){
                isShowNoRead = YES;
            }
        }
        
        if (isShow) {
            //未读标识
            UIImageView *imageAlertCell = (UIImageView *)[cell.contentView viewWithTag:1011];
            if (isShowNoRead) {
                [imageAlertCell setHidden:NO];
            }else{
                [imageAlertCell setHidden:YES];
            }
            
            //时间
            UILabel * lbTime = (UILabel*)[cell.contentView viewWithTag:13];
            NSString *timeStr = @"";
            NSString *nameStr = @"";
            if(MyAppDelegate.beaconsInfoArray.count > 0){
                NSDictionary *dic = [MyAppDelegate.beaconsInfoArray objectAtIndex:index];
                timeStr = [dic objectForKey:@"time"];
                if(timeStr.length > 10)
                    timeStr = [timeStr substringToIndex:10];
                nameStr = [dic objectForKey:@"shopname"];
                if(nameStr)
                    nameStr = [nameStr stringByAppendingString:@"开始派券啦，快去抢吧！"];
            }
            lbTime.text = timeStr;
            
            UILabel *lbContent = (UILabel *)[cell.contentView viewWithTag:14];
            lbContent.text = nameStr;
        }
        
        return  cell;
    }else{
        static NSString *CellIdentifier = @"COMMONCELL";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.clipsToBounds = YES;
            
            //图标
            UIImageView *merchantIcon = [[UIImageView alloc]initWithFrame:CGRectMake(8, 16, 34, 34)];
            merchantIcon.tag = 101;
            merchantIcon.image = [UIImage imageNamed:@"_0000_photo.png"];
            [cell.contentView addSubview:merchantIcon];
            
            NSString *imgUrl = [dicMessage objectForKey:@"listpic"];
            [merchantIcon XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:nil];
            
            UIImageView *imageAlertCell = [[UIImageView alloc]initWithFrame:CGRectMake(32, 12, 16, 16)];
            [imageAlertCell setImage:[UIImage imageNamed:@"imageAlert_b.png"]];
            [imageAlertCell setTag:1011];
            [cell.contentView addSubview:imageAlertCell];
            UILabel *alertLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 16, 16)];
            [alertLabel setTextAlignment:NSTextAlignmentCenter];
            [alertLabel setFont:[UIFont systemFontOfSize:8]];
            [alertLabel setTextColor:[UIColor whiteColor]];
            [alertLabel setTag:1012];
            [imageAlertCell addSubview:alertLabel];
            [alertLabel setText:@"99+"];
            
            //标题
            UILabel * lbTitle = [[UILabel alloc] init];
            lbTitle.tag = 12;
            lbTitle.backgroundColor = [UIColor clearColor];
            lbTitle.font = [UIFont systemFontOfSize:15];
            lbTitle.textColor = [UIColor blackColor];
            [cell.contentView addSubview:lbTitle];
            lbTitle.frame = CGRectMake(50, 10, _iTableView.frame.size.width - 180, 20 );
            lbTitle.text = [dicMessage objectForKey:@"shopname"];
            
            //时间
            UILabel * lbTime = [[UILabel alloc] init];
            lbTime.tag = 13;
            lbTime.textAlignment = NSTextAlignmentRight;
            lbTime.backgroundColor = [UIColor clearColor];
            lbTime.font = [UIFont systemFontOfSize:13];
            lbTime.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:lbTime];
            lbTime.frame = CGRectMake(self.view.frame.size.width - 120, 10, 100, 15 );
            NSString * strTime = [dicMessage objectForKey:@"time" ];
            if (strTime == nil) {
                lbTime.text = @"";
            }
            else{
                lbTime.text = [[[xkBase alloc]init] XKstampToDate:strTime format:@"yy/MM/dd"];
            }
            //摘要
            UILabel * lbContent = [[UILabel alloc] init];
            lbContent.tag = 14;
            lbContent.backgroundColor = [UIColor clearColor];
            lbContent.font = [UIFont systemFontOfSize:13];
            lbContent.textColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:lbContent];
            lbContent.frame = CGRectMake(50, 36, _iTableView.frame.size.width - 60, 20 );
            lbContent.text = [dicMessage objectForKey:@"content"];
            
            UIView *downLine = [[UIView alloc]initWithFrame:CGRectMake(0, 65.5, _iTableView.frame.size.width, 0.5)];
            downLine.backgroundColor = [UIColor lightGrayColor];
            [cell.contentView addSubview:downLine];
            
        }
        
        //商店图标
        UIImageView *merchantIcon = (UIImageView *)[cell.contentView viewWithTag:101];
        NSString *imgUrl = [dicMessage objectForKey:@"listpic"];
        if (imgUrl.length > 0) {
            [merchantIcon XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:nil];
        }else{
            merchantIcon.image = [UIImage imageNamed:@"_0000_photo.png"];
        }
        
        //未读标识
        UIImageView *imageAlertCell = (UIImageView *)[cell.contentView viewWithTag:1011];
        //未读数量
        UILabel * alertLabel = (UILabel*)[cell.contentView viewWithTag:1012];
        if ([dicMessage objectForKey:@"newsnum"] && [[dicMessage objectForKey:@"newsnum"] integerValue] > 0) {
            [imageAlertCell setHidden:NO];
            NSString *newnum = [dicMessage objectForKey:@"newsnum"];
            if ([newnum integerValue] > 99) {
                newnum = @"99+";
            }
            alertLabel.text = newnum;
        }else{
            [imageAlertCell setHidden:YES];
            alertLabel.text = @"";
            
        }
        
        //标题
        UILabel * lbTitle = (UILabel*)[cell.contentView viewWithTag:12];
        lbTitle.text = [dicMessage objectForKey:@"shopname"];
        
        //时间
        UILabel * lbTime = (UILabel*)[cell.contentView viewWithTag:13];
        NSString * strTime = [dicMessage objectForKey:@"time" ];
        if (strTime == nil) {
            lbTime.text = @"";
        }
        else{
            //个人消息和系统消息返回的时间类型不同，需要分开处理
            lbTime.text = [[[xkBase alloc]init] XKstampToDate:strTime format:@"yy/MM/dd"];
        }
        
        UILabel *lbContent = (UILabel *)[cell.contentView viewWithTag:14];
        
        NSString *strContent = [dicMessage objectForKey:@"content"];
        NSString *type = [[dicMessage objectForKey:@"type"]description];
        if ([type isEqualToString:@"1"]) {
            //图片
            strContent = @"[图片]";
        }
        lbContent.text = strContent;
        
        return cell;
    }
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        MerchantNoticeVC *vc = [[MerchantNoticeVC alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    }else if(1 == indexPath.row){
        //当没有抢券信息时，不可以进入下个页面
        BOOL bStop = NO;
        for(NSDictionary *dic in MyAppDelegate.beaconsInfoArray){
            if([[dic objectForKey:@"isnotification"] isEqualToString:@"1"]){
                bStop = YES;
            }
        }
        if(!bStop){
            [self showAlert:nil withTitle:@"没有可抢的券哦！" haveCancelButton:NO];
            return;
        }
        //跳转到抢券界面
        GrabCouponVC *vc = [[GrabCouponVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        NSDictionary * dicInfo = [_dataArray objectAtIndex:indexPath.row];
        chatVC * vc = [[chatVC alloc] init];
        vc.dicChatInfo = dicInfo;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
