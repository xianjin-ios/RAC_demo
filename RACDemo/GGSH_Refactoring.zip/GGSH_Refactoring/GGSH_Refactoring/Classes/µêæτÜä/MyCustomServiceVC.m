//
//  MyCustomServiceVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "MyCustomServiceVC.h"

@interface MyCustomServiceVC ()

@end

@implementation MyCustomServiceVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的客服";
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
