//
//  chatTimeCell.m
//  CcbCloudPay
//
//  Created by 任春宁 on 15/5/8.
//  Copyright (c) 2015年 xkdx. All rights reserved.
//

#import "chatTimeCell.h"

//字体大小
#define LBNAME_FONTSIZE 12

#define SC_WIDTH ([[UIScreen mainScreen] bounds].size.width)

@implementation chatTimeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        UILabel * lbContent = [[UILabel alloc] init];
        lbContent.tag = 12;
        lbContent.frame = CGRectMake(0, 5, SC_WIDTH, 30);
        lbContent.backgroundColor = [UIColor clearColor];
        lbContent.font = [UIFont systemFontOfSize:LBNAME_FONTSIZE];
        lbContent.textColor = [UIColor grayColor];
        lbContent.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:lbContent];
        
    }
    return self;
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

-(void)initData:(NSDictionary * )dicMsg{
    
    UILabel * lbContent = (UILabel *)[self.contentView viewWithTag:12];
    NSString * strContent = [dicMsg objectForKey:@"content"];
    
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:[strContent integerValue]];
    
    NSDateFormatter  *dateformatter = [[NSDateFormatter alloc] init];
    [dateformatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *  locationString = [dateformatter stringFromDate:date];
    lbContent.text = locationString;
    
}

//获取cell高度
+(int)getHeight:(NSDictionary * )dicMsg{
   
    return 30;
}

@end
