//
//  MyInfoVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "MyInfoVC.h"
#import "GTMBase64.h"

@interface MyInfoVC (){
    IBOutlet UITextField *realname;
    IBOutlet UITextField *address;
    IBOutlet UITextField *occupation;
    IBOutlet UITextField *email;
    IBOutlet UITextField *phone;
    IBOutlet UITextField *wchat;
    
    IBOutlet UIButton *btnGender1;
    IBOutlet UIButton *btnGender2;
    IBOutlet UIButton *btnGender3;
    
    IBOutlet UIButton *birthday;
    
    BOOL _isChangeHeadImage;
    
    IBOutlet UIImageView *_uHeadImage;
    NSInteger sex;
}

@end

@implementation MyInfoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的资料";
    // Do any additional setup after loading the view from its nib.
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0.0, 0.0, 40, 25);
    [rightBtn addTarget:self action:@selector(changeInfo:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setTitle:@"完成" forState:UIControlStateNormal];
    [rightBtn.titleLabel setFont:[UIFont systemFontOfSize:15]];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    rightBarButtonItem.style = UIBarButtonItemStylePlain;
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
    
    UITapGestureRecognizer *taphead = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(getHeadImage)];
    taphead.cancelsTouchesInView = YES;
    [_uHeadImage addGestureRecognizer:taphead];
    
    _uHeadImage.layer.cornerRadius = 25;
    _uHeadImage.layer.masksToBounds = YES;
    
    [self loadDetailView:self.userDic];
}

- (void)loadDetailView:(NSDictionary *)info{
    
    NSString *urlStr = [info objectForKey:@"head_pic"];
    [_uHeadImage XK_setImageWithURL:[NSURL URLWithString:urlStr] placeholderImage:nil];
    
    realname.text = [info objectForKey:@"realname"];
    int sexcode = [[info objectForKey:@"sex"] intValue];
    switch (sexcode) {
        case 0:
            btnGender1.selected = YES;
            btnGender2.selected = NO;
            btnGender3.selected = NO;
            break;
        case 1:
            btnGender1.selected = NO;
            btnGender2.selected = YES;
            btnGender3.selected = NO;
            break;
        case 2:
            btnGender1.selected = NO;
            btnGender2.selected = NO;
            btnGender3.selected = YES;
            break;
            
        default:
            break;
    }
    [birthday setTitle:[info objectForKey:@"birthday"] forState:UIControlStateNormal];
    address.text = [info objectForKey:@"address"];
    occupation.text = [info objectForKey:@"occupation"];
    email.text = [info objectForKey:@"email"];
    phone.text = [info objectForKey:@"phone"];
    wchat.text = [info objectForKey:@"wchat"];
    
}

- (IBAction)sex0:(id)sender {
    btnGender1.selected = YES;
    btnGender2.selected = NO;
    btnGender3.selected = NO;
    
    sex = 0;
}

- (IBAction)sex1:(id)sender {
    btnGender1.selected = NO;
    btnGender2.selected = YES;
    btnGender3.selected = NO;
    
    sex = 1;
    
}

- (IBAction)sex2:(id)sender {
    btnGender1.selected = NO;
    btnGender2.selected = NO;
    btnGender3.selected = YES;
    
    sex = 2;
    
}
- (void)getHeadImage{
    UIActionSheet *uploadActionSheet = [[UIActionSheet alloc] initWithTitle:nil
                                                                   delegate:self
                                                          cancelButtonTitle:@"取消"
                                                     destructiveButtonTitle:nil
                                                          otherButtonTitles:@"拍照",@"从手机相册选择",nil];
    
    uploadActionSheet.tag = 2003;
    [uploadActionSheet showInView:[UIApplication sharedApplication].keyWindow];
}

#pragma mark - UIActionSheet Delegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if( buttonIndex > 1 ){
        return;
    }
    //拍照
    if( buttonIndex == 0 ){
        [self takePhotPic];
    }
    //相册
    else if( buttonIndex == 1 ){
        [self selectPhoto];
    }
}

//拍照
-(void)takePhotPic{
    UIImagePickerController *imgPicker = [[UIImagePickerController alloc] init];
    [imgPicker setSourceType:UIImagePickerControllerSourceTypeCamera];
    [imgPicker setDelegate:self];
    [imgPicker setAllowsEditing:YES];
    [self presentViewController:imgPicker animated:YES completion:^{
    }];
    
}

//相册选择
- (void)selectPhoto {
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        picker.allowsEditing = YES;
        [self presentViewController:picker animated:YES completion:^{}];
    }
    else {
        
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"连接到图片库错误"
                              message:@""
                              delegate:nil
                              cancelButtonTitle:@"好"
                              otherButtonTitles:nil];
        [alert show];
    }
}

//拍照后，或者选择照片后，照片处理
- (void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo: (NSDictionary *)info{
    
    UIImage *selectImage = [info objectForKey:UIImagePickerControllerEditedImage];
    
    
    [_uHeadImage setImage:selectImage];
    
    _isChangeHeadImage = YES;
    
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
    
}

- (IBAction)changeInfo:(id)sender {
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Personal" forKey:@"Mod"];
    [dic setObject:@"PersonalEdit" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    
    [dicContent setObject:[NSString stringWithFormat:@"%@",realname.text] forKey:@"realname"];
#pragma mark - 需要传到服务器
//    [dicContent setObject:[NSNumber numberWithInteger:sex] forKey:@"sex"];
//    
//    [dicContent setObject:[NSString stringWithFormat:@"%@",self.birthday.titleLabel.text] forKey:@"birthday"];
    [dicContent setObject:[NSString stringWithFormat:@"%@",address.text] forKey:@"address"];
    [dicContent setObject:[NSString stringWithFormat:@"%@",occupation.text] forKey:@"occupation"];
    [dicContent setObject:[NSString stringWithFormat:@"%@",email.text] forKey:@"email"];
    [dicContent setObject:[NSString stringWithFormat:@"%@",phone.text] forKey:@"phone"];
    [dicContent setObject:[NSString stringWithFormat:@"%@",wchat.text] forKey:@"wchat"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    //判断是否修改了用户头像
    if (_isChangeHeadImage) {
        NSData * dataThumb = UIImageJPEGRepresentation(_uHeadImage.image, 0.8);
        NSData *basedDataThumb = [GTMBase64 encodeData:dataThumb];
        NSString *strThumb = [[NSString alloc]initWithData:basedDataThumb encoding:NSUTF8StringEncoding];
        [dicContent setObject:strThumb forKey:@"head_pic"];
    }
    
    [dic setObject:dicContent forKey:@"Content"];
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            
            
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        int code = [[resultDic  objectForKey:@"Code"] intValue];
        if (code == 0000) {
            if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
                
                //发送修改通知修改我的资料
                [[NSNotificationCenter defaultCenter]postNotificationName:@"ChangeUserInfo" object:nil];
                //返回上层
                [self.navigationController popViewControllerAnimated:YES];
            }
        }
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
