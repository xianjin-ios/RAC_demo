//
//  MyViewController.m
//  GGSH_Refactoring
//
//  Created by huadong on 16/9/14.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "MyViewController.h"
#import "LoginVC.h"
#import "SettingVC.h"
#import "MyMessageVC.h"
#import "MyOrderVC.h"
#import "MyAddressVC.h"
#import "MyCustomServiceVC.h"
#import "PersonViewController.h"

@interface MyViewController ()<UITabBarDelegate,UITableViewDataSource,loginDelegate>{
    UIImageView *imageAlert;
    
    NSArray *infoArray;
    
    __weak IBOutlet UITableView *_iTableView;
    
    __weak IBOutlet UIImageView *_imgHead;
    __weak IBOutlet UILabel *_lbName;
}

@end

@implementation MyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"我的逛逛";
    [self cancelTapHideKeyBoard:YES];
    
    infoArray = @[@[@"my_01.png",@"我的交易",@"查看我的交易记录"],@[@"my_05.png",@"我的地址",@"编辑常用的收货地址信息"],@[@"my_02.png",@"我要开店",@""],@[@"my_03.png",@"我的客服",@"查看客服联系方式"],@[@"my_04.png",@"我的资料",@"编辑个人资料"]];
    
    [self addBarButton];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(loginOut:) name:@"NOTI_LOGOUT" object:nil];
}

- (void)addBarButton{
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0.0, 0.0, 16, 16);
    [leftBtn addTarget:self action:@selector(my_set:) forControlEvents:UIControlEventTouchUpInside];
    [leftBtn setBackgroundImage:[UIImage imageNamed:@"my_set.png"] forState:UIControlStateNormal];
    UIBarButtonItem *leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftBtn];
    leftBarButtonItem.style = UIBarButtonItemStylePlain;
    self.navigationItem.leftBarButtonItem = leftBarButtonItem;
    
    
    //添加右边按钮
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0.0, 0.0, 16, 16);
    [rightBtn addTarget:self action:@selector(my_message) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setBackgroundImage:[UIImage imageNamed:@"my_message.png"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    rightBarButtonItem.style = UIBarButtonItemStylePlain;
    //判断是否要添加红点提示
    imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(10, -4, 9, 9)];
    [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
    [rightBarButtonItem.customView addSubview:imageAlert];
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
//    if (MyAppDelegate.isHaveNoReadMessage) {
//        [imageAlert setHidden:NO];
//    }else{
//        [imageAlert setHidden:YES];
//    }
//    [MyAppDelegate addRightBtn:self AndBtnArr:@[rightBarButtonItem]];
}

- (IBAction)my_set:(id)sender{
    SettingVC *vc = [[SettingVC alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)my_message{
    MyMessageVC *vc = [[MyMessageVC alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)showLoginView{
    LoginVC *vc = [[LoginVC alloc] init];
    vc.delegate = self;
    UINavigationController *navc = [[UINavigationController alloc]initWithRootViewController:vc];
    [self presentViewController:navc animated:YES completion:nil];
}

//登录成功
- (void)finishLogin{
    [self getUserHeadInfo];
}

//登录失败
- (void)cancelLogin{
    [MyAppDelegate setTabSelect:0];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if(!MyAppDelegate.userInfo){
        //未登录
        [self showLoginView];
    }else{
        _lbName.text = MyAppDelegate.userInfo[@"phone"];
    }
}

#pragma  mark -- 代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 5;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if(0 == indexPath.row){
        //我的订单
        MyOrderVC *vc = [[MyOrderVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }else if(1 == indexPath.row){
        //我的地址
        MyAddressVC *vc = [[MyAddressVC alloc]init];
        vc.isFromMy = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }else if(2 == indexPath.row){
        //云商城
        NSURL *handlbackeUrl = [NSURL URLWithString:@"CcbCloudPay://aaa"];
        if ([[UIApplication sharedApplication] canOpenURL:handlbackeUrl]){
            [[UIApplication sharedApplication] openURL:handlbackeUrl];
        }
        else{
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://ypos.guangguang.net.cn/"]];
        }
    }else if(3 ==indexPath.row){
        //我的客服
        MyCustomServiceVC *vc = [[MyCustomServiceVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }else if (4 == indexPath.row){
        //我的资料
        PersonViewController *vc = [[PersonViewController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    }

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellID = @"commcell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
        
        //imagView
        UIImageView *ImageView = [[UIImageView alloc]initWithFrame:CGRectMake(10, 12, 25, 25)];
        [cell.contentView addSubview:ImageView];
        ImageView.tag = 11;
        
        //名称
        UILabel *productLabel = [[UILabel alloc]initWithFrame:CGRectMake(43, 14, 100, 21)];
        productLabel.font = [UIFont systemFontOfSize:15];
        productLabel.tag = 22;
        [cell.contentView addSubview:productLabel];
        
        //描述
        UILabel *stateLabel = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 230, 15, 200, 15)];
        stateLabel.textColor = [UIColor colorWithHexString:@"#AAAAAA"];
        stateLabel.font = [UIFont systemFontOfSize:10];
        stateLabel.tag = 33;
        stateLabel.textAlignment = NSTextAlignmentRight;
        [cell.contentView addSubview:stateLabel];
        
        //箭头
        UIImageView *imgNav = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 33, 12, 25, 24)];
        imgNav.image = [UIImage imageNamed:@"my_next.png"];
        [cell.contentView addSubview:imgNav];
        
        //分割线
        UIImageView *imgLine = [[UIImageView alloc] initWithFrame:CGRectMake(0, 50-ONEPIXL, SCREEN_WIDTH, ONEPIXL)];
        imgLine.backgroundColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:imgLine];
        
    }
    UIImageView *ImageView = [cell.contentView viewWithTag:11];
    UILabel *productLabel = [cell.contentView viewWithTag:22];
    UILabel *stateLabel = [cell.contentView viewWithTag:33];
    
    NSArray *arr = [infoArray objectAtIndex:indexPath.row];
    ImageView.image = [UIImage imageNamed:[arr objectAtIndex:0]];
    productLabel.text = [arr objectAtIndex:1];
    stateLabel.text = [arr objectAtIndex:2];
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

- (void)getUserHeadInfo{
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Personal" forKey:@"Mod"];
    [dic setObject:@"PersonalInfo" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dic setObject:dicContent forKey:@"Content"];

    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        int code = [[resultDic  objectForKey:@"Code"] intValue];
        if (code == 0000) {
            
            if ([[resultDic objectForKey:@"DetailInfo"] isKindOfClass:[NSDictionary class]]) {
                
                //加载头像
                NSString *imgUrl = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"head_pic"];
                if (imgUrl.length > 0) {
                    
                    [_imgHead XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:[UIImage imageNamed:@"my_head.png"]] ;
                }else{
                    [_imgHead setImage:[UIImage imageNamed:@"my_head.png"]];
                }
                _lbName.text = [MyAppDelegate.userInfo objectForKey:@"phone"];
            }
        }
    }];
}

#pragma mark - 退出登录
- (void)loginOut:(NSNotification *)notify{
    [MyAppDelegate makeTabBarHidden:NO];
    [MyAppDelegate setTabSelect:0];
    
}
@end
