//
//  ChangePasswordVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/8.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "ChangePasswordVC.h"

@interface ChangePasswordVC (){
    __weak IBOutlet UITextField *_tfPassOld;
    __weak IBOutlet UITextField *_tfPassNew;
    __weak IBOutlet UITextField *_tfPassConfirm;
}

@end

@implementation ChangePasswordVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"修改密码";
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [MyAppDelegate makeTabBarHidden:YES];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MyAppDelegate makeTabBarHidden:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)changePass:(id)sender{
    if(![_tfPassNew.text isEqualToString:_tfPassConfirm.text] ){
        [self showAlert:nil withTitle:@"请输入2次一致密码！" haveCancelButton:NO];
        return;
    }else if(_tfPassOld.text.length == 0){
        [self showAlert:nil withTitle:@"请输入旧密码！" haveCancelButton:NO];
        return;
    }else if(_tfPassNew.text.length > 12 || _tfPassNew.text.length < 6){
        [self showAlert:nil withTitle:@"请输入6-12位密码" haveCancelButton:NO];
        return;
    }
    
    NSMutableDictionary *contentDic = [[NSMutableDictionary alloc]init];
    [contentDic setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
    [contentDic setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    [contentDic setObject:_tfPassOld.text forKey:@"user_pass"];
    [contentDic setObject:_tfPassNew.text forKey:@"new_pass"];
    [contentDic setObject:_tfPassConfirm.text forKey:@"repasswd"];
    [contentDic setObject:@"1" forKey:@"devicetype"];
    [contentDic setObject:KVERSION forKey:@"version_name"];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    [dic setObject:@"UserChange" forKey:@"Mod"];
    [dic setObject:@"Modify" forKey:@"Act"];
    [dic setObject:contentDic forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        int code = [[resultDic  objectForKey:@"Code"] intValue];
        if (code == 0000) {
            if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
                [self showAlert:nil withTitle:@"修改成功！" haveCancelButton:NO];
                [self.navigationController popViewControllerAnimated:YES];
            }
        }else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
        
    }];
}

@end
