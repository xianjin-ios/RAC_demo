//
//  MyCustomServiceVC.h
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface MyCustomServiceVC : BaseViewController

@end
