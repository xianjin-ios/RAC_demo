//
//  MyOrderVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/28.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "MyOrderVC.h"
#import "MyOrderDetailVC.h"

@interface MyOrderVC ()<UITableViewDelegate, UITableViewDataSource, MJRefreshBaseViewDelegate>{
    MJRefreshHeaderView *_header;
    MJRefreshFooterView *_footer;
    __weak IBOutlet UITableView *_iTableView;
    
    int pageIndex;
    NSMutableArray *_dataArr;
}

@end

@implementation MyOrderVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的交易";
    pageIndex = 1;

    self.view.backgroundColor = [UIColor whiteColor];
    [self cancelTapHideKeyBoard:YES];
    
    _dataArr = [[NSMutableArray alloc]init];
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _iTableView;
    _header.delegate = self;
    
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = _iTableView;
    _footer.delegate = self;
    
    [self performSelector:@selector(getOrderList) withObject:nil afterDelay:0.1];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)getOrderList{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Order" forKey:@"Mod"];
    [dic setObject:@"myTrade_v1" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    
    if ([MyAppDelegate.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
        [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"uid"];
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"phone"] forKey:@"user_login_name"];
    [dicContent setObject:[NSNumber numberWithInt:pageIndex] forKey:@"pageindex"];
    [dicContent setObject:[NSNumber numberWithInt:20] forKey:@"pagesize"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            
            
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        int code = [[resultDic  objectForKey:@"Code"] intValue];
        if (code == 0000) {
            NSArray *listArr = [resultDic objectForKey:@"DetailInfo"];
            if (pageIndex == 1) {
                if (_dataArr.count >0) {
                    [_dataArr removeAllObjects];
                    
                }
            }
            [_dataArr addObjectsFromArray: listArr];
            [_iTableView reloadData];
        }
        
    }];
}

- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self showHUD];
    
    if(refreshView == _header) {// 下拉刷新
        pageIndex = 1;
        [self getOrderList];
    }else if (refreshView == _footer){//上拉加载更多
        if(_dataArr.count%20 == 0){//每页有20个数据
            pageIndex += 1;
            [self getOrderList];
        }
    }
    [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.1];
    
    return;
}


- (void)endHeaderFooterLoading{
    [self hideHUD];
    [_header endRefreshing];
    [_footer endRefreshing];
}

#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArr.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //翻页CELL
    static NSString *CellIdentifier = @"COMMONCELL";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        UILabel *lbTitle = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, SCREEN_WIDTH/3*2 - 15, 20)];
        lbTitle.tag = 201;
        lbTitle.textColor = [UIColor blackColor];
        lbTitle.font = [UIFont systemFontOfSize:15];
        lbTitle.backgroundColor = [UIColor clearColor];
        lbTitle.textAlignment = 0;
        [cell.contentView addSubview:lbTitle];
        lbTitle.text = @"逛逛小店";
        
        UILabel *lbMoney = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH/3*2, 5, SCREEN_WIDTH/3 - 10, 20)];
        lbMoney.tag = 202;
        lbMoney.textColor = [UIColor blackColor];
        lbMoney.font = [UIFont systemFontOfSize:13];
        lbMoney.backgroundColor = [UIColor clearColor];
        lbMoney.textAlignment = 2;
        [cell.contentView addSubview:lbMoney];
        lbMoney.text = @"￥13600.00";
        
        UILabel *lbDetail = [[UILabel alloc]initWithFrame:CGRectMake(10, 30, SCREEN_WIDTH - 20, 20)];
        lbDetail.tag = 203;
        lbDetail.textColor = [UIColor blackColor];
        lbDetail.font = [UIFont systemFontOfSize:13];
        lbDetail.backgroundColor = [UIColor clearColor];
        lbDetail.textAlignment = 0;
        [cell.contentView addSubview:lbDetail];
        lbDetail.text = @"现金";
        
        UILabel *lbType = [[UILabel alloc]initWithFrame:CGRectMake(10, 55, SCREEN_WIDTH/2 - 15, 20)];
        lbType.tag = 204;
        lbType.textColor = [UIColor blackColor];
        lbType.font = [UIFont systemFontOfSize:13];
        lbType.backgroundColor = [UIColor clearColor];
        lbType.textAlignment = 0;
        [cell.contentView addSubview:lbType];
        lbType.text = @"支付成功";
        
        UILabel *lbTime = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH/2, 55, SCREEN_WIDTH/2 - 10, 20)];
        lbTime.tag = 205;
        lbTime.textColor = [UIColor blackColor];
        lbTime.font = [UIFont systemFontOfSize:13];
        lbTime.backgroundColor = [UIColor clearColor];
        lbTime.textAlignment = 2;
        [cell.contentView addSubview:lbTime];
        lbTime.text = @"2015-08-11 11:11:11";
        
        UIView *downLine = [[UIView alloc]initWithFrame:CGRectMake(0, 79.5, SCREEN_WIDTH, 0.5)];
        downLine.backgroundColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:downLine];
    }
    
    UILabel *lbTitle = (UILabel *)[cell.contentView viewWithTag:201];
    UILabel *lbMoney = (UILabel *)[cell.contentView viewWithTag:202];
    UILabel *lbDetail = (UILabel *)[cell.contentView viewWithTag:203];
    UILabel *lbType = (UILabel *)[cell.contentView viewWithTag:204];
    UILabel *lbTime = (UILabel *)[cell.contentView viewWithTag:205];
    
    lbTitle.text = [NSString stringWithFormat:@"%@",[[_dataArr objectAtIndex:indexPath.row] objectForKey:@"shopname"]];
    
    lbMoney.text = [NSString stringWithFormat:@"￥%.2f",[[[_dataArr objectAtIndex:indexPath.row] objectForKey:@"fee"] doubleValue]/100.0];
    
    int detailValue = [[[_dataArr objectAtIndex:indexPath.row] objectForKey:@"payway"] intValue];
    switch (detailValue) {
        case 1:
            lbDetail.text = @"mpos支付";
            break;
        case 2:
            lbDetail.text = @"支付宝";
            break;
        case 3:
            lbDetail.text = @"银联";
            break;
        case 4:
            lbDetail.text = @"现金";
            break;
            
        default:
            lbDetail.text= @"微信支付";
            break;
    }
    
    int typeValue = [[[_dataArr objectAtIndex:indexPath.row] objectForKey:@"paystatus"] intValue];
    if (typeValue == 1) {
        lbType.text = @"成功";
    }else if (typeValue == 2){
        lbType.text = @"失败";
    }
    
    NSString *timeStr = [[_dataArr objectAtIndex:indexPath.row] objectForKey:@"ctime"];
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:[timeStr integerValue]];
    NSDateFormatter  *dateformatter = [[NSDateFormatter alloc] init];
    [dateformatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    [dateformatter setTimeZone:[NSTimeZone systemTimeZone]];
    NSString *  locationString = [dateformatter stringFromDate:date];
    lbTime.text = locationString;
    
    return cell;
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyOrderDetailVC *ctrl = [[MyOrderDetailVC alloc]init];
    ctrl.infoDic = [_dataArr objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:ctrl animated:YES];
}
@end
