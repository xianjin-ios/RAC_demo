//
//  GrabCouponVC.m
//  GGSH_Refactoring
//
//  Created by STAR on 16/10/10.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "GrabCouponVC.h"
#import "qiangquanVC.h"

@interface GrabCouponVC ()<UITableViewDataSource,UITableViewDelegate>{
    __weak IBOutlet UITableView *_iTableView;
    
    NSMutableArray *_dataArray;
}

@end

@implementation GrabCouponVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"抢券通知";
    
    [self setBeaconData];
    [_iTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - tableView
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 66;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dicMessage = [_dataArray objectAtIndex:indexPath.row];
    
    //翻页CELL
    static NSString *CellIdentifier = @"COMMONCELL";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.clipsToBounds = YES;
        
        //图标
        UIImageView *merchantIcon = [[UIImageView alloc]initWithFrame:CGRectMake(8, 16, 34, 34)];
        merchantIcon.tag = 101;
        merchantIcon.image = [UIImage imageNamed:@"_0001_system.png"];
        [cell.contentView addSubview:merchantIcon];
        
        NSString *imgUrl = [dicMessage objectForKey:@"listpic"];
        [merchantIcon XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:nil];
        
        //提示标识
        UIImageView *imageAlert = [[UIImageView alloc]initWithFrame:CGRectMake(38, 12, 9, 9)];
        [imageAlert setImage:[UIImage imageNamed:@"imageAlert_s.png"]];
        [imageAlert setTag:1011];
        [cell.contentView addSubview:imageAlert];
        
        if ([dicMessage objectForKey:@"isread"] && [[dicMessage objectForKey:@"isread"] integerValue] != 1) {
            [imageAlert setHidden:NO];
        }else{
            [imageAlert setHidden:YES];
            
        }
        
        //标题
        UILabel * lbTitle = [[UILabel alloc] init];
        lbTitle.tag = 12;
        lbTitle.backgroundColor = [UIColor clearColor];
        lbTitle.font = [UIFont systemFontOfSize:15];
        lbTitle.textColor = [UIColor blackColor];
        [cell.contentView addSubview:lbTitle];
        lbTitle.frame = CGRectMake(50, 10, _iTableView.frame.size.width - 180, 20 );
        lbTitle.text = [dicMessage objectForKey:@"shopname"];
        
        //时间
        UILabel * lbTime = [[UILabel alloc] init];
        lbTime.tag = 13;
        lbTime.textAlignment = NSTextAlignmentRight;
        lbTime.backgroundColor = [UIColor clearColor];
        lbTime.font = [UIFont systemFontOfSize:13];
        lbTime.textColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:lbTime];
        lbTime.frame = CGRectMake(self.view.frame.size.width - 120, 10, 100, 15 );
        NSString * strTime = [dicMessage objectForKey:@"time" ];
        if (strTime == nil) {
            lbTime.text = @"";
        }
        else{
            
            lbTime.text = strTime;
            
        }
        //摘要
        UILabel * lbContent = [[UILabel alloc] init];
        lbContent.tag = 14;
        lbContent.backgroundColor = [UIColor clearColor];
        lbContent.font = [UIFont systemFontOfSize:13];
        lbContent.textColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:lbContent];
        lbContent.frame = CGRectMake(50, 36, _iTableView.frame.size.width - 60, 20 );
        lbContent.text = @"小店开始派券，快去抢吧！";
        
        UIView *downLine = [[UIView alloc]initWithFrame:CGRectMake(0, 65.5, _iTableView.frame.size.width, 0.5)];
        downLine.backgroundColor = [UIColor lightGrayColor];
        [cell.contentView addSubview:downLine];
        
    }
    
    //商店图标
    UIImageView *merchantIcon = (UIImageView *)[cell.contentView viewWithTag:101];
    NSString *imgUrl = [dicMessage objectForKey:@"listpic"];
    if (imgUrl.length > 0) {
        [merchantIcon XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:nil];
    }else{
        merchantIcon.image = [UIImage imageNamed:@"_0001_system.png"];
    }
    
    UIImageView *imageAlert = (UIImageView *)[cell.contentView viewWithTag:1011];
    if ([dicMessage objectForKey:@"isread"] && [[dicMessage objectForKey:@"isread"] integerValue] != 1) {
        [imageAlert setHidden:NO];
    }else{
        [imageAlert setHidden:YES];
        
    }
    
    //标题
    UILabel * lbTitle = (UILabel*)[cell.contentView viewWithTag:12];
    lbTitle.text = [dicMessage objectForKey:@"shopname"];
    
    //时间
    UILabel * lbTime = (UILabel*)[cell.contentView viewWithTag:13];
    NSString * strTime = [dicMessage objectForKey:@"time" ];
    if (strTime == nil) {
        lbTime.text = @"";
    }
    else{
        
        lbTime.text = strTime;
        
    }
    
    UILabel *lbContent = (UILabel *)[cell.contentView viewWithTag:14];
    lbContent.text = @"小店开始派券，快去抢吧！";
    
    return cell;
    
}

//点击进入详情页面
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSDictionary *dic = [_dataArray objectAtIndex:indexPath.row];
    NSString *uuidStr = [dic objectForKey:@"uuid"];
    NSString *majorStr = [dic objectForKey:@"major"];
    NSString *minorStr = [dic objectForKey:@"minor"];
    
    //修改isread标示改为已读
    for(NSMutableDictionary *tempdic in MyAppDelegate.beaconsInfoArray){
        NSString *tempuuidStr = [tempdic objectForKey:@"uuid"];
        NSString *tempmajorStr = [tempdic objectForKey:@"major"];
        NSString *tempminorSTr = [tempdic objectForKey:@"minor"];
        
        if([tempuuidStr isEqualToString:uuidStr] && [tempmajorStr isEqualToString:majorStr] && [tempminorSTr isEqualToString:minorStr]){
            [tempdic setObject:@"1" forKey:@"isread"];
            
            [self setBeaconData];
            [_iTableView reloadData];
        }
    }
    //跳转到抢券界面
    qiangquanVC *vc = [[qiangquanVC alloc]initWithUUID:uuidStr Major:majorStr minor:minorStr];
    vc.is_notification = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *dic = [_dataArray objectAtIndex:indexPath.row];
    NSString *str1 = [dic objectForKey:@"uuid"];
    NSString *str2 = [dic objectForKey:@"major"];
    NSString *str3 = [dic objectForKey:@"minor"];
    for(NSMutableDictionary *dic in MyAppDelegate.beaconsInfoArray){
        NSString *uuidStr = [dic objectForKey:@"uuid"];
        NSString *majorStr = [dic objectForKey:@"major"];
        NSString *minorSTr = [dic objectForKey:@"minor"];
        
        if([str1 isEqualToString:uuidStr] && [str2 isEqualToString:majorStr] && [str3 isEqualToString:minorSTr]){
            [dic setObject:@"0" forKey:@"isnotification"];
            
            [self setBeaconData];
            [_iTableView reloadData];
        }
    }
}

#pragma mark - 设置要显示商家数据
- (void)setBeaconData{
    if(!_dataArray){
        _dataArray = [NSMutableArray array];
    }
    [_dataArray removeAllObjects];
    
    for(NSDictionary *dic in MyAppDelegate.beaconsInfoArray){
        if([[dic objectForKey:@"isnotification"] isEqualToString:@"1"]){
            [_dataArray addObject:dic];
        }
    }
}

@end
