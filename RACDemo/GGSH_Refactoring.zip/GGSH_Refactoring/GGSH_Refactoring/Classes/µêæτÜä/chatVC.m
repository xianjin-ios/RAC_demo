//
//  chatVC.m
//  CcbCloudPay
//  聊天界面
//  Created by 任春宁 on 15/5/7.
//  Copyright (c) 2015年 xkdx. All rights reserved.
//

#import "chatVC.h"
#import "chatTextCell.h"
#import "chatTimeCell.h"
#import "UIImage+FixRotation.h"

@interface chatVC ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,SELECTPIC_DELEGATE>
{
    UIView *bgLicenseView;

    NSMutableDictionary *userheadDic;
}
@end

@implementation chatVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_tableView setFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_VIEW_HEIGHT)];
    self.view.backgroundColor = [UIColor colorWithHexString:@"#f0f0f0"];
    
    _header = [MJRefreshHeaderView header];
    _header.scrollView = _tableView;
    _header.delegate = self;
    
    //创建聊天输入框
    //创建下方的输入面板
    _msgInputBoardCtrl = [[MessageInputBoardVC alloc] init];
    _msgInputBoardCtrl.view.frame = CGRectMake(0, SCREEN_VIEW_HEIGHT - 50 , SCREEN_WIDTH, SCREEN_HEIGHT);
    _msgInputBoardCtrl.delegate = self;
    [self.view addSubview:_msgInputBoardCtrl.view];
    
    //设置标题
    self.title = [self.dicChatInfo objectForKey:@"shopname"];
    
    //获取数据
    [self performSelector:@selector(getNewMessagelist) withObject:nil afterDelay:0.1];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}
//获取聊天数据
-(void)getMessagelistByStarttime:(NSString*)starttime endTime:(NSString*)endtime old:(BOOL)isOld{
    
    NSString * shopId = [self.dicChatInfo objectForKey:@"shopid"];
    if (shopId == nil || shopId.length == 0) {
        [self showAlert:nil withTitle:@"请先开通云商城" haveCancelButton:NO];
        return;
    }
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Communication" forKey:@"Mod"];
    [dic setObject:@"details" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    [dicContent setObject:@"" forKey:@"admid"];
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    [dicContent setObject:shopId forKey:@"shopid"];
    [dicContent setObject:starttime forKey:@"starttime"];
    [dicContent setObject:endtime forKey:@"endtime"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        //此处需要合并数据
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            
            NSDictionary * dicDetail = [resultDic objectForKey:@"DetailInfo"];
            
            NSArray * arrMsg = [dicDetail objectForKey:@"info"];
            //判断是否有数据
            if (arrMsg.count > 0) {
                
                //保存头像
                NSDictionary *tempHeadDic = [NSDictionary dictionaryWithObjectsAndKeys:
                                             [dicDetail objectForKey:@"username"],@"username",
                                             [dicDetail objectForKey:@"user_pic_assetid"],@"user_pic_assetid",
                                             [dicDetail objectForKey:@"shopname"],@"shopname",
                                             [dicDetail objectForKey:@"listpic"],@"listpic",
                                             nil];
                userheadDic = [tempHeadDic mutableCopy];
                
                [self mergeMessagelist:arrMsg old:isOld];
                
                [_tableView reloadData];
            }else{
                
            }
            
            
            if (isOld) {
                [self performSelector:@selector(scrollToHeader) withObject:nil afterDelay:0.5];
            }
            else{
                [self performSelector:@selector(scrollToFooter) withObject:nil afterDelay:0.5];
            }
            
            
        }
        
        [_header endRefreshing];
        
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(getNewMessagelist) object:nil];
        [self performSelector:@selector(getNewMessagelist) withObject:nil afterDelay:10];
        
    }];
}

//合并消息
-(void)mergeMessagelist:(NSArray *)arrMsg old:(BOOL)isOld{
    
    if (arrMsg.count == 0) {
        return;
    }

    if (_arrMessages.count == 0) {
        _arrMessages = [arrMsg mutableCopy];
        
        [self addTimeTag];
        return;
    }
    
    //1.删除时间TAG
    [self delTimeTag];
    
    
    //2.然后排序插入
    
    if (isOld) {
        
        for (int i = (int)arrMsg.count - 1; i >=0 ; i -- ) {
            NSDictionary * dicMsgNew = [arrMsg objectAtIndex:i];
            [_arrMessages insertObject:dicMsgNew atIndex:0];
        }
        
    }
    else{
        for (int i = 0; i < arrMsg.count; i ++) {
            NSDictionary * dicMsgNew = [arrMsg objectAtIndex:i];
            NSString * strIDNew = [dicMsgNew objectForKey:@"id"];
            
            BOOL isContain = NO;
            for (int j = 0; j < _arrMessages.count; j ++) {
                NSDictionary * dicMsg = [_arrMessages objectAtIndex:j];
                NSString * strID = [dicMsg objectForKey:@"id"];
                
                if ([strIDNew isEqualToString:strID]) {
                    isContain = YES;
                    break;
                }
            }
            
            if (isContain) {
                continue;
            }
            
            [_arrMessages addObject:dicMsgNew];
            
        }
    }
    
    //3.再重新生成时间类型
    [self addTimeTag];
}

-(void)delTimeTag{
    
    //1.首先删除所有的时间类型
    for (int j = (int)_arrMessages.count - 1; j >= 0; j --) {
        NSDictionary * dicMsg = [_arrMessages objectAtIndex:j];
        
        //判断如果是时间类型，则不处理
        NSString * strType = [[dicMsg objectForKey:@"type"]description];
        if ( strType != nil && [strType isEqualToString:@"time"]) {
            [_arrMessages removeObject:dicMsg];
        }
    }
}

-(void)addTimeTag{
    
    NSString * strTimeTmp = nil;
    
    for (int j = 0; j < _arrMessages.count; j ++) {
        
        if (j == _arrMessages.count - 1) {
            
        }
        
        NSDictionary * dicMsg = [_arrMessages objectAtIndex:j];
        NSString * strTime = [dicMsg objectForKey:@"time"];
        
        if (strTimeTmp == nil) {
            strTimeTmp = strTime;
            
            NSMutableDictionary * dicTime = [[NSMutableDictionary alloc] init];
            [dicTime setObject:@"time" forKey:@"type"];
            [dicTime setObject:strTime forKey:@"content"];
            [_arrMessages insertObject:dicTime atIndex:j];
            
            j ++;
            continue;
        }

        int seconds = [strTime intValue] - [strTimeTmp intValue];
        //如果超过3分钟，插入时间类型
        if (seconds >= 3 * 60 ) {
            
            NSMutableDictionary * dicTime = [[NSMutableDictionary alloc] init];
            [dicTime setObject:@"time" forKey:@"type"];
            [dicTime setObject:strTime forKey:@"content"];
            [_arrMessages insertObject:dicTime atIndex:j];
            
            j ++;
        }
        
        strTimeTmp = strTime;
        
    }
    
}


#pragma mark -
#pragma mark MessageInputBoardVCDelegate

-(void)moveView:(UIView*)view toRect:(CGRect)r duration:(float)duration hide:(BOOL)hide{
    
    CGRect rcTable = _tableView.frame;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.25];
    _msgInputBoardCtrl.view.frame = r;
    _tableView.frame = CGRectMake(rcTable.origin.x, 0, rcTable.size.width, r.origin.y );
    
    [UIView commitAnimations];
    
    //判断是否是隐藏输入框，如果是，则不滚动table
    if (!hide) {
        int cell_index = (int)_arrMessages.count - 1;
        if (cell_index >= 0) {
            [_tableView scrollToRowAtIndexPath:
             [NSIndexPath indexPathForRow:cell_index inSection:0]
                              atScrollPosition:UITableViewScrollPositionBottom
                                      animated:NO];
        }
    }
    
    
}

//处理media事件,现在只有相册和拍照
-(void)clickOnButton:(int)tag
{
    if( (tag<0) || (tag>1) )
    {
        return;
    }
    
    
    UIImagePickerControllerSourceType sourceType[2] =
    {
        UIImagePickerControllerSourceTypePhotoLibrary,
        UIImagePickerControllerSourceTypeCamera
    };
    
    if([UIImagePickerController isSourceTypeAvailable:sourceType[tag]])
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.sourceType = sourceType[tag];
        NSArray *temp_MediaTypes = [UIImagePickerController availableMediaTypesForSourceType:picker.sourceType];
        picker.mediaTypes = temp_MediaTypes;
        picker.delegate = self;
        picker.allowsEditing = YES;
        [self presentViewController:picker animated:YES completion:^{}];
    }
    
    ZLog(@"off.y=%f", _tableView.contentOffset.y);
}

//拍照后，或者选择照片后，照片处理
- (void)imagePickerController: (UIImagePickerController *)picker didFinishPickingMediaWithInfo: (NSDictionary *)info{
    
    NSURL *videoURL = [info objectForKey:UIImagePickerControllerMediaURL];
    AVAsset *asset = [AVURLAsset URLAssetWithURL:videoURL options:info];
    NSArray *tracks = [asset tracksWithMediaType:AVMediaTypeVideo];
    //判断是否含有视频轨道
    BOOL hasVideoTrack = [tracks count] > 0;
    if (hasVideoTrack) {
        [picker dismissViewControllerAnimated:YES completion:^{
            [self showAlert:nil withTitle:@"不支持发送视频文件！" haveCancelButton:NO];
        }];
        return;
    }
    
    
    UIImage *selectImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    selectImage = [selectImage fixOrientation];//修正iOS图片旋转90度问题
    
    [picker dismissViewControllerAnimated:YES completion:^{

        //发送图片接口
        [self sendImage:selectImage];
        
    }];

}

//发送图片
- (void)sendImage:(UIImage *)selectImage{
    
    [[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(getNewMessagelist) object:nil];

    NSString * shopId = [self.dicChatInfo objectForKey:@"shopid"];
    if (shopId == nil || shopId.length == 0) {
        [self showAlert:nil withTitle:@"请先开通云商城" haveCancelButton:NO];
        return;
    }
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Information" forKey:@"Mod"];
    [dic setObject:@"illegal" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    [dicContent setObject:@"" forKey:@"admid"];
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    [dicContent setObject:shopId forKey:@"shopid"];
    [dicContent setObject:@"" forKey:@"content"];
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
    [dicContent setObject:[NSNumber numberWithInt:1] forKey:@"type"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];

    [dic setObject:dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        //此处需要合并数据
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            NSMutableDictionary * dicDetail = [[resultDic objectForKey:@"DetailInfo"] mutableCopy];
            [dicDetail setObject:selectImage forKey:@"defaultpic"];
            
            NSMutableArray * arrTmpMsg = [[NSMutableArray alloc] initWithArray:_arrMessages];
            [arrTmpMsg addObject:dicDetail];
            _arrMessages = arrTmpMsg;
            
            [self delTimeTag];
            [self addTimeTag];
            
            [_msgInputBoardCtrl clearText];
            
            //把结果数据插入到本地列表
            [_tableView reloadData];
            _tableView.hidden = NO;
            
            [self performSelector:@selector(scrollToFooterWithAnimation) withObject:nil afterDelay:0.2];
        }
        else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
        
    }];
}

//发送信息
-(void)sendMessage:(NSString*)text{
    
    [[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(getNewMessagelist) object:nil];

    if (text.length == 0) {
        [self showAlert:nil withTitle:@"请输入内容" haveCancelButton:NO];
        return;
    }
    
    NSString * shopId = [self.dicChatInfo objectForKey:@"shopid"];
    if (shopId == nil || shopId.length == 0) {
        [self showAlert:nil withTitle:@"请先开通云商城" haveCancelButton:NO];
        return;
    }
    
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"Information" forKey:@"Mod"];
    [dic setObject:@"illegal" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    [dicContent setObject:@"" forKey:@"admid"];
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    [dicContent setObject:shopId forKey:@"shopid"];
    
    [dicContent setObject:text forKey:@"content"];
    [dicContent setObject:[MyAppDelegate.userInfo objectForKey:@"id"] forKey:@"uid"];
    [dicContent setObject:[NSNumber numberWithInt:0] forKey:@"type"];
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];

    [dic setObject: dicContent forKey:@"Content"];
    
    [xkNetwork xk_requstWithDic:dic withUrl:kMposAppUrl withRequestMethod:@"POST" isHTTPS:NO andMultiPartFile:nil andGetData:^(id data, NSError *error) {
        if (data == nil || error != nil) {
            NSLog(@"kong");
            return;
        }
        NSString *tempStr = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"str : %@",tempStr);
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        //此处需要合并数据
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            
            NSDictionary * dicDetail = [resultDic objectForKey:@"DetailInfo"];
            
            NSMutableArray * arrTmpMsg = [[NSMutableArray alloc] initWithArray:_arrMessages];
            [arrTmpMsg addObject:dicDetail];
            _arrMessages = arrTmpMsg;
            
            [self delTimeTag];
            [self addTimeTag];
            
            [_msgInputBoardCtrl clearText];
            
            //把结果数据插入到本地列表
            [_tableView reloadData];
            _tableView.hidden = NO;
            
            [self performSelector:@selector(scrollToFooterWithAnimation) withObject:nil afterDelay:0.2];
        }
        else{
            [self showAlert:nil withTitle:[resultDic objectForKey:@"Message"] haveCancelButton:NO];
        }
        
    }];
}


#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_arrMessages count];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dicMsg = [_arrMessages objectAtIndex:indexPath.row];
    NSString * strType = [[dicMsg objectForKey:@"type"]description];
    
    if (strType != nil && [strType isEqualToString:@"time"]) {
        return [chatTimeCell getHeight:dicMsg];
    }
    
    return [chatTextCell getHeight:dicMsg] + 30;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    NSDictionary * dicMsg = [_arrMessages objectAtIndex:indexPath.row];
//    NSString * type = [[dicMsg objectForKey:@"type"] description];//消息类型（1为图片，0为文本）

    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //翻页CELL
    static NSString *CellIdentifierText = @"TEXTCELL";
    static NSString *CellIdentifierTime = @"TIMECELL";
    
    NSDictionary * dicMsg = [_arrMessages objectAtIndex:indexPath.row];
    NSString * strType = [[dicMsg objectForKey:@"type"] description];
    
    if (strType != nil && [strType isEqualToString:@"time"]) {
        chatTimeCell *cell = (chatTimeCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifierTime];
        
        if (cell == nil)
        {
            cell = [[chatTimeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifierTime];
            cell.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        
        
        //加载数据
        [cell initData:dicMsg];
        
        return cell;
        
    }
    
    chatTextCell *cell = (chatTextCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifierText];
    
    if (cell == nil)
    {
        cell = [[chatTextCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifierText];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.delegate = self;

    cell.userheadDic = userheadDic;
    
    //加载数据
    [cell initData:dicMsg];
    
    return cell;
    
}

-(void)selectpic:(NSDictionary * )dicMsg{
    CGRect rec = MyAppDelegate.window.bounds;
    bgLicenseView = [[UIView alloc] initWithFrame:rec];
    bgLicenseView.backgroundColor = [UIColor blackColor];
    UIImageView *imgV = [[UIImageView alloc] initWithFrame:rec];
    [bgLicenseView addSubview:imgV];
    UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hidePicView)];
    tapGr.cancelsTouchesInView = NO;
    [bgLicenseView addGestureRecognizer:tapGr];
    NSString *imgUrl = [dicMsg objectForKey:@"pic"];
    [imgV XK_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:nil];
    imgV.contentMode = UIViewContentModeScaleAspectFit;
    [MyAppDelegate.window addSubview:bgLicenseView];
    return;
}

- (void)hidePicView{
    [bgLicenseView removeFromSuperview];
    bgLicenseView = nil;
}

#pragma mark -
#pragma UIScrollViewDelegate

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [_msgInputBoardCtrl hide];
}

//显示最新的一条
-(void)scrollToFooterWithAnimation{
    
    if (_arrMessages.count == 0) {
        return;
    }
    
    int cell_index = (int)[_arrMessages count] - 1;
    [_tableView scrollToRowAtIndexPath:
     [NSIndexPath indexPathForRow:cell_index inSection:0]
                      atScrollPosition:UITableViewScrollPositionBottom
                              animated:YES];
    
    [self performSelector:@selector(getNewMessagelist) withObject:nil afterDelay:10];
}

-(void)scrollToHeader{
    [_tableView scrollsToTop];
}

-(void)scrollToFooter{
    _tableView.hidden = NO;
    if (_arrMessages.count == 0) {
        return;
    }
    
    if (_tableView.contentSize.height > _tableView.frame.size.height)
    {
        CGPoint offset = CGPointMake(0, _tableView.contentSize.height - _tableView.frame.size.height);
        [_tableView setContentOffset:offset animated:NO];
        
    }
}


//获取最新数据
//获取最新数据
-(void)getNewMessagelist{
    NSLog(@"getNewMessagelist");
    
    //发送阅读通知
    [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshMessageNetData" object:nil];
    
    //刷新未读消息数量
    [MyAppDelegate getNoReadInfo];
    
    NSString * strEndTime = @"";
    
    if (_arrMessages.count > 0) {
        NSDictionary * dicMsg = [_arrMessages objectAtIndex:_arrMessages.count - 1];
        
        strEndTime = [dicMsg objectForKey:@"time"];
    }
    
    [self getMessagelistByStarttime:@"" endTime:strEndTime old:NO];
}

//获取最新数据
-(void)getOldMessagelist{
    NSLog(@"getOldMessagelist");
    
    NSString * strStartTime = @"";
    
    if (_arrMessages.count > 1) {
        NSDictionary * dicMsg = [_arrMessages objectAtIndex:1];
        
        strStartTime = [dicMsg objectForKey:@"time"];
    }
    
    [self getMessagelistByStarttime:strStartTime endTime:@"" old:YES];
}

-(void)backAction{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(getNewMessagelist) object:nil];
    
    [self.navigationController popViewControllerAnimated:YES];

}

#pragma mark -
#pragma mark MJRefreshBaseViewDelegate

- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self getOldMessagelist];
}

- (void)endHeaderFooterLoading{
    [_header endRefreshing];
    
}

@end
