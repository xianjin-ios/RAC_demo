//
//  MyOrderDetailVC.h
//  GGSH_Refactoring
//
//  Created by STAR on 16/9/29.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import "BaseViewController.h"

@interface MyOrderDetailVC : BaseViewController
@property (nonatomic,strong) NSDictionary *infoDic;
@end
