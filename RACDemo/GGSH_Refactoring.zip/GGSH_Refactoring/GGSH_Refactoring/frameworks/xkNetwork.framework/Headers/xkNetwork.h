//
//  xkNetwork.h
//  xkNetwork
//
//  Created by huadong on 16/9/2.
//  Copyright © 2016年 huadong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+SBJSON.h"

@interface xkNetwork : NSObject

#pragma mark - baseReqest
/**
 综合请求

 @param dic     字典类型的请求参数
 @param urlStr  请求URL
 @param method  请求方式
 @param ishttps 是否https
 @param fileDic 上传文件信息
 @param block   返回block
 */
+ (void)xk_requstWithDic:(NSDictionary *)dic withUrl:(NSString *)urlStr withRequestMethod:(NSString *)method isHTTPS:(BOOL)ishttps andMultiPartFile:(NSDictionary *)fileDic andGetData:(void (^)(id data, NSError *error))block;

#pragma mark - other
/**
 *  检查网络
 *
 *  @return 0：无网络
 *          1：手机网络
 *          2：WiFi网络
 *          3：其他网络
 */
+ (NSInteger )checkNetStatus;

/**
 *  检测更具体的手机网络信息
 *
 *  @return 返回手机网络名称
 */
+ (NSString *)matchTelephoneNet;

/**
 *  返回手机ip地址
 *
 *  @param preferIPv4 是否ipv4
 *  @param isen0      是否返回内网
 *
 *  @return 返回手机ip地址
 */
+ (NSString *)getIPAddress:(BOOL)preferIPv4 en0:(BOOL)isen0;

/**
 *  设置网络超时时间
 *
 *  @param newTimeOutSeconds 超时时间
 */
+ (void)xk_setDefaultTimeOutSeconds:(NSTimeInterval)newTimeOutSeconds;



@end
