//
//  XKProgressHUD.h
//  XK-IOS_Framework
//
//  Created by siqiyang on 16/9/9.
//  Copyright © 2016年 mengxianjin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XKProgressHUD : UIView

+ (instancetype)sharedProgressHUD;
/**
 *  将hud显示到指定的view视图上
 *
 *  @param view     指定的view视图
 *
 *
 */
- (void)XK_showHUDAddedTo:(UIView *)view animated:(BOOL)animated;
//隐藏
- (void)XK_hideHUDForView:(UIView *)view animated:(BOOL)animated;
/**
 *  隐藏某个view上的hud
 *
 *  @param view           view
 *  @param completionHint 隐藏之后的提示
 */
- (void)XK_hideHUDForView:(UIView *)view showCompletionHint:(NSString *)completionHint animated:(BOOL)animated;
/**
 *  将hud显示到指定的view视图上
 *
 *  @param view     指定的view视图
 *  @param title    提示的文字信息
 *
 */
- (void)XK_showHUDAddedTo:(UIView *)view withHintTitle:(NSString *)title animated:(BOOL)animated;

/**
 *  将hud添加到window上面
 *
 *  @param title    提示的文字信息
 *
 */
- (void)XK_showHUDAddedToWindowWithHintTitle:(NSString *)title animated:(BOOL)animated;

//隐藏
- (void)XK_hidenHUDforWindowAnimated:(BOOL)animated;

@end
