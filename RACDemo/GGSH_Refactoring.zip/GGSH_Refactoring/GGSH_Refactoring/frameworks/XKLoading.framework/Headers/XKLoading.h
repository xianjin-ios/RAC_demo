//
//  XKLoading.h
//  XKLoading
//
//  Created by siqiyang on 16/9/12.
//  Copyright © 2016年 mengxianjin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XKProgressHUD.h"
//! Project version number for XKLoading.
FOUNDATION_EXPORT double XKLoadingVersionNumber;

//! Project version string for XKLoading.
FOUNDATION_EXPORT const unsigned char XKLoadingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XKLoading/PublicHeader.h>


