//
//  starDyLib.h
//  starDyLib
//
//  Created by STAR on 16/9/6.
//  Copyright © 2016年 XK. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for starDyLib.
FOUNDATION_EXPORT double starDyLibVersionNumber;

//! Project version string for starDyLib.
FOUNDATION_EXPORT const unsigned char starDyLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <starDyLib/PublicHeader.h>
#import "AESCrypt.h"
#import "NSData+Base64.h"
#import "NSData+CommonCrypto.h"
#import "NSString+Base64.h"
#import "XKEncAndDec.h"

//#define SCREEN_WIDTH ([[UIScreen mainScreen]bounds].size.width)
////判断iphone 6＋ 6s+
//#define IS_PLUS (SCREEN_WIDTH == 414)
//
////视图右下角坐标
//#define tailX(v) (v.frame.origin.x + v.frame.size.width)
//#define tailY(v) (v.frame.origin.y + v.frame.size.height)
//
//#define MyAppDelegate ((AppDelegate*)[[UIApplication sharedApplication] delegate])
//
//#define USERDEFAULT [NSUserDefaults standardUserDefaults]
//
//#ifdef DEBUG
//#define ZLog(format, ...) do {                                                                  \
//NSLog((@"%s[Line %d]" format),__PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);                                                   \
//fprintf(stderr, "-----------------\n");                             \
//}while (0)
//#else
//#define ZLog(format, ...) {}
//#endif
//
///*
// *一相数
// */
//#define ONE_PIXL (1/([UIScreen mainScreen].scale))
