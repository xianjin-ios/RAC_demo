//
//  NSString+MD5.h
//  starDyLib
//
//  Created by STAR on 16/9/9.
//  Copyright © 2016年 XK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)

//md5加密
- (NSString *)xkMd5HexDigest:(NSString*)input;

@end
