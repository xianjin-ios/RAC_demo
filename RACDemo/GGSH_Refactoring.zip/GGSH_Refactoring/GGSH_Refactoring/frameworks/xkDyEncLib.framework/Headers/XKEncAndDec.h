//
//  XKEncAndDec.h
//  starDyLib
//
//  Created by STAR on 16/9/8.
//  Copyright © 2016年 XK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XKEncAndDec : NSObject

- (NSString*)addString : (NSString*)strA
                andStr : (NSString*)strB;

@end
