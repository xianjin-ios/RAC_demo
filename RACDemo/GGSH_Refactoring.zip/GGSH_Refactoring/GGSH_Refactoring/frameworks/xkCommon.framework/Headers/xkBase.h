//
//  xkBase.h
//  xkCommon
//
//  Created by STAR on 16/9/9.
//  Copyright © 2016年 XK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface xkBase : NSObject
//时间戳转换为时间
-(NSString*)XKstringToStamp:(NSString*)strTime format:(NSString*)format;
/*
 *功能 时间戳转日期
 *参数 strStamp ：时间戳
 *返回 时间NSDate型
 */
- (NSDate*)XKstampToDate:(NSString*)strStamp;

- (NSString *)XKstampToDate:(NSString*)strStamp format:(NSString *)format;

@end
