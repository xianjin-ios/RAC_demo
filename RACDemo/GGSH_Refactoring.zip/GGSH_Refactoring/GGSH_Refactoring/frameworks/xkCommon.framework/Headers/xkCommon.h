//
//  xkCommon.h
//  xkCommon
//
//  Created by STAR on 16/9/9.
//  Copyright © 2016年 XK. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "xkBase.h"

//! Project version number for xkCommon.
FOUNDATION_EXPORT double xkCommonVersionNumber;

//! Project version string for xkCommon.
FOUNDATION_EXPORT const unsigned char xkCommonVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <xkCommon/PublicHeader.h>


