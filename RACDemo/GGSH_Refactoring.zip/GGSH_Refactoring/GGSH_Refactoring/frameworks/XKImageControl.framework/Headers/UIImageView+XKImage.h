//
//  UIImageView+XKImage.h
//  XK-IOS_Framework
//
//  Created by siqiyang on 16/9/6.
//  Copyright © 2016年 mengxianjin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SDWebImageManager.h"

@interface UIImageView (XKImage)

/**
 *  加载网络图片
 *
 *  @param url         图片的url,NSString或者NSURL
 *  @param placeholder 占位图片，没有占位图片时，可设为nil
 */
- (void)XK_setImageWithURL:(id)url placeholderImage:(UIImage *)placeholder;

/**
 *  使用Block,采用这个方案可以在网络图片加载过程中得知图片的下载进度和图片是否加载成功
 *
 *  @param url             图片的url,NSString或者NSURL
 *  @param placeholder     占位图片，没有占位图片时，可设为nil
 *  @param completionBlock 在网络图片加载过程中得知图片的下载进度和图片是否加载成功
 */

- (void)XK_setImageWithURL:(id)url placeholderImage:(UIImage *)placeholder complete:(SDWebImageCompletionBlock)completionBlock;

/**
 *   加载网络图片时是否显示旋转进度轮
 *
 *  @param url          图片的url,NSString或者NSURL
 *  @param placeholder 占位图片，没有占位图片时，可设为nil
 */
- (void)XK_setImageWithURL:(id)url placeholderImage:(UIImage *)placeholder isShowActivity:(BOOL)isShow;



@end
