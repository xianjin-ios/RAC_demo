//
//  XKImageControl.h
//  XKImageControl
//
//  Created by siqiyang on 16/9/12.
//  Copyright © 2016年 mengxianjin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XKImageTool.h"
#import "UIImageView+XKImage.h"


//! Project version number for XKImageControl.
FOUNDATION_EXPORT double XKImageControlVersionNumber;

//! Project version string for XKImageControl.
FOUNDATION_EXPORT const unsigned char XKImageControlVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XKImageControl/PublicHeader.h>


