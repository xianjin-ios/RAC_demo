//
//  XKImageTool.h
//  XK-IOS_Framework
//
//  Created by siqiyang on 16/9/6.
//  Copyright © 2016年 mengxianjin. All rights reserved.
//首先，我们必须明确图片的压缩其实是两个概念：
//“压” 是指文件体积变小，但是像素数不变，长宽尺寸不变，那么质量可能下降。
//“缩” 是指文件的尺寸变小，也就是像素数减少，而长宽尺寸变小，文件体积同样会减小。

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "SDWebImageManager.h"
@interface XKImageTool : NSObject

/**
 *  将原图片按体积压缩
 *
 *  @param sourceImage 原图片
 *  @param scale       压缩比例，0 ~ 1
 *
 *  @return 压缩后的图片
 */
+ (UIImage *)XK_compressImage:(UIImage *)sourceImage withScale:(CGFloat)scale ;
/**
 *  将原图片按照一定的尺寸进行缩放
 *
 *  @param image   原图片
 *  @param newSize 新的尺寸
 *
 *  @return 新的图片
 */
+(UIImage*)XK_imageWithImage:(UIImage*)image scaledToSize:(CGSize)newSize;

/**
 *   压缩图片至目标尺寸
 *
 *  @param sourceImage 原图
 *  @param targetWidth 图片最终的宽度
 *
 *  @return 压缩后的图片
 */
+ (UIImage *)XK_compressImage:(UIImage *)sourceImage toTargetWidth:(CGFloat)targetWidth;

/**
 *  对于不合规定大小或者比例的图片裁剪中间部分，或者按比例缩小
 *
 *  @param originalImage 原图
 *  @param size          标准尺寸，
 *
 *  @return 处理过的图片
 */
+ (UIImage *)XK_handleImage:(UIImage *)originalImage withSize:(CGSize)size;

#pragma mark - 加载GIF图片
+ (UIImage *)XK_animatedGIFNamed:(NSString *)name;

+ (UIImage *)XK_animatedGIFWithData:(NSData *)data;

+ (UIImage *)XK_animatedImageByScalingAndCroppingToSize:(CGSize)size;

/**
 *  图片下载的操作
 *
 *  @param url           图片的url
 *  @param progressBlock 下载进程的监控（总大小和已下载）
 *  @param completeBlock 下载完成时的操作
 */
+ (void)handleDownloadImageWithURL:(NSURL *)url protions:(SDWebImageDownloaderProgressBlock)progressBlock completed:(SDWebImageCompletionWithFinishedBlock)completeBlock;



#pragma mark -- 图片的解压
+ (UIImage *)decodeImage:(UIImage *)sourceImage;


@end
