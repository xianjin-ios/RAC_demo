//
//  ViewController.m
//  GuideViewController
//
//  Created by 发兵 杨 on 12-9-6.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+Load.h"

@implementation ViewController
@synthesize imageView;
@synthesize left = _left;
@synthesize right = _right;
@synthesize pageScroll;
@synthesize pageControl;


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    pageControl.numberOfPages = 6;
    pageControl.currentPage = 0;
    UIWindow *window = [[UIApplication sharedApplication].windows lastObject];
    pageScroll.delegate = self;
    pageScroll.frame = CGRectMake(0, -20, 320, window.frame.size.height+20);
    pageScroll.contentSize = CGSizeMake(320 * 6, self.view.frame.size.height);
    for (int i = 0; i < 6; i++) {
        NSString *imageUrl;
        if(IS_IPHONE5){
            imageUrl = [NSString stringWithFormat:@"%d_5", i+1];
        }else{
            imageUrl = [NSString stringWithFormat:@"%d", i+1];
        }
        UIImageView *imageLeadView = [[UIImageView alloc]initWithImage:[UIImage loadImg:imageUrl]];
        imageLeadView.frame = CGRectMake(320*i, 0, 320, window.frame.size.height);
        [pageScroll addSubview:imageLeadView];
        [imageLeadView release];
    }
}

- (void)endLading{
    [self.navigationController popViewControllerAnimated:NO];
}

-(void)dealloc
{
    for(UIView *v in pageScroll.subviews){
        [v removeFromSuperview];
    }
    [pageScroll removeFromSuperview];
    self.view = nil;
    [super dealloc];
}

- (void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context
{
//    if ([animationID isEqualToString:@"split"] && finished) {
//        
//        [self.left removeFromSuperview];
//        [self.right removeFromSuperview];
//        NextViewController *controller = [[NextViewController alloc] init];
//        [self presentModalViewController:controller animated:YES];
//        [controller release];
//        
//        
//    }  
}

- (IBAction)gotoMainView:(id)sender {
    
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"alreadyLaunch"];
    NSArray *array = [UIImage splitImageIntoTwoParts:self.imageView.image];
    self.left = [[UIImageView alloc] initWithImage:[array objectAtIndex:0]];
    self.right = [[UIImageView alloc] initWithImage:[array objectAtIndex:1]];
    [self.view addSubview:self.left];
    [self.view addSubview:self.right];
    [self.pageScroll setHidden:YES];
    [self.pageControl setHidden:YES];
    self.left.transform = CGAffineTransformIdentity;
    self.right.transform = CGAffineTransformIdentity;
    
    [UIView beginAnimations:@"split" context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDuration:1];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    
    self.left.transform = CGAffineTransformMakeTranslation(-160 ,0);
    self.right.transform = CGAffineTransformMakeTranslation(160 ,0);   
    [UIView commitAnimations];
    
}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{	
    CGFloat pageWidth = self.view.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    pageControl.currentPage = page;
    if(5 == page){
        [USERDEFAULT setBool:YES forKey:@"alreadyLaunch"];
        [self performSelector:@selector(endLading) withObject:nil afterDelay:2];
    }
}

@end
