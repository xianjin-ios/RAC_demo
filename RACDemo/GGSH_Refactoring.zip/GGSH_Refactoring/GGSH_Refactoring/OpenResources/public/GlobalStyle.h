//
//  GlobalStyle.h
//  LifeSearch
//
//  Created by kekey on 11-10-21.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//


#define UM_RGBCOLOR(r,g,b)      [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1]
#define UM_RGBACOLOR(r,g,b,a)   [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]


//search bar tintcolor
#define UM_SEARCHBAR_TINTCOLOR  UM_RGBCOLOR(111,107,102)

//view background color
#define UM_VIEW_BACKGROUND_COLOR    [UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]]

#define UM_ISRETINA    ([UIScreen mainScreen].scale == 2)


//文本颜色
#define UM_TEXTCOLOR_DARKBLACK      UM_RGBCOLOR(25,0,0)//深黑色
#define UM_TEXTCOLOR_REDBROWN       UM_RGBCOLOR(108,30,0)//红棕色
#define UM_TEXTCOLOR_BROWN          UM_RGBCOLOR(105,75,43)//褐色
#define UM_TEXTCOLOR_GRAY           UM_RGBCOLOR(121,114,104)//灰色
#define UM_TEXTCOLOR_ORANGE        UM_RGBCOLOR(251,176,59)//橘黄色