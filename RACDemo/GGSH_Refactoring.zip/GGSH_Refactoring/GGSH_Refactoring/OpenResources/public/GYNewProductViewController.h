//
//  GYNewProductViewController.h
//  逛逛
//
//  Created by STAR on 13-3-5.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"
#import "UAAsyncImageView.h"
#import "MBProgressHUD.h"
#import "SBJsonWriter.h"
#import "SBJsonParser.h"
#import "UAAsyncImageView.h"
#import "XLCycleScrollView.h"
#import <MessageUI/MessageUI.h>
#import "SinaWeibo.h"

#define ACTION_SHEET_GET_USER_INFO 200
#define ACTION_SHEET_FOLLOW_USER 201
#define ACTION_SHEET_GET_OTHER_USER_INFO 202
#define ACTION_SHEET_GET_ACCESS_TOKEN 203
#define ACTION_SHEET_PRINT_COPY 306

#define LEFT_PADDING 10.0
#define RIGHT_PADDING 10.0
#define HORIZONTAL_GAP 10.0
#define VERTICAL_GAP 10.0

@interface GYNewProductViewController : BaseViewControllerGGSH<UITableViewDataSource, UITableViewDelegate,XLCycleScrollViewDatasource,XLCycleScrollViewDelegate, UIActionSheetDelegate,MFMessageComposeViewControllerDelegate,SinaWeiboDelegate,SinaWeiboRequestDelegate>{
    //详细内容的高度
    float contentHeight;
    
//    MBProgressHUD *HUD;
    MFMessageComposeViewController *MSMpicker;
}
@property (nonatomic, retain) NSMutableArray *dataArray;
@property (nonatomic, retain) NSMutableArray *picArray;
@property (nonatomic, retain) IBOutlet UITableViewCell *topcell;
@property (nonatomic, retain) IBOutlet UITableViewCell *seccell;
@property (nonatomic, retain) IBOutlet UITableView *iMyTableView;
@property (nonatomic, retain) IBOutlet UILabel *numLabel;
@property (nonatomic, retain) IBOutlet UILabel *titleLabel;
@property (nonatomic, retain) IBOutlet UILabel *detailLabel;
//@property (nonatomic, retain)  ASIFormDataRequest *netrequest;
@property (nonatomic, retain) IBOutlet UILabel *timeLabel;
@property (nonatomic, retain)  NSString *picurl;

-(void)request:(int)infoid;
@end
