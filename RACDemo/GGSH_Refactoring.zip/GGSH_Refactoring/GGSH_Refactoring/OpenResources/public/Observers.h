//
//  Observers.h
//  GuangGuang
//
//  Created by STAR on 14-3-10.
//
//

#ifndef GuangGuang_Observers_h
#define GuangGuang_Observers_h

//登录后的调用
@protocol loginDelegate <NSObject>
@optional
- (void)finishLogin;
- (void)failedLogin;
- (void)cancelLogin;
@end

//注册后调用
@protocol registerDelegate <NSObject>
@required
- (void)finishRegister;
@end

#endif
