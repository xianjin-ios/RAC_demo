//
//  GYBigpicViewController.m
//  cards
//
//  Created by STAR on 12-12-20.
//  Copyright (c) 2012年 STAR. All rights reserved.
//

#import "GYBigpicViewController.h"
#import "AppDelegate.h"

@interface GYBigpicViewController ()

@end

@implementation GYBigpicViewController
-(void)dealloc{
    imageBigView = nil;
    imageView = nil;
    [super dealloc];
}
-(void)showHUD{
    HUD = [[MBProgressHUD alloc]initWithView:self.view];
    //    HUD.frame = CGRectMake(140, 240, 40, 40);
    [self.view addSubview:HUD];
    [self.view bringSubviewToFront:HUD];
    HUD.labelText = @"加载中...";
    [HUD show:YES];
}

-(void)hideHUD{
    [HUD removeFromSuperview];
    [HUD release];
    HUD = nil;
}

-(IBAction)backAction{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        backButton.frame = CGRectMake(0.0, 0.0, 44.5, 30.0);
        [backButton setImage:[UIImage imageNamed:@"btnReturn.png"] forState:UIControlStateNormal];
        [backButton setImage:[UIImage imageNamed:@"btnReturn.png"] forState:UIControlStateSelected];
        [backButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        [backButton setTitle:@"查找" forState:UIControlStateNormal];
        UIBarButtonItem *temporaryBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
        temporaryBarButtonItem.style = UIBarButtonItemStylePlain;
        self.navigationItem.leftBarButtonItem = temporaryBarButtonItem;
        [temporaryBarButtonItem release];
        
        self.title = @"图片";
        if(IS_IOS7)
            self.navigationItem.titleView = [GLBDELEGATE setTitle:@"图片"];
    }
    return self;
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
	if(!isbigpic)
        return;
    return;//增加了控件，不用响应了。
	CGPoint p1;
	CGPoint p2;
	CGFloat sub_x;
	CGFloat sub_y;
	CGFloat currentDistance;
	CGRect imgFrame;
	
	NSArray * touchesArr=[[event allTouches] allObjects];
	
    ZLog(@"手指个数%d",[touchesArr count]);
    //    ZLog(@"%@",touchesArr);
	
	if ([touchesArr count]>=2) {
		p1=[[touchesArr objectAtIndex:0] locationInView:self.view];
		p2=[[touchesArr objectAtIndex:1] locationInView:self.view];
		
		sub_x=p1.x-p2.x;
		sub_y=p1.y-p2.y;
		
		currentDistance=sqrtf(sub_x*sub_x+sub_y*sub_y);
		
		if (lastDistance>0) {
			
			imgFrame=imageView.frame;
			
			if (currentDistance>lastDistance+2) {
				ZLog(@"放大");
				
				imgFrame.size.width+=10;
				if (imgFrame.size.width>1000) {
					imgFrame.size.width=1000;
				}
				
				lastDistance=currentDistance;
			}
			if (currentDistance<lastDistance-2) {
				ZLog(@"缩小");
				
				imgFrame.size.width-=10;
				
				if (imgFrame.size.width<50) {
					imgFrame.size.width=50;
				}
				
				lastDistance=currentDistance;
			}
			
			if (lastDistance==currentDistance) {
				imgFrame.size.height=imgStartHeight*imgFrame.size.width/imgStartWidth;
                
                float addwidth=imgFrame.size.width-imageView.frame.size.width;
                float addheight=imgFrame.size.height-imageView.frame.size.height;
                
				imageView.frame=CGRectMake(imgFrame.origin.x-addwidth/2.0f, imgFrame.origin.y-addheight/2.0f, imgFrame.size.width, imgFrame.size.height);
			}
			
		}else {
			lastDistance=currentDistance;
		}
        
	}
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
	lastDistance=0;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)loadImageFromURL:(NSString*) url bigurl: (NSString *)url2{
    picurl2 = url2;
    imageView = [[UAAsyncImageView alloc ]init];
    imageView.frame = CGRectMake(0, 0, 320, 480);
    NSURL *picurl = [NSURL URLWithString:url];
    [imageView loadImageFromURL:picurl];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    [self.view addSubview:imageView];
    [imageView release];
    imageView.delegate = self;
    [self showHUD];
}

- (void)cropImage {
	ImageCropper *cropper = [[ImageCropper alloc] initWithImage:[imageView image]];
	[cropper setDelegate:self];
    [self presentViewController:cropper animated:YES completion:nil];
	
	[cropper release];
}

- (void)imageCropper:(ImageCropper *)cropper didFinishCroppingWithImage:(UIImage *)image {
	
    [self dismissViewControllerAnimated:YES completion:nil];
	
	[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
}

- (void)imageCropperDidCancel:(ImageCropper *)cropper {
    [self dismissViewControllerAnimated:YES completion:nil];
	
	[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
}
-(void)getbigimage{
    imageBigView = [[UAAsyncImageView alloc]init];
    imageBigView.delegate = self;
    [imageBigView loadImageFromURL:[NSURL URLWithString:picurl2]];
    [HUD show:YES];
    isbigpic = 1;
}
-(void)finishdownload:(NSURL *)url{
    [self hideHUD];
    
    //若是大图，直接响应大图处理
    if(1 == isbigpic){
        imageBigView.frame = CGRectMake(0, 0, 320, 367);
        
        [self.view addSubview:imageBigView];
        [imageBigView release];
        [self cropImage];
        return;
    }
    
    
    if(IS_IPHONE5){
        imageView.frame = CGRectMake(0, 0, 320, 455);
    }else{
        imageView.frame = CGRectMake(0, 0, 320, 367);
    }
    ZLog(@"image size:%f,%f",imageView.image.size.width,imageView.image.size.height);
    
    
//    UIImage* image= [UIImage imageNamed:@"btnNavDefault.png"];
//    CGRect frame_1= CGRectMake(0, 0, 51, 30);
//    UIButton* doneButton= [[UIButton alloc] initWithFrame:frame_1];
//    [doneButton setBackgroundImage:image forState:UIControlStateNormal];
//    [doneButton setTitle:@"原图" forState:UIControlStateNormal];
//    [doneButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    doneButton.titleLabel.font=[UIFont systemFontOfSize:13];
//    [doneButton addTarget:self action:@selector(getbigimage) forControlEvents:UIControlEventTouchUpInside];
//    UIBarButtonItem* someBarButtonItem= [[UIBarButtonItem alloc] initWithCustomView:doneButton];
//    self.navigationItem.rightBarButtonItem = someBarButtonItem;
//    [someBarButtonItem release];
//    [doneButton release];
}
@end
