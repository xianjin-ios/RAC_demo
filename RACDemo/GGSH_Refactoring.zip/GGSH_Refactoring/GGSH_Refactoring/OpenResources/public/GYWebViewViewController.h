//
//  GYWebViewViewController.h
//  cards
//
//  Created by STAR on 13-1-9.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChromeProgressBar.h"
#import "IMTWebView.h"
#import "BaseViewControllerGGSH.h"
@interface GYWebViewViewController : BaseViewControllerGGSH<UIWebViewDelegate, IMTWebViewProgressDelegate>{
    UIProgressView *chromeBar;
}
@property (nonatomic, retain) IBOutlet IMTWebView *webview;
@property (nonatomic, copy) NSString *url;
-(void)loadurl: (NSString*)url;
- (void)setTetle:(NSString *)title;
@end
