//
//  GYBigpicViewController.h
//  cards
//
//  Created by STAR on 12-12-20.
//  Copyright (c) 2012年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UAAsyncImageView.h"
#import "ImageCropper.h"
#import "MBProgressHUD.h"
@interface GYBigpicViewController : UIViewController<ImageCropperDelegate, downloaddelegate>{
    //手势的标注
    int isbigpic;
    MBProgressHUD *HUD;
    CGFloat lastDistance;
	
	CGFloat imgStartWidth;
	CGFloat imgStartHeight;
    
    UAAsyncImageView *imageView;
    UAAsyncImageView *imageBigView;
    NSString *picurl2;
    
}
-(void)loadImageFromURL:(NSString*) url bigurl: (NSString *)url2;

@end
