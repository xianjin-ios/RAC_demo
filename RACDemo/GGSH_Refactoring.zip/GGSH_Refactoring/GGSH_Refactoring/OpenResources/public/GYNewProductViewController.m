//
//  GYNewProductViewController.m
//  逛逛
//
//  Created by STAR on 13-3-5.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import "GYNewProductViewController.h"

//#import <AGCommon/UINavigationBar+Common.h>
//#import <AGCommon/UIImage+Common.h>
//#import <AGCommon/UIColor+Common.h>
//#import <AGCommon/UIDevice+Common.h>

#import "AppDelegate.h"

@interface GYNewProductViewController ()

@end

@implementation GYNewProductViewController
@synthesize iMyTableView;
@synthesize timeLabel;
@synthesize topcell,seccell;
@synthesize dataArray, picArray;

#pragma HUD
-(void)showHUD{
    HUD = [[MBProgressHUD alloc]initWithView:self.view];
    //    HUD.frame = CGRectMake(140, 240, 40, 40);
    [self.view addSubview:HUD];
    [self.view bringSubviewToFront:HUD];
    HUD.labelText = @"加载中...";
    [HUD show:YES];
}
-(void)dispearHUD{
    [HUD removeFromSuperview];
    [HUD release];
    HUD = nil;
}


-(void)request:(int)infoid{
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"DeviceID"];
    [item setObject:[NSNumber numberWithInt:infoid] forKey:@"InfoID"];
    SBJsonWriter *json = [[SBJsonWriter alloc] init];
    NSString *jsonString = [json stringWithObject:item];
    [json release];
    [item release];
    NSURL *url = [NSURL URLWithString:kInfoDetail];
    self.netrequest= [ASIFormDataRequest requestWithURL:url];
    ZLog(@"%@",jsonString);
    
    [self.netrequest setPostValue:jsonString forKey:@"JsonString"];
    self.netrequest.userInfo = [NSDictionary dictionaryWithObject:@"detail" forKey:@"type"];
    [GLBDELEGATE checkNetStatus];
    [self.netrequest setDelegate:self];
    [self.netrequest setDidFailSelector:@selector(timeoutFuction)];
    [self.netrequest startAsynchronous];
    
    [self showHUD];
}

//网络失败时候调用。
- (void)timeoutFuction{
    self.netrequest.delegate = nil;
    [self.netrequest cancel];
    [self dispearHUD];
}

- (void)requestFinished:(ASIHTTPRequest *)request {
    [HUD hide:YES];
	NSString *responseString = [request responseString];
	SBJsonParser *parser = [SBJsonParser new];
	NSMutableDictionary *results = [parser objectWithString:responseString];
    [parser release];
    
    if(request.userInfo && [[request.userInfo objectForKey:@"type"] isEqualToString:@"detail"] ){
        ZLog(@"***********%@",results);
        NSString *istr = [[[results objectForKey:@"Result"] objectForKey:@"DetailInfo"]objectForKey:@"BeginTime"];
        NSString *istr2 = [[[results objectForKey:@"Result"] objectForKey:@"DetailInfo"]objectForKey:@"EndTime"];
        self.timeLabel.text = [NSString stringWithFormat:@"%@  至  %@",istr ,istr2];
        
        self.picArray = [[[results objectForKey:@"Result"] objectForKey:@"DetailInfo"]objectForKey:@"PictureUrl"];

        self.detailLabel.text = [[[results objectForKey:@"Result"] objectForKey:@"DetailInfo"] objectForKey:@"InfoContent"];
        self.titleLabel.text = [[[results objectForKey:@"Result"] objectForKey:@"DetailInfo"] objectForKey:@"InfoTitle"];
        
        self.dataArray = [NSMutableArray arrayWithCapacity:3];
        if(self.picArray.count > 1){
            for(int i = 0; i < self.picArray.count; i++){
                NSMutableString *imagePath = [self.picArray objectAtIndex:i];
                int strlen = imagePath.length;
                if(strlen > 4){
                    imagePath = [NSMutableString stringWithFormat:@"%@%@%@",[imagePath substringToIndex:(strlen - 4)], @"_L", [imagePath substringFromIndex:(strlen - 4)]];
                }
                
                NSURL *url = [NSURL URLWithString:imagePath];
                ZLog(@"url is :%@",url);
                
                UAAsyncImageView *m = [[UAAsyncImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 300)];
                [m loadImageFromURL:url];
                m.tag = 106;
                [self.dataArray addObject:m];
                [m release];
            }
            
            
            self.numLabel.text = [NSString stringWithFormat:@"%d", self.picArray.count];
            
            XLCycleScrollView *csView = [[[XLCycleScrollView alloc] initWithFrame:CGRectMake(0.0,0.0,320.0,300.0)]retain];//self.view.bounds];
            csView.backgroundColor = [UIColor lightGrayColor];
            csView.delegate = self;
            csView.datasource = self;
            [self.topcell addSubview:csView];
        }else if(1 == self.picArray.count){
            //当只有一张图片时，没显示出图片，这里再加一张图片。
            NSMutableString *imagePath = [self.picArray objectAtIndex:0];
            int strlen = imagePath.length;
            if(strlen > 4){
                imagePath = [NSMutableString stringWithFormat:@"%@%@%@",[imagePath substringToIndex:(strlen - 4)], @"_L", [imagePath substringFromIndex:(strlen - 4)]];
            }
            UAAsyncImageView *onlyOneUAImage = [[UAAsyncImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 300)];
            NSURL *url = [NSURL URLWithString:imagePath];
            [onlyOneUAImage loadImageFromURL:url];
            onlyOneUAImage.tag = 106;
            [self.topcell addSubview:onlyOneUAImage];
            [onlyOneUAImage release];
        }
        [self.iMyTableView reloadData];
    }
}

#pragma mark -
#pragma mark tableview 
- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(0 == indexPath.row){
        return topcell;
    }else if(1 == indexPath.row){
        self.detailLabel.frame = CGRectMake(10, 30, 300, contentHeight);
        seccell.frame = CGRectMake(0, 0, 300, contentHeight + 40);
        seccell.contentView.backgroundColor = [UIColor blackColor];
        return seccell;
    }
    return nil;
}

//指定有多少个分区(Section)，默认为1
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

//指定每个分区中有多少行，默认为1
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2 ;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPat {
    if(0 == indexPat.row){
        return 300;
    }else if (1 == indexPat.row){
        CGSize boundingSize = CGSizeMake(300, CGFLOAT_MAX);
        
        UIFont *dateFont = [UIFont systemFontOfSize:14];
        
        CGSize dateStringSize = [self.detailLabel.text sizeWithFont:dateFont
                                                  constrainedToSize:boundingSize
                                                      lineBreakMode:NSLineBreakByWordWrapping
                                 ];
        contentHeight = dateStringSize.height;
        return contentHeight + 40;
    }
    return 0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

#pragma 轮播图
- (NSInteger)numberOfPages
{
    ZLog(@"pic array is :%@",self.picArray);
    return self.picArray.count;
}

- (UIView *)pageAtIndex:(NSInteger)index
{
    int i = index;
    if(0 == i){
        i = self.picArray.count;
    }
    self.numLabel.text = [NSString stringWithFormat:@"%d/%d",i,self.picArray.count];
    UIView *view = [self.dataArray objectAtIndex:index];
    view.frame = CGRectMake(0, 0, 320, 300);
    return view;

}

- (void)didClickPage:(XLCycleScrollView *)csView atIndex:(NSInteger)index
{
    
}
- (NSMutableString *)getPathForImage
{
    if(1 == self.picArray.count){
        //当只有一张图片时，没显示出图片，这里再加一张图片。
        NSMutableString *imagePath = [self.picArray objectAtIndex:0];
        int strlen = imagePath.length;
        if(strlen > 4){
            imagePath = [NSMutableString stringWithFormat:@"%@%@%@",[imagePath substringToIndex:(strlen - 4)], @"_L", [imagePath substringFromIndex:(strlen - 4)]];
        }
        return imagePath;
    }
    return nil;
}

#pragma 轮播图 end

-(IBAction)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 分享功能
- (void)shareAction:(id)sender
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:@"分享"
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"分享到新浪微博",@"分享到微信朋友圈",@"通过短信分享",nil];
    
    [actionSheet setDelegate:self];
    [actionSheet showInView:[UIApplication sharedApplication].keyWindow];
    [actionSheet release];
}

#pragma mark - actionSheet 分享信息
- (void)actionSheet:(UIActionSheet *)actionSheet
didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if (buttonIndex != [actionSheet cancelButtonIndex]){
        if(0 == buttonIndex ){
            // post image status 分享到新浪
            SinaWeibo *sinaweibo = GLBDELEGATE.sinaweibo;
            if(!sinaweibo){
                GLBDELEGATE.sinaweibo = [[SinaWeibo alloc]initWithAppKey:kAppKey appSecret:kAppSecret appRedirectURI:kAppRedirectURI andDelegate:self];
                sinaweibo = GLBDELEGATE.sinaweibo;
                if(!sinaweibo.isLoggedIn){
                    [sinaweibo logIn];
                    return;
                }
            }
            UIImage *shareImage = ((UAAsyncImageView*)[self.view viewWithTag:106]).image;
            if(!shareImage){
                shareImage = [UIImage imageNamed:self.picurl];
            }
            [sinaweibo requestWithURL:@"statuses/upload.json"
                               params:[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                       self.detailLabel.text, @"status",
                                       shareImage, @"pic", nil]
                           httpMethod:@"POST"
                             delegate:self];
            [self showHUD];
        }else if(1 == buttonIndex){
            UIImage *shareImage = ((UAAsyncImageView*)[self.view viewWithTag:106]).image;
            if(!shareImage){
                shareImage = [UIImage imageNamed:self.picurl];
            }
            [GLBDELEGATE sendImageContent:shareImage];
        }else if(2 == buttonIndex){
            //分享短信
            MSMpicker = [[MFMessageComposeViewController alloc] init];
            MSMpicker.messageComposeDelegate =self;
            NSString *smsBody =[NSString stringWithFormat:@"%@:%@",self.titleLabel.text,self.detailLabel.text] ;
            MSMpicker.body=smsBody;
            [self presentViewController:MSMpicker animated:YES completion:nil];
            [MSMpicker release];
        }
        ZLog(@"%d",buttonIndex);
    }else if (buttonIndex == [actionSheet cancelButtonIndex]){
        ZLog(@"%d",buttonIndex);
    }
}

//短信发完了
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result{
    [MSMpicker dismissViewControllerAnimated:YES completion:nil];
}

//新浪分享完成
- (void)request:(SinaWeiboRequest *)request didFailWithError:(NSError *)error
{
    if ([request.url hasSuffix:@"statuses/upload.json"])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                            message:@"Post image failed!"
                                                           delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alertView show];
        [alertView release];
        NSLog(@"Post image status failed with error : %@", error);
    }
}
- (void)request:(SinaWeiboRequest *)request didFinishLoadingWithResult:(id)result
{
    [self dispearHUD];
    ZLog(@"%@",result);
    if ([request.url hasSuffix:@"statuses/upload.json"])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                            message:[NSString stringWithFormat:@"Post image status \"%@\" succeed!", [result objectForKey:@"text"]]
                                                           delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alertView show];
        [alertView release];
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        UIButton *shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
        shareButton.frame = CGRectMake(0.0, 0.0,41, 27);
        [shareButton setImage:[UIImage imageNamed:@"shareApplication.png"] forState:UIControlStateNormal];
        [shareButton addTarget:self action:@selector(shareAction:) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *shareBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:shareButton];
        shareBarButtonItem.style = UIBarButtonItemStylePlain;
        self.navigationItem.rightBarButtonItem=shareBarButtonItem;
        [shareBarButtonItem release];
        self.title = @"新品信息";
        if(IS_IOS7)
            self.navigationItem.titleView = [GLBDELEGATE setTitle:@"新品信息"];
    }
    return self;
}


- (void)viewDidLoad
{
    [iMyTableView setDataSource:self];
    [iMyTableView setDelegate:self];
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    // Do any additional setup after loading the view from its nib.
}

- (void)dealloc
{
    if (self.netrequest)
    {
        [self.netrequest setDelegate:nil];
        [self.netrequest cancel];
        self.netrequest = nil;
    }
    [self.dataArray removeAllObjects];
    self.dataArray = nil;
    self.picArray = nil;
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
