//
//  PushMsgParser.h
//  LifeSearch
//
//  Created by kekey on 13-6-8.
//
//

#import <Foundation/Foundation.h>

@interface PushMsgParser : NSObject

////msg是苹果推送消息推送过来的整个消息信息字典
//- (void)parseWithPushPayload:(NSDictionary *)payload;

@end
