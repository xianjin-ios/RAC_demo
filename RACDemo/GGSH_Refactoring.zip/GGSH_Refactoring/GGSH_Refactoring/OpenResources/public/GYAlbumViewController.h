//
//  GYAlbumViewController.h
//  guangguang
//
//  Created by STAR on 13-4-19.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UAAsyncImageView.h"
#import "SBJsonWriter.h"
#import "SBJsonParser.h"
#import "ASIFormDataRequest.h"
#import "MBProgressHUD.h"


@interface GYAlbumViewController : BaseViewControllerGGSH<UITableViewDataSource, UITableViewDelegate, UIActionSheetDelegate,MJRefreshBaseViewDelegate,loginDelegate>{
    //图像来源
    int imageflag;//0；来源于相册；1:来源于相机；（相机的照片需要旋转90度）
//    IBOutlet UITableView *iTableView;
    IBOutlet UIImageView *titleView;
    UIButton *btn;
    
//    MBProgressHUD *HUD;
    
    //当前请求页数，默认是1，在viewDidLoad中初始化。一次请求10个图片
    int curPage;
    
    //相册分类
    int picType;    //相册分类处理
    NSURL *imgUrl;  //图片url
    int curPic;     //当前点击图片
    int cellCount;  //返回cell行数
    
    //YES:显示页面的时候push评论的页面；NO：不做处理
    BOOL pushPublishFlag;
}

@property (nonatomic, retain) NSString *shopID;
@property (nonatomic, retain) NSString *brandID;
@property (nonatomic, retain) ASIFormDataRequest *netrequest;
@property (nonatomic, assign) BOOL isMerchant;
- (void)getShopImageList;
- (void)getBrandImageList;
- (void)showAlbum;
- (void)jumpToUserInfo;

@end
