//
//  GYAlbumViewController.m
//  guangguang
//
//  Created by STAR on 13-4-19.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import "GYAlbumViewController.h"
#import "GYPicSubmitViewController.h"
#import "GYGalleryViewController.h"
#import "loginViewControllerGGSH.h"
#import "AppDelegate.h"


@interface GYAlbumViewController ()
{
    MJRefreshFooterView *_footer;
    int kNewHeight;
}
//相册数组
@property (nonatomic, retain) NSMutableArray *dataArray;

@end

@implementation GYAlbumViewController
@synthesize shopID, brandID;
@synthesize netrequest = _netrequest;
@synthesize dataArray=_dataArray;

- (void)dealloc{
    if (self.netrequest)
    {
        [self.netrequest setDelegate:nil];
        [self.netrequest cancel];
        self.netrequest = nil;
    }
    [self hideHUD];
    [titleView release];
    [super dealloc];
}

#pragma HUD
-(void)showHUD{
    if(HUD == nil){
        HUD = [[MBProgressHUD alloc]initWithView:self.view];
        [self.view addSubview:HUD];
        [self.view bringSubviewToFront:HUD];
        HUD.labelText = @"加载中...";
        [HUD show:YES];
    }
}
-(void)hideHUD{
    if(HUD != nil){
        [HUD removeFromSuperview];
        [HUD release];
        HUD = nil;
    }
}


#pragma -mark actionSheet
- (void)actionSheet:(UIActionSheet *)actionSheet
didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if (buttonIndex != [actionSheet cancelButtonIndex]){
        GYPicSubmitViewController *controller = [[GYPicSubmitViewController alloc]init];
        if(shopID){
            controller.shopID = shopID;
            if(self.isMerchant){
                controller.isMerchant = YES;
            }
        }else if(brandID){
            controller.brandID = brandID;
        }else{
            ZLog(@"非商场，非品牌");
        }
        if(0 == buttonIndex ){
            controller.isFromAlbum = NO;
            //            [controller fromCamra:nil];
        }else if (1 == buttonIndex){
            controller.isFromAlbum = YES;
            //            [controller fromAlbum:nil];
        }
        [self.navigationController pushViewController:controller animated:YES];
        
        
        [controller release];
        ZLog(@"%d",buttonIndex);
    }else if (buttonIndex == [actionSheet cancelButtonIndex]){
        ZLog(@"%d",buttonIndex);
    }
}

-(IBAction)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"相册";
        if(IS_IOS7)
            self.navigationItem.titleView = [GLBDELEGATE setTitle:@"相册"];
        
        UIButton *checkButton = [UIButton buttonWithType:UIButtonTypeCustom];
        checkButton.frame = CGRectMake(0.0, 0.0, 25, 20);
        [checkButton setBackgroundImage:[UIImage imageNamed:@"btnCamra.png"] forState:UIControlStateNormal];
        [checkButton setBackgroundImage:[UIImage imageNamed:@"btnCamra.png"] forState:UIControlStateSelected];
        [checkButton addTarget:self action:@selector(showSubmit) forControlEvents:UIControlEventTouchUpInside];
        checkButton.titleLabel.font = [UIFont systemFontOfSize:13];
        UIBarButtonItem *temporaryBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:checkButton];
        temporaryBarButtonItem.style = UIBarButtonItemStylePlain;
        self.navigationItem.rightBarButtonItem = temporaryBarButtonItem;
        [temporaryBarButtonItem release];
        
    }
    return self;
}


- (void)showSubmit{
    //????
    if(![GLBDELEGATE isUserLogin] ){
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"您还没有登录,请登录" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        alertView.tag = 103;
        [alertView show];
        [alertView release];
        return;
    }else{
        UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                      initWithTitle:@"选择图片来源"
                                      delegate:self
                                      cancelButtonTitle:@"取消"
                                      destructiveButtonTitle:nil
                                      otherButtonTitles:@"拍照",@"从手机相册选择",nil];
        
        [actionSheet setDelegate:self];
        [actionSheet showInView:[UIApplication sharedApplication].keyWindow];
        [actionSheet release];
    }
}
#pragma mark alertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(103 == alertView.tag){
        if(buttonIndex == 0){
            return;
        }else if (buttonIndex == 1){
            loginViewControllerGGSH *logInVC = [[loginViewControllerGGSH alloc]init];
            logInVC.delegate = self;
            //????
//            logInVC.albumVC = self;
            UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:logInVC];
            [self presentViewController:navi6 animated:YES completion:nil];
            [logInVC release];
        }
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor= [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgImage.png"]];
    
    //加载数据
    if(shopID){
        
        //这里获取图片数据，默认是全部
        curPage = 1;
        if (self.isMerchant) {
            [self getShopImageList];
        }
        else{
            [self getShopImageList];
        }
        
    }else if (brandID){
        curPage = 1;
        [self getBrandImageList];
    }
    
    //初始化上拉刷新
    _footer = [MJRefreshFooterView footer];
    _footer.scrollView = iTableView;
    _footer.delegate = self;
    
    /*
     tag值：
     1001~1005 是品牌相册
     1006~1012 是商场相册
     1013~1017 是商户相册
     */
    //设置titleView背景图片,判断是从shop还是brand进来的
    kNewHeight = 0;
    if (IS_IOS7) {
        kNewHeight = 49;
    }
    if (brandID) {
        iTableView.frame = CGRectMake(0, 40, 320, self.view.bounds.size.height-40-kNewHeight);
        titleView.frame = CGRectMake(0, 0, 320, 40);
        titleView.image = [UIImage imageNamed:@"Brand_Background.png"];
        //添加按钮
        int btnX = 9;
        int btnY = 8;
        
        for (int i = 0; i < 5; i ++) {
            btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [btn setFrame:CGRectMake(btnX, btnY, 58, 24)];
            [btn setTag:1001 + i];
            btn.titleLabel.font = [UIFont systemFontOfSize:14];
            [btn setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
            [btn setBackgroundImage:[UIImage imageNamed:@"Brand_Btn.png"] forState:UIControlStateSelected];
            [btn addTarget:self action:@selector(doTitleViewBtn:) forControlEvents:UIControlEventTouchUpInside];
            
            switch (i) {
                case 0:
                    [btn setTitle:@"全部" forState:UIControlStateNormal];
                    btn.selected = YES;
                    
                    break;
                case 1:
                    [btn setTitle:@"店面" forState:UIControlStateNormal];
                    btn.selected = NO;
                    break;
                case 2:
                    [btn setTitle:@"产品" forState:UIControlStateNormal];
                    btn.selected = NO;
                    
                    break;
                case 3:
                    [btn setTitle:@"活动" forState:UIControlStateNormal];
                    btn.selected = NO;
                    
                    break;
                case 4:
                    [btn setTitle:@"其他" forState:UIControlStateNormal];
                    btn.selected = NO;
                    
                    break;
                    
                default:
                    break;
            }
            
            [titleView addSubview:btn];
            
            btnX += 320/5-3;
            
        }
        
    }
    else if(shopID){
        if (self.isMerchant) {
            iTableView.frame = CGRectMake(0, 40, 320, self.view.bounds.size.height-40-kNewHeight);
            titleView.frame = CGRectMake(0, 0, 320, 40);
            titleView.image = [UIImage imageNamed:@"Brand_Background.png"];
            //添加按钮
            int btnX = 9;
            int btnY = 8;
            
            for (int i = 0; i < 5; i ++) {
                btn = [UIButton buttonWithType:UIButtonTypeCustom];
                [btn setFrame:CGRectMake(btnX, btnY, 58, 23)];
                [btn setTag:1013 + i];
                btn.titleLabel.font = [UIFont systemFontOfSize:14];
                [btn setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
                [btn setBackgroundImage:[UIImage imageNamed:@"Brand_Btn.png"] forState:UIControlStateSelected];
                [btn addTarget:self action:@selector(doTitleViewBtn:) forControlEvents:UIControlEventTouchUpInside];
                
                switch (i) {
                    case 0:
                        [btn setTitle:@"全部" forState:UIControlStateNormal];
                        btn.selected = YES;
                        
                        break;
                    case 1:
                        [btn setTitle:@"外观" forState:UIControlStateNormal];
                        btn.selected = NO;
                        break;
                    case 2:
                        [btn setTitle:@"店内" forState:UIControlStateNormal];
                        btn.selected = NO;
                        
                        break;
                    case 3:
                        [btn setTitle:@"商品" forState:UIControlStateNormal];
                        btn.selected = NO;
                        
                        break;
                    case 4:
                        [btn setTitle:@"真人秀" forState:UIControlStateNormal];
                        btn.selected = NO;
                        
                        break;
                        
                    default:
                        break;
                }
                
                [titleView addSubview:btn];
                
                btnX += 320/5-3;
                
            }
            
        }
        else{
            iTableView.frame = CGRectMake(0, 66, 320, self.view.bounds.size.height - 66-kNewHeight);
            titleView.frame = CGRectMake(0, 0, 320, 66);
            titleView.image = [UIImage imageNamed:@"Shop_Background.png"];
            //添加按钮
            int btnX = 9;
            int btnY = 6;
            
            for (int i = 0; i < 7; i ++) {
                
                if (btnX >= 280) {
                    btnX = 9;
                    btnY = 12 + 24;
                }
                
                btn = [UIButton buttonWithType:UIButtonTypeCustom];
                [btn setFrame:CGRectMake(btnX, btnY, 58, 24)];
                [btn setTag:1006 + i];
                btn.titleLabel.font = [UIFont systemFontOfSize:14];
                [btn setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
                [btn setBackgroundImage:[UIImage imageNamed:@"Brand_Btn.png"] forState:UIControlStateSelected];
                [btn addTarget:self action:@selector(doTitleViewBtn:) forControlEvents:UIControlEventTouchUpInside];
                
                switch (i) {
                    case 0:
                        [btn setTitle:@"全部" forState:UIControlStateNormal];
                        btn.selected = YES;
                        
                        break;
                    case 1:
                        [btn setTitle:@"外观" forState:UIControlStateNormal];
                        btn.selected = NO;
                        break;
                    case 2:
                        [btn setTitle:@"内景" forState:UIControlStateNormal];
                        btn.selected = NO;
                        
                        break;
                    case 3:
                        [btn setTitle:@"楼层图" forState:UIControlStateNormal];
                        btn.selected = NO;
                        
                        break;
                    case 4:
                        [btn setTitle:@"店铺" forState:UIControlStateNormal];
                        btn.selected = NO;
                        
                        break;
                    case 5:
                        [btn setTitle:@"活动" forState:UIControlStateNormal];
                        btn.selected = NO;
                        
                        break;
                    case 6:
                        [btn setTitle:@"真人秀" forState:UIControlStateNormal];
                        btn.selected = NO;
                        
                        break;
                        
                    default:
                        break;
                }
                
                [titleView addSubview:btn];
                btnX += 320/5-3;
            }
            
        }
    }
    
    
    
}

- (void)doTitleViewBtn:(UIButton *)sender
{
    if (brandID) {
        NSLog(@"brand");
        switch (sender.tag) {
            case 1001:
                ZLog(@"%ld",(long)sender.tag);
                sender.selected = YES;
                sender.userInteractionEnabled = NO;
                for (UIView *btn1 in [titleView subviews]) {
                    if (btn1.tag >= 1002 && btn1.tag <= 1005) {
                        UIButton *btn2 = (UIButton *)btn1;
                        btn2.selected = NO;
                        btn2.userInteractionEnabled = YES;
                        
                    }
                    
                }
                
                //获取图片数据代码写在这里
                picType = 0;//相册分类
                [self getBrandImageList];
                
                break;
            case 1002:
                ZLog(@"%ld",(long)sender.tag);
                sender.selected = YES;
                sender.userInteractionEnabled = NO;
                
                for (UIView *btn1 in [titleView subviews]) {
                    if (btn1.tag == 1001 || (btn1.tag >= 1003 && btn1.tag <= 1005)) {
                        UIButton *btn2 = (UIButton *)btn1;
                        btn2.selected = NO;
                        btn2.userInteractionEnabled = YES;
                        
                    }
                    
                }
                
                picType = 1;
                [self getBrandImageList];
                
                break;
            case 1003:
                ZLog(@"%ld",(long)sender.tag);
                sender.selected = YES;
                sender.userInteractionEnabled = NO;
                
                for (UIView *btn1 in [titleView subviews]) {
                    if (btn1.tag == 1001 || btn1.tag == 1002 || btn1.tag == 1004 || btn1.tag == 1005) {
                        UIButton *btn2 = (UIButton *)btn1;
                        btn2.selected = NO;
                        btn2.userInteractionEnabled = YES;
                        
                    }
                }
                picType = 2;
                [self getBrandImageList];
                
                break;
            case 1004:
                ZLog(@"%ld",(long)sender.tag);
                sender.selected = YES;
                sender.userInteractionEnabled = NO;
                
                for (UIView *btn1 in [titleView subviews]) {
                    if ((btn1.tag >= 1001 && btn1.tag <= 1003) || btn1.tag == 1005) {
                        UIButton *btn2 = (UIButton *)btn1;
                        btn2.selected = NO;
                        btn2.userInteractionEnabled = YES;
                        
                    }
                    
                }
                picType = 3;
                [self getBrandImageList];
                
                break;
            case 1005:
                ZLog(@"%ld",(long)sender.tag);
                sender.selected = YES;
                sender.userInteractionEnabled = NO;
                
                for (UIView *btn1 in [titleView subviews]) {
                    if (btn1.tag >= 1001 && btn1.tag <= 1004) {
                        UIButton *btn2 = (UIButton *)btn1;
                        btn2.selected = NO;
                        btn2.userInteractionEnabled = YES;
                        
                    }
                    
                }
                picType = 4;
                [self getBrandImageList];
                
                break;
                
            default:
                break;
        }
        
    }
    else if (shopID)
    {
        NSLog(@"shopID");
        if (self.isMerchant) {
            switch (sender.tag) {
                case 1013:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if (btn1.tag >= 1014 && btn1.tag <= 1017) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                        
                    }
                    
                    //获取图片数据代码写在这里
                    picType = 0;
                    [self getShopImageList];
                    
                    break;
                case 1014:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if (btn1.tag == 1013 || (btn1.tag >= 1015 && btn1.tag <= 1017)) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                        
                    }
                    picType = 1;
                    [self getShopImageList];
                    
                    break;
                case 1015:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if (btn1.tag == 1013 || btn1.tag == 1014 || btn1.tag == 1016 || btn1.tag == 1017) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                    }
                    picType = 2;
                    [self getShopImageList];
                    
                    break;
                case 1016:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if ((btn1.tag >= 1013 && btn1.tag <= 1015) || btn1.tag == 1017) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                        
                    }
                    picType = 3;
                    [self getShopImageList];
                    
                    break;
                case 1017:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if (btn1.tag >= 1013 && btn1.tag <= 1016) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                        
                    }
                    picType = 4;
                    [self getShopImageList];
                    
                    break;
                    
                default:
                    break;
            }
        }
        else{
            switch (sender.tag) {
                case 1006:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if (btn1.tag >= 1007 && btn1.tag <= 1012) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                        
                    }
                    picType = 0;
                    [self getShopImageList];
                    
                    break;
                case 1007:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if (btn1.tag == 1006 || (btn1.tag >=1008 && btn1.tag <= 1012)) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                        
                    }
                    picType = 1;
                    [self getShopImageList];
                    
                    break;
                case 1008:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if (btn1.tag == 1006 || btn1.tag == 1007 ||( btn1.tag >= 1009 && btn1.tag <= 1012)) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                        
                    }
                    picType = 2;
                    [self getShopImageList];
                    
                    break;
                case 1009:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if ((btn1.tag >= 1006 && btn1.tag <= 1008) ||( btn1.tag >= 1010 && btn1.tag <= 1012)) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                        
                    }
                    picType = 3;
                    [self getShopImageList];
                    
                    break;
                case 1010:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if ((btn1.tag >= 1006 && btn1.tag <= 1009) || btn1.tag == 1011 || btn1.tag == 1012) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                        
                    }
                    picType = 4;
                    [self getShopImageList];
                    
                    break;
                case 1011:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    for (UIView *btn1 in [titleView subviews]) {
                        if ((btn1.tag >= 1006 && btn1.tag <= 1010) || btn1.tag == 1012) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                            
                        }
                        
                    }
                    picType = 5;
                    [self getShopImageList];
                    
                    break;
                case 1012:
                    ZLog(@"%ld",(long)sender.tag);
                    sender.selected = YES;
                    sender.userInteractionEnabled = NO;
                    
                    sender.userInteractionEnabled = YES;
                    for (UIView *btn1 in [titleView subviews]) {
                        if (btn1.tag >= 1006 && btn1.tag <= 1011) {
                            UIButton *btn2 = (UIButton *)btn1;
                            btn2.selected = NO;
                            btn2.userInteractionEnabled = YES;
                        }
                        
                    }
                    picType = 6;
                    [self getShopImageList];
                    
                    break;
                    
                default:
                    break;
            }
        }
    }
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //从用户字典中获取当前查看照片的curPicIndex，如果大于当前curPage*3，则curPage改变
    int curPicG = (int)[[NSUserDefaults standardUserDefaults]doubleForKey:@"curPicIndex"];
    if (curPicG > curPage * 3) {
        int curNewPage = curPicG/6;
        curPage = curNewPage + 1;
        [iTableView reloadData];
        [[NSUserDefaults standardUserDefaults] setDouble:0 forKey:@"curPicIndex"];//清空字典中数据，防止软件返回错误curPage
    }
    
    //从字典中获取上传状态，若为yes，则重新获取数据
    BOOL isUpdate = [[NSUserDefaults standardUserDefaults]boolForKey:@"isUpdating"];
    if (isUpdate) {
        [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"isUpdating"];//清空上传状态
        //重新加载数据
        if(shopID){
            //这里获取图片数据，默认是全部
            curPage = 1;
            if (self.isMerchant) {
                [self getShopImageList];
            }
            else{
                [self getShopImageList];
            }
            
        }else if (brandID){
            curPage = 1;
            [self getBrandImageList];
        }
    }
}

- (void)showAlbum{
    pushPublishFlag = YES;
}
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    if(pushPublishFlag){
        pushPublishFlag = NO;
        
        //没有登录就不做处理。
        if(![GLBDELEGATE isUserLogin]){
            return;
        }
        
        UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                      initWithTitle:@"选择图片来源"
                                      delegate:self
                                      cancelButtonTitle:@"取消"
                                      destructiveButtonTitle:nil
                                      otherButtonTitles:@"拍照",@"从手机相册选择",nil];
        
        [actionSheet setDelegate:self];
        [actionSheet showInView:[UIApplication sharedApplication].keyWindow];
        [actionSheet release];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark tableview begin
- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    //这里不需要复用，所有条目都被完全列出
    static NSString *CellIdentifier = @"UITableViewCell";
    UITableViewCell *cell = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    cell.backgroundColor = [UIColor clearColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    
    if (_dataArray.count == 0) {
        UIImageView *bgPhotoView = [[UIImageView alloc]initWithFrame:CGRectMake(5, 7, 150, 104)];
        bgPhotoView.image = [UIImage imageNamed:@"Shop_bg.png"];
        bgPhotoView.userInteractionEnabled = YES;
        [cell addSubview:bgPhotoView];
        [bgPhotoView release];
        
        UIButton *addBtn = [[UIButton alloc]initWithFrame:CGRectMake(10, 13, 140, 102)];
        [addBtn addTarget:self action:@selector(showSubmit) forControlEvents:UIControlEventTouchUpInside];
        [bgPhotoView addSubview:addBtn];
        
        UIImageView *addView = [[UIImageView alloc]initWithFrame:CGRectMake(45, 10, 37, 37)];
        addView.image = [UIImage imageNamed:@"Add_photo.png"];
        [addBtn addSubview:addView];
        
        UILabel *addLabel = [[UILabel alloc]initWithFrame:CGRectMake(30, 58, 130, 12)];
        addLabel.text = @"点击添加照片";
        addLabel.font = [UIFont systemFontOfSize:11];
        addLabel.textColor = [UIColor grayColor];
        addLabel.textAlignment = 0;
        addLabel.backgroundColor = [UIColor clearColor];
        [addBtn addSubview:addLabel];
        [addLabel release];
        [addView release];
        [addBtn release];
        
    }
    else{
        //加载左边一列图片
        UIImageView *bgPhotoView = [[UIImageView alloc]initWithFrame:CGRectMake(6, 7, 150, 112)];
        bgPhotoView.image = [UIImage imageNamed:@"Shop_bg.png"];
        [cell addSubview:bgPhotoView];
        [bgPhotoView release];
        
        UIButton *backgroundlBtn = [[UIButton alloc]initWithFrame:CGRectMake(10, 13, 140, 102)];
        backgroundlBtn.tag = indexPath.row * 2;
        [backgroundlBtn addTarget:self action:@selector(buttonTouchAction:) forControlEvents:UIControlEventTouchUpInside];
        if(_dataArray.count > indexPath.row*2){
            UAAsyncImageView *image = [[UAAsyncImageView alloc]initWithFrame:CGRectMake(0, 0, 140, 102)];
            image.noBorderFlag = YES;
            NSURL *url = [NSURL URLWithString:[[_dataArray objectAtIndex:(indexPath.row*2)] objectForKey:@"PhotoUrl"]];
            ZLog(@"%@",url);
            [image loadImageFromURL:url];
            [backgroundlBtn addSubview:image];
            [image release];
        }
        
        UIImageView *greatView = [[UIImageView alloc]initWithFrame:CGRectMake(104, 84, 34, 16)];
        greatView.image = [UIImage imageNamed:@"Photo_Great.png"];
        [backgroundlBtn addSubview:greatView];
        
        UIImageView *greatBgView = [[UIImageView alloc]initWithFrame:CGRectMake(2, 2, 10, 11)];
        greatBgView.image = [UIImage imageNamed:@"Photo_GreatBg.png"];
        [greatView addSubview:greatBgView];
        
        UILabel *greatLabel = [[UILabel alloc]initWithFrame:CGRectMake(16, 2, 14, 11)];
        greatLabel.textColor = [UIColor whiteColor];
        greatLabel.backgroundColor = [UIColor clearColor];
        greatLabel.textAlignment = 1;
        greatLabel.text = [[_dataArray objectAtIndex:backgroundlBtn.tag] objectForKey:@"CommentCount"];//获取评论数
        greatLabel.font = [UIFont systemFontOfSize:10];
        [greatView addSubview:greatLabel];
        [cell addSubview:backgroundlBtn];
        [backgroundlBtn release];
        [greatView release];
        [greatBgView release];
        [greatLabel release];
        
        //加载右边一列图片
        if (indexPath.row*2+1 == _dataArray.count) {
            ;
        }else{
            UIImageView *bgPhotoViewR = [[UIImageView alloc]initWithFrame:CGRectMake(164, 7, 150, 112)];
            bgPhotoViewR.image = [UIImage imageNamed:@"Shop_bg.png"];;
            [cell addSubview:bgPhotoViewR];
            [bgPhotoViewR release];
            
            UIButton *backgroundrBtnR = [[UIButton alloc]initWithFrame:CGRectMake(172, 13, 140, 102)];
            backgroundrBtnR.tag = indexPath.row * 2 + 1;
            [backgroundrBtnR addTarget:self action:@selector(buttonTouchAction:) forControlEvents:UIControlEventTouchUpInside];
            if(_dataArray.count > indexPath.row*2 + 1){
                UAAsyncImageView *image2 = [[UAAsyncImageView alloc]initWithFrame:CGRectMake(0, 0, 140, 102)];
                
                image2.noBorderFlag = YES;
                NSURL *urlR = [NSURL URLWithString:[[_dataArray objectAtIndex:(indexPath.row*2 + 1)] objectForKey:@"PhotoUrl"]];
                [image2 loadImageFromURL:urlR];
                [backgroundrBtnR addSubview:image2];
                [image2 release];
            }
            UIImageView *greatView1 = [[UIImageView alloc]initWithFrame:CGRectMake(104, 84, 34, 16)];
            greatView1.image = [UIImage imageNamed:@"Photo_Great.png"];
            [backgroundrBtnR addSubview:greatView1];
            
            UIImageView *greatBgView1 = [[UIImageView alloc]initWithFrame:CGRectMake(2, 2, 10, 11)];
            greatBgView1.image = [UIImage imageNamed:@"Photo_GreatBg.png"];
            [greatView1 addSubview:greatBgView1];
            
            UILabel *greatLabel1 = [[UILabel alloc]initWithFrame:CGRectMake(16, 2, 14, 11)];
            greatLabel1.textColor = [UIColor whiteColor];
            greatLabel1.backgroundColor = [UIColor clearColor];
            greatLabel1.textAlignment = 1;
            greatLabel1.text = [[_dataArray objectAtIndex:backgroundrBtnR.tag] objectForKey:@"CommentCount"];
            greatLabel1.font = [UIFont systemFontOfSize:10];
            [greatView1 addSubview:greatLabel1];
            
            [cell addSubview:backgroundrBtnR];
            [backgroundrBtnR release];
            [greatView1 release];
            [greatBgView1 release];
            [greatLabel1 release];
        }
    }
    return cell;
}

//按钮点击后触发这里
- (IBAction)buttonTouchAction:(UIButton *)sender{
    //这里准备做个很复杂的处理 －－ 先获取商场的图片列表；然后再做判断，看是否需要进入到下级显示滚动的画廊
    
    if (_dataArray.count == 0) {
        return;
    }else{
        curPic = sender.tag;
        
        if (shopID) {
            if (self.isMerchant) {
                [self intoGallery:nil];
                
            }
            else{
                [self intoGallery:nil];
                
            }
        }
        else if (brandID)
        {
            [self intoGallery:nil];
            
        }
        return;
    }
}

//点击查看画廊，显示当前
- (IBAction)intoGallery:(id)sender{
    GYGalleryViewController *controller = [[GYGalleryViewController alloc]init];
    controller.currentPage = curPic;
    if(shopID.length > 0){
        controller.isLoadShopAlbum = YES;
    }else if(brandID.length > 0)
        controller.isLoadBrandAlbum = YES;
    controller.picArray = _dataArray;
    [self.navigationController pushViewController:controller animated:YES];
    
    [controller release];
}

//指定每个分区中有多少行，默认为1
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (_dataArray.count <= 6) {
        if (_dataArray.count%2 == 0) {
            cellCount = _dataArray.count*0.5;
        }else{
            cellCount = _dataArray.count*0.5+1;
        }
    }
    else if(_dataArray.count >6 && _dataArray.count%6 != 0){
        if (_dataArray.count < curPage*6) {
            if (_dataArray.count%2 == 0) {
                cellCount = _dataArray.count*0.5;
            }else{
                cellCount = _dataArray.count*0.5+1;
            }
        }
        else {
            return cellCount = curPage *3;
        }
    }
    else{
        cellCount = curPage *3;
    }
    
    if (_dataArray.count == 0) {
        return 1;
    }else{
        if (shopID) {
            if (self.isMerchant) {
                return cellCount;
            }else{
                return cellCount;
            }
        }else{
            return cellCount;
        }
    }
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if((_dataArray.count == (curPage - 1) * 10) && (indexPath.row == _dataArray.count/2 ) && curPage != 1){
        return 40;
    }
    return 120;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (_dataArray.count == 0) {
        //        return;
    }else{
        if( (_dataArray.count == (curPage - 1) * 10) && (indexPath.row == _dataArray.count/2) ){
            if(shopID.length > 0){
                [self getShopImageList];
            }else if(brandID.length > 0){
                [self getBrandImageList];
            }
        }
    }
}

- (void)endHeaderFooterLoading{
    //判断是否全部加载完全，若全部加载则curpage--
    if (_dataArray.count <= (curPage-1)*6) {
        ZLog(@"%d,%d",_dataArray.count,(curPage-1)*6);
        curPage--;
        UIAlertView *alerV = [[UIAlertView alloc]initWithTitle:@"" message:@"别拉了，已经没有啦！" delegate:self cancelButtonTitle:@"好的" otherButtonTitles: nil];
        [alerV show];
        [alerV release];
    }
    
    [_footer endRefreshing];
    
    //调整坐标
    if (brandID) {
        iTableView.frame = CGRectMake(0, 40, 320, self.view.bounds.size.height-40-kNewHeight);
    }else{
        if (self.isMerchant) {
            iTableView.frame = CGRectMake(0, 40, 320, self.view.bounds.size.height-40-kNewHeight);
        }else
            iTableView.frame = CGRectMake(0, 66, 320, self.view.bounds.size.height-66-kNewHeight);
    }
    
    [iTableView reloadData];
}

- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    if (refreshView == _footer) {
        curPage ++;
        [self performSelector:@selector(endHeaderFooterLoading) withObject:nil afterDelay:0.3];
        return;
    }
}

#pragma -mark 网络
-(void)getShopImageList{
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"DeviceID"];
    [item setObject:shopID forKey:@"ShopID"];
    [item setObject:[NSString stringWithFormat:@"%d",picType] forKey:@"GalleryName"];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"PageIndex"];
    [item setObject:[NSNumber numberWithInt:20000] forKey:@"PageSize"];
    
    NSString *datestr;
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setTimeZone:[NSTimeZone systemTimeZone]];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    datestr = [formatter stringFromDate:[NSDate date]];
    [item setObject:datestr forKey:@"RefreshTime"];
    [formatter release];
    
    
    SBJsonWriter *json = [[SBJsonWriter alloc] init];
    NSString *jsonString = [json stringWithObject:item];
    [json release];
    [item release];
    ZLog(@"%@",jsonString);
    if (picType == 0) {
        imgUrl = [NSURL URLWithString:kShopPhoto];
    }else{
        imgUrl = [NSURL URLWithString:kShopPhotoGallery];
    }
    ZLog(@"%@",imgUrl);
    if (self.netrequest!=nil)
    {
        [self.netrequest setDelegate:nil];
        [self.netrequest cancel];
    }
    self.netrequest = [ASIFormDataRequest requestWithURL:imgUrl];
    [self.netrequest setPostValue:jsonString forKey:@"JsonString"];
    self.netrequest.userInfo = [NSDictionary dictionaryWithObject:@"shopphoto" forKey:@"type"];
    [GLBDELEGATE checkNetStatus];
    [self.netrequest setDelegate:self];
    [self.netrequest setDidFailSelector:@selector(timeoutFuction)];
    [self.netrequest startAsynchronous];
    
    [self showHUD];
}

//网络失败时候调用。
- (void)timeoutFuction{
    self.netrequest.delegate = nil;
    [self.netrequest cancel];
    [self hideHUD];
}

- (void)getBrandImageList{
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"DeviceID"];
    [item setObject:brandID forKey:@"BrandID"];
    [item setObject:[NSString stringWithFormat:@"%d",picType] forKey:@"GalleryName"];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"PageIndex"];
    [item setObject:[NSNumber numberWithInt:20000] forKey:@"PageSize"];
    
    NSString *datestr;
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setTimeZone:[NSTimeZone systemTimeZone]];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm +0800"];
    datestr = [formatter stringFromDate:[NSDate date]];
    [item setObject:datestr forKey:@"RefreshTime"];
    [formatter release];
    
    SBJsonWriter *json = [[SBJsonWriter alloc] init];
    NSString *jsonString = [json stringWithObject:item];
    [json release];
    [item release];
    ZLog(@"%@",jsonString);
    if (picType == 0) {
        imgUrl = [NSURL URLWithString:kBrandPhoto];
    }else{
        imgUrl = [NSURL URLWithString:kBrandPhotoGallery];
    }
    if (self.netrequest!=nil)
    {
        [self.netrequest setDelegate:nil];
        [self.netrequest cancel];
    }
    self.netrequest = [ASIFormDataRequest requestWithURL:imgUrl];
    [self.netrequest setPostValue:jsonString forKey:@"JsonString"];
    self.netrequest.userInfo = [NSDictionary dictionaryWithObject:@"shopphoto" forKey:@"type"];
    [GLBDELEGATE checkNetStatus];
    [self.netrequest setDelegate:self];
    [self.netrequest setDidFailSelector:@selector(timeoutFuction)];
    [self.netrequest startAsynchronous];
    
    [self showHUD];
}

//获取图片数据
- (void)requestFinished:(ASIHTTPRequest *)request {
    [self hideHUD];
	NSString *responseString = [request responseString];
	SBJsonParser *parser = [SBJsonParser new];
	NSMutableDictionary *results = [parser objectWithString:responseString];
    [parser release];
    
    
    if (request.userInfo && [[request.userInfo objectForKey:@"type"] isEqualToString:@"shopphoto"] ){
        ZLog(@"data is:%@",results);
        
        self.dataArray = [[results objectForKey:@"Result"] objectForKey:@"ListInfo"];
        if(0 == self.dataArray.count){
            //若没有数据，则刷新一下
            [iTableView reloadData];
            
            [GLBDELEGATE showAlert:@"暂时没有图片哦！"];
            
            return;
        }else{
            //jump to gallery
            //            [self intoGallery:nil];
        }
        //当前请求页面＋1
        //        curPage++;
        
        [iTableView reloadData];
    }
}

- (void)jumpToUserInfo{
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:@"选择图片来源"
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"拍照",@"从手机相册选择",nil];
    
    [actionSheet setDelegate:self];
    [actionSheet showInView:[UIApplication sharedApplication].keyWindow];
    [actionSheet release];
}
- (void)viewDidUnload {
    [titleView release];
    titleView = nil;
    [super viewDidUnload];
}
@end
