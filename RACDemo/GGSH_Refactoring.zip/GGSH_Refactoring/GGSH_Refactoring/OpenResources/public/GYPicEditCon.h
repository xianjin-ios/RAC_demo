//
//  GYPicEditCon.h
//  guangguang
//
//  Created by STAR on 13-6-26.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BJImageCropper.h"
#import "GYSubmitPruduct.h"

@interface GYPicEditCon : BaseViewControllerGGSH


@property (nonatomic, strong) IBOutlet UILabel *boundsText;
@property (nonatomic, strong) BJImageCropper *imageCropper;
@property (nonatomic, strong) UIImageView *preview;

@property (nonatomic, assign) UIImage *fullImage;

@property (nonatomic, assign) id<submitPicDelegate> delegate;
@end
