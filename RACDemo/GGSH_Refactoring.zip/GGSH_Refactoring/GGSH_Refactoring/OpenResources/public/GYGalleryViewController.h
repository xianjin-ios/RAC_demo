//
//  GYGalleryViewController.h
//  逛逛
//
//  Created by STAR on 13-3-8.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLCycleScrollView.h"
@interface GYGalleryViewController : BaseViewControllerGGSH<XLCycleScrollViewDatasource,XLCycleScrollViewDelegate, UITextViewDelegate,UIAlertViewDelegate, UITableViewDataSource, UITableViewDelegate>{
    
    //数据加载源 1:从商场相册进入；2:从品牌加载
    NSInteger iLoadFlag;
    IBOutlet UIView *picView;
    IBOutlet UIView *commentView;
    
    //评论列表
    IBOutlet UITableView *iCommentTableView;
    
    //当前图片
    int curPicIndex;
    
    
    IBOutlet UITableViewCell *topCell;
    IBOutlet UILabel *commentNameLabel;
    IBOutlet UILabel *contentLabel;
    IBOutlet UILabel *timeLabel;
    IBOutlet UILabel *commentNumLabel;
    IBOutlet UAAsyncImageView *headPicImageView;
    IBOutlet UAAsyncImageView *bigPicImageView;
    
    BOOL bFlip;//
    
}
@property (nonatomic, retain) NSArray *picArray;
@property (nonatomic, retain) NSMutableArray *dataArray;
//进入画廊时候应该显示第几张图片。
@property (nonatomic, assign) NSInteger currentPage;
-(void)loadImages;

@property (nonatomic, assign) BOOL isLoadShopAlbum;//商场画廊
@property (nonatomic, assign) BOOL isLoadBrandAlbum;//品牌画廊

//放评论的地方
@property (nonatomic, retain) NSMutableArray *commentArray;

//@property (nonatomic, retain) ASIFormDataRequest *netrequest;
@property (nonatomic, retain) ASIFormDataRequest *submitCommentRequest;
@end
