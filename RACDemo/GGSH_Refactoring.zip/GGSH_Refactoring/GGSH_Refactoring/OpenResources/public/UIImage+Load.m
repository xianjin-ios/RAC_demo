//
//  UIImageViewCat.m
//  GuangGuang
//
//  Created by STAR on 14-3-13.
//
//

#import "UIImage+Load.h"

@implementation UIImage (UIImageLoad)

+ (UIImage*)loadImg:(NSString*)name{
    NSString *imgPath = [[NSBundle mainBundle] pathForResource:name ofType:@"png"];
    return [UIImage imageWithContentsOfFile:imgPath];
}

@end
