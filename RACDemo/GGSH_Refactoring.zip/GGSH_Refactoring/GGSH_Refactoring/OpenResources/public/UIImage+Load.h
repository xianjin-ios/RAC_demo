//
//  UIImageViewCat.h
//  GuangGuang
//
//  Created by STAR on 14-3-13.
//
//

#import <UIKit/UIKit.h>

@interface UIImage  (UIImageLoad)

+ (UIImage*) loadImg:(NSString*)name;

@end
