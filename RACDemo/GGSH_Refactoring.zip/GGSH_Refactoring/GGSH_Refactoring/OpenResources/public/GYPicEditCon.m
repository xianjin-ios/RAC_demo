//
//  GYPicEditCon.m
//  guangguang
//
//  Created by STAR on 13-6-26.
//  Copyright (c) 2013年 STAR. All rights reserved.
//
#define SHOW_PREVIEW NO

#import "GYPicEditCon.h"
#import <QuartzCore/QuartzCore.h>
#import "AppDelegate.h"

#ifndef CGWidth
#define CGWidth(rect)                   rect.size.width
#endif

#ifndef CGHeight
#define CGHeight(rect)                  rect.size.height
#endif

#ifndef CGOriginX
#define CGOriginX(rect)                 rect.origin.x
#endif

#ifndef CGOriginY
#define CGOriginY(rect)                 rect.origin.y
#endif


@interface GYPicEditCon ()

@end

@implementation GYPicEditCon


- (void)updateDisplay {
    self.boundsText.text = [NSString stringWithFormat:@"(%f, %f) (%f, %f)", CGOriginX(self.imageCropper.crop), CGOriginY(self.imageCropper.crop), CGWidth(self.imageCropper.crop), CGHeight(self.imageCropper.crop)];
    
    if (SHOW_PREVIEW) {
        self.preview.image = [self.imageCropper getCroppedImage];
        self.preview.frame = CGRectMake(10,10,self.imageCropper.crop.size.width * 0.1, self.imageCropper.crop.size.height * 0.1);
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ([object isEqual:self.imageCropper] && [keyPath isEqualToString:@"crop"]) {
        [self updateDisplay];
    }
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        UIButton *refreshButton = [UIButton buttonWithType:UIButtonTypeCustom];
        refreshButton.frame = CGRectMake(0.0, 0.0, 50.5, 30.0);
        [refreshButton setBackgroundImage:[UIImage imageNamed:@"btnNavDefault.png"] forState:UIControlStateNormal];
        [refreshButton setBackgroundImage:[UIImage imageNamed:@"btnNavDefault.png"] forState:UIControlStateSelected];
        [refreshButton addTarget:self action:@selector(getPic) forControlEvents:UIControlEventTouchUpInside];
        refreshButton.titleLabel.font = [UIFont systemFontOfSize:14];
        [refreshButton setTitle:@"使用" forState:UIControlStateNormal];
        refreshButton.titleLabel.textColor = [UIColor whiteColor];
        UIBarButtonItem *refreshBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:refreshButton];
        refreshBarButtonItem.style = UIBarButtonItemStylePlain;
        self.navigationItem.rightBarButtonItem = refreshBarButtonItem;
        [refreshBarButtonItem release];
        
        self.title = @"编辑图片";
        if(IS_IOS7)
            self.navigationItem.titleView = [GLBDELEGATE setTitle:@"编辑图片"];
    }
    return self;
}

-(void)getPic{
    if(self.delegate){
        [self.delegate setPic:[self.imageCropper getCroppedImage] andFullImage:self.fullImage];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    
    _imageCropper = [[BJImageCropper alloc] initWithImage:self.fullImage andMaxSize:CGSizeMake(400 , 4000)];
    [self.view addSubview:_imageCropper];
    [_imageCropper release];
    _imageCropper.center = CGPointMake(self.view.center.x, self.view.center.y - 44);//让图片居中
    _imageCropper.imageView.layer.shadowColor = [[UIColor blackColor] CGColor];
    _imageCropper.imageView.layer.shadowRadius = 3.0f;
    _imageCropper.imageView.layer.shadowOpacity = 0.8f;
    _imageCropper.imageView.layer.shadowOffset = CGSizeMake(1, 1);
    
    [_imageCropper addObserver:self forKeyPath:@"crop" options:NSKeyValueObservingOptionNew context:nil];
    
    if (SHOW_PREVIEW) {
        self.preview = [[UIImageView alloc] initWithFrame:CGRectMake(10,10,_imageCropper.crop.size.width * 0.1, _imageCropper.crop.size.height * 0.1)];
        self.preview.image = [_imageCropper getCroppedImage];
        self.preview.clipsToBounds = YES;
        self.preview.layer.borderColor = [[UIColor whiteColor] CGColor];
        self.preview.layer.borderWidth = 2.0;
        [self.view addSubview:self.preview];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
