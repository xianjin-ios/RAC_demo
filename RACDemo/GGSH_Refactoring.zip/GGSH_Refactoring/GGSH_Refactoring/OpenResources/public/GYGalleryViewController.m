//
//  GYGalleryViewController.m
//  逛逛
//
//  Created by STAR on 13-3-8.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import "GYGalleryViewController.h"
#import "UAAsyncImageView.h"
#import <CoreGraphics/CoreGraphics.h>
#import "AppDelegate.h"
#import "loginViewControllerGGSH.h"

@interface GYGalleryViewController ()
//评论数
@property NSString *commentNum;
//输入评论
@property UITextField *textField;
@end

@implementation GYGalleryViewController
@synthesize picArray;
@synthesize dataArray;

- (void)dealloc{
    [commentNumLabel release];
    [super dealloc];
}

-(IBAction)backAction{
    
    //将当前查看的curPicIndex存入字典，便于pop时可以得到
    [[NSUserDefaults standardUserDefaults] setDouble:curPicIndex+1 forKey:@"curPicIndex"];
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       
        self.title = @"图片详情";
        if(IS_IOS7)
            self.navigationItem.titleView = [GLBDELEGATE setTitle:@"图片详情"];
        
        UIButton *flipButton = [UIButton buttonWithType:UIButtonTypeCustom];
        flipButton.frame = CGRectMake(0.0, 0.0, 45.0, 21.0);
        [flipButton setBackgroundImage:[UIImage imageNamed:@"a-z.png"] forState:UIControlStateNormal];//二维码.png
        [flipButton setBackgroundImage:[UIImage imageNamed:@"a-z.png"] forState:UIControlStateSelected];
        [flipButton setTitle:@"评论" forState:UIControlStateNormal];
        [flipButton setTitle:@"评论" forState:UIControlStateSelected];
        flipButton.titleLabel.font = [UIFont systemFontOfSize:12];
        [flipButton addTarget:self action:@selector(flip) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *temporaryBarButtonItem2 = [[UIBarButtonItem alloc] initWithCustomView:flipButton];
        temporaryBarButtonItem2.style = UIBarButtonItemStylePlain;
        self.navigationItem.rightBarButtonItem=temporaryBarButtonItem2;
        [temporaryBarButtonItem2 release];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor= [UIColor blackColor];
    picView.backgroundColor = [UIColor blackColor];
    
    if(IS_IPHONE5){
        commentView.frame = CGRectMake(0, 0, 320, 367 + IPHONE5_HEIGHT_MORE);
    }else{
        commentView.frame = CGRectMake(0, 0, 320, 367);
    }
    iCommentTableView.frame = self.view.frame;
    
    [iCommentTableView setDelegate:self];
    [iCommentTableView setDataSource:self];
    [iCommentTableView reloadData];
    
    [self loadImages];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)loadImages{
    self.dataArray = [NSMutableArray arrayWithCapacity:3];
    if(self.picArray.count > 1){
        for(int i = 0; i < self.picArray.count; i++){
            NSMutableString *imagePath = [[self.picArray objectAtIndex:i] objectForKey:@"PhotoUrl"];
            int strlen = imagePath.length;
            if(strlen > 4){
                imagePath = [NSMutableString stringWithFormat:@"%@%@%@",[imagePath substringToIndex:(strlen - 4)], @"_BigView", [imagePath substringFromIndex:(strlen - 4)]];
            }
            
            NSURL *url = [NSURL URLWithString:imagePath];
            UAAsyncImageView *asImage = [[UAAsyncImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 320)];
            asImage.contentMode = UIViewContentModeScaleAspectFit;
            asImage.noBorderFlag = YES;
            asImage.tempImageUrl = url;
            asImage.tag = 103;
            //图片数量大时，不能完全获取图片
            //            [asImage loadImageFromURL:url];
            
            UIView *motherView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 400)];
            //显示提交用户名；图片相关简介；日期等。
            UIView *backgroundView = [[UIView alloc]initWithFrame:CGRectMake(0, 320, 320, 23)];
            backgroundView.backgroundColor = [UIColor blackColor];
            UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 2, 260, 20)];
            
            nameLabel.text = [[self.picArray objectAtIndex:i] objectForKey:@"PhotoTitle"];
            ZLog(@"---%@", [self.picArray objectAtIndex:i]);
            [backgroundView addSubview:nameLabel];
            nameLabel.backgroundColor = [UIColor clearColor];
            nameLabel.textColor = [UIColor whiteColor];
            nameLabel.textAlignment = NSTextAlignmentCenter;
            nameLabel.font = [UIFont systemFontOfSize:15];
            [nameLabel release];
            
            //评论数背景图
            UIImageView *bgCommentNumView = [[UIImageView alloc] initWithFrame:CGRectMake(260, 2, 55, 22)];
            NSString *path = [[NSBundle mainBundle] pathForResource:@"bg_commentNum" ofType:@"png"];
            bgCommentNumView.image = [UIImage imageWithContentsOfFile:path];
            [backgroundView addSubview:bgCommentNumView];
            [bgCommentNumView release];
            
            //评论数
            UILabel *numLabel = [[UILabel alloc] initWithFrame:CGRectMake(290, 3, 50, 20)];
            numLabel.text = [[self.picArray objectAtIndex:i] objectForKey:@"CommentCount"];
            numLabel.font = [UIFont systemFontOfSize:13];
            numLabel.textColor = [UIColor whiteColor];
            numLabel.backgroundColor = [UIColor clearColor];
            [backgroundView addSubview:numLabel];
            [numLabel release];
            
            [motherView addSubview:backgroundView];
            [backgroundView release];
            
            UIView *backgroundView2 = [[UIView alloc]initWithFrame:CGRectMake(0, 344, 320, 23)];
            backgroundView2.backgroundColor = [UIColor blackColor];
            [motherView addSubview:backgroundView2];
            NSString *userAndTimeStr = [NSString stringWithFormat:@"%@   上传于%@",[[self.picArray objectAtIndex:i]objectForKey:@"UserNickName"],[[self.picArray objectAtIndex:i] objectForKey:@"CreateTime"]];
            UILabel *userLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 2, 300, 20)];
            userLabel.text = userAndTimeStr;
            userLabel.font = [UIFont systemFontOfSize:13];
            userLabel.textColor = [UIColor lightGrayColor];
            userLabel.backgroundColor = [UIColor clearColor];
            userLabel.textAlignment = NSTextAlignmentCenter;
            [backgroundView2 addSubview:userLabel];
            [userLabel release];
            
            [backgroundView2 release];
            
            [motherView addSubview:asImage];
            [asImage release];
            [self.dataArray addObject:motherView];
            [motherView release];
        }
        if(self.picArray.count > 1){
            CGRect motherRect;
            if(IS_IPHONE5)
                motherRect = CGRectMake(0, IPHONE5_HEIGHT_MORE/2, 320, 400);
            else
                motherRect = CGRectMake(0, 0, 320, 400);
            XLCycleScrollView *csView = [[[XLCycleScrollView alloc] initWithFrame:motherRect]retain];
            csView.currentPage = self.currentPage;
            csView.backgroundColor = [UIColor clearColor];
            csView.delegate = self;
            csView.datasource = self;
            csView.pageControl.hidden = YES;
            //pagecontrol 显示能力有限，改成数字显示
            UILabel *curPicLabel = [[UILabel alloc]initWithFrame:CGRectMake(260, 360, 60, 12)];
            [csView addSubview:curPicLabel];
            curPicLabel.tag = 104;
            curPicLabel.font = [UIFont systemFontOfSize:12];
            curPicLabel.textColor = [UIColor lightGrayColor];
            curPicLabel.backgroundColor = [UIColor clearColor];
            curPicLabel.text = [NSString stringWithFormat:@"%d/%lu",curPicIndex+1,(unsigned long)self.dataArray.count];
            [curPicLabel release];
            [picView addSubview:csView];
        }
    }else if (1 == self.picArray.count){
        UAAsyncImageView *img = [[UAAsyncImageView alloc]initWithFrame:CGRectMake(0, 40, 320, 300)];
        NSURL *url = [NSURL URLWithString:[[self.picArray objectAtIndex:0] objectForKey:@"PhotoUrl"]];
        [img loadImageFromURL:url];
        img.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgImage.png"]];
        img.contentMode = UIViewContentModeScaleAspectFit;
        [picView addSubview:img];
        [img release];
        
        //针对不同的切入点，增加相应的附加显示。
        UIView *motherView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 400)];
        if(1 == iLoadFlag){
            //商场进入的，显示提交用户名；图片相关简介；日期等。
            UIView *backgroundView = [[UIView alloc]initWithFrame:CGRectMake(0, 320, 320, 23)];
            backgroundView.backgroundColor = [UIColor blackColor];
            UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 2, 320, 20)];
            if([[self.picArray objectAtIndex:0] objectForKey:@"PhotoTitle"] != [NSNull null]){
                nameLabel.text = [[self.picArray objectAtIndex:0] objectForKey:@"PhotoTitle"];
            }
            [backgroundView addSubview:nameLabel];
            nameLabel.backgroundColor = [UIColor clearColor];
            nameLabel.textColor = [UIColor whiteColor];
            nameLabel.textAlignment = NSTextAlignmentCenter;
            nameLabel.font = [UIFont systemFontOfSize:15];
            [nameLabel release];
            
            //评论数背景图
            UIImageView *bgCommentNumView = [[UIImageView alloc] initWithFrame:CGRectMake(260, 2, 55, 22)];
            NSString *path = [[NSBundle mainBundle] pathForResource:@"bg_commentNum" ofType:@"png"];
            bgCommentNumView.image = [UIImage imageWithContentsOfFile:path];
            [backgroundView addSubview:bgCommentNumView];
            [bgCommentNumView release];
            
            //评论数
            UILabel *numLabel = [[UILabel alloc] initWithFrame:CGRectMake(290, 3, 50, 20)];
            numLabel.text = [[self.picArray objectAtIndex:curPicIndex] objectForKey:@"CommentCount"];
            numLabel.font = [UIFont systemFontOfSize:13];
            numLabel.textColor = [UIColor whiteColor];
            numLabel.backgroundColor = [UIColor clearColor];
            [backgroundView addSubview:numLabel];
            [numLabel release];
            
            [motherView addSubview:backgroundView];
            [backgroundView release];
            
            UIView *backgroundView2 = [[UIView alloc]initWithFrame:CGRectMake(0, 344, 320, 23)];
            backgroundView2.backgroundColor = [UIColor blackColor];
            [motherView addSubview:backgroundView2];
            UILabel *userLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 2, 300, 20)];
            if([[self.picArray objectAtIndex:0]objectForKey:@"UserNickName"] != [NSNull null]){
                NSString *userAndTimeStr = [NSString stringWithFormat:@"%@   上传于%@",[[self.picArray objectAtIndex:0]objectForKey:@"UserNickName"],[[self.picArray objectAtIndex:0] objectForKey:@"CreateTime"]];
                
                userLabel.text = userAndTimeStr;
            }
            userLabel.font = [UIFont systemFontOfSize:13];
            userLabel.textColor = [UIColor lightGrayColor];
            userLabel.backgroundColor = [UIColor clearColor];
            userLabel.textAlignment = NSTextAlignmentCenter;
            [backgroundView2 addSubview:userLabel];
            [userLabel release];
            [backgroundView2 release];
        }
        [picView addSubview:motherView];
        [motherView release];
    }
}

#pragma 轮播图
- (NSInteger)numberOfPages
{
    return self.picArray.count;
}

- (UIView *)pageAtIndex:(NSInteger)index
{
    //图片轮动的策略
    if(index == 0){
        curPicIndex = self.picArray.count - 1;
    }else{
        curPicIndex = index - 1;
    }
    if([self.view viewWithTag:104]){
        UILabel *label = (UILabel*)[self.view viewWithTag:104];
        int cur = index;
        if(index == 0)
            cur = self.picArray.count;
        label.text = [NSString stringWithFormat:@"%d/%lu",cur,(unsigned long)self.picArray.count];
    }
    UIView *view = [self.dataArray objectAtIndex:index];
    view.frame = CGRectMake(0, 0, 320, 300);
    if([view viewWithTag:103]){
        UAAsyncImageView *imgV = ((UAAsyncImageView *)[view viewWithTag:103]);
        if(imgV.tempImageUrl){
            [imgV loadImageFromURL:imgV.tempImageUrl];
        }
    }
    return view;
}

- (void)didClickPage:(XLCycleScrollView *)csView atIndex:(NSInteger)index
{
}
#pragma 轮播图 end

- (void)flip{
    
    CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:1.0];
	
	// Choose left or right flip
	if (bFlip/*[(UISegmentedControl *)self.navigationItem.titleView selectedSegmentIndex]*/){
		[UIView setAnimationTransition: UIViewAnimationTransitionFlipFromLeft forView:self.view cache:YES];
        bFlip = YES;
	}else{
		[UIView setAnimationTransition: UIViewAnimationTransitionFlipFromRight forView:self.view cache:YES];
        bFlip = NO;
    }
    
	NSInteger purple = [[self.view subviews] indexOfObject:[self.view viewWithTag:100]];
	NSInteger maroon = [[self.view subviews] indexOfObject:[self.view viewWithTag:101]];
	[self.view exchangeSubviewAtIndex:purple withSubviewAtIndex:maroon];
    
	[UIView setAnimationDelegate:self];
	[UIView commitAnimations];
    [self getCommentList];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(0 == indexPath.row){
        return 194;
    }else{
        return 60;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.commentArray.count + 2;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(0 == indexPath.row){
        return topCell;
    }
    
    static NSString *CellIdentifier = @"CommentCell";
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    UITableViewCell *cell = nil;// = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil){
        cell = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier]autorelease];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if(0 == indexPath.row){
        
    }else if(self.commentArray.count + 1 == indexPath.row){
        UIImageView *bgInputView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 39)];
        bgInputView.image = [UIImage imageNamed:@"bg_inputComment.png"];
        [cell addSubview:bgInputView];
        [bgInputView release];
        
        self.textField = [[[UITextField alloc] initWithFrame:CGRectMake(20, 12, 240, 20)]autorelease];
        self.textField.placeholder = @"请输入评论";
        self.textField.font = [UIFont systemFontOfSize:13];
        self.textField.textAlignment = NSTextAlignmentCenter;
        self.textField.returnKeyType = UIReturnKeyDone;
        [self.textField addTarget:self action:@selector(finishInput) forControlEvents:UIControlEventEditingDidEndOnExit];
        [self.textField addTarget:self action:@selector(beginInpug) forControlEvents:UIControlEventEditingDidBegin];
        [cell addSubview:self.textField];
        
        UIButton *sendButton = [[UIButton alloc] initWithFrame:CGRectMake(274, 10, 44, 23)];
        [sendButton setImage:[UIImage imageNamed:@"btn_sendPicComment.png"] forState:UIControlStateNormal];
        [sendButton addTarget:self action:@selector(doSubmitAction:) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:sendButton];
        [sendButton release];
    }else{
        //        [cell removeAllSubviews];
        UAAsyncImageView *headPic = [[UAAsyncImageView alloc] initWithFrame:CGRectMake(10, 10, 45, 45)];
        headPic.image = [UIImage imageNamed:@"bgPhoto.png"];
        NSString *userHeadStr = [[self.commentArray objectAtIndex:(indexPath.row-1)] objectForKey:@"UserAvatars"];
        if([userHeadStr length] > 4){
            [headPic loadImageFromURL:[NSURL URLWithString:userHeadStr]];
        }
        [cell addSubview:headPic];
        [headPic release];
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(70, 12, 200, 15)];
        NSString *tempCommentStr = [NSString stringWithFormat:@"%@ : %@",[[self.commentArray objectAtIndex:indexPath.row-1] objectForKey:@"NickName"] ,[[self.commentArray objectAtIndex:indexPath.row-1] objectForKey:@"CommentContent"]];
        label.text = tempCommentStr;
        label.font = [UIFont systemFontOfSize:13];
        [cell addSubview:label];
        [label release];
        
        UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(70, 40, 200, 13)];
        label2.text = [[self.commentArray objectAtIndex:indexPath.row-1] objectForKey:@"CreateTime"];
        label2.font = [UIFont systemFontOfSize:11];
        label2.textColor = [UIColor lightGrayColor];
        [cell addSubview:label2];
        [label2 release];
        
        //item 间的分割线。
        UIImageView *lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 59, 320, 1)];
        lineImageView.image = [UIImage imageNamed:@"point1.png"];
        [cell addSubview:lineImageView];
        [lineImageView release];
        
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}
- (void)beginInpug{
    if(!IS_IPHONE5){
        int h = -185;
        if(0 == self.commentArray.count)
            h = -70;
        else if (1 == self.commentArray.count)
            h = -130;
        iCommentTableView.frame = CGRectMake(0, h, 320, iCommentTableView.frame.size.height);
    }else{
        int h = -130;
        if(0 == self.commentArray.count)
            h = 0;
        else if (1 == self.commentArray.count)
            h = -40;
        iCommentTableView.frame = CGRectMake(0, h, 320, iCommentTableView.frame.size.height);
    }
}

- (void)finishInput{
    if(!IS_IPHONE5){
        //挪动被挡住得输入框
        iCommentTableView.frame = CGRectMake(0, 0, 320, iCommentTableView.frame.size.height);
    }else{
        //挪动被挡住得输入框
        iCommentTableView.frame = CGRectMake(0, 0, 320, iCommentTableView.frame.size.height);
    }
    [self.textField resignFirstResponder];
}

#pragma mark - Table view delegate

- (void)getCommentList{
    if (self.netrequest!=nil)
    {
        [self.netrequest setDelegate:nil];
        [self.netrequest cancel];
    }
    NSURL *url;
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:[NSNumber numberWithInt:1] forKey:@"PageIndex"];
    [item setObject:[NSNumber numberWithInt:100] forKey:@"PageSize"];
    [item setObject:@"1" forKey:@"DeviceID"];
    ZLog(@"%@",[self.picArray objectAtIndex:curPicIndex]);
    [item setObject:[[self.picArray objectAtIndex:curPicIndex] objectForKey:@"PhotoID"] forKey:@"PhotoID"];
    NSString *datestr;
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setTimeZone:[NSTimeZone systemTimeZone]];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    datestr = [formatter stringFromDate:[NSDate date]];
    [item setObject:datestr forKey:@"RefreshTime"];
    [formatter release];
    url = [NSURL URLWithString:kGetCommentList];
    
    SBJsonWriter *json = [[SBJsonWriter alloc] init];
    NSString *jsonString = [json stringWithObject:item];
    ZLog(@"%@",jsonString);
    self.netrequest= [ASIFormDataRequest requestWithURL:url];
    [self.netrequest setPostValue:jsonString forKey:@"JsonString"];
    
    self.netrequest.userInfo = [NSDictionary dictionaryWithObject:@"detail" forKey:@"type"];
    [GLBDELEGATE checkNetStatus];
    [self.netrequest setDelegate:self];
    [self.netrequest setDidFailSelector:@selector(timeoutFuction)];
    
    [self.netrequest startAsynchronous];
    [json release];
    [item release];
    [self showHUD];
}

//网络失败时候调用。
- (void)timeoutFuction{
    self.netrequest.delegate = nil;
    [self.netrequest cancel];
    [self hideHUD];
}

- (void)requestFinished:(ASIHTTPRequest *)request {
    [HUD hide:YES];
	NSString *responseString = [request responseString];
	SBJsonParser *parser = [SBJsonParser new];
	NSMutableDictionary *results = [parser objectWithString:responseString];
    [parser release];
    
    if(request.userInfo && [[request.userInfo objectForKey:@"type"] isEqualToString:@"detail"] ){
        self.commentArray = [[results objectForKey:@"Result"] objectForKey:@"ListInfo"];
        ZLog(@"array is:%@",self.commentArray);
        
        commentNameLabel.text = [[self.picArray objectAtIndex:curPicIndex] objectForKey:@"UserNickName"];
        contentLabel.text = [[self.picArray objectAtIndex:curPicIndex] objectForKey:@"PhotoTitle"];
        NSString *avatarUrlStr = [[self.picArray objectAtIndex:curPicIndex] objectForKey:@"UserAvatars"];
        [headPicImageView loadImageFromURL:[NSURL URLWithString:avatarUrlStr]];
        NSString *photoUrlStr = [[self.picArray objectAtIndex:curPicIndex] objectForKey:@"PhotoUrl"];
        [bigPicImageView loadImageFromURL:[NSURL URLWithString:photoUrlStr]];
        timeLabel.text = [[self.picArray objectAtIndex:curPicIndex] objectForKey:@"CreateTime"];
        commentNumLabel.text = [NSString stringWithFormat:@"%lu条评论", (unsigned long)self.commentArray.count];
        
        [iCommentTableView reloadData];
    }else if (request.userInfo && [[request.userInfo objectForKey:@"type"] isEqualToString:@"submitPicComment"]){
        ZLog(@"***********%@",results);
//        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:nil message:[[results objectForKey:@"Result"] objectForKey:@"Message"] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
//        alertView.tag = 1001;
//        [alertView show];
//        [alertView release];
        
        [GLBDELEGATE showAlert:[[results objectForKey:@"Result"] objectForKey:@"Message"]];
        
        //更新本地列表
        if([[[results objectForKey:@"Result"] objectForKey:@"Message"] isEqualToString:@"评论成功"]){
            NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
            ZLog(@"%@",GLBDELEGATE.userInfo);
            
            [item setObject:[GLBDELEGATE.userInfo objectForKey:@"user_nickname"] forKey:@"NickName"];
            NSString *datestr;
            NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
            [formatter setTimeZone:[NSTimeZone systemTimeZone]];
            [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            datestr = [formatter stringFromDate:[NSDate date]];
            [formatter release];
            [item setObject:datestr forKey:@"CreateTime"];
            [item setObject:@"" forKey:@"UserAvatars"];
            [item setObject:self.textField.text forKey:@"CommentContent"];
            if(nil == self.commentArray)
                self.commentArray = [NSMutableArray array];
            [self.commentArray addObject:item];
            ZLog(@"%@",self.commentArray);
            [item release];
            commentNumLabel.text = [NSString stringWithFormat:@"%lu条评论", (unsigned long)self.commentArray.count];
            [iCommentTableView reloadData];
        }
        self.textField.text = @"";
        return;
    }
}

//
- (IBAction)doSubmitAction:(id)sender{
    if(![GLBDELEGATE isUserLogin]){
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"您还没有登录,请登录" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        alertView.tag = 1002;
        [alertView show];
        [alertView release];
        return;
    }
    if (self.submitCommentRequest!=nil)
    {
        [self.submitCommentRequest setDelegate:nil];
        [self.submitCommentRequest cancel];
    }
    NSURL *url;
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    [item setObject:@"1" forKey:@"DeviceID"];
    if ([GLBDELEGATE isUserLogin]) {
        [item setObject:[GLBDELEGATE.userInfo objectForKey:@"id"] forKey:@"UserID"];
        [item setObject:[GLBDELEGATE.userInfo objectForKey:@"logintoken"] forKey:@"LoginToken"];
    }
    ZLog(@"%@",[self.picArray objectAtIndex:curPicIndex]);
    [item setObject:[[self.picArray objectAtIndex:curPicIndex] objectForKey:@"PhotoID"] forKey:@"PhotoID"];
    [item setObject:self.textField.text forKey:@"Content"];
    url = [NSURL URLWithString:kSubmitPicComment];
    
   [HUD hide:NO];
    
    SBJsonWriter *json = [[SBJsonWriter alloc] init];
    NSString *jsonString = [json stringWithObject:item];
    ZLog(@"%@",jsonString);
    self.submitCommentRequest= [ASIFormDataRequest requestWithURL:url];
    [self.submitCommentRequest setPostValue:jsonString forKey:@"JsonString"];
    
    self.submitCommentRequest.userInfo = [NSDictionary dictionaryWithObject:@"submitPicComment" forKey:@"type"];
    [GLBDELEGATE checkNetStatus];
    [self.submitCommentRequest setDelegate:self];
    [self.submitCommentRequest setDidFailSelector:@selector(timeoutFuction2)];
    
    [self.submitCommentRequest startAsynchronous];
    [json release];
    [item release];
    [self showHUD];
}

//网络失败时候调用。
- (void)timeoutFuction2{
    self.submitCommentRequest.delegate = nil;
    [self.submitCommentRequest cancel];
    [self hideHUD];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 1002) {
        loginViewControllerGGSH *logInVC = [[loginViewControllerGGSH alloc]init];
        //        logInVC.albumVC = self;
        logInVC.delegate = self;
        UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:logInVC];
        [self presentViewController:navi6 animated:YES completion:nil];
        [logInVC release];
    }else if (alertView.tag == 1001){
        
    }
    
}
@end
