//
//  GYWebViewViewController.m
//  cards
//
//  Created by STAR on 13-1-9.
//  Copyright (c) 2013年 STAR. All rights reserved.
//

#import "GYWebViewViewController.h"
#import "AppDelegate.h"
#import "loginViewControllerGGSH.h"

@interface GYWebViewViewController ()<loginDelegate>

@end

@implementation GYWebViewViewController
@synthesize webview=_webview;


- (void)dealloc{
    self.url = nil;
    [self.webview stopLoading];
    self.webview.delegate = nil;
    self.webview.progressDelegate = nil;
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.webview.backgroundColor = [UIColor clearColor];
    
    //获取生活服务网址
    [self getLifeUrl];
    
//    [self loadurl:self.url];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //友盟统计
    [MobClick beginLogPageView:@"G_LIFE_VIEW"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //友盟统计
    [MobClick endLogPageView:@"G_LIFE_VIEW"];
    
}

- (void)setTetle:(NSString *)title{
    self.title = title;
    if(IS_IOS7)
        self.navigationItem.titleView = [GLBDELEGATE setTitle:self.title];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)loadurl: (NSString*)url{
    chromeBar = [[UIProgressView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.bounds.size.width, 6.0f)];
    [chromeBar setProgress:0.0f animated:YES];
    [self.view addSubview:chromeBar];
    [chromeBar release];
    self.webview.scalesPageToFit = YES;
    [self.webview setUserInteractionEnabled:YES];
    [self.webview setDelegate:self];
    [self.webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
    
}

-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    //huad，加入了js调取客户端方法
    NSString *urlstr = request.URL.absoluteString;
    NSRange range = [urlstr rangeOfString:@"ggshapp://"];
    if (range.length!=0) {
        //若过期
        [webView goBack];

        NSString *method = [urlstr substringFromIndex:(range.location+range.length)];
        SEL selctor = NSSelectorFromString(method);
        [self performSelector:selctor withObject:nil];
    }else{
        

    }
    return YES;
}

//重新登陆的方法
//ggshAPP://reLogin
- (void)reLogin{
    
    loginViewControllerGGSH *loginV = [[loginViewControllerGGSH alloc]init];
    loginV.delegate = self;
    UINavigationController * navi6 = [[UINavigationController alloc] initWithRootViewController:loginV];
    [self presentViewController:navi6 animated:YES completion:nil];
    
}

-(void)finishLogin{
    //登陆成功
    
    //获取生活服务网址
    [self getLifeUrl];
    
}
-(void)cancelLogin{
    //取消登陆
}
-(void)failedLogin{
    //登陆失败
}

//获取生活服务网址
- (void)getLifeUrl{
    //组合参数
    NSMutableDictionary * dic = [[NSMutableDictionary alloc] init];
    [dic setObject:@"LifeService" forKey:@"Mod"];
    [dic setObject:@"home" forKey:@"Act"];
    
    NSMutableDictionary * dicContent = [[NSMutableDictionary alloc] init];
    if ([GLBDELEGATE.userInfo objectForKey:@"logintoken"]) {
        [dicContent setObject:[GLBDELEGATE.userInfo objectForKey:@"logintoken"] forKey:@"logintoken"];
    }else{
        [dicContent setObject:@"" forKey:@"logintoken"];
        
    }
    if ([GLBDELEGATE.userInfo objectForKey:@"phone"]) {
        [dicContent setObject:[GLBDELEGATE.userInfo objectForKey:@"phone"] forKey:@"user_login_name"];
    }
    
    [dicContent setObject:@"1" forKey:@"devicetype"];
    [dicContent setObject:KVERSION forKey:@"version_name"];
    [dic setObject:dicContent forKey:@"Content"];
    
    //转换为NSString
    NSData* result = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonString = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
    
    ZLog(@"jsonString = %@",jsonString);
    NSURL *url = [NSURL URLWithString:kMposAppUrl];
    
    __block ASIFormDataRequest *request= [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:jsonString forKey:@"JsonString"];
    ASIFormDataRequest *_blorequest = request;
    [request setCompletionBlock:^{
        
        NSString *responseString = [_blorequest responseString];
        ZLog(@"*******= %@",responseString);
        NSData *responseData = [responseString dataUsingEncoding:NSUTF8StringEncoding];
        
        NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingAllowFragments error:nil];
        ZLog(@"message is:%@",[resultDic objectForKey:@"Message"]);
        if([[resultDic objectForKey:@"Code"] isEqualToString:@"0000"]){
            //数据赋值
            self.url = [[resultDic objectForKey:@"DetailInfo"] objectForKey:@"url"];
        }else{
            self.url = @"";
        }
        
        //刷新界面
        [self loadurl:self.url];

    }];
    [request setFailedBlock:^{
        
    }];
    [request startAsynchronous];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
}

- (void)webView:(IMTWebView *)_webView didReceiveResourceNumber:(int)resourceNumber totalResources:(int)totalResources {
    //Set progress value
    [chromeBar setProgress:((float)resourceNumber) / ((float)totalResources) animated:YES];
    if (((float)resourceNumber) / ((float)totalResources) == 1) {
        [chromeBar setHidden:YES];
    }
    //Reset resource count after finished
    if (resourceNumber == totalResources) {
        _webView.resourceCount = 0;
        _webView.resourceCompletedCount = 0;
    }
}
@end
